import { VehicleItem, SparePartItem, VehicleReturnClearanceOrder } from '../types';

export const INITIAL_VEHICLES_DATA: VehicleItem[] = [
  {
    id: 'veh-001',
    name: 'طقم قتالي تويوتا شاص هجومي 2024 (مزود بكايلر 12.7mm)',
    category: 'طقم قتالي',
    plateNumber: 'طقم-1042/عسكري',
    engineSerial: 'ENG-TOY-2024-99812',
    status: 'جاهزة',
    readinessPercentage: 98,
    assignedUnit: 'اللواء الأول - كتيبة المهام الخاطفة',
    assignedDriverName: 'المساعد / صلاح العتيبي',
    assignedDriverMilitaryId: '109283',
    fuelLevel: 'ممتاز (ممتلئ)',
    location: 'الموقع القتالي المتقدم - نُقطة الفجر',
    lastMaintenanceDate: '2026-07-28',
    nextMaintenanceDate: '2026-08-28',
    yearOfModel: '2024',
    mileageKm: 14200,
    notes: 'تم فحص القاعدة القتالية، السلاح مثبت وجاهز، حالة المحرك والإطارات ممتازة جداً.',
    maintenanceLogs: [
      {
        id: 'm-101',
        vehicleId: 'veh-001',
        date: '2026-07-28',
        type: 'تغيير زيوت وفلاتر',
        description: 'تغيير زيت المحرك سعة 6 لتر وفلتر الزيت وفلتر الهواء وفحص السوائل.',
        partsReplaced: 'فلتر زيت تويوتا أصلي + فلتر هواء + زيت شل 10W-40',
        workshopOrTechnician: 'المهندس / سالم الحكيمي - ورشة الصيانة الميدانية الأولى',
        cost: 280,
        status: 'مكتملة',
        notes: 'تم أخذ اختبار تسارع بعد التغيير والمحرك بأعلى كفاءة.'
      },
      {
        id: 'm-102',
        vehicleId: 'veh-001',
        date: '2026-06-15',
        type: 'صيانة دورية',
        description: 'فحص نظام التعليق والمساعدات الأمامية والخلفية وتثبيت كرسي السلاح.',
        partsReplaced: 'مساعدات خلفية تويوتا + جلد عكوس',
        workshopOrTechnician: 'الفني / أحمد باصليب - القواعد الفنية المركزية',
        cost: 650,
        status: 'مكتملة',
        notes: 'تم تجهيز الطقم للعمليات الميدانية الشاقة.'
      }
    ]
  },
  {
    id: 'veh-002',
    name: 'تويوتا هايلكس دوبل كابين 2023',
    category: 'هايلكس',
    plateNumber: 'HLX-8821/دورية',
    engineSerial: 'ENG-HLX-2023-44110',
    status: 'منصرف',
    readinessPercentage: 92,
    assignedUnit: 'اللواء الثاني - كتيبة الاستطلاع الدورية',
    assignedDriverName: 'الرقيب / أحمد الشميري',
    assignedDriverMilitaryId: '204918',
    fuelLevel: 'جيد (3/4)',
    location: 'قطاع الدورية الشمالية - مربع 4',
    lastMaintenanceDate: '2026-07-20',
    nextMaintenanceDate: '2026-08-20',
    yearOfModel: '2023',
    mileageKm: 32500,
    notes: 'العربة منصرفة لمهام الدورية الميدانية المستمرة على مدار الساعة.',
    maintenanceLogs: [
      {
        id: 'm-201',
        vehicleId: 'veh-002',
        date: '2026-07-20',
        type: 'تغيير إطارات',
        description: 'استبدال طقم 4 إطارات جبلية مخصصة للتضاريس الوعرة مع الترصيص.',
        partsReplaced: 'طقم 4 إطارات Bridgestone Desert Dueller 265/70R16',
        workshopOrTechnician: 'ورشة الدروع والآليات الثانية - الفني / صادق النهمي',
        cost: 1400,
        status: 'مكتملة',
        notes: 'السيارة جاهزة للقيادة الميدانية الشاقة.'
      }
    ]
  },
  {
    id: 'veh-003',
    name: 'دبابة قتالية ثقيلة T-72 B3',
    category: 'دبابة',
    plateNumber: 'T72-009/دروع',
    engineSerial: 'ENG-V92S2F-90812',
    status: 'جاهزة',
    readinessPercentage: 96,
    assignedUnit: 'كتيبة الدروع والفرسان - قيادة الفرقة',
    assignedDriverName: 'الملازم أول / خالد الجوفي',
    assignedDriverMilitaryId: '301145',
    fuelLevel: 'ممتاز (ممتلئ)',
    location: 'مربض الدروع الرئيسي - القاعدة الشرقية',
    lastMaintenanceDate: '2026-07-10',
    nextMaintenanceDate: '2026-09-10',
    yearOfModel: '2021',
    mileageKm: 840,
    notes: 'تم فحص البرج والملاحة ونظام تلقيم القذائف الآلي ومحرك الديزل 1130 حصان.',
    maintenanceLogs: [
      {
        id: 'm-301',
        vehicleId: 'veh-003',
        date: '2026-07-10',
        type: 'صيانة هيدروليك',
        description: 'صيانة وتغيير خراطيم الهيدروليك الخاصة ببرج الدبابة وتعديل المعايرة البصرية.',
        partsReplaced: 'خراطيم هيدروليك ضغط عالٍ + خابور المعايرة البصرية + زيت هيدروليك تخصصي',
        workshopOrTechnician: 'المهندس العقيد / عبدالكريم طاهر - ورشة الدروع الثقيلة',
        cost: 3200,
        status: 'مكتملة',
        notes: 'تم اختبار دوران البرج وتثبيت الهدف أثناء الحركة وبكفاءة 100%.'
      },
      {
        id: 'm-302',
        vehicleId: 'veh-003',
        date: '2026-05-02',
        type: 'فحص شامل',
        description: 'فحص الجنزير والمحرك والمنظومة الإلكترونية وتفريغ وغسيل خزان الوقود.',
        partsReplaced: 'وصلات جنزير صلبةعدد 6 + فلتر وقود مزدوج',
        workshopOrTechnician: 'فريق صيانة سلاح الدروع',
        cost: 1850,
        status: 'مكتملة',
        notes: 'جاهزية قتالية قصوى.'
      }
    ]
  },
  {
    id: 'veh-004',
    name: 'مدرعة وحش BMR 4x4 هجومية',
    category: 'مدرعة وحش',
    plateNumber: 'MDR-WSH-404',
    engineSerial: 'ENG-CUMMINS-6BTA-7721',
    status: 'جاهزة',
    readinessPercentage: 94,
    assignedUnit: 'اللواء الثالث - كتيبة التدخل السريع',
    assignedDriverName: 'العريف / عمار الزبيدي',
    assignedDriverMilitaryId: '408221',
    fuelLevel: 'جيد (3/4)',
    location: 'كتيبة التدخل السريع - الميدان الرابع',
    lastMaintenanceDate: '2026-07-18',
    nextMaintenanceDate: '2026-08-18',
    yearOfModel: '2023',
    mileageKm: 18900,
    notes: 'مدرعة مصفحة بالكامل ضد العبوات والألغام ومزودة ببرج رماية موجه.',
    maintenanceLogs: [
      {
        id: 'm-401',
        vehicleId: 'veh-004',
        date: '2026-07-18',
        type: 'إصلاح أعطال',
        description: 'إصلاح تسريب بسيط في طلمبة الفرامل وتغيير سائل الفرامل المصفح.',
        partsReplaced: 'طلمبة فرامل هيدروليكية + زيت DOT4 عالي درجة الحرارة',
        workshopOrTechnician: 'الفني / مروان الحطامي - الورشة الفنية',
        cost: 450,
        status: 'مكتملة',
        notes: 'تمت التجربة الميدانية واستجابة الفرامل ممتازة.'
      }
    ]
  },
  {
    id: 'veh-005',
    name: 'مدرعة كاجو ناقلة جند BTR-80',
    category: 'مدرعة كاجو',
    plateNumber: 'KJU-202/نقل-جند',
    engineSerial: 'ENG-KAMAZ-7403-1289',
    status: 'خارج الجاهزية',
    readinessPercentage: 35,
    assignedUnit: 'اللواء الرابع - الورشة الفنية المركزية',
    assignedDriverName: 'الرقيب / علي الحيمي',
    assignedDriverMilitaryId: '501290',
    fuelLevel: 'منخفض (1/4)',
    location: 'ورشة الصيانة المركزية - منصة الإصلاح رقم 3',
    lastMaintenanceDate: '2026-08-02',
    nextMaintenanceDate: '2026-08-15',
    yearOfModel: '2020',
    mileageKm: 48200,
    notes: 'تتطلب تغيير طقم القلاب الهيدروليكي وإصلاح ناقل الحركة (القير) بالكامل.',
    maintenanceLogs: [
      {
        id: 'm-501',
        vehicleId: 'veh-005',
        date: '2026-08-02',
        type: 'صيانة محرك',
        description: 'فك ناقل الحركة الكاماز وفحص التروس المكسورة وإصدار طلب توريد قطع غيار.',
        partsReplaced: 'بانتظار وصول تروس القير وطقم الصوفات السفلية',
        workshopOrTechnician: 'المهندس / جابر الريمي - ورشة الثقيل المركزية',
        cost: 4200,
        status: 'بانتظار قطع الغيار',
        notes: 'الآلية متوقفة حالياً لحين استلام التروس من مخازن قطع الغيار.'
      }
    ]
  },
  {
    id: 'veh-006',
    name: 'طقم تويوتا مصفح ضد الرصاص 2025',
    category: 'طقم مصفح',
    plateNumber: 'MSF-901/احتياط',
    engineSerial: 'ENG-ARM-2025-0012',
    status: 'لم يتم صرفها',
    readinessPercentage: 100,
    assignedUnit: 'مخازن الجاهزية والآليات المركزية',
    assignedDriverName: 'لم يتم التعيين بعد (في المخزن)',
    assignedDriverMilitaryId: '---',
    fuelLevel: 'ممتاز (ممتلئ)',
    location: 'المخزن المركزي للجاهزية - الحوش المغلق',
    lastMaintenanceDate: '2026-08-01',
    nextMaintenanceDate: '2026-11-01',
    yearOfModel: '2025',
    mileageKm: 120,
    notes: 'طقم مصفح جديد بالكامل فئة B6 ضد الرصاص والشظايا، جاهز للصرف والتحريك الفوري.',
    maintenanceLogs: [
      {
        id: 'm-601',
        vehicleId: 'veh-006',
        date: '2026-08-01',
        type: 'فحص شامل',
        description: 'فحص استلام ومطابقة الفحص الفني الأولي وقوة تصفيح الزجاج والبدن.',
        partsReplaced: 'لا يوجد (جديد بالكامل)',
        workshopOrTechnician: 'لجنة الفحص والمطابقة العسكرية',
        cost: 0,
        status: 'مكتملة',
        notes: 'تم الاعتماد بنسبة جاهزية 100% وإدخاله مخزن العهدة.'
      }
    ]
  },
  {
    id: 'veh-007',
    name: 'طقم دورية مدرع ثقيل M-1117 Guardian',
    category: 'طقم مدرع',
    plateNumber: 'MDR-550/حراسة',
    engineSerial: 'ENG-CAT-C7-88912',
    status: 'جاهزة',
    readinessPercentage: 90,
    assignedUnit: 'اللواء الخامس - كتيبة حماية المقرات',
    assignedDriverName: 'الجندي / ناصر السالمي',
    assignedDriverMilitaryId: '603391',
    fuelLevel: 'جيد (3/4)',
    location: 'بوابة الحراسة المركزية - مقرات القيادة',
    lastMaintenanceDate: '2026-07-22',
    nextMaintenanceDate: '2026-08-22',
    yearOfModel: '2022',
    mileageKm: 27800,
    notes: 'طقم دورية مدرع ممتاز مجهز بكاميرات حرارية ومحطة رماة.',
    maintenanceLogs: [
      {
        id: 'm-701',
        vehicleId: 'veh-007',
        date: '2026-07-22',
        type: 'صيانة دورية',
        description: 'صيانة الكاميرا الحرارية وتثبيت الأبواب المصفحة واختبار المولد الكهربائي.',
        partsReplaced: 'سلك توصيل حراري + فيوزات كهربائية ذات جهد عالي',
        workshopOrTechnician: 'فريق صيانة الاتصالات والأنظمة الإلكترونية',
        cost: 310,
        status: 'مكتملة',
        notes: 'المنظومة تعمل بانتظام.'
      }
    ]
  },
  {
    id: 'veh-008',
    name: 'حافلة نقل أفراد هيونداي (30 راكب) 2024',
    category: 'باصات نقل',
    plateNumber: 'BUS-102/نقل-أفراد',
    engineSerial: 'ENG-HYU-BUS-2024-551',
    status: 'منصرف',
    readinessPercentage: 88,
    assignedUnit: 'كتيبة النقل والتموين - الفرقة الثالثة',
    assignedDriverName: 'الرقيب / محمد باوزير',
    assignedDriverMilitaryId: '702118',
    fuelLevel: 'متوسط (1/2)',
    location: 'خط نقل النوبات - بين المعسكرات',
    lastMaintenanceDate: '2026-07-15',
    nextMaintenanceDate: '2026-08-15',
    yearOfModel: '2024',
    mileageKm: 41000,
    notes: 'مخصص لنقل الأفراد والضباط بين الثكنات والميادين بانتظام.',
    maintenanceLogs: [
      {
        id: 'm-801',
        vehicleId: 'veh-008',
        date: '2026-07-15',
        type: 'تغيير زيوت وفلاتر',
        description: 'تغيير سير المروحة وسيور المحرك وتعبئة فريون التكييف.',
        partsReplaced: 'سير محرك أصلي + غاز فريون R134a + فلتر مكيف',
        workshopOrTechnician: 'ورشة النقل الجماعي - الفني / حمزة الحداد',
        cost: 520,
        status: 'مكتملة',
        notes: 'تكييف الباص ممتاز والسيور مشدودة حسب المعايير.'
      }
    ]
  },
  // Equipment Readiness Additions (مولدات، لابتوبات، طابعات، ألواح شمسية، بطاريات، منظومات)
  {
    id: 'eq-001',
    name: 'مولد كهرباء كاتربيلر ديزل 150KVA',
    category: 'مولدات كهرباء',
    plateNumber: 'GEN-CAT-150',
    engineSerial: 'S/N-CAT-992120',
    status: 'جاهزة',
    readinessPercentage: 96,
    assignedUnit: 'قيادة الفرقة - مركز العمليات',
    assignedDriverName: 'الفني / سامي الخولاني',
    assignedDriverMilitaryId: '809112',
    fuelLevel: 'ممتاز (ممتلئ)',
    location: 'مبنى القيادة العامة - المولد الرئيسي',
    lastMaintenanceDate: '2026-07-25',
    nextMaintenanceDate: '2026-08-25',
    yearOfModel: '2023',
    mileageKm: 1420,
    notes: 'مولد طوارئ رئيسي لغرفة العمليات المركزية، خضعت للخدمة مؤخراً.',
    maintenanceLogs: [
      {
        id: 'm-901',
        vehicleId: 'eq-001',
        date: '2026-07-25',
        type: 'صيانة دورية',
        description: 'تغيير زيوت وفلاتر المولد وتفقد شمعات الاحتراق والمبرد.',
        partsReplaced: 'طقم فلاتر كاتربيلر + زيت ديزل ثقيل',
        workshopOrTechnician: 'فني المولدات والطاقة الميدانية',
        cost: 380,
        status: 'مكتملة',
        notes: 'جاهزية الطاقة ممتازة.'
      }
    ]
  },
  {
    id: 'eq-002',
    name: 'حاسوب لابتوب تكتيكي مضاد للصدمات Dell Latitude Rugged',
    category: 'أجهزة لابتوب وكمبيوتر',
    plateNumber: 'LAP-TAC-04',
    engineSerial: 'SN-DELL-RUGGED-8812',
    status: 'منصرف',
    readinessPercentage: 98,
    assignedUnit: 'قسم الاستخبارات والعمليات الرقمية',
    assignedDriverName: 'الملازم / وليد المعمري',
    assignedDriverMilitaryId: '901233',
    fuelLevel: 'طاقة شمسية/كهرباء',
    location: 'غرفة تحليل البيانات الميدانية',
    lastMaintenanceDate: '2026-08-01',
    nextMaintenanceDate: '2026-11-01',
    yearOfModel: '2024',
    notes: 'حاسوب تكتيكي مشفر مزود ببرامج الخرائط العسكرية ونقل البيانات الميدانية.',
    maintenanceLogs: []
  },
  {
    id: 'eq-003',
    name: 'طابعة وثائق وخرائط ملونة ثقيلة HP Color LaserJet Enterprise',
    category: 'طابعات وتجهيزات مكتبية',
    plateNumber: 'PRN-ENT-12',
    engineSerial: 'SN-HP-991200',
    status: 'جاهزة',
    readinessPercentage: 92,
    assignedUnit: 'إدارة السكرتارية والتوثيق',
    assignedDriverName: 'الرقيب / باسم المحضار',
    assignedDriverMilitaryId: '102931',
    fuelLevel: 'غير مطبق',
    location: 'مكتب إصدار الأوامر والقرارات',
    lastMaintenanceDate: '2026-07-20',
    nextMaintenanceDate: '2026-09-20',
    yearOfModel: '2023',
    notes: 'طابعة خرائط وأوامر عملياتية سريعة بحالة ممتازة.',
    maintenanceLogs: []
  },
  {
    id: 'eq-004',
    name: 'منظومة ألواح شمسية مصفوفة 12KW للموقع القتالي',
    category: 'ألواح شمسية',
    plateNumber: 'SOL-SYS-12K',
    engineSerial: 'INV-3PHASE-12000W',
    status: 'جاهزة',
    readinessPercentage: 95,
    assignedUnit: 'اللواء الأول - النقطة المتقدمة',
    assignedDriverName: 'المساعد / مبارك الجابري',
    assignedDriverMilitaryId: '201944',
    fuelLevel: 'طاقة شمسية/كهرباء',
    location: 'الموقع المتقدم - جبل الفجر',
    lastMaintenanceDate: '2026-07-30',
    nextMaintenanceDate: '2026-10-30',
    yearOfModel: '2024',
    notes: 'منظومة طاقة شمسية مستقلة لتشغيل أجهزة الرصد والإنارة الميدانية.',
    maintenanceLogs: []
  },
  {
    id: 'eq-005',
    name: 'بنك بطاريات طاقة عميقة التفريغ Gel 200Ah (طقم 16 بطارية)',
    category: 'بطاريات ومخزنات',
    plateNumber: 'BAT-BANK-16',
    engineSerial: 'SN-GEL-200AH-SET',
    status: 'تحت الصيانة',
    readinessPercentage: 65,
    assignedUnit: 'ورشة الاتصالات والطاقة الميدانية',
    assignedDriverName: 'الفني / فهد الشاوش',
    assignedDriverMilitaryId: '304912',
    fuelLevel: 'طاقة شمسية/كهرباء',
    location: 'ورشة الصيانة الكهربائية',
    lastMaintenanceDate: '2026-08-03',
    nextMaintenanceDate: '2026-08-18',
    yearOfModel: '2023',
    notes: 'يتطلب موازنة خلايا واختبار قدرة التفريغ المستمر.',
    maintenanceLogs: [
      {
        id: 'm-902',
        vehicleId: 'eq-005',
        date: '2026-08-03',
        type: 'صيانة إلكترونية وطاقة',
        description: 'استبدال حبتين بطارية تالفة وإعادة ضبط منظم الشحن الانفرتر.',
        partsReplaced: '2 بطارية جل Ritar 200Ah',
        workshopOrTechnician: 'ورشة الطاقة الكهروميكانيكية',
        cost: 420,
        status: 'قيد التنفيذ',
        notes: 'في انتظار اكتمال الشحن والتفريغ والتجربة.'
      }
    ]
  },
  {
    id: 'eq-006',
    name: 'منظومة اتصالات ومشفر تكتيكي HARRIS Falcon III',
    category: 'منظومات واتصالات',
    plateNumber: 'COM-HRS-909',
    engineSerial: 'SN-HARRIS-FALCON-7712',
    status: 'جاهزة',
    readinessPercentage: 99,
    assignedUnit: 'كتيبة الإشارة والاتصالات المركزية',
    assignedDriverName: 'النقيب / طاهر الذبحاني',
    assignedDriverMilitaryId: '401928',
    fuelLevel: 'طاقة شمسية/كهرباء',
    location: 'مركز الإشارة الرئيسي',
    lastMaintenanceDate: '2026-08-02',
    nextMaintenanceDate: '2026-11-02',
    yearOfModel: '2024',
    notes: 'منظومة اتصال مؤمنة ومفرزة للاتصالات المشفرة عالية التردد.',
    maintenanceLogs: []
  }
];

export const INITIAL_SPARE_PARTS_DATA: SparePartItem[] = [
  {
    id: 'sp-001',
    code: 'SP-TOY-OIL',
    name: 'فلتر زيت تويوتا شاص / هايلكس أصلي (فئة A)',
    category: 'زيوت وفلاتر',
    compatibleModels: 'طقم تويوتا / هايلكس 2020-2025',
    quantity: 45,
    minThreshold: 10,
    unitPrice: 35,
    location: 'المخزن الرئيسي - رف A1',
    unitOfMeasure: 'قطعة',
    notes: 'وارد اليابان الأصلي بدفعات جديدة.',
    lastRestockedDate: '2026-07-20'
  },
  {
    id: 'sp-002',
    code: 'SP-TIRE-265',
    name: 'طقم إطارات جبلية Bridgestone Desert Dueller 265/70R16',
    category: 'إطارات وبنشرات',
    compatibleModels: 'أطقم قتالية / هايلكس / مدرعات خفيفة',
    quantity: 18,
    minThreshold: 8,
    unitPrice: 320,
    location: 'ساحة الإطارات - جناح 3',
    unitOfMeasure: 'إطار',
    notes: 'مخصصة للتضاريس الوعرة والصخرية.',
    lastRestockedDate: '2026-07-15'
  },
  {
    id: 'sp-003',
    code: 'SP-GEN-FILT',
    name: 'طقم فلاتر ديزل وزيت لمولدات كاتربيلر 150KVA',
    category: 'مولدات وطاقة',
    compatibleModels: 'مولدات كاتربيلر / بيركنز',
    quantity: 12,
    minThreshold: 4,
    unitPrice: 120,
    location: 'مخزن الطاقة - رف C2',
    unitOfMeasure: 'طقم',
    notes: 'يشمل فلتر الوقود المزدوج وفلتر الزيت وفلتر الهواء.',
    lastRestockedDate: '2026-07-28'
  },
  {
    id: 'sp-004',
    code: 'SP-BAT-200AH',
    name: 'بطارية جل عميقة التفريغ Ritar 200Ah / 12V',
    category: 'كهرباء وبطاريات',
    compatibleModels: 'منظومات الطاقة الشمسية / المولدات / الآليات الثقيلة',
    quantity: 8,
    minThreshold: 5,
    unitPrice: 210,
    location: 'مخزن بطاريات الطاقة',
    unitOfMeasure: 'حبة',
    notes: 'بطاريات جافة مخصصة للمناخ الصحراوي.',
    lastRestockedDate: '2026-08-01'
  },
  {
    id: 'sp-005',
    code: 'SP-SOLAR-PANEL',
    name: 'لوح طاقة شمسية مونو كريستال 550 Watt',
    category: 'ألواح وانفرترات',
    compatibleModels: 'منظومات الطاقة الشمسية والمواقع المتقدمة',
    quantity: 14,
    minThreshold: 6,
    unitPrice: 130,
    location: 'مخزن الألواح والانفرترات - رف S1',
    unitOfMeasure: 'لوح',
    notes: 'كفاءة عالية خالية من العيوب.',
    lastRestockedDate: '2026-07-25'
  },
  {
    id: 'sp-006',
    code: 'SP-HP-TONER',
    name: 'تونر حبر طابعة HP Enterprise أسود (High Yield)',
    category: 'أجهزة وطابعات',
    compatibleModels: 'طابعات HP Enterprise LaserJet',
    quantity: 9,
    minThreshold: 3,
    unitPrice: 85,
    location: 'مخزن التجهيزات المكتبية',
    unitOfMeasure: 'علبة',
    notes: 'يكفي لطباعة 10,000 صفحة رسمية.',
    lastRestockedDate: '2026-08-02'
  }
];

export const INITIAL_VEHICLE_DISPENSE_ORDERS: any[] = [
  {
    id: 'vdisp-001',
    orderNumber: 'ORD-9082/عربات',
    orderDate: '2026-07-25',
    itemType: 'آلية عسكرية',
    itemId: 'veh-002',
    itemName: 'تويوتا هايلكس دوبل كابين 2023',
    itemCategory: 'هايلكس',
    itemSerialOrPlate: 'HLX-8821/دورية',
    engineOrChassisSerial: 'ENG-HLX-2023-44110',
    itemCondition: 'جاهزة ومتاحة',
    quantity: 1,

    // Recipient
    recipientName: 'الرقيب / أحمد الشميري',
    recipientMilitaryId: '204918',
    recipientRank: 'رقيب',
    recipientUnit: 'اللواء الثاني - كتيبة الاستطلاع الدورية',
    recipientBattalion: 'كتيبة الاستطلاع الدورية',
    recipientJobTitle: 'قائد دورية استطلاع',
    recipientPhone: '771234567',
    recipientNationalId: '1092837461',

    // Guarantor
    guarantorName: 'المساعد أول / عبد الله المقطري',
    guarantorMilitaryId: '108821',
    guarantorRank: 'مساعد أول',
    guarantorUnit: 'قيادة كتيبة الاستطلاع',
    guarantorPhone: '779876543',
    guarantorNationalId: '1088271625',

    // Order Details
    dispenseReason: 'صرف عهدة آلية لمهمة الدورية والمسح الميداني في القطاع الشمالي للواء',
    orderSource: 'قرار قيادة اللواء الثاني برقم (408/أ)',
    locationOrDestination: 'قطاع الدورية الشمالية - مربع 4',
    notes: 'تُسلم الآلية بكامل ملحقاتها وإطارات الجبال مع التعهد بالصيانة الدورية الحافظة.',
    timestamp: '2026-07-25 09:30'
  },
  {
    id: 'vdisp-002',
    orderNumber: 'ORD-9104/معدات',
    orderDate: '2026-08-05',
    itemType: 'أجهزة ومعدات أخرى',
    itemName: 'مولد كهربائي كاتربيلر صامت 50KVA',
    itemCategory: 'مولدات كهرباء',
    itemSerialOrPlate: 'GEN-CAT-50KVA-9901',
    engineOrChassisSerial: 'SN-CAT-2024-88712',
    itemCondition: 'جديدة بالمخزن',
    quantity: 1,

    // Recipient
    recipientName: 'الملازم أول / فهد الكندي',
    recipientMilitaryId: '304912',
    recipientRank: 'ملازم أول',
    recipientUnit: 'اللواء الأول - غرفة الاتصالات المركزية',
    recipientBattalion: 'كتيبة الإشارة والاتصالات',
    recipientJobTitle: 'ضابط الاتصالات والتشغيل',
    recipientPhone: '773322110',
    recipientNationalId: '1029384756',

    // Guarantor
    guarantorName: 'النقيب / طارق العولقي',
    guarantorMilitaryId: '209381',
    guarantorRank: 'نقيب',
    guarantorUnit: 'ركن الإشارة والاتصالات',
    guarantorPhone: '775544332',
    guarantorNationalId: '1054329876',

    // Order Details
    dispenseReason: 'تأمين التغذية الكهربائية الاحتياطية لغرفة منظومات الاتصالات الميدانية',
    orderSource: 'توجيهات غرفة العمليات المشتركة رقم (881/ت)',
    locationOrDestination: 'غرفة العمليات المركزية - التبة الحمراء',
    notes: 'تم فحص المولد مع اللوحة والبطاريات، والتسليم بحالة جيدة جداً.',
    timestamp: '2026-08-05 14:15'
  }
];

export const INITIAL_VEHICLE_RETURN_ORDERS: VehicleReturnClearanceOrder[] = [
  {
    id: 'vret-001',
    returnNumber: 'RET-8041/فنية-مركزية',
    returnDate: '2026-08-18',
    returnTime: '11:30',
    vehicleId: 'veh-003',
    vehicleName: 'طقم مصفح شاص قتالي 2022',
    vehicleCategory: 'طقم مصفح',
    plateNumber: 'مصفح-7719/عمليات',
    engineSerial: 'ENG-ARM-2022-33109',
    yearOfModel: '2022',
    mileageKmAtReturn: 48500,
    fuelLevelAtReturn: 'متوسط (1/2)',

    // Handover Person (المسلّم ومخلِي العهدة)
    handoverPersonName: 'المساعد أول / منصور اليافعي',
    handoverPersonMilitaryId: '107442',
    handoverPersonRank: 'مساعد أول',
    handoverPersonUnit: 'اللواء الأول - كتيبة التدخل السريع',
    handoverPersonBattalion: 'كتيبة التدخل السريع',
    handoverPersonPhone: '778899001',
    handoverPersonNationalId: '1029384711',

    // Receiving Branch & Officers (المستلم في فرع الفنية والحركة المركزي)
    recipientBranch: 'فرع الفنية والحركة المركزي الرئيسي',
    receivingOfficerName: 'الرائد / خالد بن عبد العزيز السالم',
    receivingOfficerRank: 'رائد',
    receivingOfficerMilitaryId: '401928',
    receivingTechnicianName: 'المهندس الفني / بدر الحارثي',
    headOfBranchApproval: 'مدير فرع الفنية والحركة المركزي - العميد ركن / مسعد القحطاني',

    // Context & Reason
    returnReason: 'انتهاء المهمة الميدانية وحاجة الطقم المصفح لعملية صيانة كبرى وتجديد نظام التبريد ونظام الهيدروليك',
    returnAuthority: 'برقية عمليات قيادة اللواء رقم (1042/ع) وتوجيهات ركن الفنية والحركة',

    // Condition at Handover (حالة العربة وقت تسليمها إلى فرع الفنية والحركة الرئيسي)
    conditionAtHandover: 'معطلة بحاجة لإصلاح',
    handoverConditionNotes: 'تم فحص الآلية وقت الاستلام في فرع الفنية والحركة الرئيسي: المحرك يعمل ولكن مع وجود تسريب زيت خفيف في صوفة الكرنك، تهريب في رديتر الماء، الدبل ونظام الدفع الرباعي سليم، البودي الخارجي والدروع بحالة جيدة مع وجود خدوش في الصدام الأمامي. الإطارات مستهلكة بنسبة 45%. تحتاج إلى استبدال رديتر وفحص نظام الفرامل الخلفية وتصفية البخاخات.',
    technicalDefects: 'تسريب صوفة كرنك أمامية، تهريب في رديتر التبريد، بطارية ضعيفة تحتاج شحن/استبدال، الإطار الخلفي الأيمن يحتاج بنشر.',

    // Checklist
    accessoriesChecklist: {
      spareTire: true,
      jackAndTools: true,
      radioComms: true,
      fireExtinguisher: true,
      keysHandedOver: true,
      registrationDocs: true,
      otherEquipment: 'قاعدة السلاح البرمائي + ونش سحب أمريكي أصلي مثبت'
    },

    clearanceStatus: 'تم إخلاء العهدة بالكامل',
    notes: 'تمت مطابقة أرقام الشاسي والمحرك، واستلام الآلية رسمياً وإدخالها حوش الورشة المركزية تمهيداً للصيانة.',
    timestamp: '2026-08-18 11:30'
  }
];


