import type {
  ArmoryWeaponPiece,
  ArmoryInventoryItem,
  ArmoryIntakeRecord,
  ArmoryIssueOrder,
  WeaponLifecycleEvent,
  WeaponTypeConfig,
  AmmoTypeConfig
} from './data/armamentData';

export type MilitaryRank =
  | 'فريق أول'
  | 'فريق'
  | 'لواء'
  | 'عميد'
  | 'عقيد'
  | 'مقدم'
  | 'رائد'
  | 'نقيب'
  | 'ملازم أول'
  | 'ملازم'
  | 'رئيس رقباء'
  | 'رقيب أول'
  | 'رقيب'
  | 'وكيل رقيب'
  | 'عريف'
  | 'جندي أول'
  | 'جندي';

export type PersonnelStatus =
  | 'على رأس العمل'
  | 'مكلف بمهمة'
  | 'مجاز'
  | 'غائب'
  | 'فار'
  | 'منوم بالمستشفى'
  | 'موقوف'
  | 'منقول'
  | 'متقاعد'
  | 'متواجد'
  | 'في الميدان'
  | 'إجازة'
  | 'إذن'
  | 'مستشفى'
  | 'غياب'
  | 'فرار'
  | 'فرار بالسلاح'
  | 'مأمورية'
  | 'مفقود'
  | 'احتياط'
  | 'منتدب'
  | 'اسير'
  | 'شهيد'
  | 'معاق'
  | 'جريح'
  | 'دورة تدريبية داخلية'
  | 'دورة تدريبية خارجية';

export type DepartmentRole =
  | 'القيادة الرئيسية'
  | 'إدارة الموارد البشرية'
  | 'إدارة القوة البشرية'
  | 'إدارة التسليح'
  | 'إدارة التدريب'
  | 'الإدارة المالية'
  | 'الاستخبارات والأمن'
  | 'الإدارة الطبية العسكرية'
  | 'الإدارة الفنية'
  | 'إدارة التموين والإمداد'
  | 'جاهزية العربات والآليات';

export interface MovementLog {
  id: string;
  date: string;
  type:
    | 'نقل'
    | 'إلحاق'
    | 'تكليف'
    | 'انتداب'
    | 'مأمورية'
    | 'أمر إداري'
    | 'ترقية'
    | 'تعديل وظيفة ورتبة'
    | 'استبدال عسكري'
    | 'صرف عهدة آلية/معدة'
    | 'تقييد كفالة وضمانة عهدة'
    | string;
  details?: string;
  reason?: string;
  fromUnit?: string;
  toUnit?: string;
  issuingAuthority?: string;
  orderReference?: string;
  effectiveDate?: string;
  notes?: string;
}

export interface AttendanceLog {
  id: string;
  date: string;
  type:
    | 'حضور'
    | 'غياب'
    | 'إجازة'
    | 'إذن'
    | 'فرار'
    | 'احتجاز'
    | 'انتداب'
    | 'عودة للخدمة'
    | PersonnelStatus
    | string;
  reason: string;
  durationDays: number;
  approvedBy: string;
  startDate: string;
  endDate?: string;
  leaveType?: string;
  permissionType?: string;
  notes?: string;
  statusPeriodState?: 'completed' | 'active';
  faceVerified?: boolean;
  faceVerificationSnapshot?: string;
  faceVerificationConfidence?: number;
  faceVerifiedAt?: string;
  withWeapon?: boolean;
  weaponDetails?: {
    primaryWeapon?: {
      weaponType: string;
      weaponSerial: string;
      magazinesCount: number;
      ammoCount: number;
      notes?: string;
    };
    additionalWeapons?: Array<{
      weaponType: string;
      weaponSerial: string;
      magazinesCount: number;
      ammoCount: number;
      notes?: string;
    }>;
    custodyNotes?: string;
    totalAmmo?: number;
    totalMagazines?: number;
  };
}

export interface DispensedMedication {
  id: string;
  name: string;
  dose: string;
  dateDispensed: string;
  prescribedBy: string;
}

export interface MedicalLog {
  id: string;
  date: string;
  diagnosis: string;
  hospital: string;
  doctor: string;
  injuryDetails?: string;
  surgicalOperations?: string;
  sickLeaveDays: number;
  medications: DispensedMedication[];
  prescriptionDetails?: string; // تفاصيل الوصفات العلاجية
  recoveryStartDate?: string; // تاريخ بداية التعافي
  recoveryEndDate?: string; // تاريخ انتهاء التعافي
  isReturnToDuty?: boolean; // عودة علاجية للخدمة
  recommendations?: string;
  notes?: string;
}

export interface FinancialLog {
  id: string;
  date: string;
  type: 'راتب' | 'بدل' | 'مكافأة' | 'حافز' | 'استقطاع' | 'سلفة' | 'تعويض' | 'مساعدة مالية' | 'سلفة مالية' | string;
  amount: number;
  reason: string;
  transactionDate: string;
  approvedBy?: string;
  notes?: string;
  voucherNumber?: string;
  monthYear?: string;
  isDeductedFromSalary?: boolean;
  grantType?: 'سلفة مالية' | 'مساعدة مالية';
}

export interface SecurityLog {
  id: string;
  date: string;
  violation: string;
  investigationDetails: string;
  penalty: string;
  warningLevel: 'منخفض' | 'متوسط' | 'شديد الخطورة' | 'عالي' | 'حرج';
  detentionOrder?: string;
  authority: string;
  status: 'قيد التحقيق' | 'تم البت' | 'محال للقضاء العسكري' | 'مغلق' | 'محال للنيابة العسكرية' | 'منتهي';
}

export interface AmmoAction {
  id: string;
  type: 'صرف' | 'استرجاع';
  quantity: number;
  date: string;
  reason: string;
  issuedBy: string;
}

export interface ArmamentLog {
  id: string;
  weaponSerial: string;
  weaponType: string;
  issueDate: string;
  returnDate?: string;
  status?: 'بحوزته' | 'مورد' | 'في المخزن' | 'في الصيانة'; // حالة السلاح: بحوزته أو مورد في التسليح
  turnInReceiptNumber?: string; // رقم سند التوريد إن وجد
  turnInOfficer?: string; // اسم ضابط التسليح المستلم عند التوريد
  turnInDate?: string; // تاريخ التوريد
  turnInTime?: string; // وقت التوريد
  reissueDate?: string; // تاريخ إعادة الصرف من المخازن
  reissueTime?: string; // وقت إعادة الصرف
  reissueOfficer?: string; // ضابط التسليح الذي قام بإعادة صرف السلاح
  reissueReceiptNumber?: string; // رقم سند إعادة الصرف
  reissueProcedures?: string; // الإجراءات المتخذة (صرف السلاح فقط، مخازن إضافية، ذخيرة إضافية، عهدة كاملة، إلخ)
  ammoQty: number;
  firelinesCount: number; // عدد خطوط النار / الخزائن
  ammoHistory: AmmoAction[];
  condition: 'ممتازة' | 'جيدة' | 'تحتاج صيانة' | 'معطوبة';
  technicalNotes: string;
}

export interface TrainingLog {
  id: string;
  courseName: string;
  courseType: 'ميداني' | 'قيادي' | 'تقني' | 'أمني' | 'تخصصي' | 'خارجي';
  provider: string;
  startDate: string;
  endDate: string;
  durationWeeks: number;
  grade: 'ممتاز' | 'جيد جداً' | 'جيد' | 'مقبول' | 'مؤهل';
  evaluation: string;
  certificates: string;
  supervisorOfficer?: string; // الضابط المشرف على الدورة
  trainingLocation?: string; // مقر/مكان الدورة
  status?: 'قائمة' | 'مكتملة' | 'مستقبلية' | 'قيد التنفيذ' | 'مستمر';
  notes?: string;
}

export interface PersonnelAttachment {
  id: string;
  title: string;
  category: 'قرار إداري' | 'تقرير' | 'شهادة' | 'مستند شخصي' | 'وثيقة أمنية' | 'صورة/فيديو';
  fileType: 'pdf' | 'image' | 'video' | 'doc';
  uploadDate: string;
  fileSize: string;
  fileUrl?: string;
  url?: string;
  uploadedBy?: string;
  notes?: string;
}

export interface SupplyLog {
  id: string;
  itemType:
    | 'بدلة عسكرية'
    | 'بسطار/حذاء'
    | 'خوذة/دروع'
    | 'معدات ميدانية'
    | 'مؤن/تجهيزات'
    | 'مهمات أخرى'
    | 'آلية عسكرية'
    | 'أجهزة ومعدات أخرى'
    | string;
  itemName: string;
  quantity: number;
  issueDate: string;
  returnDate?: string;
  condition: 'جديد' | 'مستعمل ممتازة' | 'مستعمل جيدة' | 'مستهلك' | string;
  issuedBy: string;
  serialNumber?: string;
  notes?: string;
}

export interface PersonnelRecord {
  id?: string; // معرف اختياري للتوافق مع شاشات الطباعة والتقارير
  militaryId: string; // الرقم الوظيفي - Unique ID
  nationalId: string; // الرقم الوطني
  fullName: string; // الاسم الرباعي
  rank: MilitaryRank; // الرتبة
  dob: string; // تاريخ الميلاد
  pob: string; // مكان الميلاد
  maritalStatus: 'أعزب' | 'متزوج' | 'مطلق' | 'أرمل'; // الحالة الاجتماعية
  education: string; // المؤهل العلمي
  specialization: string; // التخصص
  bloodType: 'A+' | 'A-' | 'B+' | 'B-' | 'AB+' | 'AB-' | 'O+' | 'O-';
  phone: string;
  motherName?: string; // اسم الأم
  guarantorName?: string; // اسم الضمين
  relativeName?: string; // اسم أقرب الأقارب
  relativePhone?: string; // رقم هاتف القريب
  photoUrl: string;
  biometricsRecorded: boolean; // حالة البصمة
  unit: string; // الوحدة
  battalion: string; // الكتيبة
  company: string; // السرية
  platoon: string; // الفصيل
  jobTitle: string; // الوظيفه
  enlistmentDate: string; // تاريخ الالتحاق
  currentStatus: PersonnelStatus; // الحالة الحالية
  status?: PersonnelStatus; // حقل رديف للتوافق
  secondedUnit?: string; // الوحدة المنتدب لديها
  trainingCourseType?: string; // نوع ومسمى الدورة التدريبية (للدورات التدريبية الداخلية والخارجية)
  missionDestination?: string; // موقع ومقر أو جهة المأمورية الميدانية
  missionStartDate?: string; // تاريخ بدء المأمورية
  missionEndDate?: string; // تاريخ انتهاء المأمورية
  leaveStartDate?: string; // تاريخ بدء الإجازة أو الإذن
  leaveEndDate?: string; // تاريخ انتهاء الإجازة أو الإذن
  leaveType?: string; // نوع الإجازة أو الإذن (اعتيادي، سنوي، مرضي، ساعي، رسمي...)
  lastStatusChangeDate?: string; // تاريخ آخر تغيير للحالة (لتقييد الأيام بسجل الانضباط والتمام)
  absenceStreakStartDate?: string; // تاريخ بدء سلسلة الغياب أو الفرار المتواصلة لاحتساب الاستقطاع المالي اليومي
  createdByAccountId?: string; // معرف الحساب الذي قام بإدخال أو إنشاء الفرد (مثل 'hq', 'brigade1')
  faceVerificationSnapshot?: string; // لقطة المطابقة الرقمية
  attachments?: PersonnelAttachment[]; // المرفقات المستندية
  combatReadiness?: string; // نسبة الجاهزية القتالية
  medicalFitness?: string; // اللياقة الطبية
  assignedWeapon?: string; // السلاح المسند
  armament?: any; // للتوافق مع تقارير التسليح
  armamentLogs?: ArmamentLog[]; // للتوافق مع نماذج الأذونات
  
  logs: {
    movement: MovementLog[];
    attendance: AttendanceLog[];
    medical: MedicalLog[];
    financial: FinancialLog[];
    security: SecurityLog[];
    armament: ArmamentLog[];
    training: TrainingLog[];
    attachments: PersonnelAttachment[];
    supply?: SupplyLog[];
  };
}

export interface AuditLogEntry {
  id: string;
  timestamp: string;
  userName: string;
  department: DepartmentRole;
  accountId?: string; // معرف الحساب / اللواء
  accountName?: string; // اسم الحساب / اللواء
  action: string;
  targetMilitaryId: string;
  targetName: string;
  details: string;
  faceVerified?: boolean;
  faceConfidence?: number;
}

export interface DuplicateAlertDetails {
  militaryId: string;
  nationalId: string;
  fullName: string;
  rank: string;
  originalAccount: string;
  originalUnit: string;
  attemptedAccount: string;
  attemptedUnit: string;
  attemptedUser: string;
  timestamp: string;
}

export interface SystemAlert {
  id: string;
  title: string;
  description: string;
  level: 'urgent' | 'warning' | 'info';
  date: string;
  militaryId?: string;
  createdByAccountId?: string;
  isDuplicateAlert?: boolean;
  duplicateDetails?: DuplicateAlertDetails;
}

export type BrigadeAccountType =
  | 'hq'
  | 'brigade1'
  | 'brigade2'
  | 'brigade3'
  | 'brigade4'
  | 'brigade5'
  | 'brigade6'
  | 'brigade7'
  | 'brigade8'
  | 'vehicles_readiness';

export interface DeviceSessionInfo {
  deviceId: string;
  deviceType: 'mobile' | 'desktop';
  deviceTypeName: string;
  lastPing: number;
}

export interface AccessTimeRestriction {
  enabled: boolean;
  startTime: string; // "08:00"
  endTime: string;   // "17:00"
  allowedDays?: string[]; // ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday']
  denyOutsideHoursMessage?: string;
}

export interface TwoFactorAuthConfig {
  enabled: boolean;
  requireOnUnknownDevice: boolean;
  verificationPin?: string; // 6-digit pin code
  phoneOrEmail?: string;
  trustedDevices?: string[]; // Array of trusted device signatures
}

export interface AccountSecuritySettings {
  accessHours?: AccessTimeRestriction;
  twoFactor?: TwoFactorAuthConfig;
  lastSecurityAudit?: string;
}

export interface TenantUserPermission {
  role: DepartmentRole; // Department or role title
  canAdd: boolean;
  canEdit: boolean;
  canDelete: boolean;
  canExport: boolean;
  modules: {
    personnel: boolean;
    armament: boolean;
    medical: boolean;
    security: boolean;
    reports: boolean;
    audit: boolean;
    accounts: boolean;
  };
}

export interface TenantUserAccount {
  id: string;
  tenantId: string;
  username: string;
  password?: string;
  fullName: string;
  rank?: string;
  email?: string;
  phone?: string;
  isSuperAdmin: boolean;
  roleTitle: string;
  status: 'نشط' | 'موقوف' | 'محظور';
  permissions: TenantUserPermission;
  createdAt: string;
  lastLogin?: string;
}

export interface OrganizationTenant {
  id: string; // Tenant ID e.g. 'tenant-hq-main', 'tenant-brigade-1'
  name: string; // e.g. 'المؤسسة العسكرية المركزية - الفرقة الثالثة'
  code: string; // e.g. 'ORG-HQ'
  category: 'عسكري' | 'أمني' | 'حكومي' | 'طبي' | 'إداري';
  badge: string; // Icon/Emblem string
  description: string;
  accessKey?: string; // Optional secret key for tenant entrance
  status: 'نشط' | 'موقوف' | 'تحت الصيانة';
  createdAt: string;
  isDefaultMain?: boolean;
  unitFilter?: string;
  contactEmail?: string;
  contactPhone?: string;
  superAdminUsername?: string;
  superAdminName?: string;
  superAdminEmail?: string;
}

export interface UserAccount {
  id: BrigadeAccountType;
  name: string;
  shortCode: string;
  description: string;
  isMainCommand: boolean;
  unitFilter: string;
  color: string;
  badge: string;
  status: 'نشط' | 'غير نشط' | 'محظور';
  isBlocked?: boolean;
  blockedReason?: string;
  blockedAt?: string;
  customAccessKey?: string;
  lastSeen: string;
  connectedDevicesCount: number;
  boundDeviceId?: string;
  boundDeviceName?: string;
  boundAt?: string;
  devicesBreakdown?: {
    mobileCount: number;
    desktopCount: number;
    lastDeviceType?: string;
  };
  activeSessions?: DeviceSessionInfo[];
  securitySettings?: AccountSecuritySettings;
}


export interface SearchFilterState {
  searchTerm: string;
  rank?: string;
  unit?: string;
  battalion?: string;
  company?: string;
  status?: PersonnelStatus | 'الكل';
  weaponSearch?: string;
  hasViolationsOnly?: boolean;
}

export interface RecycledPersonnel {
  id: string;
  personnel: PersonnelRecord;
  deletedAt: string; // ISO string e.g. 2026-07-27T13:00:00.000Z
  deletedBy: string;
  reason?: string;
}

export interface PersonnelReplacementRecord {
  id: string;
  replacementSerial: string; // e.g. REP-2026-0042
  replacementDate: string; // YYYY-MM-DD
  createdByAccountId?: string;
  
  // Replaced Absent/Deserter Soldier (الفرد الأصلي المتغيب/الفرار)
  replacedMilitaryId: string;
  replacedFullName: string;
  replacedRank: MilitaryRank;
  replacedUnit: string;
  replacedBattalion: string;
  replacedCompany: string;
  replacedJobTitle: string;
  replacedStatus: PersonnelStatus; // e.g. فرار or غياب
  absenceStartDate?: string;

  // New Replacement Soldier (الفرد البديل الجديد)
  newMilitaryId: string;
  newNationalId: string;
  newFullName: string;
  newRank: MilitaryRank;
  newUnit: string;
  newBattalion: string;
  newCompany: string;
  newPlatoon: string;
  newJobTitle: string;
  newPhone: string;
  newEnlistmentDate: string;

  // Administrative Authority & Orders (الجهة الآمرة وأمر الاستبدال)
  orderNumber: string; // e.g. أمر قيادة اللواء رقم 4091/ب
  orderDate: string;
  issuingAuthority: string; // e.g. قيادة القوات المسلحة - شعبة إدارة التنظيم والضباط
  reason: string; // e.g. استبدال كادر بشرى بديل عن فرد متغيب/فرار لاستكمال الجاهزية القتالية
  notes?: string;

  // Signatures / Approvals
  responsibleOfficer: string;
  hrBranchChief: string;
  commandApproval: string;
}

export interface VehicleDispenseOrder {
  id: string; // e.g. VOUCH-DISP-2026-001
  orderNumber: string; // رقم أمر الصرف e.g. ORD-9082/آ
  orderDate: string; // YYYY-MM-DD
  itemType: 'آلية عسكرية' | 'أجهزة ومعدات أخرى';
  itemId?: string; // ID of VehicleItem if selected from inventory
  itemName: string; // اسم الآلية أو الجهاز المصروف
  itemCategory: string; // الفئة / التصنيف
  itemSerialOrPlate: string; // رقم اللوحة / السيريال S/N
  engineOrChassisSerial?: string; // رقم الشاسي / السيريال الداخلي
  itemCondition: 'جاهزة ومتاحة' | 'جديدة بالمخزن' | 'مستعملة بحالة جيدة' | 'تحت الصيانة الخفيفة' | string;
  quantity: number; // الكمية المصروفة
  
  // Recipient (المستلم)
  recipientName: string;
  recipientMilitaryId: string;
  recipientRank: MilitaryRank | string;
  recipientUnit: string;
  recipientBattalion?: string;
  recipientJobTitle?: string;
  recipientPhone?: string;
  recipientNationalId?: string;

  // Guarantor / Surety (الضمين)
  guarantorName: string;
  guarantorMilitaryId: string;
  guarantorRank: MilitaryRank | string;
  guarantorUnit: string;
  guarantorPhone?: string;
  guarantorNationalId?: string;

  // Order Details
  dispenseReason: string; // سبب الصرف
  orderSource: string; // مصدر أمر الصرف (e.g. توجيهات قائد اللواء / قرار غرفة العمليات / أمر القيادة العامة)
  locationOrDestination?: string; // موقع/جهة التسليم أو الاستخدام الميداني
  notes?: string;

  // Signatures / Approval
  createdByAccountId?: string;
  createdByName?: string;
  timestamp: string; // YYYY-MM-DD HH:mm
}

export type VehicleReadinessStatus = 'جاهزة' | 'منصرف' | 'لم يتم صرفها' | 'خارج الجاهزية' | 'تحت الصيانة' | 'مرجعة للفنية والحركة المركزية';

export interface VehicleReturnClearanceOrder {
  id: string; // e.g. vret-2026-001
  returnNumber: string; // رقم سند إخلاء العهدة e.g. RET-1092/فنية
  returnDate: string; // YYYY-MM-DD
  returnTime?: string; // HH:mm
  
  // Vehicle / Equipment Details
  vehicleId?: string; // ID of VehicleItem if selected from inventory
  vehicleName: string; // اسم الآلية أو المعدة
  vehicleCategory: string; // الفئة
  plateNumber: string; // رقم اللوحة / السيريال S/N
  engineSerial?: string; // رقم المحرك / الشاسي
  yearOfModel?: string; // سنة الصنع / الموديل
  mileageKmAtReturn?: number; // قراءة العداد / ساعات التشغيل عند التسليم
  fuelLevelAtReturn?: string; // مستوى الوقود وقت التسليم
  
  // Handover Person (المسلّم ومخلِي العهدة)
  handoverPersonName: string;
  handoverPersonMilitaryId: string;
  handoverPersonRank: MilitaryRank | string;
  handoverPersonUnit: string;
  handoverPersonBattalion?: string;
  handoverPersonPhone?: string;
  handoverPersonNationalId?: string;

  // Receiving Branch & Officer (المستلم في فرع الفنية والحركة المركزي / الرئيسي)
  recipientBranch: string; // e.g. "فرع الفنية والحركة المركزي"
  receivingOfficerName: string; // اسم ضابط الاستلام
  receivingOfficerRank: MilitaryRank | string; // رتبة ضابط الاستلام
  receivingOfficerMilitaryId?: string;
  receivingTechnicianName?: string; // الفني الفاحص
  headOfBranchApproval?: string; // مصادقة رئيس فرع الفنية والحركة الرئيسي

  // Context & Reason
  returnReason: string; // سبب الإرجاع (انتهاء المهمة / بحاجة لصيانة كبرى وعمرة / انتهاء التكليف / استبدال بآلية أخرى / فائض عن التشكيل)
  returnAuthority: string; // الجهة الآمرة بالإرجاع (أمر قيادة اللواء / توجيهات ركن الفنية والحركة / أمر العمليات)
  
  // Condition at Handover (حالة العربة وقت تسليمها إلى فرع الفنية والحركة الرئيسي)
  conditionAtHandover: 'صالحة وجاهزة للخدمة' | 'معطلة بحاجة لإصلاح' | 'بحاجة لعمرة شاملة' | 'خارجة عن الجاهزية / تالفة' | 'مستعملة بحالة متوسطة' | string;
  handoverConditionNotes: string; // ملاحظة تفصيلية عن حالة العربة وقت تسليمها إلى فرع الفنية والحركة الرئيسي
  technicalDefects?: string; // النواقص أو الأعطال المرصودة وقت التسليم
  
  // Checklist for accessories and equipment at handover
  accessoriesChecklist?: {
    spareTire: boolean; // الإطار الاحتياطي (الاستبنة)
    jackAndTools: boolean; // العفريتة ومعدات الطوارئ
    radioComms: boolean; // جهاز اللاسلكي والاتصالات
    fireExtinguisher: boolean; // طفاية الحريق
    keysHandedOver: boolean; // تسليم المفاتيح الأصلية
    registrationDocs: boolean; // وثائق وكروت الآلية
    otherEquipment?: string; // تجهيزات إضافية
  };

  clearanceStatus: 'تم إخلاء العهدة بالكامل' | 'إخلاء عهدة مشروط' | 'قيد الفحص والمطابقة';
  notes?: string;
  createdByAccountId?: string;
  createdByName?: string;
  timestamp: string;
}

export interface SparePartItem {
  id: string;
  code: string; // كود الصنف / الرقم الكتلوجي e.g. SP-TOY-101
  name: string; // اسم قطعة الغيار / المكون
  category: 'قطع محركات' | 'إطارات وبنشرات' | 'زيوت وفلاتر' | 'كهرباء وبطاريات' | 'مولدات وطاقة' | 'ألواح وانفرترات' | 'منظومات وإلكترونيات' | 'أجهزة وطابعات' | 'أخرى' | string;
  compatibleModels: string; // الطرازات والآليات المتوافقة
  quantity: number; // الكمية المتوفرة حالياً بالمخزن
  minThreshold: number; // حد التنبيه عند نقص المخزون
  unitPrice: number; // السعر التقديري للقطعة
  location: string; // الموقع / الرف / المستودع
  unitOfMeasure?: string; // قطعة / طقم / لتر / حبة / متر
  notes?: string;
  lastRestockedDate?: string; // YYYY-MM-DD
}

export interface VehicleMaintenanceLog {
  id: string;
  vehicleId: string;
  date: string; // YYYY-MM-DD
  type: 'صيانة دورية' | 'إصلاح أعطال' | 'تغيير زيوت وفلاتر' | 'إحلال وتجديد' | 'صيانة محرك' | 'صيانة هيدروليك' | 'تغيير إطارات' | 'فحص شامل' | 'استبدال قطعة غيار' | 'صيانة إلكترونية وطاقة';
  description: string;
  partsReplaced: string;
  sparePartIdUsed?: string; // معرف قطعة الغيار المستخدمة من المخزن (إن وجدت)
  sparePartNameUsed?: string; // اسم القطعة المخصومة
  sparePartQtyUsed?: number; // الكمية المخصومة من المخزن
  workshopOrTechnician: string;
  cost: number;
  status: 'مكتملة' | 'قيد التنفيذ' | 'بانتظار قطع الغيار';
  notes?: string;
  performedByAccountId?: string;
}

export type VehicleCategory =
  | 'طقم قتالي'
  | 'هايلكس'
  | 'دبابة'
  | 'مدرعة وحش'
  | 'مدرعة كاجو'
  | 'طقم مصفح'
  | 'طقم مدرع'
  | 'باصات نقل'
  | 'آلية ثقيلة'
  | 'مولدات كهرباء'
  | 'أجهزة لابتوب وكمبيوتر'
  | 'طابعات وتجهيزات مكتبية'
  | 'ألواح شمسية'
  | 'بطاريات ومخزنات'
  | 'منظومات واتصالات'
  | string;

export interface VehicleItem {
  id: string;
  name: string; // e.g. هايلكس 2024, مولد كاتربيلر, لابتوب تكتيكي, منظومة اتصالات...
  category: VehicleCategory;
  plateNumber: string; // رقم اللوحة / الرقم التسلسلي / S/N
  engineSerial?: string; // رقم الشاسي / السيريال للمعدة
  status: VehicleReadinessStatus;
  readinessPercentage: number; // 0 - 100%
  assignedUnit: string; // الوحدة / اللواء المخصص له
  assignedDriverName?: string; // السائق / المسلم له العهدة
  assignedDriverMilitaryId?: string; // الرقم العسكري للمستلم
  fuelLevel: 'ممتاز (ممتلئ)' | 'جيد (3/4)' | 'متوسط (1/2)' | 'منخفض (1/4)' | 'حرج (خالي)' | 'طاقة شمسية/كهرباء' | 'غير مطبق';
  location: string; // الموقع الميداني / المخزن / الورشة
  lastMaintenanceDate: string; // YYYY-MM-DD
  nextMaintenanceDate?: string; // YYYY-MM-DD
  yearOfModel?: string; // سنة الصنع / الموديل
  mileageKm?: number; // عداد الكيلومترات / ساعات التشغيل
  photoUrl?: string; // صورة الآلية أو المعدة
  notes?: string;
  createdByAccountId?: string;
  maintenanceLogs: VehicleMaintenanceLog[];
  returnDetails?: {
    isReturned: boolean;
    returnDate: string;
    returnNumber: string;
    returnedToBranch: string;
    conditionAtHandover: string;
    handoverConditionNotes: string;
    handoverPersonName: string;
    receivingOfficerName: string;
  };
}

export interface DuplicateGroup {
  groupId: string;
  matchType: 'fullName' | 'militaryId' | 'nationalId';
  matchValue: string;
  fullName: string;
  records: PersonnelRecord[];
  suggestedPrimaryMilitaryId: string;
  unitDistribution: { [unit: string]: number };
}

export interface EmergencyRecallTargetPersonnel {
  militaryId: string;
  fullName: string;
  rank: MilitaryRank | string;
  unit: string;
  battalion?: string;
  company?: string;
  contactNumber?: string;
  statusAtRecall?: string;
}

export interface EmergencyRecallLog {
  id: string; // e.g. RECALL-2026-0811-001
  issueDate: string; // YYYY-MM-DD
  issueTime: string; // HH:mm
  missionCode: string; // e.g. M-301-EMG / رمز المهمة
  missionTitle: string; // عنوان أو بيان مهمة الاستدعاء
  urgencyLevel: 'عاجل جداً' | 'طارئ' | 'اعتيادي';
  issuingAuthority: string; // e.g. "قيادة قوات الطوارئ - الفرقة الثالثة طوارئ"
  issuedByOfficer: string; // اسم أو رتبة الضابط المحرر
  targetPersonnelCount: number;
  targetPersonnel: EmergencyRecallTargetPersonnel[];
  printedAt: string; // ISO string
  accountId?: string;
  accountName?: string;
  notes?: string;
}

export interface PayrollDeduction {
  id: string;
  category: 'غياب / فرار' | 'عهدة لم تسلم' | 'جزاء مسلكي' | 'سلفة / استقطاع' | 'أخرى';
  reason: string;
  amount: number;
  daysCount?: number;
  days?: number;
  date?: string;
  autoGenerated?: boolean;
}

export interface PayrollAllowance {
  id: string;
  title: string;
  amount: number;
}

export interface PersonnelSalaryProfile {
  militaryId: string;
  basicSalary: number;
  allowances: PayrollAllowance[];
  bankName?: string;
  bankAccountNumber?: string;
  salaryStatus?: 'نشط' | 'موقوف' | 'محتجز';
  notes?: string;
}

export interface PayrollMonthlyRecord {
  id: string;
  monthYear: string; // e.g. "2026-08"
  militaryId: string;
  fullName: string;
  rank: MilitaryRank | string;
  unit: string;
  battalion?: string;
  company?: string;
  basicSalary: number;
  allowances: PayrollAllowance[];
  totalAllowances: number;
  deductions: PayrollDeduction[];
  totalDeductions: number;
  netSalary: number; // basicSalary + totalAllowances - totalDeductions
  status: 'مسودة' | 'معتمد' | 'تم الصرف';
  disbursementDate?: string;
  disbursedBy?: string;
  bankName?: string;
  bankAccountNumber?: string;
  notes?: string;
}

export interface PayrollMonthBatch {
  id: string; // e.g. BATCH-2026-08
  monthYear: string; // "2026-08"
  title: string; // "كشف مرتبات شهر أغسطس 2026"
  status: 'قيد الإعداد' | 'معتمد' | 'تم صرف الكشف بالكامل';
  createdAt: string;
  approvedAt?: string;
  approvedBy?: string;
  totalPersonnel: number;
  totalBasicSalary: number;
  totalAllowances: number;
  totalDeductions: number;
  totalNetPayout: number;
  notes?: string;
}

export interface FinancialGrantRecord {
  id: string;
  militaryId: string;
  fullName: string;
  rank: string;
  unit: string;
  battalion?: string;
  company?: string;
  grantType: 'مساعدة مالية' | 'سلفة مالية';
  amount: number;
  monthYear: string; // e.g. "2026-08"
  date: string; // YYYY-MM-DD
  reason: string;
  notes?: string;
  approvedBy: string;
  isDeductedFromSalary: boolean; // false for مساعدة مالية (non-deducted grant), true for سلفة مالية (deducted from salary)
  deductionMonthYear?: string;
  voucherNumber: string;
  createdAt: string;
}

export type StorageOperationType =
  | 'ADD_PERSONNEL'
  | 'UPDATE_PERSONNEL'
  | 'DELETE_PERSONNEL'
  | 'RESTORE_PERSONNEL'
  | 'SAVE_PERSONNEL'
  | 'IMPORT_EXCEL'
  | 'CLOUD_SNAPSHOT_MERGE'
  | 'CLOUD_PUSH'
  | 'RECOVER_LOCAL'
  | 'DEDUPLICATE';

export interface StorageOperationLog {
  id: string;
  timestamp: string;
  type: StorageOperationType;
  actor: string;
  actorDepartment?: string;
  tenantId: string;
  militaryId?: string;
  fullName?: string;
  rank?: string;
  unit?: string;
  countBefore?: number;
  countAfter?: number;
  deltaCount?: number;
  status: 'نجاح' | 'تحذير' | 'خطأ';
  details: string;
  changesSummary?: string[];
  clientTelemetry?: {
    isOnline: boolean;
    storageUsedMB?: number;
    platform?: string;
  };
}

export interface SystemBackupPayload {
  version: string;
  systemName: string;
  exportTimestamp: string;
  activeTenantId: string;
  activeTenantName: string;
  summary: {
    personnelCount: number;
    armoryWeaponsCount: number;
    armoryInventoryCount: number;
    vehiclesCount: number;
    sparePartsCount: number;
    payrollRecordsCount: number;
    financialGrantsCount: number;
    tenantsCount: number;
    usersCount: number;
    auditLogsCount: number;
  };
  data: {
    tenants: OrganizationTenant[];
    activeTenant?: OrganizationTenant;
    personnel: PersonnelRecord[];
    auditLogs: AuditLogEntry[];
    alerts: SystemAlert[];
    recycleBin: RecycledPersonnel[];
    replacements: PersonnelReplacementRecord[];
    emergencyRecalls: EmergencyRecallLog[];
    accounts: UserAccount[];
    armoryWeapons: ArmoryWeaponPiece[];
    armoryInventory: ArmoryInventoryItem[];
    armoryIntakes: ArmoryIntakeRecord[];
    armoryIssues: ArmoryIssueOrder[];
    armoryLifecycle: WeaponLifecycleEvent[];
    weaponTypes: WeaponTypeConfig[];
    ammoTypes: AmmoTypeConfig[];
    vehicles: VehicleItem[];
    spareParts: SparePartItem[];
    vehicleDispenses: VehicleDispenseOrder[];
    vehicleReturns?: VehicleReturnClearanceOrder[];
    salaryProfiles: PersonnelSalaryProfile[];
    payrollRecords: PayrollMonthlyRecord[];
    payrollBatches: PayrollMonthBatch[];
    financialGrants: FinancialGrantRecord[];
    tenantUsersMap: Record<string, TenantUserAccount[]>;
    tenantsDataMap?: Record<string, any>;
  };
}

export interface RestoreBackupOptions {
  mode?: 'replace' | 'merge';
  targetAccountId?: string;
  targetUnitName?: string;
  reassignToCurrentAccount?: boolean;
}

export interface BackupRestoreResult {
  success: boolean;
  message: string;
  restoredStats?: string;
  details?: {
    personnel?: number;
    weapons?: number;
    inventory?: number;
    vehicles?: number;
    spareParts?: number;
    payroll?: number;
    grants?: number;
    tenants?: number;
    users?: number;
    auditLogs?: number;
  };
}

