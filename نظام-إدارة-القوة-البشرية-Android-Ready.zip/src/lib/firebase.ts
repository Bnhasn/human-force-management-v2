/**
 * Local-only storage adapter. Cloud synchronization is intentionally disabled.
 * The application persists data on this device through IndexedDB/LocalStorage.
 * Keep these compatible exports so existing storage code remains stable without
 * initializing Firebase or making network requests.
 */
export const db: null = null;

export async function syncDocToCloudDirect<T>(_docId: string, _data: T): Promise<boolean> {
  return false;
}

export async function syncDocToCloud<T>(_docId: string, _data: T): Promise<void> {
  // Intentionally disabled in local-only mode.
}

export function subscribeCloudDoc<T>(
  _docId: string,
  _onDataReceived: (data: T) => void,
  _initialFallbackData?: T,
  _storageKey?: string
): () => void {
  return () => {};
}

export async function fetchCloudDoc<T>(_docId: string): Promise<T | null> {
  return null;
}
