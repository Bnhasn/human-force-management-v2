import { BRIGADE_ACCOUNTS } from '../data/accountsData';

export interface DocumentHeaderInfo {
  forceName: string;     // "قوات الطوارئ اليمنية"
  divisionName: string;  // "الفرقة الثالثة"
  unitName: string;      // "اللواء الأول" | "اللواء الثاني" ... | "قيادة الفرقة"
  country?: string;      // Backward compatibility
}

/**
 * Returns official standard document header details according to user's active account.
 * - Force: قوات الطوارئ اليمنية
 * - Division: الفرقة الثالثة
 * - Unit: Depends on logged-in brigade account (اللواء الأول .. اللواء الثامن / قيادة الفرقة)
 */
export function getCurrentHeaderInfo(fallbackUnit?: string): DocumentHeaderInfo {
  let activeCode = 'hq';
  if (typeof window !== 'undefined') {
    activeCode = localStorage.getItem('military_active_account_v1') || 'hq';
  }

  const account = BRIGADE_ACCOUNTS.find((a) => a.id === activeCode);

  let unitName = 'اللواء الأول';

  if (account) {
    if (account.id === 'hq') {
      if (fallbackUnit && fallbackUnit !== 'الكل' && fallbackUnit !== 'قيادة اللواء الميداني' && fallbackUnit !== 'قيادة اللواء') {
        unitName = fallbackUnit;
      } else {
        unitName = 'قيادة الفرقة';
      }
    } else if (account.id === 'vehicles_readiness') {
      unitName = 'اللواء الأول';
    } else if (account.unitFilter && account.unitFilter !== 'الكل') {
      unitName = account.unitFilter;
    } else {
      unitName = account.name;
    }
  } else if (fallbackUnit && fallbackUnit !== 'الكل' && fallbackUnit !== 'قيادة اللواء الميداني' && fallbackUnit !== 'قيادة اللواء') {
    unitName = fallbackUnit;
  }

  return {
    country: 'قوات الطوارئ اليمنية',
    forceName: 'قوات الطوارئ اليمنية',
    divisionName: 'الفرقة الثالثة',
    unitName: unitName,
  };
}

