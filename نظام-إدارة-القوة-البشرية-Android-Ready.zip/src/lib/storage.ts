import {
  MilitaryRank,
  PersonnelRecord,
  PersonnelStatus,
  AuditLogEntry,
  SystemAlert,
  DepartmentRole,
  MovementLog,
  AttendanceLog,
  MedicalLog,
  FinancialLog,
  SecurityLog,
  ArmamentLog,
  TrainingLog,
  PersonnelAttachment,
  SupplyLog,
  RecycledPersonnel,
  UserAccount,
  PersonnelReplacementRecord,
  OrganizationTenant,
  TenantUserAccount,
  VehicleItem,
  VehicleMaintenanceLog,
  SparePartItem,
  EmergencyRecallLog,
  VehicleDispenseOrder,
  VehicleReturnClearanceOrder,
  DuplicateGroup,
  PersonnelSalaryProfile,
  PayrollMonthlyRecord,
  PayrollMonthBatch,
  PayrollDeduction,
  PayrollAllowance,
  FinancialGrantRecord,
  StorageOperationLog,
  StorageOperationType,
  SystemBackupPayload,
  BackupRestoreResult,
  RestoreBackupOptions
} from '../types';
import { DEFAULT_TENANTS, createFullSuperAdminUser } from '../data/tenantData';
import { INITIAL_PERSONNEL, INITIAL_AUDIT_LOGS, INITIAL_ALERTS, INITIAL_EMERGENCY_RECALL_LOGS } from '../data/initialData';
import { BRIGADE_ACCOUNTS, getAccountIdForUnit, getAllAccounts } from '../data/accountsData';
import { INITIAL_VEHICLES_DATA, INITIAL_SPARE_PARTS_DATA, INITIAL_VEHICLE_DISPENSE_ORDERS, INITIAL_VEHICLE_RETURN_ORDERS } from '../data/vehiclesData';
import {
  ArmoryInventoryItem,
  ArmoryWeaponPiece,
  ArmoryIntakeRecord,
  ArmoryIssueOrder,
  WeaponLifecycleEvent,
  WeaponTypeConfig,
  AmmoTypeConfig,
  INITIAL_INVENTORY_ITEMS,
  INITIAL_WEAPON_PIECES,
  INITIAL_INTAKE_RECORDS,
  INITIAL_ISSUE_ORDERS,
  INITIAL_LIFECYCLE_EVENTS,
  INITIAL_WEAPON_TYPES,
  INITIAL_AMMO_TYPES
} from '../data/armamentData';
import { syncDocToCloud, subscribeCloudDoc, fetchCloudDoc } from './firebase';
import {
  safeSetLocalItem,
  safeGetLocalItem,
  getLocalSaveTimestamp,
  hasUserSavedDataOnDevice,
  markUserHasSavedData,
  createDeviceSnapshot,
  getDeviceSnapshots,
  restoreDeviceSnapshot,
  getStorageHealth,
  getAllIDBEntries,
  DeviceSnapshotEntry,
  getAllMemoryCachedEntries,
  getMemoryCachedItem,
  purgeObsoleteReplacedData
} from './safeLocalStorage';
import { getDeviceTelemetry } from './deviceTelemetry';

const STORAGE_KEY_PERSONNEL = 'military_hr_personnel_v2';
const STORAGE_KEY_AUDIT = 'military_hr_audit_logs_v2';
const STORAGE_KEY_ALERTS = 'military_hr_alerts_v2';
const STORAGE_KEY_RECYCLE_BIN = 'military_hr_recycle_bin_v1';
const STORAGE_KEY_REPLACEMENTS = 'military_hr_replacements_v1';
const STORAGE_KEY_EMERGENCY_RECALLS = 'military_emergency_recall_logs_v1';

const STORAGE_KEY_ARMORY_INVENTORY = 'military_armory_inventory_v1';
const STORAGE_KEY_ARMORY_WEAPONS = 'military_armory_weapons_v1';
const STORAGE_KEY_ARMORY_INTAKES = 'military_armory_intakes_v1';
const STORAGE_KEY_ARMORY_ISSUES = 'military_armory_issues_v1';
const STORAGE_KEY_ARMORY_LIFECYCLE = 'military_armory_lifecycle_v1';
const STORAGE_KEY_WEAPON_TYPES = 'military_weapon_types_config_v1';
const STORAGE_KEY_AMMO_TYPES = 'military_ammo_types_config_v1';
const STORAGE_KEY_VEHICLES = 'military_vehicles_readiness_v1';
const STORAGE_KEY_SPARE_PARTS = 'military_spare_parts_inventory_v1';
const STORAGE_KEY_VEHICLE_DISPENSES = 'military_vehicle_dispense_orders_v1';
const STORAGE_KEY_VEHICLE_RETURNS = 'military_vehicle_returns_v1';
const STORAGE_KEY_ACCOUNTS = 'military_accounts_config_v2';
const STORAGE_KEY_ACTIVE_TENANT = 'military_active_tenant_id_v1';
const STORAGE_KEY_REGISTERED_TENANTS = 'military_registered_tenants_v1';
const STORAGE_KEY_SALARY_PROFILES = 'military_salary_profiles_v1';
const STORAGE_KEY_PAYROLL_RECORDS = 'military_payroll_records_v1';
const STORAGE_KEY_PAYROLL_BATCHES = 'military_payroll_batches_v1';
const STORAGE_KEY_FINANCIAL_GRANTS = 'military_financial_grants_v1';
const STORAGE_KEY_STORAGE_LOGS = 'military_storage_audit_logs_v1';

const syncChannel = typeof window !== 'undefined' && 'BroadcastChannel' in window ? new BroadcastChannel('military_hq_sync') : null;

const notifyDataChange = () => {
  StorageService.clearMemoryCache();
  if (typeof window !== 'undefined') {
    window.dispatchEvent(new Event('military_data_changed'));
    if (syncChannel) {
      try {
        syncChannel.postMessage({ type: 'DATA_UPDATED', timestamp: Date.now() });
      } catch (err) {
        console.error('Failed to post broadcast message:', err);
      }
    }
  }
};

export class StorageService {
  private static cloudSubscribed = false;
  private static cloudUnsubscribers: (() => void)[] = [];

  // In-memory performance cache for rapid navigation and instant search
  private static isProcessingTransitions = false;
  private static memoizedPersonnel: { tenantId: string; data: PersonnelRecord[] } | null = null;
  private static memoizedAuditLogs: { tenantId: string; data: AuditLogEntry[] } | null = null;
  private static memoizedAlerts: { tenantId: string; data: SystemAlert[] } | null = null;
  private static memoizedAccounts: UserAccount[] | null = null;
  private static memoizedEmergencyRecalls: { tenantId: string; data: EmergencyRecallLog[] } | null = null;
  private static storageOperationLogs: StorageOperationLog[] | null = null;

  // Diagnostic Storage Operations Logger (Zero Data Loss Audit Trail)
  static logStorageOperation(entry: Omit<StorageOperationLog, 'id' | 'timestamp'> & { timestamp?: string }): StorageOperationLog {
    const timestamp = entry.timestamp || new Date().toISOString();
    const id = `st-log-${Date.now()}-${Math.floor(Math.random() * 10000)}`;
    const fullLog: StorageOperationLog = {
      id,
      timestamp,
      ...entry,
      clientTelemetry: entry.clientTelemetry || {
        isOnline: typeof navigator !== 'undefined' ? navigator.onLine : true,
        platform: typeof navigator !== 'undefined' ? navigator.userAgent : 'Unknown'
      }
    };

    // Keep in memory (capped at 300 entries)
    if (!this.storageOperationLogs) {
      this.storageOperationLogs = this.getStorageOperationLogs();
    }
    this.storageOperationLogs = [fullLog, ...this.storageOperationLogs.slice(0, 299)];

    // Persist to safe storage asynchronously
    const key = this.getKeyForTenant(STORAGE_KEY_STORAGE_LOGS);
    safeSetLocalItem(key, this.storageOperationLogs);

    // Formatted structured developer console log
    if (typeof window !== 'undefined') {
      const isError = fullLog.status === 'خطأ';
      const isWarning = fullLog.status === 'تحذير';
      const style = isError
        ? 'background: #dc2626; color: white; font-weight: bold; padding: 2px 6px; border-radius: 4px;'
        : isWarning
        ? 'background: #d97706; color: white; font-weight: bold; padding: 2px 6px; border-radius: 4px;'
        : 'background: #059669; color: white; font-weight: bold; padding: 2px 6px; border-radius: 4px;';

      const tag = `[StorageService: ${fullLog.type}]`;
      console.log(
        `%c${tag}%c [${fullLog.actor}] - ${fullLog.details} (سجلات: ${fullLog.countBefore ?? '?'} -> ${fullLog.countAfter ?? '?'})`,
        style,
        'color: inherit; font-weight: normal;',
        {
          operation: fullLog.type,
          militaryId: fullLog.militaryId,
          fullName: fullLog.fullName,
          status: fullLog.status,
          deltaCount: fullLog.deltaCount,
          changes: fullLog.changesSummary,
          timestamp: fullLog.timestamp
        }
      );
    }

    return fullLog;
  }

  static getStorageOperationLogs(): StorageOperationLog[] {
    if (this.storageOperationLogs) {
      return this.storageOperationLogs;
    }
    try {
      const key = this.getKeyForTenant(STORAGE_KEY_STORAGE_LOGS);
      const raw = safeGetLocalItem<StorageOperationLog[]>(key);
      if (raw && Array.isArray(raw)) {
        this.storageOperationLogs = raw;
        return raw;
      }
    } catch (e) {}
    this.storageOperationLogs = [];
    return [];
  }

  static clearStorageOperationLogs(): void {
    this.storageOperationLogs = [];
    const key = this.getKeyForTenant(STORAGE_KEY_STORAGE_LOGS);
    safeSetLocalItem(key, []);
    notifyDataChange();
  }

  public static clearMemoryCache(): void {
    StorageService.memoizedPersonnel = null;
    StorageService.memoizedAuditLogs = null;
    StorageService.memoizedAlerts = null;
    StorageService.memoizedAccounts = null;
    StorageService.memoizedEmergencyRecalls = null;
  }

  // Multi-Tenant Isolation Helpers
  static getActiveTenantId(): string {
    if (typeof window !== 'undefined') {
      try {
        const id = localStorage.getItem(STORAGE_KEY_ACTIVE_TENANT);
        if (id) return id;
      } catch (e) {}
    }
    return DEFAULT_TENANTS[0].id; // 'tenant-hq-main'
  }

  static getTenants(): OrganizationTenant[] {
    if (typeof window !== 'undefined') {
      try {
        const raw = localStorage.getItem(STORAGE_KEY_REGISTERED_TENANTS);
        if (raw) {
          const parsed = JSON.parse(raw);
          if (Array.isArray(parsed) && parsed.length > 0) return parsed;
        }
      } catch (e) {}
    }
    return DEFAULT_TENANTS;
  }

  static saveTenants(tenants: OrganizationTenant[]): void {
    if (typeof window !== 'undefined') {
      try {
        localStorage.setItem(STORAGE_KEY_REGISTERED_TENANTS, JSON.stringify(tenants));
        syncDocToCloud('registered_tenants', tenants);
        notifyDataChange();
      } catch (e) {}
    }
  }

  static getActiveTenant(): OrganizationTenant {
    const list = this.getTenants();
    const activeId = this.getActiveTenantId();
    return list.find((t) => t.id === activeId) || list[0] || DEFAULT_TENANTS[0];
  }

  static setActiveTenant(tenant: OrganizationTenant): void {
    if (typeof window !== 'undefined') {
      try {
        localStorage.setItem(STORAGE_KEY_ACTIVE_TENANT, tenant.id);
        this.restartCloudSync();
        notifyDataChange();
      } catch (e) {}
    }
  }

  static addTenant(newTenant: OrganizationTenant): void {
    const list = this.getTenants();
    if (!list.some((t) => t.id === newTenant.id)) {
      list.push(newTenant);
      this.saveTenants(list);
    }
    // Automatically seed Super Admin user for this new tenant
    const superAdmin = createFullSuperAdminUser(newTenant);
    this.addTenantUser(newTenant.id, superAdmin);
  }

  // Tenant Users & Permissions Management
  static getTenantUsers(tenantId?: string): TenantUserAccount[] {
    const targetId = tenantId || this.getActiveTenantId();
    const key = `military_tenant_users_${targetId}_v1`;
    if (typeof window !== 'undefined') {
      try {
        const raw = localStorage.getItem(key);
        if (raw) {
          const parsed = JSON.parse(raw);
          if (Array.isArray(parsed) && parsed.length > 0) return parsed;
        }
      } catch (e) {}
    }
    // If no users exist, initialize default Super Admin for this tenant
    const activeTenantObj = this.getTenants().find((t) => t.id === targetId) || this.getActiveTenant();
    const defaultSuperAdmin = createFullSuperAdminUser(activeTenantObj);
    const initialList = [defaultSuperAdmin];
    this.saveTenantUsers(targetId, initialList);
    return initialList;
  }

  static saveTenantUsers(tenantId: string, users: TenantUserAccount[]): void {
    const key = `military_tenant_users_${tenantId}_v1`;
    if (typeof window !== 'undefined') {
      try {
        localStorage.setItem(key, JSON.stringify(users));
        syncDocToCloud(`tenant_users_${tenantId}`, users);
        notifyDataChange();
      } catch (e) {}
    }
  }

  static addTenantUser(tenantId: string, newUser: TenantUserAccount): void {
    const users = this.getTenantUsers(tenantId);
    if (!users.some((u) => u.id === newUser.id || u.username.toLowerCase() === newUser.username.toLowerCase())) {
      users.push(newUser);
      this.saveTenantUsers(tenantId, users);
    }
  }

  static updateTenantUser(tenantId: string, updatedUser: TenantUserAccount): void {
    const users = this.getTenantUsers(tenantId);
    const index = users.findIndex((u) => u.id === updatedUser.id);
    if (index !== -1) {
      users[index] = updatedUser;
      this.saveTenantUsers(tenantId, users);
    }
  }

  static deleteTenantUser(tenantId: string, userId: string): void {
    const users = this.getTenantUsers(tenantId);
    const filtered = users.filter((u) => u.id !== userId || u.isSuperAdmin); // Never delete Super Admin
    this.saveTenantUsers(tenantId, filtered);
  }

  // Current Logged-in User Session Management
  static getCurrentUser(): TenantUserAccount | null {
    if (typeof window !== 'undefined') {
      try {
        const raw = localStorage.getItem('military_current_logged_user_v1');
        if (raw) {
          return JSON.parse(raw);
        }
      } catch (e) {}
    }
    // Fallback: Default to Active Tenant Super Admin
    const activeTenant = this.getActiveTenant();
    const users = this.getTenantUsers(activeTenant.id);
    const superAdmin = users.find((u) => u.isSuperAdmin) || users[0] || createFullSuperAdminUser(activeTenant);
    return superAdmin;
  }

  static setCurrentUser(user: TenantUserAccount | null): void {
    if (typeof window !== 'undefined') {
      try {
        if (user) {
          localStorage.setItem('military_current_logged_user_v1', JSON.stringify(user));
        } else {
          localStorage.removeItem('military_current_logged_user_v1');
        }
        notifyDataChange();
      } catch (e) {}
    }
  }

  static logoutUser(): void {
    this.setCurrentUser(null);
  }

  static authenticateTenantUser(
    username: string,
    password?: string,
    targetTenantId?: string
  ): { success: boolean; user?: TenantUserAccount; tenant?: OrganizationTenant; message?: string } {
    const tenants = this.getTenants();
    const cleanUsername = username.trim().toLowerCase();

    // Search across tenants or in specified tenant
    const candidateTenants = targetTenantId ? tenants.filter((t) => t.id === targetTenantId) : tenants;

    for (const t of candidateTenants) {
      const users = this.getTenantUsers(t.id);
      const user = users.find((u) => u.username.toLowerCase() === cleanUsername);

      if (user) {
        if (user.status === 'موقوف' || user.status === 'محظور') {
          return { success: false, message: `هذا الحساب (${user.fullName}) موقوف حالياً من قِبل مسؤول المؤسسة!` };
        }

        // Verify password if provided
        if (password && user.password && user.password !== password) {
          return { success: false, message: 'كلمة المرور غير صحيحة! يرجى إعادة المحاولة.' };
        }

        // Update last login
        const updatedUser = { ...user, lastLogin: new Date().toISOString() };
        this.updateTenantUser(t.id, updatedUser);
        this.setActiveTenant(t);
        this.setCurrentUser(updatedUser);

        return { success: true, user: updatedUser, tenant: t };
      }
    }

    return { success: false, message: 'اسم المستخدم غير موجود أو لم يتم العثور على حساب مطابق!' };
  }

  // Tenant-isolated key resolver for LocalStorage
  static getKeyForTenant(baseKey: string): string {
    const activeId = this.getActiveTenantId();
    if (!activeId || activeId === 'tenant-hq-main') {
      return baseKey; // Default main tenant uses base un-prefixed keys for 100% data preservation
    }
    return `tenant_${activeId}_${baseKey}`;
  }

  // Tenant-isolated document ID resolver for Cloud Firestore
  static getCloudDocIdForTenant(baseDocId: string): string {
    const activeId = this.getActiveTenantId();
    if (!activeId || activeId === 'tenant-hq-main') {
      return baseDocId;
    }
    return `${activeId}_${baseDocId}`;
  }

  static restartCloudSync(): void {
    if (this.cloudUnsubscribers.length > 0) {
      this.cloudUnsubscribers.forEach((u) => u());
      this.cloudUnsubscribers = [];
    }
    this.cloudSubscribed = false;
    this.initCloudSync();
  }

  // Zero-Data-Loss Bidirectional Local & Cloud Personnel Merger
  static mergeLocalAndCloudPersonnel(
    localRecords: PersonnelRecord[],
    cloudRecords: PersonnelRecord[]
  ): { merged: PersonnelRecord[]; addedFromCloud: number; localKept: number } {
    if (!cloudRecords || cloudRecords.length === 0) {
      return { merged: localRecords || [], addedFromCloud: 0, localKept: (localRecords || []).length };
    }
    if (!localRecords || localRecords.length === 0) {
      return { merged: cloudRecords, addedFromCloud: cloudRecords.length, localKept: 0 };
    }

    const cleanMil = (id?: string) => (id ? id.trim().toLowerCase() : '');
    const cleanNat = (id?: string) => (id && id.trim().length > 5 && id !== '0000000000' ? id.trim() : '');

    const map = new Map<string, PersonnelRecord>();
    const localMilSet = new Set<string>();

    // 1. Load Local Records first
    localRecords.forEach((loc) => {
      const milKey = cleanMil(loc.militaryId);
      const natKey = cleanNat(loc.nationalId);
      const primaryKey = milKey || (natKey ? `nat_${natKey}` : `temp_${loc.fullName}_${loc.unit}`);
      map.set(primaryKey, { ...loc });
      if (milKey) localMilSet.add(milKey);
    });

    let addedFromCloud = 0;

    // 2. Merge Cloud Records without erasing local additions
    cloudRecords.forEach((cld) => {
      const milKey = cleanMil(cld.militaryId);
      const natKey = cleanNat(cld.nationalId);
      const primaryKey = milKey || (natKey ? `nat_${natKey}` : `temp_${cld.fullName}_${cld.unit}`);

      const existing = map.get(primaryKey);
      if (!existing) {
        map.set(primaryKey, { ...cld });
        addedFromCloud++;
      } else {
        // Merge logs (attendance, movement, attachments, etc.) so no historical actions are lost
        if (cld.logs) {
          if (!existing.logs) {
            existing.logs = { ...cld.logs };
          } else {
            (['attendance', 'movement', 'medical', 'financial', 'security', 'armament', 'training', 'attachments', 'supply'] as const).forEach((logType) => {
              const cLogs = (cld.logs?.[logType] || []) as any[];
              const eLogs = ((existing.logs?.[logType] as any[]) || []) as any[];
              const eIds = new Set(eLogs.map((x: any) => x.id));
              cLogs.forEach((item: any) => {
                if (item && item.id && !eIds.has(item.id)) {
                  eLogs.push(item);
                  eIds.add(item.id);
                }
              });
              (existing.logs as any)[logType] = eLogs;
            });
          }
        }

        // Prefer newer status update
        if (cld.lastStatusChangeDate && (!existing.lastStatusChangeDate || cld.lastStatusChangeDate > existing.lastStatusChangeDate)) {
          existing.currentStatus = cld.currentStatus;
          existing.lastStatusChangeDate = cld.lastStatusChangeDate;
          if (cld.secondedUnit) existing.secondedUnit = cld.secondedUnit;
          if (cld.trainingCourseType) existing.trainingCourseType = cld.trainingCourseType;
        }

        // Fill non-empty details
        if (!existing.photoUrl && cld.photoUrl) existing.photoUrl = cld.photoUrl;
        if ((!existing.phone || existing.phone === 'غير مسجل') && cld.phone) existing.phone = cld.phone;
        if (!existing.nationalId && cld.nationalId) existing.nationalId = cld.nationalId;
        if (!existing.motherName && cld.motherName) existing.motherName = cld.motherName;
        if (!existing.bloodType && cld.bloodType) existing.bloodType = cld.bloodType;
        if (!existing.guarantorName && cld.guarantorName) existing.guarantorName = cld.guarantorName;
        if (!existing.relativeName && cld.relativeName) existing.relativeName = cld.relativeName;
        if (!existing.relativePhone && cld.relativePhone) existing.relativePhone = cld.relativePhone;
      }
    });

    const merged = Array.from(map.values());
    const localKept = merged.length - addedFromCloud;

    return { merged, addedFromCloud, localKept };
  }

  // Local-only mode: keep the method for backwards compatibility, but never connect to Firestore.
  static initCloudSync(): () => void {
    return () => {};
  }

  // Force Instant Cloud Data Fetch / Recovery
  static async syncFromCloudForce(): Promise<{ success: boolean; count: number; message: string }> {
    try {
      const activeTenantId = this.getActiveTenantId();
      const personnelCloudId = this.getCloudDocIdForTenant('personnel');
      const cloudPersonnel = await fetchCloudDoc<PersonnelRecord[]>(personnelCloudId);

      if (cloudPersonnel && Array.isArray(cloudPersonnel) && cloudPersonnel.length > 0) {
        this.savePersonnel(cloudPersonnel);
        return {
          success: true,
          count: cloudPersonnel.length,
          message: `تم استرجاع ومزامنة (${cloudPersonnel.length}) فرد/ضابط من قاعدة البيانات السحابية بنجاح!`
        };
      } else {
        // Try fallback to main tenant personnel
        const mainCloudPersonnel = await fetchCloudDoc<PersonnelRecord[]>('personnel_tenant-hq-main');
        if (mainCloudPersonnel && Array.isArray(mainCloudPersonnel) && mainCloudPersonnel.length > 0) {
          this.savePersonnel(mainCloudPersonnel);
          return {
            success: true,
            count: mainCloudPersonnel.length,
            message: `تم استرجاع ومزامنة (${mainCloudPersonnel.length}) فرد/ضابط من السجل الرئيسي للفرقة!`
          };
        }
        return {
          success: false,
          count: 0,
          message: 'النظام مضبوط للعمل محلياً على هذا الجهاز ولا يستخدم المزامنة السحابية.'
        };
      }
    } catch (err: any) {
      return {
        success: false,
        count: 0,
        message: 'المزامنة السحابية معطلة؛ استخدم النسخة الاحتياطية المحلية عند الحاجة إلى الاستعادة.'
      };
    }
  }

  // Subscribe to live changes across tabs / components
  static notifySubscribers(): void {
    notifyDataChange();
  }

  static subscribeToChanges(callback: () => void): () => void {
    const handleEvent = () => callback();
    if (typeof window !== 'undefined') {
      window.addEventListener('military_data_changed', handleEvent);
      window.addEventListener('storage', handleEvent);
      if (syncChannel) {
        syncChannel.onmessage = (event) => {
          if (event.data?.type === 'DATA_UPDATED') {
            callback();
          }
        };
      }
    }
    return () => {
      if (typeof window !== 'undefined') {
        window.removeEventListener('military_data_changed', handleEvent);
        window.removeEventListener('storage', handleEvent);
      }
    };
  }

  // Automatic check for expired leaves/permissions and 30-day absences (Zero False Overwrites)
  static checkAndProcessExpiredLeavesAndAbsences(list: PersonnelRecord[]): { updated: boolean; records: PersonnelRecord[] } {
    let updated = false;
    const today = new Date();
    const todayStr = today.toISOString().split('T')[0];

    list.forEach((p) => {
      if (!p.logs) return;
      if (!p.logs.attendance) p.logs.attendance = [];

      // RULE 1: Check if soldier is currently on 'إجازة' or 'إذن' and the current active leave expired
      if (['إجازة', 'إذن', 'مجاز'].includes(p.currentStatus)) {
        // Only inspect the most recent active log that matches current status
        const activeLog = p.logs.attendance[0];

        if (
          activeLog &&
          (activeLog.type === 'إجازة' || activeLog.type === 'إذن') &&
          activeLog.endDate &&
          activeLog.endDate < todayStr &&
          (!p.lastStatusChangeDate || (activeLog.startDate && activeLog.startDate >= p.lastStatusChangeDate))
        ) {
          // Expiration date has passed without updating to 'متواجد'
          p.currentStatus = 'غياب';
          p.lastStatusChangeDate = todayStr;
          updated = true;

          const newLog: AttendanceLog = {
            id: `att-auto-absent-${Date.now()}-${p.militaryId}`,
            date: todayStr,
            type: 'غياب',
            reason: `انقضاء تاريخ انتهاء ${activeLog.type} المحدد (${activeLog.endDate}) دون تقديم تحضير - تم تحويل الحالة آلياً إلى غياب`,
            durationDays: 1,
            approvedBy: 'النظام الإداري الآلي',
            startDate: todayStr
          };
          p.logs.attendance.unshift(newLog);

          this.addAlert({
            title: `تنبيه انقضاء إجازة/إذن: تحويل إلى غياب`,
            description: `تجاوز الفرد ${p.rank} ${p.fullName} (${p.militaryId}) تاريخ انتهاء إذنه/إجازته (${activeLog.endDate}) دون تحضير. تم تعديل الحالة رسمياً إلى (غياب).`,
            level: 'warning',
            militaryId: p.militaryId
          });
        }
      }

      // RULE 2: Check if soldier has been in 'غياب' for >= 30 days without status updated to 'متواجد'
      if (['غياب', 'غائب'].includes(p.currentStatus)) {
        const activeAbsentLog = p.logs.attendance[0];

        if (activeAbsentLog && activeAbsentLog.type === 'غياب') {
          const absenceStartDateStr = activeAbsentLog.startDate || activeAbsentLog.date;

          if (absenceStartDateStr) {
            const startDateObj = new Date(absenceStartDateStr);
            const diffMs = today.getTime() - startDateObj.getTime();
            const diffDays = Math.floor(diffMs / (1000 * 60 * 60 * 24));

            if (diffDays >= 30) {
              // 30 days passed without updating status to 'متواجد' -> Status becomes 'فرار'
              p.currentStatus = 'فرار';
              p.lastStatusChangeDate = todayStr;
              updated = true;

              const desertionLog: AttendanceLog = {
                id: `att-auto-desertion-${Date.now()}-${p.militaryId}`,
                date: todayStr,
                type: 'فرار',
                reason: `انقضاء 30 يوماً متواصلة على الغياب (${absenceStartDateStr}) دون تحضير - تم تعديل الحالة رسمياً إلى (فرار) بموجب اللوائح العسكرية`,
                durationDays: diffDays,
                approvedBy: 'القضاء العسكري والقيادة العامة',
                startDate: todayStr
              };
              p.logs.attendance.unshift(desertionLog);

              this.addAlert({
                title: `🚨 بلاغ فرار رسمي: تجاوز 30 يوماً غياب`,
                description: `الفرد ${p.rank} ${p.fullName} (${p.militaryId}) انقضى على غيابه 30 يوماً متواصلة دون تقديم تحضير. تم اعتماد حالة (فرار) رسمياً وإحالة السجل للجهات القضائية.`,
                level: 'urgent',
                militaryId: p.militaryId
              });
            }
          }
        }
      }
    });

    return { updated, records: list };
  }

  // Automatic Deduplication & Records Sanitization Engine (Optimized O(N))
  static deduplicatePersonnelList(records: PersonnelRecord[]): PersonnelRecord[] {
    if (!records || !Array.isArray(records) || records.length <= 1) return records || [];

    const cleanNameStr = (str: string) => {
      if (!str) return '';
      return str
        .trim()
        .toLowerCase()
        .replace(/[\u064B-\u0652]/g, '')
        .replace(/[أإآ]/g, 'ا')
        .replace(/ة/g, 'ه')
        .replace(/ى/g, 'ي')
        .replace(/\s+/g, ' ');
    };

    const isCustomPhoto = (url?: string) => {
      if (!url) return false;
      return (
        url.startsWith('data:image') ||
        url.startsWith('blob:') ||
        (!url.includes('images.unsplash.com') && !url.includes('unsplash.com') && !url.includes('placeholder') && url.length > 20)
      );
    };

    const milMap = new Map<string, PersonnelRecord>();
    const natMap = new Map<string, PersonnelRecord>();
    const nameMap = new Map<string, PersonnelRecord>();
    const result: PersonnelRecord[] = [];

    for (let i = 0; i < records.length; i++) {
      const rec = records[i];
      if (!rec) continue;

      const cName = cleanNameStr(rec.fullName);
      const cMil = rec.militaryId ? rec.militaryId.trim().toLowerCase() : '';
      const cNat = rec.nationalId && rec.nationalId.trim().length > 5 && rec.nationalId !== '0000000000' ? rec.nationalId.trim() : '';

      // Match strictly on ID to guarantee that soldiers sharing common Arabic names are NOT merged
      let existingRec: PersonnelRecord | undefined = undefined;
      if (cMil && milMap.has(cMil)) {
        existingRec = milMap.get(cMil);
      } else if (cNat && natMap.has(cNat)) {
        existingRec = natMap.get(cNat);
      } else if (!cMil && !cNat && cName && nameMap.has(cName)) {
        const potential = nameMap.get(cName);
        if (potential && !potential.militaryId && (!potential.nationalId || potential.nationalId === '0000000000') && potential.unit === rec.unit && potential.rank === rec.rank) {
          existingRec = potential;
        }
      }

      if (existingRec) {
        // Prefer custom uploaded photo over placeholder
        if (isCustomPhoto(rec.photoUrl)) {
          existingRec.photoUrl = rec.photoUrl;
        } else if (!existingRec.photoUrl && rec.photoUrl) {
          existingRec.photoUrl = rec.photoUrl;
        }

        // Prefer newer/updated status if present
        if (rec.lastStatusChangeDate && (!existingRec.lastStatusChangeDate || rec.lastStatusChangeDate >= existingRec.lastStatusChangeDate)) {
          existingRec.currentStatus = rec.currentStatus;
          existingRec.lastStatusChangeDate = rec.lastStatusChangeDate;
          if (rec.secondedUnit) existingRec.secondedUnit = rec.secondedUnit;
        } else if (existingRec.currentStatus === 'متواجد' && rec.currentStatus !== 'متواجد') {
          existingRec.currentStatus = rec.currentStatus;
          existingRec.lastStatusChangeDate = rec.lastStatusChangeDate || new Date().toISOString().split('T')[0];
          if (rec.secondedUnit) existingRec.secondedUnit = rec.secondedUnit;
        }

        // Merge contact and personal fields safely
        if (!existingRec.nationalId || existingRec.nationalId === '0000000000') existingRec.nationalId = rec.nationalId;
        if (!existingRec.phone || existingRec.phone === 'غير مسجل') existingRec.phone = rec.phone;
        if (rec.motherName && (!existingRec.motherName || existingRec.motherName === 'غير مسجل')) existingRec.motherName = rec.motherName;
        if (rec.guarantorName && (!existingRec.guarantorName || existingRec.guarantorName === 'غير مسجل')) existingRec.guarantorName = rec.guarantorName;
        if (rec.relativeName && (!existingRec.relativeName || existingRec.relativeName === 'غير مسجل')) existingRec.relativeName = rec.relativeName;
        if (rec.relativePhone && (!existingRec.relativePhone || existingRec.relativePhone === 'غير مسجل')) existingRec.relativePhone = rec.relativePhone;
        if (!existingRec.biometricsRecorded && rec.biometricsRecorded) existingRec.biometricsRecorded = true;
        if (!existingRec.bloodType) existingRec.bloodType = rec.bloodType;
        if (rec.rank) existingRec.rank = rec.rank;
        if (rec.unit && rec.unit !== 'اللواء الأول' && existingRec.unit === 'اللواء الأول') existingRec.unit = rec.unit;
        if (rec.jobTitle && rec.jobTitle !== 'غير محدد') existingRec.jobTitle = rec.jobTitle;

        // Merge logs safely
        if (rec.logs) {
          if (!existingRec.logs) {
            existingRec.logs = {
              movement: [], attendance: [], medical: [], financial: [],
              security: [], armament: [], training: [], attachments: [], supply: []
            };
          }
          (['movement', 'attendance', 'medical', 'financial', 'security', 'armament', 'training', 'attachments', 'supply'] as const).forEach((logType) => {
            const srcLogs = rec.logs[logType];
            if (Array.isArray(srcLogs)) {
              if (!existingRec.logs![logType]) existingRec.logs![logType] = [] as any;
              const targetArr = existingRec.logs![logType] as any[];
              const existingIds = new Set(targetArr.map((x) => x.id));
              srcLogs.forEach((item: any) => {
                if (item && item.id && !existingIds.has(item.id)) {
                  targetArr.push(item);
                  existingIds.add(item.id);
                }
              });
            }
          });
        }
      } else {
        const copy = { ...rec };
        result.push(copy);
        if (cMil) milMap.set(cMil, copy);
        if (cNat) natMap.set(cNat, copy);
        if (cName) nameMap.set(cName, copy);
      }
    }

    return result;
  }

  // Automatic recovery scanner across all LocalStorage keys, IndexedDB cache, and on-device snapshots
  static recoverLocalPersonnelFromAllKeys(): PersonnelRecord[] {
    const foundMap = new Map<string, PersonnelRecord>();
    if (typeof window === 'undefined') return [];

    const excludedKeys = [
      STORAGE_KEY_RECYCLE_BIN,
      STORAGE_KEY_AUDIT,
      STORAGE_KEY_ALERTS,
      STORAGE_KEY_SALARY_PROFILES,
      STORAGE_KEY_PAYROLL_RECORDS,
      STORAGE_KEY_PAYROLL_BATCHES,
      STORAGE_KEY_ARMORY_INVENTORY,
      STORAGE_KEY_ARMORY_WEAPONS,
      STORAGE_KEY_VEHICLES,
      STORAGE_KEY_SPARE_PARTS,
      STORAGE_KEY_ACCOUNTS,
      STORAGE_KEY_REGISTERED_TENANTS,
      'military_tenant_users',
      'military_current_logged_user'
    ];

    const addPersonnelIfValid = (p: any) => {
      if (p && typeof p === 'object' && (p.militaryId || p.fullName)) {
        const idKey = (p.militaryId || p.fullName || '').trim().toLowerCase();
        if (idKey && !foundMap.has(idKey)) {
          foundMap.set(idKey, p);
        }
      }
    };

    // 1. Scan memory fast cache (pre-hydrated from IndexedDB)
    try {
      const memEntries = getAllMemoryCachedEntries();
      for (const [k, val] of Object.entries(memEntries)) {
        if (!excludedKeys.some((ex) => k.includes(ex)) && Array.isArray(val) && val.length > 0) {
          const sample = val[0];
          if (sample && typeof sample === 'object' && ('militaryId' in sample || 'fullName' in sample)) {
            val.forEach(addPersonnelIfValid);
          }
        }
      }
    } catch (e) {}

    // 2. Scan standard LocalStorage keys
    try {
      const keysToScan: string[] = [];
      for (let i = 0; i < localStorage.length; i++) {
        const k = localStorage.key(i);
        if (k && !excludedKeys.some((ex) => k.includes(ex))) {
          keysToScan.push(k);
        }
      }

      for (const k of keysToScan) {
        try {
          const raw = localStorage.getItem(k);
          if (!raw || raw.length < 20) continue;
          if (raw.trim().startsWith('[') && raw.trim().endsWith(']')) {
            const parsed = JSON.parse(raw);
            if (Array.isArray(parsed) && parsed.length > 0) {
              const sample = parsed[0];
              if (sample && typeof sample === 'object' && ('militaryId' in sample || 'fullName' in sample) && ('rank' in sample || 'unit' in sample)) {
                parsed.forEach(addPersonnelIfValid);
              }
            }
          }
        } catch (e) {}
      }
    } catch (e) {}

    return this.deduplicatePersonnelList(Array.from(foundMap.values()));
  }

  // Load personnel list
  static getPersonnel(): PersonnelRecord[] {
    const activeTenantId = this.getActiveTenantId();
    if (this.memoizedPersonnel && this.memoizedPersonnel.tenantId === activeTenantId) {
      return this.memoizedPersonnel.data;
    }

    const key = this.getKeyForTenant(STORAGE_KEY_PERSONNEL);
    try {
      let parsed = safeGetLocalItem<PersonnelRecord[]>(key);

      // CRITICAL DATA PRESERVATION RECOVERY:
      // If current tenant key has no personnel records, search ALL keys in LocalStorage on device
      if (!parsed || !Array.isArray(parsed) || parsed.length === 0) {
        const recovered = this.recoverLocalPersonnelFromAllKeys();
        if (recovered && recovered.length > 0) {
          parsed = recovered;
          safeSetLocalItem(key, recovered);
          safeSetLocalItem(STORAGE_KEY_PERSONNEL, recovered);
        }
      }

      if (parsed && Array.isArray(parsed) && parsed.length > 0) {
        let migrationNeeded = false;
        const mapped = parsed.map((p) => {
          // Remove AI/stock/Unsplash placeholder photos from personnel records
          if (p.photoUrl && (p.photoUrl.includes('images.unsplash.com') || p.photoUrl.includes('unsplash.com') || p.photoUrl.includes('placeholder'))) {
            p.photoUrl = '';
            migrationNeeded = true;
          }
          if (p.unit === 'جاهزية العربات والآليات' || p.unit === 'فرع جاهزية العربات والآليات' || (p.unit && p.unit.includes('جاهزية العربات'))) {
            p.unit = 'اللواء الأول';
            migrationNeeded = true;
          }
          if (!p.createdByAccountId) {
            p.createdByAccountId = getAccountIdForUnit(p.unit, 'vehicles_readiness');
            migrationNeeded = true;
          }
          if (!p.logs) {
            p.logs = {
              movement: [],
              attendance: [],
              medical: [],
              financial: [],
              security: [],
              armament: [],
              training: [],
              attachments: [],
              supply: []
            };
          } else {
            if (!p.logs.attachments) {
              p.logs.attachments = Array.isArray(p.attachments) ? p.attachments : [];
            }
            if (!p.logs.supply) {
              p.logs.supply = [];
            }
          }
          if (!p.attachments) {
            p.attachments = p.logs.attachments;
          }

          // Purge default mock sample weapons from personnel armament logs
          const defaultSampleArmamentIds = new Set([
            'arm-1', 'arm-201', 'arm-301', 'arm-401', 'arm-501', 'arm-601',
            'arm-701', 'arm-801', 'arm-901', 'arm-1001', 'arm-1101', 'arm-1201', 'arm-1401'
          ]);
          const defaultSampleSerials = new Set([
            'WPN-SIG-99120', 'WPN-HK-416-08', 'WPN-M4-88410', 'WPN-GLOCK-7711',
            'WPN-SIG-10492', 'WPN-M16-3392', 'WPN-BROWNING-0092', 'WPN-AK47-0912',
            'WPN-SNIPER-ACCURACY-019', 'WPN-G3-55910', 'WPN-MP5-99201', 'WPN-G3-11029',
            'WPN-GLOCK-00911', 'SN-78921'
          ]);
          if (p.logs && Array.isArray(p.logs.armament)) {
            const originalLen = p.logs.armament.length;
            p.logs.armament = p.logs.armament.filter(
              (arm) => !defaultSampleArmamentIds.has(arm.id) && !defaultSampleSerials.has(arm.weaponSerial)
            );
            if (p.logs.armament.length !== originalLen) {
              migrationNeeded = true;
            }
          }
          if (p.armament && (defaultSampleSerials.has(p.armament.serialNumber || p.armament.weaponSerial || '') || p.armament.weaponSerial === 'SN-78921')) {
            delete (p as any).armament;
            migrationNeeded = true;
          }

          return p;
        });

        // Automatically clean and merge any duplicates
        const cleanMapped = this.deduplicatePersonnelList(mapped);
        if (cleanMapped.length !== mapped.length) {
          migrationNeeded = true;
        }

        const { updated, records: processed } = this.checkAndProcessExpiredLeavesAndAbsences(cleanMapped);
        if (updated || migrationNeeded) {
          this.savePersonnel(processed);
        }
        this.memoizedPersonnel = { tenantId: activeTenantId, data: processed };
        return processed;
      }
    } catch (err) {
      console.error('Failed to load personnel from safe storage:', err);
    }

    // Check if user has previously saved personnel data on this device
    const hasPriorSavedData = hasUserSavedDataOnDevice(key) || hasUserSavedDataOnDevice();

    // Default fallback: return initial personnel as transient in-memory view WITHOUT saving to disk (prevents overwriting user data on slow startup)
    if (this.getActiveTenantId() === 'tenant-hq-main' && !hasPriorSavedData) {
      const mappedInitial = INITIAL_PERSONNEL.map(p => {
        if (p.unit === 'جاهزية العربات والآليات' || p.unit === 'فرع جاهزية العربات والآليات' || (p.unit && p.unit.includes('جاهزية العربات'))) {
          return { ...p, unit: 'اللواء الأول' };
        }
        return p;
      });
      const cleanInitial = this.deduplicatePersonnelList(mappedInitial);
      this.memoizedPersonnel = { tenantId: activeTenantId, data: cleanInitial };
      return cleanInitial;
    }
    
    // If user previously had data, return memoized or empty without wiping the database
    if (this.memoizedPersonnel && this.memoizedPersonnel.tenantId === activeTenantId && this.memoizedPersonnel.data.length > 0) {
      return this.memoizedPersonnel.data;
    }

    this.memoizedPersonnel = { tenantId: activeTenantId, data: [] };
    return [];
  }

  // Grant Leave or Permission directly
  static grantLeaveOrPermission(
    militaryId: string,
    grantType: 'إجازة' | 'إذن',
    details: {
      leaveType?: string;
      permissionType?: string;
      durationDays: number;
      startDate: string;
      endDate: string;
      reason: string;
      approvedBy: string;
      notes?: string;
      withWeapon?: boolean;
      weaponDetails?: {
        primaryWeapon?: {
          weaponType: string;
          weaponSerial: string;
          magazinesCount: number;
          ammoCount: number;
          notes?: string;
        };
        additionalWeapons?: Array<{
          weaponType: string;
          weaponSerial: string;
          magazinesCount: number;
          ammoCount: number;
          notes?: string;
        }>;
        custodyNotes?: string;
        totalAmmo?: number;
        totalMagazines?: number;
      };
    },
    actingUser: string,
    actingDept: DepartmentRole
  ): boolean {
    const list = this.getPersonnel();
    const person = list.find((p) => p.militaryId === militaryId);
    if (!person) return false;

    const oldStatus = person.currentStatus;
    const targetStatus: PersonnelStatus = grantType === 'إجازة' ? 'إجازة' : 'إذن';
    person.currentStatus = targetStatus;

    const newAttLog: AttendanceLog = {
      id: `att-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
      date: new Date().toISOString().split('T')[0],
      type: grantType,
      leaveType: details.leaveType,
      permissionType: details.permissionType,
      reason: details.reason || `منح ${grantType} (${details.leaveType || details.permissionType || 'رسمي'})`,
      durationDays: details.durationDays,
      startDate: details.startDate,
      endDate: details.endDate,
      approvedBy: details.approvedBy || actingUser || 'إدارة الموارد البشرية والقيادة',
      notes: details.notes,
      withWeapon: details.withWeapon,
      weaponDetails: details.weaponDetails
    };

    if (!person.logs.attendance) {
      person.logs.attendance = [];
    }
    person.logs.attendance.unshift(newAttLog);

    this.savePersonnel(list);

    this.logAction(
      actingUser,
      actingDept,
      `مصادقة منح ${grantType}`,
      militaryId,
      person.fullName,
      `منح ${grantType} نوع: (${details.leaveType || details.permissionType || 'عام'}) - المدة: ${details.durationDays} يوم - ينتهي في: ${details.endDate} - المعتمد: ${details.approvedBy}`
    );

    return true;
  }

  // Save personnel list
  static savePersonnel(records: PersonnelRecord[], source = 'حفظ النظام'): void {
    try {
      const activeTenantId = this.getActiveTenantId();
      const currentLocal = this.memoizedPersonnel?.data || [];
      const countBefore = currentLocal.length;

      const cleanRecords = this.deduplicatePersonnelList(records);
      this.memoizedPersonnel = { tenantId: activeTenantId, data: cleanRecords };
      const key = this.getKeyForTenant(STORAGE_KEY_PERSONNEL);
      const cloudDocId = this.getCloudDocIdForTenant('personnel');

      safeSetLocalItem(key, cleanRecords);
      safeSetLocalItem(STORAGE_KEY_PERSONNEL, cleanRecords);
      syncDocToCloud(cloudDocId, cleanRecords);
      syncDocToCloud('personnel_tenant-hq-main', cleanRecords);

      // Log storage operation
      this.logStorageOperation({
        type: 'SAVE_PERSONNEL',
        actor: source,
        actorDepartment: 'إدارة الموارد البشرية',
        tenantId: activeTenantId,
        countBefore,
        countAfter: cleanRecords.length,
        deltaCount: cleanRecords.length - countBefore,
        status: 'نجاح',
        details: `تم حفظ (${cleanRecords.length}) فرد في التخزين المحلي والمزامنة مع قاعدة بيانات Firebase السحابية [المصدر: ${source}].`
      });

      notifyDataChange();
    } catch (err) {
      console.error('Failed to save personnel:', err);
      this.logStorageOperation({
        type: 'SAVE_PERSONNEL',
        actor: source,
        actorDepartment: 'إدارة الموارد البشرية',
        tenantId: this.getActiveTenantId(),
        status: 'خطأ',
        details: `فشل حفظ بيانات الأفراد: ${err instanceof Error ? err.message : String(err)}`
      });
    }
  }

  // Recycle Bin (سلة المحذوفات) - 30 days retention
  static getRecycleBin(): RecycledPersonnel[] {
    try {
      const key = this.getKeyForTenant(STORAGE_KEY_RECYCLE_BIN);
      const parsed = safeGetLocalItem<RecycledPersonnel[]>(key);
      if (parsed) {
        const now = new Date().getTime();
        const thirtyDaysMs = 30 * 24 * 60 * 60 * 1000;

        // Auto-purge items older than 30 days
        const validItems = parsed.filter((item) => {
          const deletedTime = new Date(item.deletedAt).getTime();
          return now - deletedTime < thirtyDaysMs;
        });

        if (validItems.length !== parsed.length) {
          this.saveRecycleBin(validItems);
        }
        return validItems;
      }
    } catch (err) {
      console.error('Failed to load recycle bin:', err);
    }
    return [];
  }

  static saveRecycleBin(items: RecycledPersonnel[]): void {
    try {
      const key = this.getKeyForTenant(STORAGE_KEY_RECYCLE_BIN);
      const cloudDocId = this.getCloudDocIdForTenant('recycle_bin');
      safeSetLocalItem(key, items);
      syncDocToCloud(cloudDocId, items);
      notifyDataChange();
    } catch (err) {
      console.error('Failed to save recycle bin:', err);
    }
  }

  // Soft-delete personnel record to recycle bin
  static deletePersonnelToRecycleBin(
    militaryId: string,
    userName: string = 'المستخدم',
    department: DepartmentRole = 'إدارة الموارد البشرية',
    reason: string = 'تم النقل إلى سلة المحذوفات',
    targetRecord?: PersonnelRecord
  ): boolean {
    const personnel = this.getPersonnel();
    if (personnel.length === 0) return false;
    const countBefore = personnel.length;

    // Locate precise index of target record in personnel array
    let targetIndex = -1;

    if (targetRecord) {
      targetIndex = personnel.findIndex(
        (p) =>
          p === targetRecord ||
          (p.militaryId === targetRecord.militaryId &&
            p.unit === targetRecord.unit &&
            p.fullName === targetRecord.fullName &&
            (p.nationalId || '') === (targetRecord.nationalId || ''))
      );
    }

    if (targetIndex === -1) {
      targetIndex = personnel.findIndex((p) => p.militaryId === militaryId);
    }

    if (targetIndex === -1) return false;

    const target = personnel[targetIndex];

    // Remove ONLY the single target record at targetIndex from active personnel
    const updatedPersonnel = personnel.filter((_, idx) => idx !== targetIndex);
    this.savePersonnel(updatedPersonnel, `حذف فرد (${target.fullName})`);

    // Add to recycle bin
    const recycleBin = this.getRecycleBin();
    const trashItem: RecycledPersonnel = {
      id: `trash-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
      personnel: target,
      deletedAt: new Date().toISOString(),
      deletedBy: userName,
      reason
    };
    this.saveRecycleBin([trashItem, ...recycleBin]);

    // Storage diagnostic logging
    this.logStorageOperation({
      type: 'DELETE_PERSONNEL',
      actor: userName,
      actorDepartment: department,
      tenantId: this.getActiveTenantId(),
      militaryId: target.militaryId,
      fullName: target.fullName,
      rank: target.rank,
      unit: target.unit,
      countBefore,
      countAfter: updatedPersonnel.length,
      deltaCount: -1,
      status: 'نجاح',
      details: `تم حذف الفرد (${target.rank} / ${target.fullName}) [الرقم العسكري: ${target.militaryId}] ونقله إلى سلة المحذوفات. السبب: ${reason}`
    });

    // Audit log & alert
    this.logAction(
      userName,
      department,
      'نقل إلى سلة المحذوفات',
      target.militaryId,
      target.fullName,
      `تم نقل بيانات الفرد (${target.rank} / ${target.fullName}) [الوحدة: ${target.unit}] إلى سلة المحذوفات.`
    );

    return true;
  }

  // Restore personnel from recycle bin back to active list
  static restorePersonnelFromRecycleBin(
    trashId: string,
    userName: string = 'المستخدم',
    department: DepartmentRole = 'إدارة الموارد البشرية'
  ): boolean {
    const recycleBin = this.getRecycleBin();
    const targetItem = recycleBin.find((item) => item.id === trashId);
    if (!targetItem) return false;

    // Remove from recycle bin
    const updatedBin = recycleBin.filter((item) => item.id !== trashId);
    this.saveRecycleBin(updatedBin);

    // Add back to active personnel list if not already present
    const personnel = this.getPersonnel();
    const countBefore = personnel.length;
    let newCount = countBefore;
    if (!personnel.some((p) => p.militaryId === targetItem.personnel.militaryId)) {
      const restoredList = [targetItem.personnel, ...personnel];
      newCount = restoredList.length;
      this.savePersonnel(restoredList, `استعادة فرد (${targetItem.personnel.fullName})`);
    }

    // Storage diagnostic logging
    this.logStorageOperation({
      type: 'RESTORE_PERSONNEL',
      actor: userName,
      actorDepartment: department,
      tenantId: this.getActiveTenantId(),
      militaryId: targetItem.personnel.militaryId,
      fullName: targetItem.personnel.fullName,
      rank: targetItem.personnel.rank,
      unit: targetItem.personnel.unit,
      countBefore,
      countAfter: newCount,
      deltaCount: newCount - countBefore,
      status: 'نجاح',
      details: `تمت استعادة الفرد (${targetItem.personnel.rank} / ${targetItem.personnel.fullName}) من سلة المحذوفات إلى القوة العاملة.`
    });

    // Audit log
    this.logAction(
      userName,
      department,
      'استعادة من سلة المحذوفات',
      targetItem.personnel.militaryId,
      targetItem.personnel.fullName,
      `تمت استعادة الفرد (${targetItem.personnel.rank} / ${targetItem.personnel.fullName}) بنجاح وإعادة تفعيل ملفه بقوة القوات.`
    );

    return true;
  }

  // Permanently delete single personnel record from recycle bin
  static permanentlyDeleteFromRecycleBin(
    trashId: string,
    userName: string = 'المستخدم',
    department: DepartmentRole = 'إدارة الموارد البشرية'
  ): boolean {
    const recycleBin = this.getRecycleBin();
    const targetItem = recycleBin.find((item) => item.id === trashId);
    if (!targetItem) return false;

    const updatedBin = recycleBin.filter((item) => item.id !== trashId);
    this.saveRecycleBin(updatedBin);

    this.logAction(
      userName,
      department,
      'حذف نهائي',
      targetItem.personnel.militaryId,
      targetItem.personnel.fullName,
      `تم مسح سجل وحسُاب البيانات العسكرية للفرد (${targetItem.personnel.fullName}) نهائياً من سلة المحذوفات.`
    );

    return true;
  }

  // Empty entire recycle bin
  static clearRecycleBin(
    userName: string = 'المستخدم',
    department: DepartmentRole = 'إدارة الموارد البشرية'
  ): void {
    const recycleBin = this.getRecycleBin();
    this.saveRecycleBin([]);

    this.logAction(
      userName,
      department,
      'إفراغ سلة المحذوفات',
      '-',
      'الكل',
      `تم إفراغ سلة المحذوفات وحذف (${recycleBin.length}) سجل عسكري نهائياً.`
    );
  }

  // Load audit logs
  static getAuditLogs(): AuditLogEntry[] {
    const activeTenantId = this.getActiveTenantId();
    if (this.memoizedAuditLogs && this.memoizedAuditLogs.tenantId === activeTenantId) {
      return this.memoizedAuditLogs.data;
    }

    const key = this.getKeyForTenant(STORAGE_KEY_AUDIT);
    try {
      const parsed = safeGetLocalItem<AuditLogEntry[]>(key);
      if (parsed && Array.isArray(parsed) && parsed.length > 0) {
        this.memoizedAuditLogs = { tenantId: activeTenantId, data: parsed };
        return parsed;
      }
    } catch (err) {
      console.error('Failed to load audit logs:', err);
    }
    if (!hasUserSavedDataOnDevice(key) && !hasUserSavedDataOnDevice() && this.getActiveTenantId() === 'tenant-hq-main') {
      this.saveAuditLogs(INITIAL_AUDIT_LOGS);
      this.memoizedAuditLogs = { tenantId: activeTenantId, data: INITIAL_AUDIT_LOGS };
      return INITIAL_AUDIT_LOGS;
    }
    this.memoizedAuditLogs = { tenantId: activeTenantId, data: [] };
    return [];
  }

  // Save audit logs
  static saveAuditLogs(logs: AuditLogEntry[]): void {
    try {
      const activeTenantId = this.getActiveTenantId();
      this.memoizedAuditLogs = { tenantId: activeTenantId, data: logs };
      const key = this.getKeyForTenant(STORAGE_KEY_AUDIT);
      const cloudDocId = this.getCloudDocIdForTenant('audit_logs');
      localStorage.setItem(key, JSON.stringify(logs));
      syncDocToCloud(cloudDocId, logs);
      notifyDataChange();
    } catch (err) {
      console.error('Failed to save audit logs:', err);
    }
  }

  // Add audit log entry
  static logAction(
    userName: string,
    department: DepartmentRole,
    action: string,
    targetMilitaryId: string,
    targetName: string,
    details: string,
    accountId?: string,
    accountName?: string
  ): void {
    const currentLogs = this.getAuditLogs();
    const now = new Date();
    const formattedDate = `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, '0')}-${String(
      now.getDate()
    ).padStart(2, '0')} ${String(now.getHours()).padStart(2, '0')}:${String(now.getMinutes()).padStart(
      2,
      '0'
    )}:${String(now.getSeconds()).padStart(2, '0')}`;

    let effAccountId = accountId;
    let effAccountName = accountName;

    if (!effAccountId && typeof window !== 'undefined') {
      const activeCode = localStorage.getItem('military_active_account_v1');
      if (activeCode) {
        const found = getAllAccounts().find(
          (a) => a.id === activeCode || a.shortCode === activeCode || a.customAccessKey === activeCode
        );
        if (found) {
          effAccountId = found.id;
          effAccountName = found.name;
        }
      }
    }

    if (!effAccountId) {
      effAccountId = 'hq';
      effAccountName = 'لواء القيادة';
    }

    const newLog: AuditLogEntry = {
      id: `aud-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
      timestamp: formattedDate,
      userName,
      department,
      accountId: effAccountId,
      accountName: effAccountName,
      action,
      targetMilitaryId,
      targetName,
      details
    };

    const updated = [newLog, ...currentLogs];
    this.saveAuditLogs(updated);

    // Automatically create real-time alert for Main Command / Notification center on data modifications
    if (targetMilitaryId && targetMilitaryId !== '-' && targetMilitaryId !== 'الكل') {
      this.addAlert({
        title: `تحديث بيانات: ${targetName} (${action})`,
        description: `قام المستخدم (${userName} - ${department} - ${effAccountName}) بإجراء: ${action}. التفاصيل: ${details}`,
        level: action.includes('حرج') || action.includes('فرار') || action.includes('مخالفة') ? 'urgent' : 'info',
        militaryId: targetMilitaryId
      });
    }
  }

  // Dismissed Alert IDs Storage
  static getDismissedAlertIds(): string[] {
    try {
      const data = localStorage.getItem('military_hr_dismissed_alerts_v1');
      if (data) return JSON.parse(data);
    } catch (err) {
      console.error('Failed to load dismissed alerts:', err);
    }
    return [];
  }

  static dismissAlert(alertId: string): void {
    const dismissed = this.getDismissedAlertIds();
    if (!dismissed.includes(alertId)) {
      const updated = [...dismissed, alertId];
      localStorage.setItem('military_hr_dismissed_alerts_v1', JSON.stringify(updated));
      syncDocToCloud('dismissed_alerts', updated);
    }
    this.deleteAlert(alertId);
    notifyDataChange();
  }

  static deleteAlert(alertId: string): void {
    const alerts = this.getAlerts();
    const updated = alerts.filter((a) => a.id !== alertId);
    this.saveAlerts(updated);
  }

  static clearAllAlerts(): void {
    const alerts = this.getAlerts();
    const dismissed = this.getDismissedAlertIds();
    const allIds = alerts.map((a) => a.id);
    const combinedDismissed = Array.from(new Set([...dismissed, ...allIds]));
    localStorage.setItem('military_hr_dismissed_alerts_v1', JSON.stringify(combinedDismissed));
    syncDocToCloud('dismissed_alerts', combinedDismissed);
    this.saveAlerts([]);
  }

  // Get alerts
  static getAlerts(): SystemAlert[] {
    const activeTenantId = this.getActiveTenantId();
    if (this.memoizedAlerts && this.memoizedAlerts.tenantId === activeTenantId) {
      return this.memoizedAlerts.data;
    }

    const key = this.getKeyForTenant(STORAGE_KEY_ALERTS);
    try {
      const parsed = safeGetLocalItem<SystemAlert[]>(key);
      if (parsed && Array.isArray(parsed) && parsed.length > 0) {
        this.memoizedAlerts = { tenantId: activeTenantId, data: parsed };
        return parsed;
      }
    } catch (err) {
      console.error('Failed to load alerts:', err);
    }
    if (!hasUserSavedDataOnDevice(key) && !hasUserSavedDataOnDevice() && this.getActiveTenantId() === 'tenant-hq-main') {
      this.saveAlerts(INITIAL_ALERTS);
      this.memoizedAlerts = { tenantId: activeTenantId, data: INITIAL_ALERTS };
      return INITIAL_ALERTS;
    }
    this.memoizedAlerts = { tenantId: activeTenantId, data: [] };
    return [];
  }

  // Save alerts
  static saveAlerts(alerts: SystemAlert[]): void {
    try {
      const activeTenantId = this.getActiveTenantId();
      this.memoizedAlerts = { tenantId: activeTenantId, data: alerts };
      const key = this.getKeyForTenant(STORAGE_KEY_ALERTS);
      const cloudDocId = this.getCloudDocIdForTenant('alerts');
      localStorage.setItem(key, JSON.stringify(alerts));
      syncDocToCloud(cloudDocId, alerts);
      notifyDataChange();
    } catch (err) {
      console.error('Failed to save alerts:', err);
    }
  }

  // Add new alert
  static addAlert(alert: Omit<SystemAlert, 'id' | 'date'>): void {
    const alerts = this.getAlerts();
    const today = new Date().toISOString().split('T')[0];

    let activeAccId = (alert as any).createdByAccountId;
    if (!activeAccId && typeof window !== 'undefined') {
      const activeCode = localStorage.getItem('military_active_account_v1');
      if (activeCode) {
        const found = BRIGADE_ACCOUNTS.find(
          (a) => a.id === activeCode || a.shortCode === activeCode || a.customAccessKey === activeCode
        );
        if (found) {
          activeAccId = found.id;
        }
      }
    }

    const newAlert: SystemAlert = {
      ...alert,
      createdByAccountId: activeAccId || 'hq',
      id: `alt-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
      date: today
    };
    this.saveAlerts([newAlert, ...alerts]);
  }

  // Get single personnel by ID
  static getPersonnelById(militaryId: string): PersonnelRecord | undefined {
    const list = this.getPersonnel();
    return list.find((p) => p.militaryId === militaryId);
  }

  // Check for duplicate personnel by militaryId, nationalId, or fullName
  static checkForDuplicatePersonnel(
    militaryId: string,
    nationalId?: string,
    fullName?: string,
    excludeMilitaryId?: string
  ): PersonnelRecord | undefined {
    const list = this.getPersonnel();
    const cleanMil = militaryId ? militaryId.trim().toLowerCase() : '';
    const cleanNat = nationalId ? nationalId.trim() : '';
    const cleanName = fullName ? fullName.trim().toLowerCase() : '';

    return list.find((p) => {
      if (excludeMilitaryId && p.militaryId === excludeMilitaryId) return false;

      if (cleanMil && String(p.militaryId || '').toLowerCase() === cleanMil) return true;
      if (cleanNat && cleanNat.length > 3 && p.nationalId && p.nationalId === cleanNat) return true;
      if (cleanName && cleanName.length > 5 && String(p.fullName || '').trim().toLowerCase() === cleanName) return true;

      return false;
    });
  }

  // Add new personnel
  static addPersonnel(
    personnel: PersonnelRecord,
    actingUser = 'مسؤول الموارد البشرية',
    actingDept: DepartmentRole = 'إدارة الموارد البشرية'
  ): void {
    const today = new Date().toISOString().split('T')[0];
    const list = this.getPersonnel();

    let activeAccId = 'hq';
    if (typeof window !== 'undefined') {
      const activeCode = localStorage.getItem('military_active_account_v1');
      if (activeCode) {
        const found = BRIGADE_ACCOUNTS.find(
          (a) => a.id === activeCode || a.shortCode === activeCode || a.customAccessKey === activeCode
        );
        if (found) {
          activeAccId = found.id;
        }
      }
    }
    personnel.createdByAccountId = getAccountIdForUnit(personnel.unit, personnel.createdByAccountId || activeAccId);

    // Check for duplicate soldier on system
    const existing = this.checkForDuplicatePersonnel(personnel.militaryId, personnel.nationalId, personnel.fullName);

    if (existing) {
      const timeStr = `${today} ${new Date().toLocaleTimeString('ar-SA')}`;
      this.addAlert({
        level: 'urgent',
        title: '🚨 إنذار إدخال متكرر بين الحسابات (تكرار بيانات فرد)',
        description: `تم رصد عملية إدخال متكررة للفرد (${personnel.rank} / ${personnel.fullName}). الفرد مُسجّل أصلاً لدى (${existing.unit}). الحساب المنفذ للإدخال الجديد: (${actingUser} - ${personnel.unit}).`,
        militaryId: personnel.militaryId,
        isDuplicateAlert: true,
        duplicateDetails: {
          militaryId: personnel.militaryId,
          nationalId: personnel.nationalId || existing.nationalId || '-',
          fullName: personnel.fullName,
          rank: personnel.rank,
          originalAccount: existing.unit,
          originalUnit: existing.unit,
          attemptedAccount: personnel.unit,
          attemptedUnit: personnel.unit,
          attemptedUser: actingUser,
          timestamp: timeStr
        }
      });

      this.logAction(
        actingUser,
        actingDept,
        '🚨 إدخال متكرر بين الحسابات',
        personnel.militaryId,
        personnel.fullName,
        `تكرار إدخال بيانات الفرد (${personnel.fullName}). الحساب المسجل أصلاً: (${existing.unit}). الحساب المنفذ للإدخال المتكرر: (${personnel.unit})`
      );
    }

    if (!personnel.logs) {
      personnel.logs = {
        movement: [],
        attendance: [],
        medical: [],
        financial: [],
        security: [],
        armament: [],
        training: [],
        attachments: []
      };
    }
    if (!personnel.logs.attendance) {
      personnel.logs.attendance = [];
    }

    if (personnel.logs.attendance.length === 0) {
      const initialLog: AttendanceLog = {
        id: `att-${Date.now()}`,
        date: today,
        startDate: today,
        type:
          personnel.currentStatus === 'إجازة'
            ? 'إجازة'
            : personnel.currentStatus === 'إذن'
            ? 'إذن'
            : personnel.currentStatus === 'مستشفى'
            ? 'احتجاز'
            : personnel.currentStatus === 'فرار'
            ? 'فرار'
            : personnel.currentStatus === 'غياب'
            ? 'غياب'
            : personnel.currentStatus === 'موقوف'
            ? 'احتجاز'
            : 'حضور',
        reason: `إدراج وحصر جديد للفرد برتبة (${personnel.rank}) وحالة جاهزية مبدئية: ${personnel.currentStatus}`,
        durationDays: 1,
        approvedBy: actingUser
      };
      personnel.logs.attendance.push(initialLog);
    }

    const cleanNameStr = (str: string) => str ? str.trim().toLowerCase().replace(/[\u064B-\u0652]/g, '').replace(/[أإآ]/g, 'ا').replace(/ة/g, 'ه').replace(/ى/g, 'ي').replace(/\s+/g, ' ') : '';
    const targetName = cleanNameStr(personnel.fullName);
    const targetMil = personnel.militaryId ? personnel.militaryId.trim().toLowerCase() : '';
    const targetNat = personnel.nationalId && personnel.nationalId.trim().length > 5 && personnel.nationalId !== '0000000000' ? personnel.nationalId.trim() : '';

    const existingIndex = list.findIndex((p) => {
      const pMil = p.militaryId ? p.militaryId.trim().toLowerCase() : '';
      const pNat = p.nationalId && p.nationalId.trim().length > 5 && p.nationalId !== '0000000000' ? p.nationalId.trim() : '';
      const pName = cleanNameStr(p.fullName);

      // Strict matching to prevent erasing different personnel who have common Arabic names
      if (targetMil && pMil) return targetMil === pMil;
      if (targetNat && pNat) return targetNat === pNat;
      if (!targetMil && !pMil && !targetNat && !pNat) {
        return targetName === pName && p.unit === personnel.unit && p.rank === personnel.rank;
      }
      return false;
    });

    const countBefore = list.length;
    let updated: PersonnelRecord[];
    const isUpdate = existingIndex >= 0;
    if (isUpdate) {
      updated = [...list];
      updated[existingIndex] = personnel;
    } else {
      updated = [personnel, ...list];
    }
    this.savePersonnel(updated, isUpdate ? `تعديل فرد (${personnel.fullName})` : `إضافة فرد جديد (${personnel.fullName})`);

    // Storage diagnostic audit logging
    this.logStorageOperation({
      type: isUpdate ? 'UPDATE_PERSONNEL' : 'ADD_PERSONNEL',
      actor: actingUser,
      actorDepartment: actingDept,
      tenantId: this.getActiveTenantId(),
      militaryId: personnel.militaryId,
      fullName: personnel.fullName,
      rank: personnel.rank,
      unit: personnel.unit,
      countBefore,
      countAfter: updated.length,
      deltaCount: isUpdate ? 0 : 1,
      status: 'نجاح',
      details: isUpdate
        ? `تم تحديث بيانات الفرد (${personnel.rank} / ${personnel.fullName}) [الرقم العسكري: ${personnel.militaryId}].`
        : `تمت إضافة فرد جديد بنجاح: (${personnel.rank} / ${personnel.fullName}) [الرقم العسكري: ${personnel.militaryId}] إلى قوة (${personnel.unit}) بحالة (${personnel.currentStatus}).`
    });

    // Synchronize default rank salary into payroll system for newly added personnel
    this.updateSalaryOnRankChange(personnel.militaryId, personnel.rank, undefined, personnel.jobTitle);

    this.logAction(
      actingUser,
      actingDept,
      'إضافة فرد جديد',
      personnel.militaryId,
      personnel.fullName,
      `تم إدراج الفرد برتبة ${personnel.rank} بالوحدة ${personnel.unit} بحالة جاهزية (${personnel.currentStatus})`
    );

    this.addAlert({
      level: 'warning',
      title: 'تحديث جاهزية - إضافة فرد جديد',
      description: `تم إضافة الفرد (${personnel.rank} / ${personnel.fullName}) رسمياً إلى قوة (${personnel.unit}) بحالة ${personnel.currentStatus}`,
      militaryId: personnel.militaryId
    });
  }

  // Update existing personnel basic info or status
  static updatePersonnel(
    updatedRecord: PersonnelRecord,
    actingUser = 'مسؤول الموارد البشرية',
    actingDept: DepartmentRole = 'إدارة الموارد البشرية',
    actionNote = 'تحديث بيانات الفرد',
    originalMilitaryId?: string
  ): void {
    const list = this.getPersonnel();
    const searchId = originalMilitaryId || updatedRecord.militaryId;
    const index = list.findIndex(
      (p) => (searchId && p.militaryId === searchId) || (updatedRecord.nationalId && updatedRecord.nationalId.length > 5 && p.nationalId === updatedRecord.nationalId)
    );

    if (index !== -1) {
      const oldRecord = list[index];
      updatedRecord.createdByAccountId = getAccountIdForUnit(
        updatedRecord.unit || oldRecord.unit,
        updatedRecord.createdByAccountId || oldRecord.createdByAccountId || 'hq'
      );
      const oldRank = oldRecord.rank;
      const oldJobTitle = oldRecord.jobTitle || 'غير محدد';
      const oldUnit = oldRecord.unit;
      const oldBattalion = oldRecord.battalion || 'غير محدد';
      const oldCompany = oldRecord.company || 'غير محدد';
      const oldStatus = oldRecord.currentStatus;

      const rankChanged = oldRank !== updatedRecord.rank;
      const jobChanged = oldJobTitle !== updatedRecord.jobTitle;
      const unitChanged = oldUnit !== updatedRecord.unit;
      const battalionChanged = oldBattalion !== updatedRecord.battalion;
      const companyChanged = oldCompany !== updatedRecord.company;
      const statusChanged = oldStatus !== updatedRecord.currentStatus;

      // Preserve existing logs or initialize
      if (!updatedRecord.logs) {
        updatedRecord.logs = oldRecord.logs || {
          movement: [],
          attendance: [],
          medical: [],
          financial: [],
          security: [],
          armament: [],
          training: [],
          attachments: [],
          supply: []
        };
      } else {
        updatedRecord.logs = {
          ...oldRecord.logs,
          ...updatedRecord.logs
        };
      }

      const changes: string[] = [];
      if (rankChanged) changes.push(`تعديل الرتبة من (${oldRank}) إلى (${updatedRecord.rank})`);
      if (jobChanged) changes.push(`تعديل الوظيفة من (${oldJobTitle}) إلى (${updatedRecord.jobTitle})`);
      if (unitChanged) changes.push(`تعديل الوحدة من (${oldUnit}) إلى (${updatedRecord.unit})`);
      if (battalionChanged) changes.push(`تعديل الكتيبة من (${oldBattalion}) إلى (${updatedRecord.battalion})`);
      if (companyChanged) changes.push(`تعديل السرية من (${oldCompany}) إلى (${updatedRecord.company})`);
      if (statusChanged) changes.push(`تعديل الحالة من (${oldStatus}) إلى (${updatedRecord.currentStatus})`);

      // Prepend movement log if rank, job title, unit, battalion, company or status changed
      if (rankChanged || jobChanged || unitChanged || battalionChanged || companyChanged || statusChanged) {
        const isTransfer = unitChanged || battalionChanged;

        const newMoveLog: MovementLog = {
          id: `mov-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
          date: new Date().toISOString().split('T')[0],
          type: isTransfer ? 'نقل' : 'تعديل وظيفة ورتبة',
          fromUnit: `${oldUnit} - ${oldBattalion}`,
          toUnit: `${updatedRecord.unit} - ${updatedRecord.battalion}`,
          reason: `تحديث سجـل الترافق والتنقل الإداري للفرد: [${changes.join(' | ')}]`,
          orderReference: `أمر إداري صادر من (${actingUser})`,
          effectiveDate: new Date().toISOString().split('T')[0]
        };

        if (!updatedRecord.logs.movement) {
          updatedRecord.logs.movement = [];
        }
        updatedRecord.logs.movement.unshift(newMoveLog);
      }

      list[index] = updatedRecord;
      this.savePersonnel(list, `تحديث فرد (${updatedRecord.fullName})`);

      // Storage diagnostic audit logging
      this.logStorageOperation({
        type: 'UPDATE_PERSONNEL',
        actor: actingUser,
        actorDepartment: actingDept,
        tenantId: this.getActiveTenantId(),
        militaryId: updatedRecord.militaryId,
        fullName: updatedRecord.fullName,
        rank: updatedRecord.rank,
        unit: updatedRecord.unit,
        countBefore: list.length,
        countAfter: list.length,
        deltaCount: 0,
        status: 'نجاح',
        details: `${actionNote}: (${updatedRecord.rank} / ${updatedRecord.fullName}) [الرقم العسكري: ${updatedRecord.militaryId}]`,
        changesSummary: changes.length > 0 ? changes : ['تحديث بيانات شخصية/إدارية']
      });

      // Automatically update salary in the payroll system if rank or job title was changed
      if (rankChanged || jobChanged) {
        this.updateSalaryOnRankChange(updatedRecord.militaryId, updatedRecord.rank, oldRank, updatedRecord.jobTitle);
      }

      const statusNote = statusChanged
        ? ` (تغيرت الحالة من ${oldStatus} إلى ${updatedRecord.currentStatus})`
        : '';

      this.logAction(
        actingUser,
        actingDept,
        'تحديث بيانات الفرد',
        updatedRecord.militaryId,
        updatedRecord.fullName,
        `${actionNote} [الرتبة: ${updatedRecord.rank} - الوظيفة: ${updatedRecord.jobTitle}]${statusNote}`
      );
    } else {
      this.addPersonnel(updatedRecord, actingUser, actingDept);
    }
  }

  // Get list of personnel replacement records
  static getReplacements(): PersonnelReplacementRecord[] {
    try {
      const parsed = safeGetLocalItem<PersonnelReplacementRecord[]>(STORAGE_KEY_REPLACEMENTS);
      if (parsed && Array.isArray(parsed)) {
        return parsed;
      }
    } catch (e) {
      console.error('Failed to load replacement records:', e);
    }
    return [];
  }

  // Save replacement records
  static saveReplacements(list: PersonnelReplacementRecord[]): void {
    safeSetLocalItem(STORAGE_KEY_REPLACEMENTS, list);
    syncDocToCloud('replacements', list);
    notifyDataChange();
  }

  // --- Emergency Recall Logs Archive (نماذج استدعاء الطوارئ المطبوعة) ---
  static getEmergencyRecallLogs(): EmergencyRecallLog[] {
    const activeTenantId = this.getActiveTenantId();
    if (this.memoizedEmergencyRecalls && this.memoizedEmergencyRecalls.tenantId === activeTenantId) {
      return this.memoizedEmergencyRecalls.data;
    }

    try {
      const key = this.getKeyForTenant(STORAGE_KEY_EMERGENCY_RECALLS);
      const data = localStorage.getItem(key);
      if (data !== null) {
        const parsed: EmergencyRecallLog[] = JSON.parse(data);
        if (Array.isArray(parsed)) {
          this.memoizedEmergencyRecalls = { tenantId: activeTenantId, data: parsed };
          return parsed;
        }
      }
    } catch (err) {
      console.error('Failed to load emergency recall logs:', err);
    }

    const defaultLogs = (activeTenantId === 'tenant-hq-main' || activeTenantId.includes('hq'))
      ? (INITIAL_EMERGENCY_RECALL_LOGS as EmergencyRecallLog[])
      : [];

    this.saveEmergencyRecallLogs(defaultLogs);
    this.memoizedEmergencyRecalls = { tenantId: activeTenantId, data: defaultLogs };
    return defaultLogs;
  }

  static saveEmergencyRecallLogs(logs: EmergencyRecallLog[]): void {
    try {
      const activeTenantId = this.getActiveTenantId();
      this.memoizedEmergencyRecalls = { tenantId: activeTenantId, data: logs };
      const key = this.getKeyForTenant(STORAGE_KEY_EMERGENCY_RECALLS);
      const cloudDocId = this.getCloudDocIdForTenant('emergency_recall_logs');
      localStorage.setItem(key, JSON.stringify(logs));
      syncDocToCloud(cloudDocId, logs);
      notifyDataChange();
    } catch (err) {
      console.error('Failed to save emergency recall logs:', err);
    }
  }

  static addEmergencyRecallLog(log: EmergencyRecallLog): EmergencyRecallLog {
    const currentLogs = this.getEmergencyRecallLogs();
    const updated = [log, ...currentLogs];
    this.saveEmergencyRecallLogs(updated);

    // Log to Audit Trail
    this.logAction(
      log.issuedByOfficer || 'القيادة والسيطرة',
      'إدارة الموارد البشرية',
      'إصدار وأرشفة نموذج استدعاء طوارئ',
      log.missionCode,
      log.id,
      `تم إصدار وأرشفة نموذج استدعاء طوارئ رقم (${log.id}) برمز المهمة (${log.missionCode}) يستهدف عدد (${log.targetPersonnelCount}) فرد/ضابط.`
    );

    return log;
  }

  static deleteEmergencyRecallLog(id: string): void {
    const currentLogs = this.getEmergencyRecallLogs();
    const updated = currentLogs.filter((l) => l.id !== id);
    this.saveEmergencyRecallLogs(updated);

    this.logAction(
      'ضابط السيطرة',
      'الاستخبارات والأمن',
      'حذف سجل استدعاء طوارئ مؤرشف',
      id,
      id,
      `تم حذف سجل نموذج استدعاء الطوارئ رقم (${id}) من الأرشيف العسكري.`
    );
  }

  static deleteMultipleEmergencyRecallLogs(ids: string[]): void {
    const idSet = new Set(ids);
    const currentLogs = this.getEmergencyRecallLogs();
    const updated = currentLogs.filter((l) => !idSet.has(l.id));
    this.saveEmergencyRecallLogs(updated);

    this.logAction(
      'ضابط السيطرة',
      'الاستخبارات والأمن',
      'حذف متعدد لسجلات استدعاء طوارئ',
      `COUNT_${ids.length}`,
      ids.join(', '),
      `تم حذف (${ids.length}) سجل من أرشيف استدعاءات الطوارئ.`
    );
  }

  static clearAllEmergencyRecallLogs(): void {
    const currentCount = this.getEmergencyRecallLogs().length;
    this.saveEmergencyRecallLogs([]);

    this.logAction(
      'ضابط السيطرة',
      'الاستخبارات والأمن',
      'مسح وتفريغ أرشيف استدعاءات الطوارئ بالكامل',
      'ALL_RECALLS',
      'ALL_RECALLS',
      `تم تفريغ وحذف سجلات استدعاء الطوارئ بالكامل (${currentCount} سجل).`
    );
  }

  // Execute a personnel substitution (استبدال فرد متغيب/فرار)
  static processPersonnelReplacement(
    data: Omit<PersonnelReplacementRecord, 'id' | 'replacementSerial'>,
    actingUser = 'مسؤول الموارد البشرية',
    actingRole: DepartmentRole = 'إدارة الموارد البشرية'
  ): { replacement: PersonnelReplacementRecord; newPerson: PersonnelRecord } {
    const list = this.getPersonnel();

    let activeAccId = 'hq';
    if (typeof window !== 'undefined') {
      const activeCode = localStorage.getItem('military_active_account_v1');
      if (activeCode) {
        const found = BRIGADE_ACCOUNTS.find(
          (a) => a.id === activeCode || a.shortCode === activeCode || a.customAccessKey === activeCode
        );
        if (found) {
          activeAccId = found.id;
        }
      }
    }

    // 1. Mark or add replaced soldier as substituted
    const replacedIndex = list.findIndex((p) => p.militaryId === data.replacedMilitaryId);
    if (replacedIndex !== -1) {
      const replacedPerson = list[replacedIndex];
      replacedPerson.createdByAccountId = replacedPerson.createdByAccountId || activeAccId;
      replacedPerson.fullName = data.replacedFullName || replacedPerson.fullName;
      replacedPerson.rank = data.replacedRank || replacedPerson.rank;
      replacedPerson.unit = data.replacedUnit || replacedPerson.unit;
      replacedPerson.battalion = data.replacedBattalion || replacedPerson.battalion;
      replacedPerson.company = data.replacedCompany || replacedPerson.company;
      replacedPerson.jobTitle = data.replacedJobTitle || replacedPerson.jobTitle;
      replacedPerson.currentStatus = data.replacedStatus || 'فرار';
      if (!replacedPerson.logs) {
        replacedPerson.logs = {
          movement: [],
          attendance: [],
          medical: [],
          financial: [],
          security: [],
          armament: [],
          training: [],
          attachments: [],
          supply: []
        };
      }
      if (!replacedPerson.logs.movement) replacedPerson.logs.movement = [];
      replacedPerson.logs.movement.unshift({
        id: `mov-rep-${Date.now()}`,
        date: data.replacementDate,
        type: 'استبدال عسكري',
        reason: `تم استبدال الفرد (حالة ${data.replacedStatus}) بالفرد البديل الجديد (${data.newRank} / ${data.newFullName} - الرقم ${data.newMilitaryId}) بموجب ${data.orderNumber}`,
        orderReference: data.orderNumber,
        issuingAuthority: data.issuingAuthority,
        effectiveDate: data.replacementDate
      });
    } else if (data.replacedMilitaryId && data.replacedFullName) {
      // Create record for replaced deserter if manually entered and not previously in database
      const deserterRecord: PersonnelRecord = {
        militaryId: data.replacedMilitaryId,
        nationalId: `10${Math.floor(100000000 + Math.random() * 900000000)}`,
        fullName: data.replacedFullName,
        rank: data.replacedRank || 'جندي',
        dob: '1995-01-01',
        pob: 'الرياض',
        maritalStatus: 'أعزب',
        education: 'ثانوية عامة',
        specialization: 'مشاة عامة',
        bloodType: 'O+',
        phone: '0500000000',
        photoUrl: '',
        biometricsRecorded: false,
        unit: data.replacedUnit || 'اللواء الأول',
        battalion: data.replacedBattalion || 'الكتيبة الأولى',
        company: data.replacedCompany || 'السرية الأولى',
        platoon: 'الفصيل الأول',
        jobTitle: data.replacedJobTitle || 'فرد مشاة',
        enlistmentDate: data.absenceStartDate || '2023-01-01',
        currentStatus: data.replacedStatus || 'فرار',
        createdByAccountId: activeAccId,
        logs: {
          movement: [{
            id: `mov-rep-${Date.now()}`,
            date: data.replacementDate,
            type: 'استبدال عسكري',
            reason: `سجل فرد متغيب/فرار تم استبداله بالفرد البديل (${data.newRank} / ${data.newFullName}) بموجب ${data.orderNumber}`,
            orderReference: data.orderNumber,
            issuingAuthority: data.issuingAuthority,
            effectiveDate: data.replacementDate
          }],
          attendance: [{
            id: `att-des-${Date.now()}`,
            date: data.absenceStartDate || data.replacementDate,
            type: (data.replacedStatus as string) === 'متغيب' ? 'غياب' : 'فرار',
            reason: 'انقطاع وفرار عن الخدمة العسكرية',
            durationDays: 30,
            approvedBy: data.issuingAuthority,
            startDate: data.absenceStartDate || data.replacementDate
          }],
          medical: [], financial: [], security: [], armament: [], training: [], attachments: [], supply: []
        }
      };
      list.unshift(deserterRecord);
    }

    // 2. Build and insert new replacement soldier
    const newPerson: PersonnelRecord = {
      militaryId: data.newMilitaryId,
      nationalId: data.newNationalId,
      fullName: data.newFullName,
      rank: data.newRank,
      dob: '1998-01-01',
      pob: 'الرياض',
      maritalStatus: 'متزوج',
      education: 'ثانوية عامة',
      specialization: 'مشاة عامة',
      bloodType: 'O+',
      phone: data.newPhone || '0500000000',
      photoUrl: '',
      biometricsRecorded: true,
      unit: data.newUnit,
      battalion: data.newBattalion,
      company: data.newCompany,
      platoon: data.newPlatoon,
      jobTitle: data.newJobTitle,
      enlistmentDate: data.newEnlistmentDate || data.replacementDate,
      currentStatus: 'متواجد',
      createdByAccountId: activeAccId,
      logs: {
        movement: [
          {
            id: `mov-newrep-${Date.now()}`,
            date: data.replacementDate,
            type: 'استبدال عسكري',
            reason: `تعيين وإدراج بديل جديد بدلاً من الفرد المتغيب/الفرار (${data.replacedRank} / ${data.replacedFullName} - رقم ${data.replacedMilitaryId}) بموجب ${data.orderNumber}`,
            orderReference: data.orderNumber,
            issuingAuthority: data.issuingAuthority,
            effectiveDate: data.replacementDate
          }
        ],
        attendance: [
          {
            id: `att-rep-${Date.now()}`,
            date: data.replacementDate,
            type: 'حضور',
            reason: 'مباشرة القوة كفرد بديل معتمد',
            durationDays: 0,
            approvedBy: data.issuingAuthority,
            startDate: data.replacementDate
          }
        ],
        medical: [],
        financial: [],
        security: [],
        armament: [],
        training: [],
        attachments: [],
        supply: []
      }
    };

    list.unshift(newPerson);
    this.savePersonnel(list);

    // 3. Save replacement transaction
    const replacementRecord: PersonnelReplacementRecord = {
      ...data,
      createdByAccountId: activeAccId,
      id: `repl-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
      replacementSerial: `REP-SUB-${Math.floor(100000 + Math.random() * 900000)}`
    };

    const replacements = this.getReplacements();
    replacements.unshift(replacementRecord);
    this.saveReplacements(replacements);

    // 4. Record audit log & alerts
    this.logAction(
      actingUser,
      actingRole,
      'إجراء استبدال عسكري',
      data.newMilitaryId,
      data.newFullName,
      `استبدال البديل الجديد (${data.newRank} / ${data.newFullName}) بالفرد الفرار/المتغيب (${data.replacedRank} / ${data.replacedFullName}) - بموجب ${data.orderNumber}`
    );

    this.addAlert({
      level: 'warning',
      title: 'إحلال واستبدال فرد (فرار/متغيب)',
      description: `تم اعتماد إحلال الفرد البديل (${data.newRank} / ${data.newFullName}) رسمياً بدلاً من (${data.replacedRank} / ${data.replacedFullName}) في (${data.newUnit})`,
      militaryId: data.newMilitaryId
    });

    return { replacement: replacementRecord, newPerson };
  }

  // Update Status directly with propagation
  static updateStatus(
    militaryId: string,
    newStatus: PersonnelStatus,
    reason?: string,
    actingUser: string = 'المستخدم',
    actingDept: DepartmentRole = 'إدارة الموارد البشرية',
    extraDetails?: {
      secondedUnit?: string;
      trainingCourseType?: string;
      missionDestination?: string;
      missionStartDate?: string;
      missionEndDate?: string;
      leaveStartDate?: string;
      leaveEndDate?: string;
      leaveType?: string;
      durationDays?: number;
      reason?: string;
      effectiveDate?: string;
    }
  ): void {
    const list = this.getPersonnel();
    const person = list.find((p) => p.militaryId === militaryId);
    if (!person) return;

    if (!person.logs) {
      person.logs = {
        movement: [],
        attendance: [],
        medical: [],
        financial: [],
        security: [],
        armament: [],
        training: [],
        attachments: []
      };
    }
    if (!person.logs.attendance) person.logs.attendance = [];
    if (!person.logs.movement) person.logs.movement = [];
    if (!person.logs.security) person.logs.security = [];
    if (!person.logs.training) person.logs.training = [];

    const oldStatus = person.currentStatus;
    const today = extraDetails?.effectiveDate || new Date().toISOString().split('T')[0];

    // Determine when oldStatus started
    const startDate =
      person.lastStatusChangeDate ||
      person.logs.attendance?.[0]?.startDate ||
      person.logs.attendance?.[0]?.date ||
      person.enlistmentDate ||
      today;

    // Calculate elapsed duration in days
    let durationDays = 1;
    if (startDate && today) {
      const startMs = new Date(startDate).getTime();
      const endMs = new Date(today).getTime();
      if (!isNaN(startMs) && !isNaN(endMs)) {
        const diffDays = Math.ceil((endMs - startMs) / (1000 * 60 * 60 * 24));
        durationDays = diffDays > 0 ? diffDays : 1;
      }
    }

    // Update status and last change date
    person.currentStatus = newStatus;
    person.lastStatusChangeDate = extraDetails?.effectiveDate || today;

    // Track continuous streak for absence / desertion to drive daily payroll deductions
    const isAbsenceStatus = (s: string) => ['غياب', 'فرار', 'فرار بالسلاح'].includes(s);
    if (isAbsenceStatus(newStatus)) {
      if (!isAbsenceStatus(oldStatus) || !person.absenceStreakStartDate) {
        person.absenceStreakStartDate = extraDetails?.effectiveDate || today;
      }
    } else {
      person.absenceStreakStartDate = undefined;
    }

    // Handle Seconded Unit
    if (newStatus === 'منتدب') {
      if (extraDetails?.secondedUnit && extraDetails.secondedUnit.trim()) {
        person.secondedUnit = extraDetails.secondedUnit.trim();
      } else if (!person.secondedUnit) {
        person.secondedUnit = 'قيادة المنطقة العسكرية / انتداب خارجي';
      }
    }

    // Handle Training Course (Internal & External)
    if (newStatus === 'دورة تدريبية داخلية' || newStatus === 'دورة تدريبية خارجية') {
      if (extraDetails?.trainingCourseType && extraDetails.trainingCourseType.trim()) {
        person.trainingCourseType = extraDetails.trainingCourseType.trim();
      } else if (!person.trainingCourseType) {
        person.trainingCourseType = newStatus === 'دورة تدريبية داخلية' ? 'دورة عسكرية تخصصية داخلية' : 'دورة عسكرية متقدمة خارجية';
      }
    }

    // Handle Mission Location (مأمورية)
    if (newStatus === 'مأمورية') {
      if (extraDetails?.missionDestination && extraDetails.missionDestination.trim()) {
        person.missionDestination = extraDetails.missionDestination.trim();
      } else if (!person.missionDestination) {
        person.missionDestination = 'غرفة العمليات المشتركة / مأمورية ميدانية';
      }
      if (extraDetails?.missionStartDate) {
        person.missionStartDate = extraDetails.missionStartDate;
      }
      if (extraDetails?.missionEndDate) {
        person.missionEndDate = extraDetails.missionEndDate;
      }
    }

    // Handle Leave / Permission Dates (إجازة / إذن)
    if (newStatus === 'إجازة' || newStatus === 'إذن') {
      if (extraDetails?.leaveStartDate) {
        person.leaveStartDate = extraDetails.leaveStartDate;
      } else if (!person.leaveStartDate) {
        person.leaveStartDate = today;
      }
      if (extraDetails?.leaveEndDate) {
        person.leaveEndDate = extraDetails.leaveEndDate;
      }
      if (extraDetails?.leaveType) {
        person.leaveType = extraDetails.leaveType;
      }
    }

    // 1. Record Disciplinary Log (SecurityLog - سجل الانضباط والأمن المسلكي)
    // If transitioning out of or into statuses like 'فرار' or 'غياب' or 'موقوف' or 'مفقود' or 'اسير', record duration & tracking!
    if (
      oldStatus !== newStatus &&
      (['فرار', 'فرار بالسلاح', 'غياب', 'موقوف', 'مفقود', 'منتدب', 'اسير'].includes(oldStatus) ||
        ['فرار', 'فرار بالسلاح', 'غياب', 'موقوف', 'مفقود', 'اسير'].includes(newStatus))
    ) {
      const secLog: SecurityLog = {
        id: `sec-stat-${Date.now()}`,
        date: today,
        violation: `تقييد مدة حالة (${oldStatus}) والتحويل إلى (${newStatus})`,
        investigationDetails: `تم تقييد مدة (${oldStatus}) والبالغة (${durationDays} أيام) [الفترة من ${startDate} حتى ${today}] بملف الفرد، وتسوية الحالة بالتحويل إلى (${newStatus}).${
          newStatus === 'منتدب' && person.secondedUnit ? ` الجهة المنتدب إليها: [${person.secondedUnit}]` : ''
        }${
          newStatus === 'مأمورية' && person.missionDestination ? ` موقع المأمورية: [${person.missionDestination}]` : ''
        }${
          (newStatus === 'إجازة' || newStatus === 'إذن') && (person.leaveStartDate || person.leaveEndDate)
            ? ` فترة ${newStatus}: [من ${person.leaveStartDate || '-'} إلى ${person.leaveEndDate || '-'}]`
            : ''
        }${
          (newStatus === 'دورة تدريبية داخلية' || newStatus === 'دورة تدريبية خارجية') && person.trainingCourseType
            ? ` نوع الدورة: [${person.trainingCourseType}]`
            : ''
        }`,
        penalty: `تقييد مدة ${oldStatus} (${durationDays} أيام) بالسجل الانضباطي المسلكي`,
        warningLevel:
          oldStatus === 'فرار' || oldStatus === 'فرار بالسلاح' || newStatus === 'فرار' || newStatus === 'فرار بالسلاح' || newStatus === 'اسير'
            ? 'شديد الخطورة'
            : oldStatus === 'غياب' || newStatus === 'غياب'
            ? 'عالي'
            : 'متوسط',
        authority: actingDept,
        status: 'تم البت'
      };
      person.logs.security.unshift(secLog);
    }

    // 2. Record Administrative Movement Log (MovementLog - سجل الحركة والقرارات)
    if (oldStatus !== newStatus) {
      const movLog: MovementLog = {
        id: `mov-stat-${Date.now()}`,
        date: today,
        type: newStatus === 'منتدب' ? 'انتداب' : (newStatus === 'مأمورية' ? 'مأمورية' : (newStatus === 'دورة تدريبية داخلية' || newStatus === 'دورة تدريبية خارجية' ? 'تكليف' : 'أمر إداري')),
        details: `تغيير حالة الجاهزية العسكرية من [${oldStatus}] إلى [${newStatus}] | تقييد فترة [${oldStatus}] السابقة: من [${startDate}] حتى [${today}] (${durationDays} أيام)${
          newStatus === 'منتدب' && person.secondedUnit ? ` - الوحدة المنتدب إليها: [${person.secondedUnit}]` : ''
        }${
          newStatus === 'مأمورية' && person.missionDestination ? ` - موقع ومقر المأمورية: [${person.missionDestination}]` : ''
        }${
          (newStatus === 'إجازة' || newStatus === 'إذن') && (person.leaveStartDate || person.leaveEndDate)
            ? ` - فترة ${newStatus}: [من ${person.leaveStartDate || '-'} حتى ${person.leaveEndDate || '-'}]`
            : ''
        }${
          (newStatus === 'دورة تدريبية داخلية' || newStatus === 'دورة تدريبية خارجية') && person.trainingCourseType
            ? ` - نوع ومسمى الدورة: [${person.trainingCourseType}]`
            : ''
        }`,
        effectiveDate: today,
        issuingAuthority: actingUser || actingDept
      };
      person.logs.movement.unshift(movLog);
    }

    // 3. Record & Seal Historical Attendance Log (AttendanceLog - سجل التمام والجاهزية من تاريخ إلى تاريخ)
    if (oldStatus !== newStatus) {
      // 3.1. Seal previous status (تقييد الحالة السابقة: من تاريخ إلى تاريخ بدقة تامة)
      const existingActiveLog = person.logs.attendance.find(
        (a) =>
          (a.type === oldStatus || (oldStatus === 'متواجد' && a.type === 'حضور')) &&
          (!a.endDate || a.statusPeriodState === 'active')
      );

      if (existingActiveLog) {
        existingActiveLog.type = oldStatus;
        existingActiveLog.startDate = startDate;
        existingActiveLog.endDate = today;
        existingActiveLog.durationDays = durationDays;
        existingActiveLog.statusPeriodState = 'completed';
        existingActiveLog.reason = `فترة (${oldStatus}) من تاريخ [${startDate}] إلى تاريخ [${today}] (${durationDays} أيام)`;
        existingActiveLog.notes = `تم تقييد اكتمال فترة (${oldStatus}) رسمياً والتحويل إلى (${newStatus})`;
      } else {
        const sealedOldStatusLog: AttendanceLog = {
          id: `att-closed-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
          date: today,
          type: oldStatus,
          reason: `فترة (${oldStatus}) من تاريخ [${startDate}] إلى تاريخ [${today}] (${durationDays} أيام)`,
          durationDays: durationDays,
          approvedBy: actingDept || actingUser || 'شؤون الأفراد والسيطرة',
          startDate: startDate,
          endDate: today,
          statusPeriodState: 'completed',
          notes: `تم تقييد اكتمال فترة (${oldStatus}) رسمياً بملف الفرد والتحويل إلى (${newStatus})`
        };
        person.logs.attendance.unshift(sealedOldStatusLog);
      }

      // 3.2. Open new status (بدء سريان الحالة الجديدة)
      const newStatusStartDate =
        (newStatus === 'إجازة' || newStatus === 'إذن') && extraDetails?.leaveStartDate
          ? extraDetails.leaveStartDate
          : (newStatus === 'مأمورية' && extraDetails?.missionStartDate ? extraDetails.missionStartDate : today);

      const newStatusEndDate =
        (newStatus === 'إجازة' || newStatus === 'إذن') && extraDetails?.leaveEndDate
          ? extraDetails.leaveEndDate
          : (newStatus === 'مأمورية' && extraDetails?.missionEndDate ? extraDetails.missionEndDate : undefined);

      const newAttLog: AttendanceLog = {
        id: `att-active-${Date.now() + 1}-${Math.floor(Math.random() * 1000)}`,
        date: today,
        type: newStatus,
        leaveType: extraDetails?.leaveType || person.leaveType,
        permissionType: extraDetails?.leaveType || person.leaveType,
        reason:
          reason ||
          (newStatus === 'منتدب' && person.secondedUnit
            ? `انتداب رسمي لدى جهة: [${person.secondedUnit}]`
            : newStatus === 'مأمورية' && person.missionDestination
            ? `مأمورية ميدانية في موقع: [${person.missionDestination}]`
            : (newStatus === 'إجازة' || newStatus === 'إذن') && person.leaveStartDate
            ? `${newStatus} رسمية من [${newStatusStartDate}] حتى [${newStatusEndDate || 'إشعار آخر'}] (${person.leaveType || 'عام'})`
            : (newStatus === 'دورة تدريبية داخلية' || newStatus === 'دورة تدريبية خارجية') && person.trainingCourseType
            ? `الالتحاق بـ ${newStatus}: [${person.trainingCourseType}]`
            : newStatus === 'فرار بالسلاح'
            ? `⚠️ بلاغ أمني: هروب بالسلاح العسكري والذخيرة`
            : newStatus === 'فرار'
            ? `⚠️ فرار عن المعسكر والخدمة العسكرية`
            : newStatus === 'غياب'
            ? `غياب غير مبرر عن نداء التمام`
            : newStatus === 'متواجد'
            ? `حضور وتواجد بالثكنة والميدان`
            : newStatus === 'في الميدان'
            ? `مرابطة وانتشار عملياتي في الميدان`
            : `بدء سريان حالة (${newStatus}) رسمياً بملف الفرد`),
        durationDays: (newStatus === 'إجازة' || newStatus === 'إذن') && extraDetails?.durationDays ? extraDetails.durationDays : 1,
        approvedBy: actingDept || actingUser || 'شؤون الأفراد والسيطرة',
        startDate: newStatusStartDate,
        endDate: newStatusEndDate,
        statusPeriodState: (newStatus === 'إجازة' || newStatus === 'إذن' || newStatus === 'مأمورية') && newStatusEndDate ? 'completed' : 'active',
        notes: `سارية حالياً في التمام والجاهزية منذ تاريخ [${newStatusStartDate}]`
      };
      person.logs.attendance.unshift(newAttLog);
    } else {
      // If same status was re-asserted with a new date (e.g. via date sub-tab)
      if (extraDetails?.effectiveDate) {
        const currentActiveLog = person.logs.attendance.find(
          (a) => (a.type === newStatus || (newStatus === 'متواجد' && a.type === 'حضور')) && (!a.endDate || a.statusPeriodState === 'active')
        );
        if (currentActiveLog) {
          currentActiveLog.startDate = extraDetails.effectiveDate;
          currentActiveLog.date = extraDetails.effectiveDate;
          currentActiveLog.notes = `تم تعديل تاريخ سريان الحالة إلى [${extraDetails.effectiveDate}]`;
        } else {
          person.logs.attendance.unshift({
            id: `att-active-${Date.now()}`,
            date: extraDetails.effectiveDate,
            type: newStatus,
            reason: reason || `سريان حالة (${newStatus}) من تاريخ [${extraDetails.effectiveDate}]`,
            durationDays: 1,
            approvedBy: actingDept || actingUser || 'شؤون الأفراد',
            startDate: extraDetails.effectiveDate,
            statusPeriodState: 'active',
            notes: `سارية من تاريخ [${extraDetails.effectiveDate}]`
          });
        }
      }
    }

    this.savePersonnel(list);

    // Immediately calculate and synchronize daily absence deduction in the payroll system
    this.syncAbsencePayrollDeduction(militaryId);

    this.logAction(
      actingUser,
      actingDept,
      'تحديث الحالة الحالية وتقييد مدة السجل الانضباطي',
      militaryId,
      person.fullName,
      `تحويل من (${oldStatus}) إلى (${newStatus}) - المدة المنقضية: (${durationDays} أيام) [من ${startDate} حتى ${today}]${
        newStatus === 'منتدب' && person.secondedUnit ? ` - الوحدة المنتدب إليها: ${person.secondedUnit}` : ''
      }${
        newStatus === 'مأمورية' && person.missionDestination ? ` - موقع المأمورية: ${person.missionDestination}` : ''
      }${
        (newStatus === 'إجازة' || newStatus === 'إذن') && (person.leaveStartDate || person.leaveEndDate)
          ? ` - فترة ${newStatus}: [من ${person.leaveStartDate || '-'} إلى ${person.leaveEndDate || '-'}]`
          : ''
      }${
        (newStatus === 'دورة تدريبية داخلية' || newStatus === 'دورة تدريبية خارجية') && person.trainingCourseType
          ? ` - مسمى الدورة: ${person.trainingCourseType}`
          : ''
      } - السبب: ${reason || 'تعديل حالة الجاهزية'}`
    );

    // Create high-level alerts for critical statuses
    if (['فرار', 'مفقود', 'موقوف', 'اسير', 'شهيد', 'معاق', 'جريح'].includes(newStatus)) {
      this.addAlert({
        title: `تحديث حرج: حالة ${newStatus}`,
        description: `تم تحويل الفرد ${person.fullName} (${person.rank}) إلى حالة ${newStatus}. السبب: ${reason || 'تعديل الجاهزية'}`,
        level: 'urgent',
        militaryId
      });
    }
  }

  // Add Movement Log
  static addMovementLog(
    militaryId: string,
    log: Omit<MovementLog, 'id'>,
    actingUser: string,
    actingDept: DepartmentRole,
    autoChangeStatus?: PersonnelStatus
  ): void {
    const list = this.getPersonnel();
    const person = list.find((p) => p.militaryId === militaryId);
    if (!person) return;

    const newLog: MovementLog = { ...log, id: `mov-${Date.now()}` };
    person.logs.movement.unshift(newLog);

    if (autoChangeStatus && person.currentStatus !== autoChangeStatus) {
      person.currentStatus = autoChangeStatus;
    }

    this.savePersonnel(list);

    this.logAction(
      actingUser,
      actingDept,
      'إضافة سجل حركة',
      militaryId,
      person.fullName,
      `نوع الحركة: ${log.type} - ${log.details}`
    );
  }

  // Add Medical Log
  static addMedicalLog(
    militaryId: string,
    log: Omit<MedicalLog, 'id'>,
    actingUser: string,
    actingDept: DepartmentRole,
    admitToHospital = false
  ): void {
    const list = this.getPersonnel();
    const person = list.find((p) => p.militaryId === militaryId);
    if (!person) return;

    const newLog: MedicalLog = { ...log, id: `med-${Date.now()}` };
    person.logs.medical.unshift(newLog);

    if (admitToHospital) {
      person.currentStatus = 'مستشفى';
    }

    this.savePersonnel(list);

    this.logAction(
      actingUser,
      actingDept,
      'إضافة سجل طبي',
      militaryId,
      person.fullName,
      `التشخيص: ${log.diagnosis} - المستشفى: ${log.hospital}`
    );
  }

  // Register Medical Return / Recovery
  static registerMedicalReturn(
    militaryId: string,
    details: {
      diagnosis: string;
      hospital: string;
      doctor: string;
      prescriptionDetails: string;
      recoveryStartDate: string;
      recoveryEndDate: string;
      newStatus: PersonnelStatus;
      notes?: string;
    },
    actingUser: string,
    actingDept: DepartmentRole
  ): boolean {
    const list = this.getPersonnel();
    const person = list.find((p) => p.militaryId === militaryId);
    if (!person) return false;

    const oldStatus = person.currentStatus;
    person.currentStatus = details.newStatus;

    const newMedLog: MedicalLog = {
      id: `med-${Date.now()}`,
      date: new Date().toISOString().split('T')[0],
      diagnosis: details.diagnosis || 'تعافي كامل وعودة للخدمة',
      hospital: details.hospital || 'المستشفى العسكري المركزي',
      doctor: details.doctor || 'الطبيب العسكري المعالج',
      sickLeaveDays: 0,
      medications: details.prescriptionDetails
        ? [
            {
              id: `medrx-${Date.now()}`,
              name: details.prescriptionDetails,
              dose: 'حسب الخطة العلاجية والتعافي',
              dateDispensed: new Date().toISOString().split('T')[0],
              prescribedBy: details.doctor || 'طبيب الفرع الطبي'
            }
          ]
        : [],
      prescriptionDetails: details.prescriptionDetails,
      recoveryStartDate: details.recoveryStartDate,
      recoveryEndDate: details.recoveryEndDate,
      isReturnToDuty: true
    };

    if (!person.logs.medical) person.logs.medical = [];
    person.logs.medical.unshift(newMedLog);

    // Record attendance log for return to duty
    const today = new Date().toISOString().split('T')[0];
    const newAttLog: AttendanceLog = {
      id: `att-${Date.now()}`,
      date: today,
      type: 'عودة للخدمة',
      reason: `عودة علاجية واستكمال التعافي - ${details.diagnosis}`,
      durationDays: 1,
      approvedBy: details.doctor || actingUser,
      startDate: details.recoveryStartDate || today,
      endDate: details.recoveryEndDate || today,
      notes: details.notes
    };
    if (!person.logs.attendance) person.logs.attendance = [];
    person.logs.attendance.unshift(newAttLog);

    this.savePersonnel(list);

    this.logAction(
      actingUser,
      actingDept,
      'مصادقة عودة علاجية وتحديث جاهزية',
      militaryId,
      person.fullName,
      `تمت العودة العلاجية بنجاح من المستشفى. تحولت الحالة من (${oldStatus}) إلى (${details.newStatus}). فترة التعافي: ${details.recoveryStartDate} إلى ${details.recoveryEndDate}`
    );

    this.addAlert({
      level: 'info',
      title: 'عودة علاجية واستعادة جاهزية قتالية',
      description: `عاد الفرد (${person.rank} / ${person.fullName}) للخدمة بعد رحلة التعافي بالمستشفى. الجاهزية الحالية: ${details.newStatus}`,
      militaryId
    });

    return true;
  }

  // Register Training Course Enrollment
  static registerTrainingCourse(
    militaryId: string,
    details: {
      courseName: string;
      courseType: 'ميداني' | 'قيادي' | 'تقني' | 'أمني' | 'تخصصي' | 'خارجي';
      startDate: string;
      endDate: string;
      supervisorOfficer: string;
      trainingLocation: string;
      grade?: 'ممتاز' | 'جيد جداً' | 'جيد' | 'مقبول' | 'مؤهل';
      evaluation?: string;
      certificates?: string;
      updateStatusToField?: boolean;
      notes?: string;
    },
    actingUser: string,
    actingDept: DepartmentRole
  ): boolean {
    const list = this.getPersonnel();
    const person = list.find((p) => p.militaryId === militaryId);
    if (!person) return false;

    const oldStatus = person.currentStatus;
    if (details.updateStatusToField) {
      person.currentStatus = 'في الميدان';
    }

    const startD = new Date(details.startDate);
    const endD = new Date(details.endDate);
    const diffWeeks = Math.max(1, Math.round((endD.getTime() - startD.getTime()) / (1000 * 60 * 60 * 24 * 7)));

    const newTrnLog: TrainingLog = {
      id: `trn-${Date.now()}`,
      courseName: details.courseName,
      courseType: details.courseType,
      provider: details.trainingLocation || 'مركز التدريب الميداني المركزي',
      startDate: details.startDate,
      endDate: details.endDate,
      durationWeeks: diffWeeks,
      grade: details.grade || 'ممتاز',
      evaluation: details.evaluation || 'دورة تدريبية متقدمة لرفع الكفاءة والجاهزية القتالية',
      certificates: details.certificates || 'شهادة اجتياز الدورة بنجاح',
      supervisorOfficer: details.supervisorOfficer,
      trainingLocation: details.trainingLocation,
      status: 'قائمة',
      notes: details.notes
    };

    if (!person.logs.training) person.logs.training = [];
    person.logs.training.unshift(newTrnLog);

    this.savePersonnel(list);

    this.logAction(
      actingUser,
      actingDept,
      'تسجيل دورة تدريبية وتعيين مشرف',
      militaryId,
      person.fullName,
      `الدورة: (${details.courseName}) - النوع: (${details.courseType}) - الفترة: (${details.startDate} إلى ${details.endDate}) - المشرف: (${details.supervisorOfficer})`
    );

    this.addAlert({
      level: 'info',
      title: 'تسجيل دورة تدريبية - رفع جاهزية',
      description: `تم إدراج الفرد (${person.rank} / ${person.fullName}) في دورة: ${details.courseName} بمركز ${details.trainingLocation} إشراف ${details.supervisorOfficer}`,
      militaryId
    });

    return true;
  }

  // Add Financial Log
  static addFinancialLog(
    militaryId: string,
    log: Omit<FinancialLog, 'id'>,
    actingUser: string,
    actingDept: DepartmentRole
  ): void {
    const list = this.getPersonnel();
    const person = list.find((p) => p.militaryId === militaryId);
    if (!person) return;

    // If this is an advance or financial aid, route through the comprehensive grant processor
    if (log.type === 'سلفة' || log.type === 'سلفة مالية' || log.type === 'مساعدة مالية' || log.grantType) {
      const grantType: 'سلفة مالية' | 'مساعدة مالية' =
        log.grantType || (log.type === 'مساعدة مالية' ? 'مساعدة مالية' : 'سلفة مالية');
      this.grantFinancialAidOrAdvance({
        militaryId,
        grantType,
        amount: log.amount,
        monthYear: log.monthYear || (log.date ? log.date.slice(0, 7) : new Date().toISOString().slice(0, 7)),
        date: log.date || new Date().toISOString().split('T')[0],
        reason: log.reason || (grantType === 'سلفة مالية' ? 'طلب سلفة مالية على المرتب' : 'مساعدة مالية وإعانة استثنائية'),
        notes: log.notes || 'معتمد ومقيد بملف الفرد',
        actingUser,
        actingDept
      });
      return;
    }

    if (!person.logs) {
      person.logs = {
        movement: [], attendance: [], medical: [], financial: [],
        security: [], armament: [], training: [], attachments: [], supply: []
      };
    }
    if (!person.logs.financial) person.logs.financial = [];

    const newLog: FinancialLog = { ...log, id: `fin-${Date.now()}` };
    person.logs.financial.unshift(newLog);

    this.savePersonnel(list);

    this.logAction(
      actingUser,
      actingDept,
      'إضافة عملية مالية',
      militaryId,
      person.fullName,
      `نوع العملية: ${log.type} - المبلغ: ${log.amount} ريال - السبب: ${log.reason}`
    );
  }

  // Add Security Log
  static addSecurityLog(
    militaryId: string,
    log: Omit<SecurityLog, 'id'>,
    actingUser: string,
    actingDept: DepartmentRole,
    detainPerson = false
  ): void {
    const list = this.getPersonnel();
    const person = list.find((p) => p.militaryId === militaryId);
    if (!person) return;

    const newLog: SecurityLog = { ...log, id: `sec-${Date.now()}` };
    person.logs.security.unshift(newLog);

    if (detainPerson) {
      person.currentStatus = 'موقوف';
    }

    this.savePersonnel(list);

    this.logAction(
      actingUser,
      actingDept,
      'تسجيل سجل أمني/مخالفة',
      militaryId,
      person.fullName,
      `المخالفة: ${log.violation} - العقوبة: ${log.penalty}`
    );
  }

  // Delete Security Log
  static deleteSecurityLog(
    militaryId: string,
    logId: string,
    actingUser = 'المستخدم الحالي',
    actingDept: DepartmentRole = 'الاستخبارات والأمن'
  ): void {
    const list = this.getPersonnel();
    const person = list.find((p) => p.militaryId === militaryId);
    if (!person) return;

    person.logs.security = (person.logs.security || []).filter((l) => l.id !== logId);
    this.savePersonnel(list);

    this.logAction(
      actingUser,
      actingDept,
      'حذف قيد أمني',
      militaryId,
      person.fullName,
      `تم حذف القيد الأمني برقم: ${logId}`
    );
  }

  // Add Armament Log or update weapon
  static addArmamentLog(
    militaryId: string,
    log: Omit<ArmamentLog, 'id'>,
    actingUser: string,
    actingDept: DepartmentRole
  ): void {
    const list = this.getPersonnel();
    const person = list.find((p) => p.militaryId === militaryId);
    if (!person) return;

    const newLog: ArmamentLog = { ...log, id: `arm-${Date.now()}` };
    person.logs.armament.unshift(newLog);

    this.savePersonnel(list);

    this.logAction(
      actingUser,
      actingDept,
      'تسليح / إسناد سلاح',
      militaryId,
      person.fullName,
      `السلاح: ${log.weaponType} (${log.weaponSerial}) - كمية الذخيرة: ${log.ammoQty}`
    );
  }

  // Add Training Log
  static addTrainingLog(
    militaryId: string,
    log: Omit<TrainingLog, 'id'>,
    actingUser: string,
    actingDept: DepartmentRole
  ): void {
    const list = this.getPersonnel();
    const person = list.find((p) => p.militaryId === militaryId);
    if (!person) return;

    const newLog: TrainingLog = { ...log, id: `trn-${Date.now()}` };
    person.logs.training.unshift(newLog);

    this.savePersonnel(list);

    this.logAction(
      actingUser,
      actingDept,
      'تسجيل دورة تدريبية',
      militaryId,
      person.fullName,
      `الدورة: ${log.courseName} - التقدير: ${log.grade}`
    );
  }

  // Add Attachment
  static addAttachment(
    militaryId: string,
    attachment: Omit<PersonnelAttachment, 'id'>,
    actingUser: string,
    actingDept: DepartmentRole
  ): void {
    const list = this.getPersonnel();
    const person = list.find((p) => p.militaryId === militaryId);
    if (!person) return;

    const newAtt: PersonnelAttachment = { ...attachment, id: `attch-${Date.now()}` };
    if (!person.logs) {
      person.logs = {
        movement: [], attendance: [], medical: [], financial: [],
        security: [], armament: [], training: [], attachments: [], supply: []
      };
    }
    if (!person.logs.attachments) person.logs.attachments = [];
    person.logs.attachments.unshift(newAtt);

    if (!person.attachments) person.attachments = [];
    person.attachments.unshift(newAtt);

    this.savePersonnel(list);

    this.logAction(
      actingUser,
      actingDept,
      'إرفاق وثيقة إلكترونية',
      militaryId,
      person.fullName,
      `عنوان المرفق: ${attachment.title} (${attachment.category})`
    );
  }

  // Delete Attachment
  static deleteAttachment(
    militaryId: string,
    attachmentId: string,
    actingUser: string,
    actingDept: DepartmentRole
  ): void {
    const list = this.getPersonnel();
    const person = list.find((p) => p.militaryId === militaryId);
    if (!person) return;

    if (person.logs?.attachments) {
      person.logs.attachments = person.logs.attachments.filter((a) => a.id !== attachmentId);
    }
    if (person.attachments) {
      person.attachments = person.attachments.filter((a) => a.id !== attachmentId);
    }

    this.savePersonnel(list);

    this.logAction(
      actingUser,
      actingDept,
      'حذف وثيقة إلكترونية',
      militaryId,
      person.fullName,
      `تم حذف المرفق رقم: ${attachmentId}`
    );
  }

  // Add Supply / Equipment Log (صرف مهمات وبدلات عسكرية)
  static addSupplyLog(
    militaryId: string,
    log: Omit<SupplyLog, 'id'>,
    actingUser: string,
    actingDept: DepartmentRole
  ): void {
    const list = this.getPersonnel();
    const person = list.find((p) => p.militaryId === militaryId);
    if (!person) return;

    const newLog: SupplyLog = { ...log, id: `sup-${Date.now()}` };
    if (!person.logs.supply) person.logs.supply = [];
    person.logs.supply.unshift(newLog);

    this.savePersonnel(list);

    this.logAction(
      actingUser,
      actingDept,
      'صرف مهمات/بدلات عسكرية',
      militaryId,
      person.fullName,
      `الصنف: ${log.itemName} (${log.itemType}) - الكمية: ${log.quantity} - الحالة: ${log.condition}`
    );
  }

  // Helper to filter out legacy mock sample items
  private static filterOutSampleIds<T extends { id: string }>(items: T[]): T[] {
    const sampleIds = [
      'inv-1', 'inv-2', 'inv-3', 'inv-4', 'inv-5', 'inv-6',
      'wp-101', 'wp-102', 'wp-103', 'wp-104', 'wp-105',
      'INT-2026-101', 'INT-2026-102',
      'iss-1', 'iss-2',
      'lc-1', 'lc-2'
    ];
    return items.filter((item) => !sampleIds.includes(item.id));
  }

  // --- ARMAMENT & AMMUNITION MODULE STORAGE METHODS ---

  // Armory Inventory
  static getArmoryInventory(): ArmoryInventoryItem[] {
    const key = this.getKeyForTenant(STORAGE_KEY_ARMORY_INVENTORY);
    try {
      const data = safeGetLocalItem<ArmoryInventoryItem[]>(key);
      if (data && Array.isArray(data) && data.length > 0) {
        return this.filterOutSampleIds(data);
      }
    } catch (e) {
      console.error('Failed to load armory inventory', e);
    }
    if (!hasUserSavedDataOnDevice(key) && !hasUserSavedDataOnDevice() && this.getActiveTenantId() === 'tenant-hq-main') {
      this.saveArmoryInventory(INITIAL_INVENTORY_ITEMS);
      return INITIAL_INVENTORY_ITEMS;
    }
    return [];
  }

  static saveArmoryInventory(items: ArmoryInventoryItem[]): void {
    try {
      const filtered = this.filterOutSampleIds(items);
      const key = this.getKeyForTenant(STORAGE_KEY_ARMORY_INVENTORY);
      const cloudDocId = this.getCloudDocIdForTenant('armory_inventory');
      safeSetLocalItem(key, filtered);
      syncDocToCloud(cloudDocId, filtered);
      notifyDataChange();
    } catch (e) {
      console.error('Failed to save armory inventory', e);
    }
  }

  // Tracked Weapon Pieces
  static getArmoryWeapons(): ArmoryWeaponPiece[] {
    const key = this.getKeyForTenant(STORAGE_KEY_ARMORY_WEAPONS);
    try {
      const data = safeGetLocalItem<ArmoryWeaponPiece[]>(key);
      if (data && Array.isArray(data) && data.length > 0) {
        return this.filterOutSampleIds(data);
      }
    } catch (e) {
      console.error('Failed to load armory weapons', e);
    }
    if (!hasUserSavedDataOnDevice(key) && !hasUserSavedDataOnDevice() && this.getActiveTenantId() === 'tenant-hq-main') {
      this.saveArmoryWeapons(INITIAL_WEAPON_PIECES);
      return INITIAL_WEAPON_PIECES;
    }
    return [];
  }

  static saveArmoryWeapons(pieces: ArmoryWeaponPiece[]): void {
    try {
      const filtered = this.filterOutSampleIds(pieces);
      const key = this.getKeyForTenant(STORAGE_KEY_ARMORY_WEAPONS);
      const cloudDocId = this.getCloudDocIdForTenant('armory_weapons');
      safeSetLocalItem(key, filtered);
      syncDocToCloud(cloudDocId, filtered);
      notifyDataChange();
    } catch (e) {
      console.error('Failed to save armory weapons', e);
    }
  }

  // Intakes / Imports
  static getArmoryIntakes(): ArmoryIntakeRecord[] {
    const key = this.getKeyForTenant(STORAGE_KEY_ARMORY_INTAKES);
    try {
      const data = safeGetLocalItem<ArmoryIntakeRecord[]>(key);
      if (data && Array.isArray(data) && data.length > 0) {
        return this.filterOutSampleIds(data);
      }
    } catch (e) {
      console.error('Failed to load armory intakes', e);
    }
    if (!hasUserSavedDataOnDevice(key) && !hasUserSavedDataOnDevice() && this.getActiveTenantId() === 'tenant-hq-main') {
      this.saveArmoryIntakes(INITIAL_INTAKE_RECORDS);
      return INITIAL_INTAKE_RECORDS;
    }
    return [];
  }

  static saveArmoryIntakes(records: ArmoryIntakeRecord[]): void {
    try {
      const filtered = this.filterOutSampleIds(records);
      const key = this.getKeyForTenant(STORAGE_KEY_ARMORY_INTAKES);
      const cloudDocId = this.getCloudDocIdForTenant('armory_intakes');
      safeSetLocalItem(key, filtered);
      syncDocToCloud(cloudDocId, filtered);
      notifyDataChange();
    } catch (e) {
      console.error('Failed to save armory intakes', e);
    }
  }

  // Issue Orders
  static getArmoryIssues(): ArmoryIssueOrder[] {
    const key = this.getKeyForTenant(STORAGE_KEY_ARMORY_ISSUES);
    try {
      const data = safeGetLocalItem<ArmoryIssueOrder[]>(key);
      if (data && Array.isArray(data) && data.length > 0) {
        return this.filterOutSampleIds(data);
      }
    } catch (e) {
      console.error('Failed to load armory issues', e);
    }
    if (!hasUserSavedDataOnDevice(key) && !hasUserSavedDataOnDevice() && this.getActiveTenantId() === 'tenant-hq-main') {
      this.saveArmoryIssues(INITIAL_ISSUE_ORDERS);
      return INITIAL_ISSUE_ORDERS;
    }
    return [];
  }

  static saveArmoryIssues(orders: ArmoryIssueOrder[]): void {
    try {
      const filtered = this.filterOutSampleIds(orders);
      const key = this.getKeyForTenant(STORAGE_KEY_ARMORY_ISSUES);
      const cloudDocId = this.getCloudDocIdForTenant('armory_issues');
      safeSetLocalItem(key, filtered);
      syncDocToCloud(cloudDocId, filtered);
      notifyDataChange();
    } catch (e) {
      console.error('Failed to save armory issues', e);
    }
  }

  // Weapon Lifecycle History
  static getWeaponLifecycle(): WeaponLifecycleEvent[] {
    try {
      const key = this.getKeyForTenant(STORAGE_KEY_ARMORY_LIFECYCLE);
      const data = safeGetLocalItem<WeaponLifecycleEvent[]>(key);
      if (data && Array.isArray(data)) {
        return this.filterOutSampleIds(data);
      }
    } catch (e) {
      console.error('Failed to load weapon lifecycle', e);
    }
    if (this.getActiveTenantId() === 'tenant-hq-main') {
      return INITIAL_LIFECYCLE_EVENTS;
    }
    return [];
  }

  static saveWeaponLifecycle(events: WeaponLifecycleEvent[]): void {
    try {
      const filtered = this.filterOutSampleIds(events);
      const key = this.getKeyForTenant(STORAGE_KEY_ARMORY_LIFECYCLE);
      const cloudDocId = this.getCloudDocIdForTenant('armory_lifecycle');
      safeSetLocalItem(key, filtered);
      syncDocToCloud(cloudDocId, filtered);
      notifyDataChange();
    } catch (e) {
      console.error('Failed to save weapon lifecycle', e);
    }
  }

  // Weapon Types Config
  static getWeaponTypesConfig(): WeaponTypeConfig[] {
    try {
      const key = this.getKeyForTenant(STORAGE_KEY_WEAPON_TYPES);
      const data = safeGetLocalItem<WeaponTypeConfig[]>(key);
      if (data && Array.isArray(data)) return data;
    } catch (e) {
      console.error('Failed to load weapon types config', e);
    }
    return INITIAL_WEAPON_TYPES;
  }

  static saveWeaponTypesConfig(types: WeaponTypeConfig[]): void {
    try {
      const key = this.getKeyForTenant(STORAGE_KEY_WEAPON_TYPES);
      const cloudDocId = this.getCloudDocIdForTenant('weapon_types');
      safeSetLocalItem(key, types);
      syncDocToCloud(cloudDocId, types);
      notifyDataChange();
    } catch (e) {
      console.error('Failed to save weapon types config', e);
    }
  }

  // Ammo Types Config
  static getAmmoTypesConfig(): AmmoTypeConfig[] {
    try {
      const key = this.getKeyForTenant(STORAGE_KEY_AMMO_TYPES);
      const data = safeGetLocalItem<AmmoTypeConfig[]>(key);
      if (data && Array.isArray(data)) return data;
    } catch (e) {
      console.error('Failed to load ammo types config', e);
    }
    return INITIAL_AMMO_TYPES;
  }

  static saveAmmoTypesConfig(types: AmmoTypeConfig[]): void {
    try {
      const key = this.getKeyForTenant(STORAGE_KEY_AMMO_TYPES);
      const cloudDocId = this.getCloudDocIdForTenant('ammo_types');
      safeSetLocalItem(key, types);
      syncDocToCloud(cloudDocId, types);
      notifyDataChange();
    } catch (e) {
      console.error('Failed to save ammo types config', e);
    }
  }

  // Vehicles & Machinery Management (جاهزية العربات والآليات)
  static getVehicles(): VehicleItem[] {
    const key = this.getKeyForTenant(STORAGE_KEY_VEHICLES);
    try {
      const data = safeGetLocalItem<VehicleItem[]>(key);
      if (data && Array.isArray(data) && data.length > 0) return data;
    } catch (e) {
      console.error('Failed to load vehicles data', e);
    }
    if (!hasUserSavedDataOnDevice(key) && !hasUserSavedDataOnDevice() && this.getActiveTenantId() === 'tenant-hq-main') {
      this.saveVehicles(INITIAL_VEHICLES_DATA);
      return INITIAL_VEHICLES_DATA;
    }
    return [];
  }

  static saveVehicles(vehicles: VehicleItem[]): void {
    try {
      const key = this.getKeyForTenant(STORAGE_KEY_VEHICLES);
      const cloudDocId = this.getCloudDocIdForTenant('vehicles');
      safeSetLocalItem(key, vehicles);
      syncDocToCloud(cloudDocId, vehicles);
      notifyDataChange();
    } catch (e) {
      console.error('Failed to save vehicles data', e);
    }
  }

  static addVehicle(
    vehicleData: Omit<VehicleItem, 'id' | 'maintenanceLogs'>,
    actingUser = 'مسؤول جاهزية العربات'
  ): VehicleItem {
    const list = this.getVehicles();
    const newVehicle: VehicleItem = {
      ...vehicleData,
      id: `veh-${Date.now()}`,
      maintenanceLogs: []
    };
    list.unshift(newVehicle);
    this.saveVehicles(list);

    this.logAction(
      actingUser,
      'جاهزية العربات والآليات',
      'إضافة عربة/آلية',
      newVehicle.plateNumber,
      newVehicle.name,
      `تم تسجيل آلية جديدة (${newVehicle.name}) - اللوحة: ${newVehicle.plateNumber} - الحالة: ${newVehicle.status}`
    );

    return newVehicle;
  }

  static updateVehicle(vehicleId: string, updates: Partial<VehicleItem>, actingUser = 'مسؤول جاهزية العربات'): VehicleItem[] {
    const list = this.getVehicles();
    const index = list.findIndex(v => v.id === vehicleId);
    if (index !== -1) {
      list[index] = { ...list[index], ...updates };
      this.saveVehicles(list);
      this.logAction(
        actingUser,
        'جاهزية العربات والآليات',
        'تعديل عربة/آلية',
        list[index].plateNumber,
        list[index].name,
        `تم تحديث بيانات الآلية (${list[index].name}) - اللوحة: ${list[index].plateNumber}`
      );
    }
    return list;
  }

  static deleteVehicle(vehicleId: string, actingUser = 'مسؤول جاهزية العربات'): VehicleItem[] {
    const list = this.getVehicles();
    const target = list.find(v => v.id === vehicleId);
    const updated = list.filter(v => v.id !== vehicleId);
    this.saveVehicles(updated);

    if (target) {
      this.logAction(
        actingUser,
        'جاهزية العربات والآليات',
        'حذف عربة/آلية',
        target.plateNumber,
        target.name,
        `تم حذف الآلية (${target.name}) - اللوحة: ${target.plateNumber} من سجلات الجاهزية`
      );
    }
    return updated;
  }

  static addMaintenanceLogToVehicle(
    vehicleId: string,
    logData: Omit<VehicleMaintenanceLog, 'id' | 'vehicleId'>,
    actingUser = 'فني الصيانة والجاهزية'
  ): VehicleItem[] {
    const list = this.getVehicles();
    const index = list.findIndex(v => v.id === vehicleId);
    if (index !== -1) {
      const newLog: VehicleMaintenanceLog = {
        ...logData,
        id: `m-${Date.now()}`,
        vehicleId
      };
      if (!list[index].maintenanceLogs) {
        list[index].maintenanceLogs = [];
      }
      list[index].maintenanceLogs.unshift(newLog);
      list[index].lastMaintenanceDate = logData.date;

      if (logData.status === 'قيد التنفيذ' || logData.status === 'بانتظار قطع الغيار') {
        list[index].status = 'تحت الصيانة';
      } else if (logData.status === 'مكتملة' && list[index].status === 'تحت الصيانة') {
        list[index].status = 'جاهزة';
      }

      this.saveVehicles(list);

      // الخصم التلقائي من مخزن قطع الغيار إذا تم اختيار قطعة غيار
      if (logData.sparePartIdUsed && logData.sparePartQtyUsed && logData.sparePartQtyUsed > 0) {
        const spareParts = this.getSpareParts();
        const pIndex = spareParts.findIndex(sp => sp.id === logData.sparePartIdUsed);
        if (pIndex !== -1) {
          const deductQty = Math.min(spareParts[pIndex].quantity, logData.sparePartQtyUsed);
          spareParts[pIndex].quantity = Math.max(0, spareParts[pIndex].quantity - deductQty);
          this.saveSpareParts(spareParts);

          this.logAction(
            actingUser,
            'جاهزية العربات والآليات',
            'خصم قطعة غيار لصالح صيانة',
            list[index].plateNumber,
            spareParts[pIndex].name,
            `تم خصم تلقائي لعدد ${deductQty} ${spareParts[pIndex].unitOfMeasure || 'قطعة'} من (${spareParts[pIndex].name}) لتقييدها بكرت صيانة الآلية (${list[index].name})`
          );
        }
      }

      this.logAction(
        actingUser,
        'جاهزية العربات والآليات',
        'تسجيل عمل صيانة',
        list[index].plateNumber,
        list[index].name,
        `تم تسجيل عمل صيانة (${logData.type}) للآلية (${list[index].name}) - التكلفة: ${logData.cost} ريال`
      );
    }
    return list;
  }

  // إدارة مخزن قطع الغيار والمستلزمات (Spare Parts Warehouse Management)
  static getSpareParts(): SparePartItem[] {
    const key = this.getKeyForTenant(STORAGE_KEY_SPARE_PARTS);
    try {
      const data = safeGetLocalItem<SparePartItem[]>(key);
      if (data && Array.isArray(data) && data.length > 0) return data;
    } catch (e) {
      console.error('Failed to load spare parts data', e);
    }
    if (!hasUserSavedDataOnDevice(key) && !hasUserSavedDataOnDevice() && this.getActiveTenantId() === 'tenant-hq-main') {
      this.saveSpareParts(INITIAL_SPARE_PARTS_DATA);
      return INITIAL_SPARE_PARTS_DATA;
    }
    return [];
  }

  static saveSpareParts(parts: SparePartItem[]): void {
    try {
      const key = this.getKeyForTenant(STORAGE_KEY_SPARE_PARTS);
      const cloudDocId = this.getCloudDocIdForTenant('spare_parts');
      safeSetLocalItem(key, parts);
      syncDocToCloud(cloudDocId, parts);
      notifyDataChange();
    } catch (e) {
      console.error('Failed to save spare parts data', e);
    }
  }

  static addSparePart(
    partData: Omit<SparePartItem, 'id'>,
    actingUser = 'مسؤول مخزن قطع الغيار'
  ): SparePartItem {
    const list = this.getSpareParts();
    const newPart: SparePartItem = {
      ...partData,
      id: `sp-${Date.now()}`
    };
    list.unshift(newPart);
    this.saveSpareParts(list);

    this.logAction(
      actingUser,
      'جاهزية العربات والآليات',
      'تسجيل وارد قطعة غيار',
      newPart.code,
      newPart.name,
      `تم تسجيل وارد مخزني جديد (${newPart.name}) - الكمية: ${newPart.quantity} ${newPart.unitOfMeasure || 'قطعة'} - السعر التقديري: ${newPart.unitPrice} ريال`
    );

    return newPart;
  }

  static updateSparePart(
    partId: string,
    updates: Partial<SparePartItem>,
    actingUser = 'مسؤول مخزن قطع الغيار'
  ): SparePartItem[] {
    const list = this.getSpareParts();
    const index = list.findIndex(p => p.id === partId);
    if (index !== -1) {
      list[index] = { ...list[index], ...updates };
      this.saveSpareParts(list);
      this.logAction(
        actingUser,
        'جاهزية العربات والآليات',
        'تعديل صنف بمخزن قطع الغيار',
        list[index].code,
        list[index].name,
        `تم تحديث بيانات قطعة الغيار (${list[index].name})`
      );
    }
    return list;
  }

  static deleteSparePart(partId: string, actingUser = 'مسؤول مخزن قطع الغيار'): SparePartItem[] {
    const list = this.getSpareParts();
    const target = list.find(p => p.id === partId);
    const updated = list.filter(p => p.id !== partId);
    this.saveSpareParts(updated);

    if (target) {
      this.logAction(
        actingUser,
        'جاهزية العربات والآليات',
        'حذف قطعة غيار من المخزن',
        target.code,
        target.name,
        `تم حذف قطعة الغيار (${target.name}) من المخزن الرئيسي`
      );
    }
    return updated;
  }

  // إدارة أوامر وسندات الصرف للآليات والأجهزة (Vehicle & Equipment Dispense Orders)
  static getVehicleDispenseOrders(): VehicleDispenseOrder[] {
    const key = this.getKeyForTenant(STORAGE_KEY_VEHICLE_DISPENSES);
    try {
      const data = safeGetLocalItem<VehicleDispenseOrder[]>(key);
      if (data && Array.isArray(data) && data.length > 0) return data;
    } catch (e) {
      console.error('Failed to load vehicle dispense orders', e);
    }
    if (!hasUserSavedDataOnDevice(key) && !hasUserSavedDataOnDevice() && this.getActiveTenantId() === 'tenant-hq-main') {
      this.saveVehicleDispenseOrders(INITIAL_VEHICLE_DISPENSE_ORDERS);
      return INITIAL_VEHICLE_DISPENSE_ORDERS;
    }
    return [];
  }

  static saveVehicleDispenseOrders(orders: VehicleDispenseOrder[]): void {
    try {
      const key = this.getKeyForTenant(STORAGE_KEY_VEHICLE_DISPENSES);
      const cloudDocId = this.getCloudDocIdForTenant('vehicle_dispense_orders');
      safeSetLocalItem(key, orders);
      syncDocToCloud(cloudDocId, orders);
      notifyDataChange();
    } catch (e) {
      console.error('Failed to save vehicle dispense orders', e);
    }
  }

  static addVehicleDispenseOrder(
    orderData: Omit<VehicleDispenseOrder, 'id' | 'timestamp'>,
    actingUser = 'مسؤول ركن العربات'
  ): VehicleDispenseOrder {
    const list = this.getVehicleDispenseOrders();
    const nowStr = new Date().toISOString().replace('T', ' ').substring(0, 16);
    const newOrder: VehicleDispenseOrder = {
      ...orderData,
      id: `vdisp-${Date.now()}`,
      timestamp: nowStr
    };
    list.unshift(newOrder);
    this.saveVehicleDispenseOrders(list);

    // If an inventory vehicle/item was selected, update its status to 'منصرف' and assign recipient
    if (newOrder.itemId) {
      const vehicles = this.getVehicles();
      const vIndex = vehicles.findIndex(v => v.id === newOrder.itemId);
      if (vIndex !== -1) {
        vehicles[vIndex] = {
          ...vehicles[vIndex],
          status: 'منصرف',
          assignedUnit: newOrder.recipientUnit || vehicles[vIndex].assignedUnit,
          assignedDriverName: newOrder.recipientName,
          assignedDriverMilitaryId: newOrder.recipientMilitaryId,
          notes: `منصرف بموجب أمر صرف رقم ${newOrder.orderNumber} - المستلم: ${newOrder.recipientName}`
        };
        this.saveVehicles(vehicles);
      }
    }

    // Update Personnel records:
    // 1. Recipient (المستلم): Register the custody in p.logs.supply and movement note in p.logs.movement
    // 2. Guarantor (الضمين): Register guarantee in p.logs.movement if guarantor is a registered personnel
    try {
      const allPersonnel = this.getPersonnel();
      let personnelUpdated = false;

      // Find recipient by militaryId or fullName
      const rIndex = allPersonnel.findIndex(
        p => (newOrder.recipientMilitaryId && p.militaryId === newOrder.recipientMilitaryId) ||
             (newOrder.recipientName && p.fullName?.trim() === newOrder.recipientName.trim())
      );

      if (rIndex !== -1) {
        const recipient = { ...allPersonnel[rIndex] };
        if (!recipient.logs) {
          recipient.logs = {
            movement: [],
            attendance: [],
            medical: [],
            financial: [],
            security: [],
            armament: [],
            training: [],
            attachments: [],
            supply: []
          };
        }
        const supplyLogs = [...(recipient.logs.supply || [])];
        const movementLogs = [...(recipient.logs.movement || [])];

        // Register custody in supply logs
        const newSupplyEntry: SupplyLog = {
          id: `sup-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`,
          itemType: (newOrder.itemType === 'آلية عسكرية' ? 'آلية عسكرية' : 'أجهزة ومعدات أخرى') as any,
          itemName: `${newOrder.itemType}: ${newOrder.itemName} [لوحة/سيريال: ${newOrder.itemSerialOrPlate}]`,
          quantity: Number(newOrder.quantity) || 1,
          issueDate: newOrder.orderDate || nowStr.split(' ')[0],
          condition: (newOrder.itemCondition?.includes('جديد') ? 'جديد' : 'مستعمل ممتازة') as any,
          issuedBy: `${newOrder.orderSource} (أمر صرف: ${newOrder.orderNumber})`,
          serialNumber: newOrder.itemSerialOrPlate,
          notes: `أمر صرف عهدة رقم: ${newOrder.orderNumber} - سبب الصرف: ${newOrder.dispenseReason} - الضمين: ${newOrder.guarantorRank || ''} ${newOrder.guarantorName} (رقم عسكري/وطني: ${newOrder.guarantorMilitaryId || newOrder.guarantorNationalId || 'غير مسجل'} - هاتف: ${newOrder.guarantorPhone || 'غير مدون'})`
        };
        supplyLogs.unshift(newSupplyEntry);

        // Register movement log for recipient
        movementLogs.unshift({
          id: `mov-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`,
          date: newOrder.orderDate || nowStr.split(' ')[0],
          type: 'صرف عهدة آلية/معدة',
          reason: `استلام عهدة (${newOrder.itemName} - ${newOrder.itemSerialOrPlate}) بموجب أمر صرف رقم ${newOrder.orderNumber} بكفالة الضمين (${newOrder.guarantorName})`,
          notes: `العهدة: ${newOrder.itemType} - ${newOrder.itemName} (لوحة/سيريال: ${newOrder.itemSerialOrPlate}) - الكمية: ${newOrder.quantity}`
        });

        // Set or update guarantor on recipient profile if not present
        if (!recipient.guarantorName && newOrder.guarantorName) {
          recipient.guarantorName = newOrder.guarantorName;
        }

        recipient.logs.supply = supplyLogs;
        recipient.logs.movement = movementLogs;
        allPersonnel[rIndex] = recipient;
        personnelUpdated = true;
      }

      // Find guarantor by militaryId or fullName if militaryId is not civilian placeholder
      const isCivilianOrNoId = !newOrder.guarantorMilitaryId ||
        ['مدني', 'بدون', 'غير مسجل', 'خارجي', 'لا يوجد', '-'].includes(newOrder.guarantorMilitaryId.trim());

      const gIndex = allPersonnel.findIndex(
        p => (!isCivilianOrNoId && p.militaryId === newOrder.guarantorMilitaryId) ||
             (newOrder.guarantorName && p.fullName?.trim() === newOrder.guarantorName.trim())
      );

      if (gIndex !== -1 && gIndex !== rIndex) {
        const guarantor = { ...allPersonnel[gIndex] };
        if (!guarantor.logs) {
          guarantor.logs = {
            movement: [],
            attendance: [],
            medical: [],
            financial: [],
            security: [],
            armament: [],
            training: [],
            attachments: [],
            supply: []
          };
        }
        const gMovementLogs = [...(guarantor.logs.movement || [])];

        gMovementLogs.unshift({
          id: `gmov-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`,
          date: newOrder.orderDate || nowStr.split(' ')[0],
          type: 'تقييد كفالة وضمانة عهدة',
          reason: `كفالة وضمانة الفرد المستلم (${newOrder.recipientRank || ''} / ${newOrder.recipientName} - رقم عسكري: ${newOrder.recipientMilitaryId}) في عهدة (${newOrder.itemType}: ${newOrder.itemName} - لوحة/سيريال: ${newOrder.itemSerialOrPlate}) بموجب أمر صرف رقم ${newOrder.orderNumber}`,
          notes: `تم تقييد الالتزام بالضمانة في السجل الرسمي للعهدة برقم أمر صرف ${newOrder.orderNumber}`
        });

        guarantor.logs.movement = gMovementLogs;
        allPersonnel[gIndex] = guarantor;
        personnelUpdated = true;
      }

      if (personnelUpdated) {
        this.savePersonnel(allPersonnel);
      }
    } catch (err) {
      console.error('Failed to link vehicle dispense order to personnel files:', err);
    }

    this.logAction(
      actingUser,
      'جاهزية العربات والآليات',
      'إصدار أمر صرف عهدة',
      newOrder.orderNumber,
      newOrder.itemName,
      `تم إصدار سند صرف (${newOrder.itemType}: ${newOrder.itemName}) للمستلم: ${newOrder.recipientName} (الضمين: ${newOrder.guarantorName}) وتقييد العهدة بالسجل الإلكتروني`
    );

    return newOrder;
  }

  static deleteVehicleDispenseOrder(
    orderId: string,
    actingUser = 'مسؤول ركن العربات'
  ): VehicleDispenseOrder[] {
    const list = this.getVehicleDispenseOrders();
    const target = list.find(o => o.id === orderId);
    const updated = list.filter(o => o.id !== orderId);
    this.saveVehicleDispenseOrders(updated);

    if (target) {
      // Revert vehicle status if it was assigned by this order
      if (target.itemId) {
        const vehicles = this.getVehicles();
        const vIndex = vehicles.findIndex(v => v.id === target.itemId);
        if (vIndex !== -1 && vehicles[vIndex].status === 'منصرف') {
          vehicles[vIndex] = {
            ...vehicles[vIndex],
            status: 'جاهزة',
            assignedDriverName: '',
            assignedDriverMilitaryId: '',
            notes: (vehicles[vIndex].notes || '')
              .replace(`منصرف بموجب أمر صرف رقم ${target.orderNumber} - المستلم: ${target.recipientName}`, '')
              .trim()
          };
          this.saveVehicles(vehicles);
        }
      }

      // Remove related custody and guarantee logs from all personnel
      try {
        const allPersonnel = this.getPersonnel();
        let personnelModified = false;

        allPersonnel.forEach(p => {
          if (!p.logs) return;
          let changed = false;

          // Remove supply logs matching this order number
          if (p.logs.supply) {
            const initialLen = p.logs.supply.length;
            p.logs.supply = p.logs.supply.filter(
              s => !s.notes?.includes(target.orderNumber) && !s.issuedBy?.includes(target.orderNumber)
            );
            if (p.logs.supply.length !== initialLen) changed = true;
          }

          // Remove movement logs matching this order number
          if (p.logs.movement) {
            const initialLen = p.logs.movement.length;
            p.logs.movement = p.logs.movement.filter(
              m => !m.reason?.includes(target.orderNumber) && !m.notes?.includes(target.orderNumber)
            );
            if (p.logs.movement.length !== initialLen) changed = true;
          }

          if (changed) personnelModified = true;
        });

        if (personnelModified) {
          this.savePersonnel(allPersonnel);
        }
      } catch (err) {
        console.error('Failed to clean up personnel logs on delete dispense order:', err);
      }

      this.logAction(
        actingUser,
        'جاهزية العربات والآليات',
        'إلغاء/حذف سند صرف',
        target.orderNumber,
        target.itemName,
        `تم إلغاء وحذف سند الصرف رقم (${target.orderNumber}) للآلية/المعدة: ${target.itemName} وإخلاء قيود العهدة من سجلات الأفراد`
      );
    }
    return updated;
  }

  // إدارة العربات والآليات المرجعة وسندات إخلاء العهدة (Vehicle Return & Clearance Orders)
  static getVehicleReturnOrders(): VehicleReturnClearanceOrder[] {
    const key = this.getKeyForTenant(STORAGE_KEY_VEHICLE_RETURNS);
    try {
      const data = safeGetLocalItem<VehicleReturnClearanceOrder[]>(key);
      if (data && Array.isArray(data) && data.length > 0) return data;
    } catch (e) {
      console.error('Failed to load vehicle return orders', e);
    }
    if (!hasUserSavedDataOnDevice(key) && !hasUserSavedDataOnDevice() && this.getActiveTenantId() === 'tenant-hq-main') {
      this.saveVehicleReturnOrders(INITIAL_VEHICLE_RETURN_ORDERS);
      return INITIAL_VEHICLE_RETURN_ORDERS;
    }
    return [];
  }

  static saveVehicleReturnOrders(orders: VehicleReturnClearanceOrder[]): void {
    try {
      const key = this.getKeyForTenant(STORAGE_KEY_VEHICLE_RETURNS);
      const cloudDocId = this.getCloudDocIdForTenant('vehicle_return_orders');
      safeSetLocalItem(key, orders);
      syncDocToCloud(cloudDocId, orders);
      notifyDataChange();
    } catch (e) {
      console.error('Failed to save vehicle return orders', e);
    }
  }

  static addVehicleReturnOrder(
    orderData: Omit<VehicleReturnClearanceOrder, 'id' | 'timestamp'>,
    actingUser = 'مسؤول ركن الفنية والحركة'
  ): VehicleReturnClearanceOrder {
    const list = this.getVehicleReturnOrders();
    const nowStr = new Date().toISOString().replace('T', ' ').substring(0, 16);
    const newOrder: VehicleReturnClearanceOrder = {
      ...orderData,
      id: `vret-${Date.now()}`,
      timestamp: nowStr
    };
    list.unshift(newOrder);
    this.saveVehicleReturnOrders(list);

    // If an existing vehicle was selected from inventory, update its status and attach return details
    if (newOrder.vehicleId) {
      const vehicles = this.getVehicles();
      const vIndex = vehicles.findIndex(v => v.id === newOrder.vehicleId);
      if (vIndex !== -1) {
        vehicles[vIndex] = {
          ...vehicles[vIndex],
          status: 'مرجعة للفنية والحركة المركزية',
          location: newOrder.recipientBranch || 'فرع الفنية والحركة المركزي الرئيسي',
          notes: `${vehicles[vIndex].notes || ''}\n(أُرجعت إلى الفنية والحركة المركزي بسند رقم ${newOrder.returnNumber} بتاريخ ${newOrder.returnDate}. الملاحظة: ${newOrder.handoverConditionNotes})`.trim(),
          returnDetails: {
            isReturned: true,
            returnDate: newOrder.returnDate,
            returnNumber: newOrder.returnNumber,
            returnedToBranch: newOrder.recipientBranch || 'فرع الفنية والحركة المركزي الرئيسي',
            conditionAtHandover: newOrder.conditionAtHandover,
            handoverConditionNotes: newOrder.handoverConditionNotes,
            handoverPersonName: newOrder.handoverPersonName,
            receivingOfficerName: newOrder.receivingOfficerName
          }
        };
        this.saveVehicles(vehicles);
      }
    }

    this.logAction(
      actingUser,
      'جاهزية العربات والآليات',
      'إصدار سند إخلاء عهدة وإرجاع',
      newOrder.returnNumber,
      newOrder.vehicleName,
      `تم إصدار سند إخلاء عهدة وإرجاع الآلية (${newOrder.vehicleName} - ${newOrder.plateNumber}) لفرع الفنية والحركة المركزي من المسلّم: ${newOrder.handoverPersonName}. الحالة: ${newOrder.conditionAtHandover}`
    );

    return newOrder;
  }

  static updateVehicleReturnOrder(
    orderId: string,
    updates: Partial<VehicleReturnClearanceOrder>,
    actingUser = 'مسؤول ركن الفنية والحركة'
  ): VehicleReturnClearanceOrder[] {
    const list = this.getVehicleReturnOrders();
    const index = list.findIndex(o => o.id === orderId);
    if (index !== -1) {
      list[index] = { ...list[index], ...updates };
      this.saveVehicleReturnOrders(list);

      // Sync with vehicle record if attached
      const vehicleId = list[index].vehicleId;
      if (vehicleId) {
        const vehicles = this.getVehicles();
        const vIndex = vehicles.findIndex(v => v.id === vehicleId);
        if (vIndex !== -1 && vehicles[vIndex].returnDetails) {
          vehicles[vIndex] = {
            ...vehicles[vIndex],
            returnDetails: {
              ...vehicles[vIndex].returnDetails!,
              conditionAtHandover: list[index].conditionAtHandover,
              handoverConditionNotes: list[index].handoverConditionNotes,
              handoverPersonName: list[index].handoverPersonName,
              receivingOfficerName: list[index].receivingOfficerName,
              returnDate: list[index].returnDate
            }
          };
          this.saveVehicles(vehicles);
        }
      }

      this.logAction(
        actingUser,
        'جاهزية العربات والآليات',
        'تعديل سند إخلاء عهدة',
        list[index].returnNumber,
        list[index].vehicleName,
        `تم تعديل بيانات سند إخلاء العهدة والملاحظة الفنية للآلية (${list[index].vehicleName})`
      );
    }
    return list;
  }

  static deleteVehicleReturnOrder(
    orderId: string,
    restoreVehicleToActive = true,
    actingUser = 'مسؤول ركن الفنية والحركة'
  ): VehicleReturnClearanceOrder[] {
    const list = this.getVehicleReturnOrders();
    const target = list.find(o => o.id === orderId);
    const updated = list.filter(o => o.id !== orderId);
    this.saveVehicleReturnOrders(updated);

    if (target) {
      // Optional restore vehicle to active status
      if (restoreVehicleToActive && target.vehicleId) {
        const vehicles = this.getVehicles();
        const vIndex = vehicles.findIndex(v => v.id === target.vehicleId);
        if (vIndex !== -1) {
          vehicles[vIndex] = {
            ...vehicles[vIndex],
            status: 'جاهزة',
            location: 'المقر الرئيسي للجاهزية',
            returnDetails: undefined
          };
          this.saveVehicles(vehicles);
        }
      }

      this.logAction(
        actingUser,
        'جاهزية العربات والآليات',
        'إلغاء/حذف سند إخلاء عهدة',
        target.returnNumber,
        target.vehicleName,
        `تم إلغاء وحذف سند إخلاء العهدة رقم (${target.returnNumber}) للآلية: ${target.vehicleName}`
      );
    }
    return updated;
  }

  // Process a new Armory Intake (تسجيل وارد جديد)
  static processArmoryIntake(
    intakeData: Omit<ArmoryIntakeRecord, 'id' | 'date'>,
    actingUser = 'ضابط التسليح والذخيرة',
    actingDept: DepartmentRole = 'إدارة التسليح'
  ): void {
    const intakes = this.getArmoryIntakes();
    const now = new Date().toISOString().split('T')[0];
    const newIntake: ArmoryIntakeRecord = {
      ...intakeData,
      id: `INT-${Date.now()}`,
      date: now
    };

    intakes.unshift(newIntake);
    this.saveArmoryIntakes(intakes);

    // Update or add to inventory stock
    const inventory = this.getArmoryInventory();
    const existingIndex = inventory.findIndex(
      (inv) =>
        inv.itemType === intakeData.itemType &&
        inv.name.trim().toLowerCase() === intakeData.name.trim().toLowerCase() &&
        inv.caliber.trim().toLowerCase() === intakeData.caliber.trim().toLowerCase()
    );

    if (existingIndex !== -1) {
      inventory[existingIndex].totalReceived += intakeData.quantity;
      inventory[existingIndex].availableQty += intakeData.quantity;
      inventory[existingIndex].lastUpdated = now;
      if (intakeData.expiryDate) {
        inventory[existingIndex].expiryDate = intakeData.expiryDate;
      }
    } else {
      inventory.push({
        id: `inv-${Date.now()}`,
        itemType: intakeData.itemType,
        name: intakeData.name,
        category: intakeData.itemType === 'weapon' ? 'بنادق/أسلحة' : 'ذخائر حية',
        caliber: intakeData.caliber,
        totalReceived: intakeData.quantity,
        availableQty: intakeData.quantity,
        issuedQty: 0,
        inMaintenanceQty: 0,
        minThreshold: intakeData.itemType === 'weapon' ? 10 : 1000,
        storageLocation: 'مخزن التسليح الرئيسي',
        unit: 'اللواء الأول',
        expiryDate: intakeData.expiryDate,
        lastUpdated: now
      });
    }

    this.saveArmoryInventory(inventory);

    // If it's a weapon intake, generate tracked weapon pieces with serial numbers
    if (intakeData.itemType === 'weapon') {
      const weapons = this.getArmoryWeapons();
      const countToCreate = Math.min(intakeData.quantity, 50);
      const batchCode = intakeData.batchNumber ? intakeData.batchNumber.replace(/[^a-zA-Z0-9]/g, '') : `B${Date.now().toString().slice(-4)}`;
      const prefix = intakeData.name.replace(/[^\u0621-\u064Aa-zA-Z0-9]/g, '').slice(0, 3).toUpperCase() || 'WPN';
      
      for (let i = 1; i <= countToCreate; i++) {
        weapons.push({
          id: `wp-intake-${Date.now()}-${i}`,
          serialNumber: `${prefix}-${batchCode}-${String(i).padStart(3, '0')}`,
          weaponType: intakeData.name,
          caliber: intakeData.caliber,
          manufactureYear: new Date().getFullYear().toString(),
          technicalCondition: 'جاهز',
          status: 'في المخزن',
          storageLocation: 'مخزن التسليح الرئيسي',
          entryDate: now,
          notes: `وارد بموجب الشحنة: ${intakeData.batchNumber || batchCode}`
        });
      }
      this.saveArmoryWeapons(weapons);
    }

    this.logAction(
      actingUser,
      actingDept,
      'تسجيل وارد تسليح/ذخائر',
      '-',
      'مخزن التسليح المركزية',
      `استلام: ${intakeData.name} (${intakeData.caliber}) - الكمية: ${intakeData.quantity} - المصدر: ${intakeData.source}`
    );
  }

  // Helper to check if personnel currently has an active weapon in custody
  static getActiveWeaponForPersonnel(person: PersonnelRecord): ArmamentLog | undefined {
    if (!person) return undefined;
    const cleanId = String(person.militaryId || '').trim().toLowerCase();
    const cleanName = (person.fullName || '').trim().toLowerCase();

    // 1. Authoritative: Check active Armory Issue Orders from Armory Branch
    const issues = this.getArmoryIssues();
    const activeIssue = issues.find((iss) => {
      if (iss.status !== 'نشط') return false;
      const serial = (iss.weaponSerial || '').trim();
      if (!serial || serial === 'ذخيرة فقط' || serial === '-' || serial.toLowerCase() === `ak-${cleanId}`) return false;
      const issId = String(iss.recipientMilitaryId || '').trim().toLowerCase();
      const issName = (iss.recipientName || '').trim().toLowerCase();
      return (issId && issId === cleanId) || (cleanName && (issName === cleanName || issName.includes(cleanName) || cleanName.includes(issName)));
    });

    if (activeIssue && activeIssue.weaponSerial) {
      return {
        id: activeIssue.id,
        weaponSerial: activeIssue.weaponSerial.trim(),
        weaponType: activeIssue.weaponType || 'بندقية آلي كلاشنكوف AK-47',
        issueDate: activeIssue.date,
        status: 'بحوزته',
        ammoQty: activeIssue.issuedAmmoQty,
        firelinesCount: 4,
        ammoHistory: [],
        condition: 'ممتازة',
        technicalNotes: activeIssue.notes || `أمر صرف تسليح رقم ${activeIssue.orderNumber}`
      };
    }

    // 2. Check Armory tracked pieces assigned to this individual (قطع السلاح المنصرفة للفرد)
    const pieces = this.getArmoryWeapons();
    const activePiece = pieces.find((piece) => {
      if (piece.status !== 'منصرف للفرد') return false;
      const pSerial = (piece.serialNumber || '').trim();
      if (!pSerial || pSerial === 'ذخيرة فقط' || pSerial === '-' || pSerial.toLowerCase() === `ak-${cleanId}`) return false;
      const pId = String(piece.currentHolderMilitaryId || '').trim().toLowerCase();
      const pName = (piece.currentHolderName || '').trim().toLowerCase();
      return (pId && pId === cleanId) || (cleanName && (pName === cleanName || pName.includes(cleanName) || cleanName.includes(pName)));
    });

    if (activePiece && activePiece.serialNumber) {
      return {
        id: activePiece.id,
        weaponSerial: activePiece.serialNumber.trim(),
        weaponType: activePiece.weaponType || 'بندقية آلي كلاشنكوف AK-47',
        issueDate: activePiece.entryDate,
        status: 'بحوزته',
        ammoQty: 120,
        firelinesCount: 4,
        ammoHistory: [],
        condition: 'ممتازة',
        technicalNotes: activePiece.notes || 'قطعة سلاح منصرفة من مخزن التسليح'
      };
    }

    // 3. Check person's primary logs.armament
    if (person.logs && Array.isArray(person.logs.armament)) {
      const activeLog = person.logs.armament.find(
        (a) =>
          !a.returnDate &&
          a.status !== 'مورد' &&
          a.status !== 'في المخزن' &&
          a.weaponSerial &&
          a.weaponSerial.trim() !== '' &&
          a.weaponSerial !== 'ذخيرة فقط' &&
          a.weaponSerial !== '-' &&
          a.weaponSerial.trim().toLowerCase() !== `ak-${cleanId}` &&
          a.weaponType !== 'صرف ذخيرة'
      );
      if (activeLog) return activeLog;
    }

    // 4. Check person's armamentLogs
    if (Array.isArray(person.armamentLogs)) {
      const activeLog = person.armamentLogs.find(
        (a) =>
          !a.returnDate &&
          a.status !== 'مورد' &&
          a.status !== 'في المخزن' &&
          a.weaponSerial &&
          a.weaponSerial.trim() !== '' &&
          a.weaponSerial !== 'ذخيرة فقط' &&
          a.weaponSerial !== '-' &&
          a.weaponSerial.trim().toLowerCase() !== `ak-${cleanId}`
      );
      if (activeLog) return activeLog;
    }

    // 5. Check direct armament object on person
    if (person.armament) {
      const d = person.armament;
      const directSerial = (d.serialNumber || d.weaponSerial || '').trim();
      if (directSerial && directSerial !== 'ذخيرة فقط' && directSerial !== '-' && directSerial.toLowerCase() !== `ak-${cleanId}`) {
        return {
          id: `arm-direct-${person.militaryId}`,
          weaponSerial: directSerial,
          weaponType: d.weaponType || d.name || 'بندقية آلي كلاشنكوف AK-47',
          issueDate: new Date().toISOString().split('T')[0],
          status: 'بحوزته',
          ammoQty: d.ammoQty || 120,
          firelinesCount: d.magazinesCount || 4,
          ammoHistory: [],
          condition: 'ممتازة',
          technicalNotes: d.notes || 'سلاح عهدة مباشرة بملف الفرد'
        };
      }
    }

    return undefined;
  }

  // Comprehensive helper to get all active weapons in custody for a personnel member
  static getActiveWeaponsForPersonnel(militaryId: string): Array<{
    weaponType: string;
    weaponSerial: string;
    magazinesCount: number;
    ammoCount: number;
    notes: string;
    source: string;
  }> {
    if (!militaryId) return [];
    const cleanId = String(militaryId).trim().toLowerCase();
    const list = this.getPersonnel();
    const person = list.find((p) => String(p.militaryId || '').trim().toLowerCase() === cleanId);
    const cleanName = (person?.fullName || '').trim().toLowerCase();

    const results: Array<{
      weaponType: string;
      weaponSerial: string;
      magazinesCount: number;
      ammoCount: number;
      notes: string;
      source: string;
    }> = [];

    const seenSerials = new Set<string>();

    const addWeaponIfUnique = (
      type: string | undefined,
      serial: string | undefined,
      mags: number | undefined,
      ammo: number | undefined,
      notes: string | undefined,
      source: string
    ) => {
      const cleanSerial = (serial || '').trim();
      if (!cleanSerial || cleanSerial === '-' || cleanSerial === 'ذخيرة فقط') return;
      // Never allow fabricated fallback fake serials like 'AK-12345' matching the military ID
      if (cleanSerial.toLowerCase() === `ak-${cleanId}`) return;
      
      const lower = cleanSerial.toLowerCase();
      if (seenSerials.has(lower)) return;
      seenSerials.add(lower);

      results.push({
        weaponType: (type || 'بندقية آلي كلاشنكوف AK-47').trim(),
        weaponSerial: cleanSerial,
        magazinesCount: Number(mags) || 4,
        ammoCount: Number(ammo) || 120,
        notes: (notes || '').trim(),
        source
      });
    };

    // 1. Authoritative: Active Armory Issue Orders (أوامر صرف التسليح المعتمدة)
    const issues = this.getArmoryIssues();
    issues.forEach((iss) => {
      if (iss.status !== 'نشط') return;
      const issId = String(iss.recipientMilitaryId || '').trim().toLowerCase();
      const issName = (iss.recipientName || '').trim().toLowerCase();
      const isMatch = (issId && issId === cleanId) || (cleanName && (issName === cleanName || issName.includes(cleanName) || cleanName.includes(issName)));
      if (isMatch) {
        addWeaponIfUnique(
          iss.weaponType,
          iss.weaponSerial,
          4,
          iss.issuedAmmoQty,
          iss.notes || `أمر صرف تسليح رقم ${iss.orderNumber}`,
          'أمر صرف تسليح نشط'
        );
      }
    });

    // 2. Armory tracked pieces in possession (قطع السلاح المنصرفة بمخزن التسليح)
    const pieces = this.getArmoryWeapons();
    pieces.forEach((piece) => {
      if (piece.status !== 'منصرف للفرد') return;
      const pId = String(piece.currentHolderMilitaryId || '').trim().toLowerCase();
      const pName = (piece.currentHolderName || '').trim().toLowerCase();
      const isMatch = (pId && pId === cleanId) || (cleanName && (pName === cleanName || pName.includes(cleanName) || cleanName.includes(pName)));
      if (isMatch) {
        addWeaponIfUnique(
          piece.weaponType,
          piece.serialNumber,
          4,
          120,
          piece.notes || 'قطعة سلاح مسجلة بمخزن التسليح بحوزة الفرد',
          'مخزن التسليح (قطعة منصرفة)'
        );
      }
    });

    // 3. Check person's logs.armament (primary registry)
    if (person && person.logs && Array.isArray(person.logs.armament)) {
      person.logs.armament.forEach((a) => {
        if (!a.returnDate && a.status !== 'مورد' && a.status !== 'في المخزن' && a.weaponType !== 'صرف ذخيرة') {
          addWeaponIfUnique(
            a.weaponType,
            a.weaponSerial,
            a.firelinesCount,
            a.ammoQty,
            a.technicalNotes || 'سلاح مقيد في عهدة الفرد',
            'سجل تسليح الفرد'
          );
        }
      });
    }

    // 4. Check person's armamentLogs (secondary array)
    if (person && Array.isArray(person.armamentLogs)) {
      person.armamentLogs.forEach((a) => {
        if (!a.returnDate && a.status !== 'مورد' && a.status !== 'في المخزن' && a.weaponType !== 'صرف ذخيرة') {
          addWeaponIfUnique(
            a.weaponType,
            a.weaponSerial,
            a.firelinesCount,
            a.ammoQty,
            a.technicalNotes || 'سجل تسليح الفرد',
            'سجل تسليح الفرد'
          );
        }
      });
    }

    // 5. Check direct armament object on person
    if (person && person.armament) {
      const d = person.armament;
      addWeaponIfUnique(
        d.weaponType || d.name,
        d.serialNumber || d.weaponSerial,
        d.magazinesCount,
        d.ammoQty,
        d.notes || 'سلاح عهدة مباشرة',
        'ملف التسليح'
      );
    }

    // 6. Check last attendance log with weapon if any
    if (person && person.logs && Array.isArray(person.logs.attendance)) {
      const lastAttWithWpn = person.logs.attendance
        .slice()
        .reverse()
        .find((att) => att.withWeapon && att.weaponDetails?.primaryWeapon?.weaponSerial);
      if (lastAttWithWpn && lastAttWithWpn.weaponDetails?.primaryWeapon) {
        const pw = lastAttWithWpn.weaponDetails.primaryWeapon;
        addWeaponIfUnique(
          pw.weaponType,
          pw.weaponSerial,
          pw.magazinesCount,
          pw.ammoCount,
          pw.notes || 'مستورد من آخر إجازة/إذن مع السلاح',
          'سجل الأذونات السابقة'
        );
      }
    }

    return results;
  }

  // Process a new Armory Dispense / Issue Order (عملية صرف سلاح/ذخيرة)
  static processArmoryIssue(
    orderData: Omit<ArmoryIssueOrder, 'id' | 'orderNumber' | 'date' | 'status'>,
    actingUser = 'ضابط التسليح',
    actingDept: DepartmentRole = 'إدارة التسليح'
  ): { success: boolean; message: string; order?: ArmoryIssueOrder; alreadyArmed?: boolean; existingWeapon?: ArmamentLog } {
    // 1. Double-arming check: Ensure the soldier is NOT already armed with an active weapon piece
    if (orderData.weaponType && orderData.recipientMilitaryId) {
      const recipient = this.getPersonnelById(orderData.recipientMilitaryId);
      if (recipient) {
        const existingWeapon = this.getActiveWeaponForPersonnel(recipient);
        if (existingWeapon) {
          return {
            success: false,
            alreadyArmed: true,
            existingWeapon,
            message: `تحذير أمني: الفرد (${recipient.rank} / ${recipient.fullName}) مسلّح بالفعل ولديه سلاح عهدة بحوزته: [${existingWeapon.weaponType} - S/N: ${existingWeapon.weaponSerial}]. لا يمكن تسليحه مرة أخرى إلا بعد توريد السلاح السابق إلى مخازن التسليح.`
          };
        }
      }
    }

    const inventory = this.getArmoryInventory();

    // Find ammo stock item if ammo issued
    if (orderData.issuedAmmoQty > 0 && orderData.ammoType) {
      const ammoItem = inventory.find(
        (inv) =>
          inv.itemType === 'ammo' &&
          (inv.name.includes(orderData.ammoType) || orderData.ammoType.includes(inv.name))
      );

      if (ammoItem) {
        if (ammoItem.availableQty < orderData.issuedAmmoQty) {
          return {
            success: false,
            message: `عذراً! الكمية المطلوبة من الذخيرة (${orderData.issuedAmmoQty}) أكبر من الكمية المتوفرة بالمخزن حالياً (${ammoItem.availableQty}).`
          };
        }
        ammoItem.availableQty -= orderData.issuedAmmoQty;
        ammoItem.issuedQty += orderData.issuedAmmoQty;
        ammoItem.lastUpdated = new Date().toISOString().split('T')[0];
      }
    }

    // Find weapon stock item if weapon issued
    if (orderData.weaponType) {
      const weaponItem = inventory.find(
        (inv) =>
          inv.itemType === 'weapon' &&
          (inv.name.includes(orderData.weaponType) || orderData.weaponType.includes(inv.name))
      );

      if (weaponItem) {
        if (weaponItem.availableQty <= 0) {
          return {
            success: false,
            message: `عذراً! لا يوجد رصيد متاح حالياً من النوع (${orderData.weaponType}) بالمخزن.`
          };
        }
        weaponItem.availableQty -= 1;
        weaponItem.issuedQty += 1;
        weaponItem.lastUpdated = new Date().toISOString().split('T')[0];
      }
    }

    this.saveArmoryInventory(inventory);

    // Create Issue Order
    const issues = this.getArmoryIssues();
    const now = new Date();
    const dateStr = now.toISOString().split('T')[0] + ' ' + now.toTimeString().slice(0, 5);
    const orderNumber = `ORD-${now.getFullYear()}-${Math.floor(1000 + Math.random() * 9000)}`;

    const newOrder: ArmoryIssueOrder = {
      ...orderData,
      id: `iss-${Date.now()}`,
      orderNumber,
      date: dateStr,
      status: 'نشط'
    };

    issues.unshift(newOrder);
    this.saveArmoryIssues(issues);

    // Update tracked weapon piece status if serial provided
    if (orderData.weaponSerial) {
      const weapons = this.getArmoryWeapons();
      const piece = weapons.find(
        (w) => w.serialNumber.trim().toLowerCase() === orderData.weaponSerial?.trim().toLowerCase()
      );

      if (piece) {
        piece.status = 'منصرف للفرد';
        piece.currentHolderMilitaryId = orderData.recipientMilitaryId;
        piece.currentHolderName = orderData.recipientName;
        piece.currentHolderUnit = orderData.unit;
        this.saveArmoryWeapons(weapons);
      }

      // Record Lifecycle event
      const lifecycle = this.getWeaponLifecycle();
      lifecycle.unshift({
        id: `lc-${Date.now()}`,
        weaponSerial: orderData.weaponSerial,
        weaponType: orderData.weaponType,
        eventType: 'صرف للفرد',
        date: dateStr.split(' ')[0],
        actor: actingUser,
        recipientOrUnit: `${orderData.recipientRank} / ${orderData.recipientName} (${orderData.unit})`,
        details: `صرف بموجب أمر أمر الصرف رقم ${orderNumber} - ذخيرة: ${orderData.issuedAmmoQty} طلقة - سبب الصرف: ${orderData.issueReason}`
      });
      this.saveWeaponLifecycle(lifecycle);
    }

    // Sync with recipient's profile Armament log
    if (orderData.recipientMilitaryId) {
      this.addArmamentLog(
        orderData.recipientMilitaryId,
        {
          weaponSerial: orderData.weaponSerial || `WPN-${Math.floor(10000 + Math.random() * 90000)}`,
          weaponType: orderData.weaponType,
          issueDate: dateStr.split(' ')[0],
          status: 'بحوزته',
          ammoQty: orderData.issuedAmmoQty,
          firelinesCount: 4,
          ammoHistory: [
            {
              id: `ah-${Date.now()}`,
              type: 'صرف',
              quantity: orderData.issuedAmmoQty,
              date: dateStr.split(' ')[0],
              reason: orderData.issueReason || 'صرف رسمي لمهمة قتالية',
              issuedBy: actingUser
            }
          ],
          condition: 'ممتازة',
          technicalNotes: `أمر صرف رقم ${orderNumber}`
        },
        actingUser,
        actingDept
      );
    }

    this.logAction(
      actingUser,
      actingDept,
      'إصدار أمر صرف سلاح وذخيرة',
      orderData.recipientMilitaryId,
      orderData.recipientName,
      `أمر رقم: ${orderNumber} - السلاح: ${orderData.weaponType} (${orderData.weaponSerial || 'بدون رقم تسلسلي'}) - الذخيرة: ${orderData.issuedAmmoQty}`
    );

    return {
      success: true,
      message: `تم إصدار وتسجيل أمر الصرف رقم (${orderNumber}) وخصم الكمية من المخزون بنجاح.`,
      order: newOrder
    };
  }

  // Dedicated equipment turn-in (توريد واسترجاع عهدة السلاح لمخازن التسليح)
  static processWeaponTurnIn(
    data: {
      militaryId: string;
      weaponType: string;
      weaponSerial: string;
      weaponCondition: string;
      ammoQty: number;
      magazinesCount: number;
      vest?: boolean;
      helmet?: boolean;
      newStatus?: PersonnelStatus;
      notes?: string;
      receivingOfficer: string;
      receiptNumber: string;
      turnInDate?: string;
      turnInTime?: string;
    },
    actingUser = 'ضابط التسليح',
    actingDept: DepartmentRole = 'إدارة التسليح'
  ): { success: boolean; message: string } {
    const finalTurnInDate = data.turnInDate || new Date().toISOString().split('T')[0];
    const finalTurnInTime = data.turnInTime || new Date().toTimeString().slice(0, 5);
    const cleanSerial = (data.weaponSerial || '').trim();

    // Find person info first for accurate historical tagging
    const allPersonnel = this.getPersonnel();
    const pIndex = allPersonnel.findIndex((p) => p.militaryId === data.militaryId);
    let targetPersonName = '-';
    let targetPersonRank: MilitaryRank | undefined = undefined;
    let targetPersonUnit: string | undefined = undefined;
    if (pIndex !== -1) {
      targetPersonName = allPersonnel[pIndex].fullName;
      targetPersonRank = allPersonnel[pIndex].rank;
      targetPersonUnit = allPersonnel[pIndex].unit;
    }

    // 1. Update Armory Inventory (Add 1 back to availableQty of weapon, and ammoQty if returned)
    const inventory = this.getArmoryInventory();
    if (data.weaponType) {
      const weaponItem = inventory.find(
        (inv) =>
          inv.itemType === 'weapon' &&
          (inv.name.trim().toLowerCase() === data.weaponType.trim().toLowerCase() ||
           inv.name.includes(data.weaponType) ||
           data.weaponType.includes(inv.name))
      );
      if (weaponItem) {
        weaponItem.availableQty += 1;
        if (weaponItem.issuedQty > 0) weaponItem.issuedQty -= 1;
        weaponItem.lastUpdated = finalTurnInDate;
      } else {
        inventory.push({
          id: `inv-turnin-${Date.now()}`,
          itemType: 'weapon',
          name: data.weaponType,
          category: 'بنادق/أسلحة',
          caliber: '7.62×39mm',
          totalReceived: 1,
          availableQty: 1,
          issuedQty: 0,
          inMaintenanceQty: 0,
          minThreshold: 5,
          storageLocation: 'مخزن التسليح الرئيسي',
          unit: targetPersonUnit || 'اللواء الأول',
          lastUpdated: finalTurnInDate
        });
      }
    }
    if (data.ammoQty > 0) {
      const ammoItem =
        inventory.find(
          (inv) => inv.itemType === 'ammo' && (inv.caliber.includes('7.62') || inv.name.includes('ذخيرة'))
        ) || inventory.find((inv) => inv.itemType === 'ammo');
      if (ammoItem) {
        ammoItem.availableQty += data.ammoQty;
        if (ammoItem.issuedQty >= data.ammoQty) ammoItem.issuedQty -= data.ammoQty;
        ammoItem.lastUpdated = finalTurnInDate;
      }
    }
    this.saveArmoryInventory(inventory);

    // 2. Update or Add Weapon Piece in Armory Weapons
    const weapons = this.getArmoryWeapons();
    const isDamaged = data.weaponCondition === 'معطوبة' || data.weaponCondition === 'تحتاج صيانة';
    const finalSerial = cleanSerial || `WPN-${Date.now().toString().slice(-5)}`;

    const pieceIndex = weapons.findIndex(
      (w) =>
        (cleanSerial && w.serialNumber.trim().toLowerCase() === cleanSerial.toLowerCase()) ||
        (!cleanSerial && w.currentHolderMilitaryId === data.militaryId && w.weaponType === data.weaponType)
    );

    if (pieceIndex !== -1) {
      weapons[pieceIndex].status = isDamaged ? 'في الصيانة' : 'في المخزن';
      weapons[pieceIndex].technicalCondition =
        data.weaponCondition === 'معطوبة' ? 'معطوبة' : data.weaponCondition === 'تحتاج صيانة' ? 'تحتاج صيانة' : 'جاهز';
      weapons[pieceIndex].previousHolderMilitaryId = data.militaryId;
      weapons[pieceIndex].previousHolderName = targetPersonName;
      weapons[pieceIndex].previousHolderRank = targetPersonRank;
      weapons[pieceIndex].previousHolderUnit = targetPersonUnit;
      weapons[pieceIndex].turnInDate = finalTurnInDate;
      weapons[pieceIndex].turnInTime = finalTurnInTime;
      weapons[pieceIndex].turnInOfficer = data.receivingOfficer;
      weapons[pieceIndex].turnInReceiptNumber = data.receiptNumber;
      weapons[pieceIndex].turnInAmmoQty = data.ammoQty;
      weapons[pieceIndex].turnInMagazinesCount = data.magazinesCount;
      weapons[pieceIndex].currentHolderMilitaryId = undefined;
      weapons[pieceIndex].currentHolderName = undefined;
      weapons[pieceIndex].currentHolderRank = undefined;
      weapons[pieceIndex].currentHolderUnit = undefined;
      weapons[pieceIndex].notes = `تم التوريد بسند رقم ${data.receiptNumber} بواسطة ضابط التسليح ${data.receivingOfficer} بتاريخ ${finalTurnInDate} ${finalTurnInTime}: ${data.notes || ''}`;
    } else {
      // Weapon was not previously in pieces list, add it back to armory warehouse
      weapons.unshift({
        id: `wp-returned-${Date.now()}`,
        serialNumber: finalSerial,
        weaponType: data.weaponType,
        caliber: '7.62×39mm',
        manufactureYear: new Date().getFullYear().toString(),
        technicalCondition:
          data.weaponCondition === 'معطوبة' ? 'معطوبة' : data.weaponCondition === 'تحتاج صيانة' ? 'تحتاج صيانة' : 'جاهز',
        status: isDamaged ? 'في الصيانة' : 'في المخزن',
        previousHolderMilitaryId: data.militaryId,
        previousHolderName: targetPersonName,
        previousHolderRank: targetPersonRank,
        previousHolderUnit: targetPersonUnit,
        turnInDate: finalTurnInDate,
        turnInTime: finalTurnInTime,
        turnInOfficer: data.receivingOfficer,
        turnInReceiptNumber: data.receiptNumber,
        turnInAmmoQty: data.ammoQty,
        turnInMagazinesCount: data.magazinesCount,
        storageLocation: 'مخزن التسليح الرئيسي',
        entryDate: finalTurnInDate,
        notes: `مورد من الفرد (${data.militaryId} - ${targetPersonName}) بسند رقم ${data.receiptNumber} واستلمه ضابط التسليح ${data.receivingOfficer}`
      });
    }
    this.saveArmoryWeapons(weapons);

    // Record Lifecycle event
    const lifecycle = this.getWeaponLifecycle();
    lifecycle.unshift({
      id: `lc-${Date.now()}`,
      weaponSerial: finalSerial,
      weaponType: data.weaponType,
      eventType: 'إرجاع للمخزن',
      date: `${finalTurnInDate} ${finalTurnInTime}`,
      actor: data.receivingOfficer || actingUser,
      recipientOrUnit: 'مخزن التسليح الرئيسي',
      details: `توريد عهدة واستعادة قطعة سلاح بسند رقم ${data.receiptNumber} - الفرد (${targetPersonRank || ''} ${targetPersonName} - الرقم العسكري: ${data.militaryId}) - استلمها ضابط التسليح: ${data.receivingOfficer} - التاريخ والوقت: ${finalTurnInDate} ${finalTurnInTime} - الذخيرة: ${data.ammoQty} - المخازن: ${data.magazinesCount} - الحالة: ${data.weaponCondition}`
    });
    this.saveWeaponLifecycle(lifecycle);

    // 3. Update Personnel File Armament Log (Guarantee no active weapon remains in custody)
    if (pIndex !== -1) {
      const p = allPersonnel[pIndex];
      if (!p.logs) p.logs = { movement: [], attendance: [], medical: [], financial: [], security: [], armament: [], training: [], attachments: [] };
      if (!p.logs.armament) p.logs.armament = [];

      let matched = false;
      p.logs.armament = p.logs.armament.map((arm) => {
        const isSerialMatch = cleanSerial && arm.weaponSerial && arm.weaponSerial.trim().toLowerCase() === cleanSerial.toLowerCase();
        const isActiveWeapon = !arm.returnDate && arm.status !== 'مورد' && arm.status !== 'في المخزن' && arm.weaponSerial !== 'ذخيرة فقط';

        // Match if serial matches OR if this is the active weapon being turned in
        if (isSerialMatch || (!cleanSerial && isActiveWeapon) || (!matched && isActiveWeapon)) {
          matched = true;
          return {
            ...arm,
            returnDate: finalTurnInDate,
            turnInDate: finalTurnInDate,
            turnInTime: finalTurnInTime,
            turnInOfficer: data.receivingOfficer,
            status: 'مورد' as const,
            turnInReceiptNumber: data.receiptNumber,
            firelinesCount: data.magazinesCount,
            ammoQty: data.ammoQty,
            condition: (data.weaponCondition as any) || arm.condition,
            technicalNotes: (arm.technicalNotes || '') + ` • تم التوريد لمخزن التسليح بسند رقم ${data.receiptNumber} استلمه ضابط التسليح (${data.receivingOfficer}) بتاريخ ${finalTurnInDate} الساعة ${finalTurnInTime}`
          };
        }
        return arm;
      });

      if (!matched) {
        // If no unreturned log matched, prepend log marked as returned
        p.logs.armament.unshift({
          id: `arm-${Date.now()}`,
          weaponSerial: finalSerial,
          weaponType: data.weaponType,
          issueDate: finalTurnInDate,
          returnDate: finalTurnInDate,
          turnInDate: finalTurnInDate,
          turnInTime: finalTurnInTime,
          turnInOfficer: data.receivingOfficer,
          status: 'مورد',
          turnInReceiptNumber: data.receiptNumber,
          ammoQty: data.ammoQty,
          firelinesCount: data.magazinesCount,
          ammoHistory: [],
          condition: (data.weaponCondition as any) || 'ممتازة',
          technicalNotes: `توريد عهدة لمخزن التسليح بسند رقم ${data.receiptNumber} استلمه ضابط التسليح (${data.receivingOfficer}) بتاريخ ${finalTurnInDate} الساعة ${finalTurnInTime}`
        });
      }

      if (data.newStatus) {
        p.currentStatus = data.newStatus;
        p.lastStatusChangeDate = finalTurnInDate;
      }

      this.savePersonnel(allPersonnel);
    }

    // 4. Update any open Armory Issue order for this recipient
    const issues = this.getArmoryIssues();
    let issueUpdated = false;
    issues.forEach((iss) => {
      if (
        iss.status === 'نشط' &&
        iss.recipientMilitaryId === data.militaryId &&
        ((cleanSerial && iss.weaponSerial?.trim().toLowerCase() === cleanSerial.toLowerCase()) ||
          (!cleanSerial && iss.weaponType === data.weaponType) ||
          !iss.weaponSerial)
      ) {
        iss.status = 'تم الإرجاع';
        iss.returnDate = finalTurnInDate;
        iss.notes = (iss.notes || '') + ` | تم التوريد بسند رقم ${data.receiptNumber} استلمه ضابط التسليح (${data.receivingOfficer})`;
        issueUpdated = true;
      }
    });
    if (issueUpdated) {
      this.saveArmoryIssues(issues);
    }

    this.logAction(
      actingUser,
      actingDept,
      'توريد عهدة سلاح إلى المخزن',
      data.militaryId,
      '-',
      `تم توريد السلاح (${data.weaponType} - S/N: ${cleanSerial}) لمخزن التسليح بسند رقم ${data.receiptNumber} واستلمه ضابط التسليح: ${data.receivingOfficer} بتاريخ ${finalTurnInDate} ${finalTurnInTime}`
    );

    return {
      success: true,
      message: `تم بنجاح توريد السلاح (${cleanSerial}) لمخازن التسليح واستلامه بواسطة ضابط التسليح (${data.receivingOfficer}) وتوثيقه في ملف الفرد.`
    };
  }

  // Dedicated Re-Issue of Turned-in Weapon from Armory back to Soldier (صرف سلاح مورد في المخازن)
  static processReissueTurnedInWeapon(
    data: {
      militaryId: string;
      weaponType: string;
      weaponSerial: string;
      magazinesCount: number;
      ammoQty: number;
      reissueOfficer: string;
      reissueDate?: string;
      reissueTime?: string;
      reissueReceiptNumber: string;
      proceduresType: string; // e.g. 'صرف العهدة كاملة' | 'صرف السلاح فقط بدون المخازن والذخيرة' | 'صرف مخازن إضافية' | 'صرف ذخيرة إضافية' | string
      notes?: string;
      weaponCondition?: 'ممتازة' | 'جيدة' | 'تحتاج صيانة' | 'معطوبة';
    },
    actingUser = 'ضابط التسليح',
    actingDept: DepartmentRole = 'إدارة التسليح'
  ): { success: boolean; message: string; issueOrder?: ArmoryIssueOrder } {
    const finalDate = data.reissueDate || new Date().toISOString().split('T')[0];
    const finalTime = data.reissueTime || new Date().toTimeString().slice(0, 5);
    const cleanSerial = (data.weaponSerial || '').trim();

    // 1. Locate Soldier in Personnel
    const allPersonnel = this.getPersonnel();
    const pIndex = allPersonnel.findIndex((p) => p.militaryId === data.militaryId);
    if (pIndex === -1) {
      return { success: false, message: 'لم يتم العثور على بيانات الفرد المستهدف.' };
    }
    const targetPerson = allPersonnel[pIndex];

    // 2. Update Weapon Piece in Armory Weapons
    const weapons = this.getArmoryWeapons();
    const pieceIndex = weapons.findIndex(
      (w) => cleanSerial && w.serialNumber.trim().toLowerCase() === cleanSerial.toLowerCase()
    );

    const mappedCondition: 'جاهز' | 'تحتاج صيانة' | 'غير جاهز' | 'معطوبة' =
      data.weaponCondition === 'معطوبة'
        ? 'معطوبة'
        : data.weaponCondition === 'تحتاج صيانة'
        ? 'تحتاج صيانة'
        : 'جاهز';

    if (pieceIndex !== -1) {
      weapons[pieceIndex].status = 'منصرف للفرد';
      weapons[pieceIndex].technicalCondition = mappedCondition;
      weapons[pieceIndex].currentHolderMilitaryId = targetPerson.militaryId;
      weapons[pieceIndex].currentHolderName = targetPerson.fullName;
      weapons[pieceIndex].currentHolderRank = targetPerson.rank;
      weapons[pieceIndex].currentHolderUnit = targetPerson.unit;
      weapons[pieceIndex].lastReissueDate = finalDate;
      weapons[pieceIndex].lastReissueTime = finalTime;
      weapons[pieceIndex].lastReissueOfficer = data.reissueOfficer;
      weapons[pieceIndex].lastReissueProcedures = data.proceduresType;
      weapons[pieceIndex].lastReissueReceiptNumber = data.reissueReceiptNumber;
      weapons[pieceIndex].notes = `أعيد صرفه للفرد بسند رقم ${data.reissueReceiptNumber} بواسطة ضابط التسليح (${data.reissueOfficer}) [الإجراء: ${data.proceduresType}] ${data.notes ? `• ${data.notes}` : ''}`;
    } else {
      weapons.unshift({
        id: `wp-${Date.now()}`,
        serialNumber: cleanSerial,
        weaponType: data.weaponType,
        caliber: '7.62×39mm',
        manufactureYear: new Date().getFullYear().toString(),
        technicalCondition: mappedCondition,
        status: 'منصرف للفرد',
        currentHolderMilitaryId: targetPerson.militaryId,
        currentHolderName: targetPerson.fullName,
        currentHolderRank: targetPerson.rank,
        currentHolderUnit: targetPerson.unit,
        lastReissueDate: finalDate,
        lastReissueTime: finalTime,
        lastReissueOfficer: data.reissueOfficer,
        lastReissueProcedures: data.proceduresType,
        lastReissueReceiptNumber: data.reissueReceiptNumber,
        storageLocation: 'مخزن التسليح الرئيسي',
        entryDate: finalDate,
        notes: `أعيد صرفه للفرد بسند رقم ${data.reissueReceiptNumber} بواسطة ضابط التسليح (${data.reissueOfficer}) [الإجراء: ${data.proceduresType}]`
      });
    }
    this.saveArmoryWeapons(weapons);

    // 3. Update Inventory (Deduct weapon piece and ammo from available stocks)
    const inventory = this.getArmoryInventory();
    if (data.weaponType) {
      const weaponItem = inventory.find(
        (inv) =>
          inv.itemType === 'weapon' &&
          (inv.name.trim().toLowerCase() === data.weaponType.trim().toLowerCase() ||
           inv.name.includes(data.weaponType) ||
           data.weaponType.includes(inv.name))
      );
      if (weaponItem) {
        if (weaponItem.availableQty > 0) weaponItem.availableQty -= 1;
        weaponItem.issuedQty += 1;
        weaponItem.lastUpdated = finalDate;
      }
    }
    if (data.ammoQty > 0) {
      const ammoItem =
        inventory.find(
          (inv) => inv.itemType === 'ammo' && (inv.caliber.includes('7.62') || inv.name.includes('ذخيرة'))
        ) || inventory.find((inv) => inv.itemType === 'ammo');
      if (ammoItem) {
        if (ammoItem.availableQty >= data.ammoQty) {
          ammoItem.availableQty -= data.ammoQty;
        } else {
          ammoItem.availableQty = 0;
        }
        ammoItem.issuedQty += data.ammoQty;
        ammoItem.lastUpdated = finalDate;
      }
    }
    this.saveArmoryInventory(inventory);

    // 4. Update Soldier's Armament Log in Personnel File
    if (!targetPerson.logs) targetPerson.logs = { movement: [], attendance: [], medical: [], financial: [], security: [], armament: [], training: [], attachments: [] };
    if (!targetPerson.logs.armament) targetPerson.logs.armament = [];

    const newArmLog: ArmamentLog = {
      id: `arm-reissue-${Date.now()}`,
      weaponSerial: cleanSerial,
      weaponType: data.weaponType,
      issueDate: finalDate,
      reissueDate: finalDate,
      reissueTime: finalTime,
      reissueOfficer: data.reissueOfficer,
      reissueReceiptNumber: data.reissueReceiptNumber,
      reissueProcedures: data.proceduresType,
      status: 'بحوزته',
      ammoQty: data.ammoQty,
      firelinesCount: data.magazinesCount,
      ammoHistory: [
        {
          id: `act-${Date.now()}`,
          type: 'صرف',
          quantity: data.ammoQty,
          date: finalDate,
          reason: `إعادة صرف سلاح مورد من المخازن - ${data.proceduresType}`,
          issuedBy: data.reissueOfficer
        }
      ],
      condition: data.weaponCondition || 'ممتازة',
      technicalNotes: `إعادة صرف سلاح مورد من المخازن بسند رقم ${data.reissueReceiptNumber} بواسطة ضابط التسليح (${data.reissueOfficer}) بتاريخ ${finalDate} الساعة ${finalTime}. الإجراء المتخذ: [${data.proceduresType}]. عدد المخازن: ${data.magazinesCount}، الذخيرة: ${data.ammoQty} طلقة. ${data.notes || ''}`
    };

    targetPerson.logs.armament.unshift(newArmLog);
    this.savePersonnel(allPersonnel);

    // 5. Record Lifecycle event
    const lifecycle = this.getWeaponLifecycle();
    lifecycle.unshift({
      id: `lc-${Date.now()}`,
      weaponSerial: cleanSerial,
      weaponType: data.weaponType,
      eventType: 'صرف للفرد',
      date: `${finalDate} ${finalTime}`,
      actor: data.reissueOfficer || actingUser,
      recipientOrUnit: `${targetPerson.rank} / ${targetPerson.fullName} (${targetPerson.militaryId}) - ${targetPerson.unit}`,
      details: `إعادة صرف سلاح مورد من المخازن للفرد بسند رقم ${data.reissueReceiptNumber}. الإجراء المتخذ: [${data.proceduresType}]. الذخيرة المصروفة: ${data.ammoQty} طلقة، عدد المخازن: ${data.magazinesCount}. ضابط التسليح: ${data.reissueOfficer}. ${data.notes || ''}`
    });
    this.saveWeaponLifecycle(lifecycle);

    // 6. Create Official Armory Issue Order
    const issues = this.getArmoryIssues();
    const newOrder: ArmoryIssueOrder = {
      id: `iss-reissue-${Date.now()}`,
      orderNumber: data.reissueReceiptNumber,
      date: finalDate,
      recipientName: targetPerson.fullName,
      recipientMilitaryId: targetPerson.militaryId,
      recipientRank: targetPerson.rank,
      unit: targetPerson.unit,
      weaponType: data.weaponType,
      weaponSerial: cleanSerial,
      ammoType: `ذخيرة ${data.weaponType}`,
      ammoCaliber: '7.62×39mm',
      issuedAmmoQty: data.ammoQty,
      issueReason: `إعادة صرف سلاح مورد من المخازن [${data.proceduresType}]`,
      orderReference: data.reissueReceiptNumber,
      responsibleOfficer: data.reissueOfficer,
      notes: `إعادة صرف سلاح مورد - عدد المخازن: ${data.magazinesCount} - الذخيرة: ${data.ammoQty} - ضابط التسليح: ${data.reissueOfficer} - ${data.notes || ''}`,
      status: 'نشط'
    };
    issues.unshift(newOrder);
    this.saveArmoryIssues(issues);

    // 7. Audit log
    this.logAction(
      actingUser,
      actingDept,
      'صرف سلاح مورد في المخازن',
      data.militaryId,
      '-',
      `تمت إعادة صرف السلاح المورد (${data.weaponType} - S/N: ${cleanSerial}) للفرد (${targetPerson.rank} / ${targetPerson.fullName}) بسند رقم ${data.reissueReceiptNumber}. الإجراء: ${data.proceduresType}. ضابط التسليح: ${data.reissueOfficer}`
    );

    return {
      success: true,
      message: `تم بنجاح صرف السلاح المورد (${cleanSerial}) للفرد (${targetPerson.fullName}) وتوثيق العملية في ملفه الإلكتروني وسجل حركة السلاح.`,
      issueOrder: newOrder
    };
  }

  // Process Weapon/Ammo Return (إرجاع سلاح/ذخيرة للمخزن)
  static processArmoryReturn(
    issueId: string,
    returnNotes: string,
    actingUser = 'ضابط التسليح',
    actingDept: DepartmentRole = 'إدارة التسليح'
  ): { success: boolean; message: string } {
    const issues = this.getArmoryIssues();
    const orderIndex = issues.findIndex((i) => i.id === issueId);
    if (orderIndex === -1) {
      return { success: false, message: 'عذراً! لم يتم العثور على امر الصرف المستهدف.' };
    }

    const order = issues[orderIndex];
    if (order.status === 'تم الإرجاع') {
      return { success: false, message: 'هذا السند مسجل كمعاد مسبقاً.' };
    }

    order.status = 'تم الإرجاع';
    order.returnDate = new Date().toISOString().split('T')[0];
    order.notes = (order.notes || '') + ` | تم الإرجاع بتاريخ ${order.returnDate}: ${returnNotes}`;
    this.saveArmoryIssues(issues);

    // Return weapon & ammo back to inventory stock
    const inventory = this.getArmoryInventory();

    if (order.weaponType) {
      const weaponItem = inventory.find(
        (inv) =>
          inv.itemType === 'weapon' &&
          (inv.name.includes(order.weaponType) || order.weaponType.includes(inv.name))
      );
      if (weaponItem) {
        weaponItem.availableQty += 1;
        if (weaponItem.issuedQty > 0) weaponItem.issuedQty -= 1;
      }
    }

    if (order.issuedAmmoQty > 0 && order.ammoType) {
      const ammoItem = inventory.find(
        (inv) =>
          inv.itemType === 'ammo' &&
          (inv.name.includes(order.ammoType) || order.ammoType.includes(inv.name))
      );
      if (ammoItem) {
        ammoItem.availableQty += order.issuedAmmoQty;
        if (ammoItem.issuedQty >= order.issuedAmmoQty) ammoItem.issuedQty -= order.issuedAmmoQty;
      }
    }

    this.saveArmoryInventory(inventory);

    // Update tracked weapon piece
    if (order.weaponSerial) {
      const weapons = this.getArmoryWeapons();
      const piece = weapons.find(
        (w) => w.serialNumber.trim().toLowerCase() === order.weaponSerial?.trim().toLowerCase()
      );
      if (piece) {
        piece.status = 'في المخزن';
        piece.currentHolderMilitaryId = undefined;
        piece.currentHolderName = undefined;
        piece.currentHolderUnit = undefined;
        this.saveArmoryWeapons(weapons);
      }

      // Record Lifecycle event
      const lifecycle = this.getWeaponLifecycle();
      lifecycle.unshift({
        id: `lc-${Date.now()}`,
        weaponSerial: order.weaponSerial,
        weaponType: order.weaponType,
        eventType: 'إرجاع للمخزن',
        date: order.returnDate,
        actor: actingUser,
        recipientOrUnit: 'مخزن التسليح الرئيسي',
        details: `إرجاع السلاح من الفرد (${order.recipientName}) - الملاحظات: ${returnNotes}`
      });
      this.saveWeaponLifecycle(lifecycle);
    }

    // Also update recipient's armament logs in PersonnelRecord!
    if (order.recipientMilitaryId) {
      const allPersonnel = this.getPersonnel();
      const pIndex = allPersonnel.findIndex((p) => p.militaryId === order.recipientMilitaryId);
      if (pIndex !== -1 && allPersonnel[pIndex].logs?.armament) {
        allPersonnel[pIndex].logs.armament = allPersonnel[pIndex].logs.armament.map((arm) => {
          const matchSerial =
            order.weaponSerial &&
            arm.weaponSerial &&
            arm.weaponSerial.trim().toLowerCase() === order.weaponSerial.trim().toLowerCase();
          const matchType = !order.weaponSerial && arm.weaponType === order.weaponType && (!arm.returnDate || arm.status !== 'مورد');
          if (matchSerial || matchType) {
            return {
              ...arm,
              returnDate: order.returnDate,
              status: 'مورد' as const,
              technicalNotes: (arm.technicalNotes || '') + ` | تم التوريد للمخزن بسند إرجاع`
            };
          }
          return arm;
        });
        this.savePersonnel(allPersonnel);
      }
    }

    this.logAction(
      actingUser,
      actingDept,
      'إرجاع سلاح/ذخيرة للمخزن',
      order.recipientMilitaryId,
      order.recipientName,
      `أمر الصرف: ${order.orderNumber} - السلاح: ${order.weaponType} (${order.weaponSerial || '-'})`
    );

    return { success: true, message: `تم تسليم وإعادة السلاح/الذخيرة للمخزن بنجاح وتحديث الرصيد.` };
  }

  // Reset to initial mock database
  static resetToDefault(): void {
    localStorage.removeItem(STORAGE_KEY_PERSONNEL);
    localStorage.removeItem(STORAGE_KEY_AUDIT);
    localStorage.removeItem(STORAGE_KEY_ALERTS);

    localStorage.removeItem(STORAGE_KEY_ARMORY_INVENTORY);
    localStorage.removeItem(STORAGE_KEY_ARMORY_WEAPONS);
    localStorage.removeItem(STORAGE_KEY_ARMORY_INTAKES);
    localStorage.removeItem(STORAGE_KEY_ARMORY_ISSUES);
    localStorage.removeItem(STORAGE_KEY_ARMORY_LIFECYCLE);
    localStorage.removeItem(STORAGE_KEY_WEAPON_TYPES);
    localStorage.removeItem(STORAGE_KEY_AMMO_TYPES);

    this.savePersonnel(INITIAL_PERSONNEL);
    this.saveAuditLogs(INITIAL_AUDIT_LOGS);
    this.saveAlerts(INITIAL_ALERTS);

    this.saveArmoryInventory(INITIAL_INVENTORY_ITEMS);
    this.saveArmoryWeapons(INITIAL_WEAPON_PIECES);
    this.saveArmoryIntakes(INITIAL_INTAKE_RECORDS);
    this.saveArmoryIssues(INITIAL_ISSUE_ORDERS);
    this.saveWeaponLifecycle(INITIAL_LIFECYCLE_EVENTS);
    this.saveWeaponTypesConfig(INITIAL_WEAPON_TYPES);
    this.saveAmmoTypesConfig(INITIAL_AMMO_TYPES);
    localStorage.removeItem(STORAGE_KEY_ACCOUNTS);
    this.saveAccounts(BRIGADE_ACCOUNTS);
  }

  // User Accounts Management
  static getAccounts(): UserAccount[] {
    if (this.memoizedAccounts) {
      return this.memoizedAccounts;
    }

    try {
      const parsed = safeGetLocalItem<UserAccount[]>(STORAGE_KEY_ACCOUNTS);
      if (parsed && Array.isArray(parsed) && parsed.length > 0) {
        const res = BRIGADE_ACCOUNTS.map((defaultAcc) => {
          const found = parsed.find((a) => a.id === defaultAcc.id);
          return found ? { ...defaultAcc, ...found } : defaultAcc;
        });
        this.memoizedAccounts = res;
        return res;
      }
    } catch (err) {
      console.error('Failed to get user accounts:', err);
    }
    this.memoizedAccounts = BRIGADE_ACCOUNTS;
    return BRIGADE_ACCOUNTS;
  }

  static saveAccounts(accounts: UserAccount[]): void {
    try {
      this.memoizedAccounts = accounts;
      safeSetLocalItem(STORAGE_KEY_ACCOUNTS, accounts);
      syncDocToCloud('accounts_config', accounts);
      notifyDataChange();
    } catch (err) {
      console.error('Failed to save user accounts:', err);
    }
  }

  static updateAccount(accountId: string, updates: Partial<UserAccount>): UserAccount[] {
    const current = this.getAccounts();
    const updated = current.map((acc) => {
      if (acc.id === accountId) {
        return { ...acc, ...updates };
      }
      return acc;
    });
    this.saveAccounts(updated);
    return updated;
  }

  // Register live device presence & ping active status across devices
  static registerAccountActivity(accountId: string): UserAccount[] {
    const currentAccounts = this.getAccounts();
    const telemetry = getDeviceTelemetry();
    const now = Date.now();
    const nowTimeStr = new Date().toLocaleTimeString('ar-EG', { hour: '2-digit', minute: '2-digit', second: '2-digit' });

    const updated = currentAccounts.map((acc) => {
      // Filter out sessions silent for more than 3 minutes (180,000 ms)
      let sessions = (acc.activeSessions || []).filter((s) => now - s.lastPing < 180000);

      if (acc.id === accountId && !acc.isBlocked && acc.status !== 'محظور') {
        const existingIdx = sessions.findIndex((s) => s.deviceId === telemetry.deviceId);
        if (existingIdx >= 0) {
          sessions[existingIdx] = {
            ...sessions[existingIdx],
            deviceTypeName: telemetry.deviceTypeName,
            deviceType: telemetry.deviceType,
            lastPing: now
          };
        } else {
          sessions.push({
            deviceId: telemetry.deviceId,
            deviceType: telemetry.deviceType,
            deviceTypeName: telemetry.deviceTypeName,
            lastPing: now
          });
        }

        const mobileCount = sessions.filter((s) => s.deviceType === 'mobile').length;
        const desktopCount = sessions.filter((s) => s.deviceType === 'desktop').length;
        const totalConnected = sessions.length;

        return {
          ...acc,
          status: 'نشط' as const,
          lastSeen: `متصل الآن (${nowTimeStr})`,
          connectedDevicesCount: totalConnected > 0 ? totalConnected : 1,
          devicesBreakdown: {
            mobileCount: mobileCount > 0 ? mobileCount : telemetry.deviceType === 'mobile' ? 1 : 0,
            desktopCount: desktopCount > 0 ? desktopCount : telemetry.deviceType === 'desktop' ? 1 : 0,
            lastDeviceType: telemetry.deviceTypeName
          },
          activeSessions: sessions
        };
      } else {
        if (sessions.length === 0 && acc.status === 'نشط' && !acc.isBlocked) {
          return {
            ...acc,
            status: 'غير نشط' as const,
            connectedDevicesCount: 0,
            activeSessions: []
          };
        }
        return {
          ...acc,
          connectedDevicesCount: sessions.length,
          activeSessions: sessions
        };
      }
    });

    safeSetLocalItem(STORAGE_KEY_ACCOUNTS, updated);
    return updated;
  }

  // Device binding logic for account link protection
  static checkAndBindAccountDevice(
    account: UserAccount,
    isHqAuthenticated: boolean = false
  ): { allowed: boolean; updatedAccount: UserAccount; isNewBinding?: boolean; reason?: string } {
    if (account.isMainCommand || isHqAuthenticated) {
      return { allowed: true, updatedAccount: account };
    }

    const telemetry = getDeviceTelemetry();
    const currentAccounts = this.getAccounts();
    const freshAccount = currentAccounts.find((a) => a.id === account.id) || account;

    // Case 1: Account is not bound to any device yet
    if (!freshAccount.boundDeviceId) {
      const nowIso = new Date().toISOString();
      const updatedList = this.updateAccount(freshAccount.id, {
        boundDeviceId: telemetry.deviceId,
        boundDeviceName: telemetry.deviceTypeName,
        boundAt: nowIso
      });
      const boundAcc = updatedList.find((a) => a.id === freshAccount.id) || {
        ...freshAccount,
        boundDeviceId: telemetry.deviceId,
        boundDeviceName: telemetry.deviceTypeName,
        boundAt: nowIso
      };

      this.logAction(
        'النظام / الأمان',
        'الاستخبارات والأمن',
        'تقييد جهاز الحساب تلقائياً',
        freshAccount.id,
        freshAccount.name,
        `تم ربط وتقييد رابط حساب (${freshAccount.name}) بالجهاز (${telemetry.deviceTypeName}) عند أول فتح للرابط.`,
        freshAccount.id,
        freshAccount.name
      );

      return { allowed: true, updatedAccount: boundAcc, isNewBinding: true };
    }

    // Case 2: Account is already bound to a device
    if (freshAccount.boundDeviceId === telemetry.deviceId) {
      return { allowed: true, updatedAccount: freshAccount };
    }

    // Case 3: Device mismatch! Unauthorized access attempt!
    this.registerUnauthorizedAccessAttempt(freshAccount, telemetry);

    return {
      allowed: false,
      updatedAccount: freshAccount,
      reason: `رابط حساب (${freshAccount.name}) مقيد بجهاز آخر (${freshAccount.boundDeviceName || 'جهاز مصرح به'}). لا يمكنك الفتح من هذا الجهاز.`
    };
  }

  static registerUnauthorizedAccessAttempt(account: UserAccount, telemetry: ReturnType<typeof getDeviceTelemetry>): void {
    const alerts = this.getAlerts();
    const nowStr = new Date().toLocaleTimeString('ar-EG', { hour: '2-digit', minute: '2-digit' });

    // Prevent duplicate security alerts within 2 minutes for the same attempt
    const hasRecent = alerts.find(
      (a) =>
        a.title.includes(account.name) &&
        a.description &&
        a.description.includes(telemetry.deviceTypeName) &&
        Date.now() - new Date(a.date).getTime() < 120000
    );

    if (!hasRecent) {
      const newAlert: SystemAlert = {
        id: `alt-sec-dev-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
        title: `🚨 تنبيه أمني عاجل: محاولة دخول غير مصرح بها عبر رابط (${account.name})`,
        description: `تم رصد محاولة فتح رابط حساب (${account.name}) [كود الحساب: ${account.shortCode}] عبر جهاز غير مصرح به: (${telemetry.deviceTypeName}) الساعة ${nowStr}. الحساب مقيد مسبقاً بالجهاز: (${account.boundDeviceName || 'جهاز آخر'}). تم منع الدخول وتوثيق التنبيه للمستخدم الرئيسي.`,
        level: 'urgent',
        date: new Date().toISOString().split('T')[0],
        createdByAccountId: 'hq'
      };

      this.saveAlerts([newAlert, ...alerts]);

      this.logAction(
        'نظام الأمان الحصري',
        'الاستخبارات والأمن',
        'محاولة دخول غير مصرح بها',
        account.id,
        account.name,
        `رصد محاولة فتح رابط حساب (${account.name}) من جهاز غير مصرح به (${telemetry.deviceTypeName}). تم الحظر التلقائي وإبلاغ القيادة الرئيسية.`,
        account.id,
        account.name
      );
    }
  }

  static unbindAccountDevice(accountId: string): UserAccount[] {
    const accounts = this.getAccounts();
    const target = accounts.find((a) => a.id === accountId);
    const updated = this.updateAccount(accountId, {
      boundDeviceId: undefined,
      boundDeviceName: undefined,
      boundAt: undefined
    });

    if (target) {
      this.logAction(
        'القيادة الرئيسية',
        'القيادة الرئيسية',
        'إعادة ضبط تقييد الجهاز',
        target.id,
        target.name,
        `تم إلغاء تقييد الجهاز لحساب (${target.name}) بواسطة القيادة الرئيسية. الحساب جاهز للتقييد بأي جهاز جديد عند فتح الرابط.`,
        target.id,
        target.name
      );
    }
    return updated;
  }

  // Authorize and bind the current active device to the account, lifting lock
  static forceUnbindAndAuthorizeDevice(accountId: string): UserAccount[] {
    const telemetry = getDeviceTelemetry();
    const nowIso = new Date().toISOString();
    const accounts = this.getAccounts();
    const target = accounts.find((a) => a.id === accountId);

    const updated = this.updateAccount(accountId, {
      boundDeviceId: telemetry.deviceId,
      boundDeviceName: telemetry.deviceTypeName,
      boundAt: nowIso,
      isBlocked: false,
      status: 'نشط',
      blockedReason: undefined
    });

    this.logAction(
      'القيادة الرئيسية',
      'الاستخبارات والأمن',
      'فك قفل وترخيص جهاز جديد',
      accountId,
      target ? target.name : accountId,
      `تم فك القفل بنجاح وترخيص هذا الجهاز (${telemetry.deviceTypeName}) للعمل على حساب (${target ? target.name : accountId}).`,
      accountId,
      target ? target.name : accountId
    );

    return updated;
  }

  // Lift any security block on an account
  static unblockAccount(accountId: string): UserAccount[] {
    const accounts = this.getAccounts();
    const target = accounts.find((a) => a.id === accountId);

    const updated = this.updateAccount(accountId, {
      isBlocked: false,
      status: 'نشط',
      blockedReason: undefined
    });

    this.logAction(
      'القيادة الرئيسية',
      'الاستخبارات والأمن',
      'رفع الحظر الأمني عن الحساب',
      accountId,
      target ? target.name : accountId,
      `تم رفع الحظر الأمني عن حساب (${target ? target.name : accountId}) واستعادة الصلاحيات بنجاح.`,
      accountId,
      target ? target.name : accountId
    );

    return updated;
  }

  // Completely reset session back to HQ Main Command
  static resetSessionToMainCommand(): void {
    if (typeof window !== 'undefined') {
      try {
        localStorage.removeItem('military_active_account_v1');
        const url = new URL(window.location.href);
        url.searchParams.delete('account');
        url.searchParams.delete('user');
        url.searchParams.delete('brigade');
        url.searchParams.delete('acc');
        url.searchParams.delete('code');
        url.hash = '';
        window.history.replaceState({}, '', url.pathname);
      } catch (e) {
        console.warn('Error resetting session URL:', e);
      }
    }
  }

  // --- STORAGE METRICS, BACKUP & RESTORE METHODS ---

  static getStorageMetrics(): {
    totalUsedBytes: number;
    totalQuotaBytes: number;
    usedPercentage: number;
    storageEngine: string;
    categories: {
      name: string;
      key: string;
      bytes: number;
      percentage: number;
      itemCount: number;
      icon: string;
    }[];
  } {
    // 50 GB High-Capacity IndexedDB & Cloud Engine
    const totalQuotaBytes = 50 * 1024 * 1024 * 1024; // 50 GB Allocated Dynamic Space
    let totalUsedBytes = 0;

    const keysToTrack = [
      { name: 'سجلات القوة البشرية والضباط', key: STORAGE_KEY_PERSONNEL, icon: '🪖' },
      { name: 'سجلات التسليح والأسلحة', key: STORAGE_KEY_ARMORY_WEAPONS, icon: '⚔️' },
      { name: 'جرد وإدخالات العتاد', key: STORAGE_KEY_ARMORY_INVENTORY, icon: '📦' },
      { name: 'سجلات العربات والآليات', key: STORAGE_KEY_VEHICLES, icon: '🚙' },
      { name: 'سجل التدقيق والحركات العسكرية', key: STORAGE_KEY_AUDIT, icon: '📋' },
      { name: 'التنبيهات والإشعارات اللحظية', key: STORAGE_KEY_ALERTS, icon: '🚨' },
      { name: 'حسابات ومستخدمي المؤسسات (Users & Tenants)', key: STORAGE_KEY_REGISTERED_TENANTS, icon: '🏢' },
      { name: 'سلة المحذوفات والمستردات', key: STORAGE_KEY_RECYCLE_BIN, icon: '🗑️' },
      { name: 'حسابات الألوية والروابط', key: STORAGE_KEY_ACCOUNTS, icon: '🔑' }
    ];

    const categoryStats = keysToTrack.map((cat) => {
      let raw = '';
      let itemCount = 0;
      if (typeof window !== 'undefined') {
        try {
          raw = localStorage.getItem(cat.key) || '';
          if (raw) {
            const parsed = JSON.parse(raw);
            if (Array.isArray(parsed)) itemCount = parsed.length;
            else if (typeof parsed === 'object') itemCount = Object.keys(parsed).length;
          }
        } catch (e) {}
      }
      const bytes = new Blob([raw]).size;
      totalUsedBytes += bytes;
      return {
        name: cat.name,
        key: cat.key,
        bytes,
        percentage: 0,
        itemCount,
        icon: cat.icon
      };
    });

    const categories = categoryStats.map((cat) => ({
      ...cat,
      percentage: totalUsedBytes > 0 ? Math.round((cat.bytes / totalUsedBytes) * 100) : 0
    }));

    // Calculated against a practical 50MB local soft gauge for smooth visual rendering
    const visualQuotaBytes = 50 * 1024 * 1024;
    const usedPercentage = Math.min(100, Math.max(1, Math.round((totalUsedBytes / visualQuotaBytes) * 100 * 10) / 10));

    return {
      totalUsedBytes,
      totalQuotaBytes,
      usedPercentage,
      storageEngine: 'IndexedDB v3 + Persistent Storage + Firestore Cloud',
      categories
    };
  }

  static async getStorageHealthMetrics() {
    return await getStorageHealth();
  }

  static async getDeviceSnapshots(): Promise<DeviceSnapshotEntry[]> {
    return await getDeviceSnapshots();
  }

  static async restoreDeviceSnapshot(snapshotId: string): Promise<boolean> {
    const ok = await restoreDeviceSnapshot(snapshotId);
    if (ok) {
      StorageService.clearMemoryCache();
      notifyDataChange();
    }
    return ok;
  }

  static async createDeviceSnapshotNow(): Promise<string | null> {
    return await createDeviceSnapshot();
  }

  static optimizeDatabase(): { success: boolean; freedBytes: number; message: string } {
    let freedBytes = 0;
    if (typeof window !== 'undefined') {
      try {
        // 1. Clean up stale or orphan chunk keys
        const allKeys = Object.keys(localStorage);
        for (const k of allKeys) {
          if (k.endsWith('_temp') || k.endsWith('_cache_old')) {
            const size = (localStorage.getItem(k) || '').length;
            freedBytes += size;
            localStorage.removeItem(k);
          }
        }
        // 2. Clear memory caches to rebuild clean state
        StorageService.clearMemoryCache();
        notifyDataChange();
        return {
          success: true,
          freedBytes,
          message: 'تم فحص قاعدة البيانات بنجاح، وترتيب الفهارس وتنظيف البيانات المؤقتة لتسريع الاستجابة.'
        };
      } catch (err: any) {
        return { success: false, freedBytes: 0, message: err.message || 'فشل تحسين القاعدة' };
      }
    }
    return { success: true, freedBytes: 0, message: 'القاعدة في أفضل حالة أداء.' };
  }

  static exportFullSystemBackup(): SystemBackupPayload {
    const activeTenant = this.getActiveTenant();
    const tenants = this.getTenants();
    const tenantUsersMap: Record<string, TenantUserAccount[]> = {};

    tenants.forEach((t) => {
      tenantUsersMap[t.id] = this.getTenantUsers(t.id);
    });

    const personnel = this.getPersonnel();
    const armoryWeapons = this.getArmoryWeapons();
    const armoryInventory = this.getArmoryInventory();
    const armoryIntakes = this.getArmoryIntakes();
    const armoryIssues = this.getArmoryIssues();
    const armoryLifecycle = this.getWeaponLifecycle();
    const weaponTypes = this.getWeaponTypesConfig();
    const ammoTypes = this.getAmmoTypesConfig();
    const vehicles = this.getVehicles();
    const spareParts = this.getSpareParts();
    const vehicleDispenses = this.getVehicleDispenseOrders();
    const salaryProfiles = this.getSalaryProfiles();
    const payrollRecords = this.getPayrollRecords();
    const payrollBatches = this.getPayrollBatches();
    const financialGrants = this.getFinancialGrants();
    const auditLogs = this.getAuditLogs();
    const alerts = this.getAlerts();
    const recycleBin = this.getRecycleBin();
    const replacements = this.getReplacements();
    const emergencyRecalls = this.getEmergencyRecallLogs();
    const accounts = this.getAccounts();

    // Export per-tenant datasets as well so all institutions are safely preserved
    const tenantsDataMap: Record<string, any> = {};
    if (typeof window !== 'undefined') {
      try {
        tenants.forEach((t) => {
          if (t.id && t.id !== 'tenant-hq-main') {
            const tPersonnel = safeGetLocalItem(`tenant_${t.id}_${STORAGE_KEY_PERSONNEL}`);
            const tWeapons = safeGetLocalItem(`tenant_${t.id}_${STORAGE_KEY_ARMORY_WEAPONS}`);
            const tVehicles = safeGetLocalItem(`tenant_${t.id}_${STORAGE_KEY_VEHICLES}`);
            const tPayroll = safeGetLocalItem(`${STORAGE_KEY_PAYROLL_RECORDS}_${t.id}`);
            const tGrants = safeGetLocalItem(`${STORAGE_KEY_FINANCIAL_GRANTS}_${t.id}`);
            if (tPersonnel || tWeapons || tVehicles || tPayroll || tGrants) {
              tenantsDataMap[t.id] = {
                personnel: tPersonnel,
                armoryWeapons: tWeapons,
                vehicles: tVehicles,
                payroll: tPayroll,
                grants: tGrants
              };
            }
          }
        });
      } catch (e) {}
    }

    let totalUsers = 0;
    Object.values(tenantUsersMap).forEach((uList) => {
      totalUsers += uList?.length || 0;
    });

    return {
      version: '4.0-military-hq-comprehensive',
      systemName: 'منظومة إدارة الموارد والجاهزية العسكرية الموحدة - قيادة الفرقة',
      exportTimestamp: new Date().toISOString(),
      activeTenantId: activeTenant.id,
      activeTenantName: activeTenant.name,
      summary: {
        personnelCount: personnel.length,
        armoryWeaponsCount: armoryWeapons.length,
        armoryInventoryCount: armoryInventory.length,
        vehiclesCount: vehicles.length,
        sparePartsCount: spareParts.length,
        payrollRecordsCount: payrollRecords.length,
        financialGrantsCount: financialGrants.length,
        tenantsCount: tenants.length,
        usersCount: totalUsers,
        auditLogsCount: auditLogs.length
      },
      data: {
        tenants,
        activeTenant,
        personnel,
        auditLogs,
        alerts,
        recycleBin,
        replacements,
        emergencyRecalls,
        accounts,
        armoryWeapons,
        armoryInventory,
        armoryIntakes,
        armoryIssues,
        armoryLifecycle,
        weaponTypes,
        ammoTypes,
        vehicles,
        spareParts,
        vehicleDispenses,
        salaryProfiles,
        payrollRecords,
        payrollBatches,
        financialGrants,
        tenantUsersMap,
        tenantsDataMap
      }
    };
  }

  static restoreFullSystemBackup(
    backupJson: any,
    modeOrOptions: 'replace' | 'merge' | RestoreBackupOptions = 'replace'
  ): BackupRestoreResult {
    try {
      if (!backupJson) {
        return {
          success: false,
          message: 'ملف النسخة الاحتياطية فارغ أو غير موجود!'
        };
      }

      let mode: 'replace' | 'merge' = 'replace';
      let targetAccountId: string | undefined = undefined;
      let targetUnitName: string | undefined = undefined;
      let reassignToCurrentAccount = false;

      if (modeOrOptions === 'merge' || modeOrOptions === 'replace') {
        mode = modeOrOptions;
      } else if (modeOrOptions && typeof modeOrOptions === 'object') {
        mode = modeOrOptions.mode === 'merge' ? 'merge' : 'replace';
        targetAccountId = modeOrOptions.targetAccountId;
        targetUnitName = modeOrOptions.targetUnitName;
        reassignToCurrentAccount = !!modeOrOptions.reassignToCurrentAccount;
      }

      let parsed = backupJson;
      if (typeof backupJson === 'string') {
        try {
          parsed = JSON.parse(backupJson);
        } catch (e) {
          return {
            success: false,
            message: 'صيغة ملف النسخة الاحتياطية غير صالحة! يجب أن يكون ملف JSON صالح.'
          };
        }
      }

      // Handle raw array of personnel records directly
      let data: any = parsed;
      if (Array.isArray(parsed)) {
        data = { personnel: parsed };
      } else if (parsed && typeof parsed === 'object') {
        if (parsed.data && typeof parsed.data === 'object') {
          data = parsed.data;
        }
      }

      if (!data || typeof data !== 'object') {
        return {
          success: false,
          message: 'هيكل بيانات النسخة الاحتياطية غير متوافق أو تالف.'
        };
      }

      const counts = {
        personnel: 0,
        weapons: 0,
        inventory: 0,
        vehicles: 0,
        spareParts: 0,
        payroll: 0,
        grants: 0,
        tenants: 0,
        users: 0,
        auditLogs: 0
      };

      // 1. Restore Tenants
      if (Array.isArray(data.tenants) && data.tenants.length > 0) {
        if (mode === 'merge') {
          const currentTenants = this.getTenants();
          const map = new Map(currentTenants.map((t) => [t.id, t]));
          data.tenants.forEach((t: OrganizationTenant) => map.set(t.id, t));
          this.saveTenants(Array.from(map.values()));
        } else {
          this.saveTenants(data.tenants);
        }
        counts.tenants = data.tenants.length;
      }

      // 2. Restore Personnel Records
      if (Array.isArray(data.personnel)) {
        let personnelToSave: PersonnelRecord[] = data.personnel;
        
        // If reassigning to current account/brigade
        if (reassignToCurrentAccount && targetAccountId && targetAccountId !== 'hq') {
          const resolvedUnit = targetUnitName || (targetAccountId === 'brigade1' ? 'اللواء الأول مشاة' : targetAccountId === 'brigade2' ? 'اللواء الثاني مشاة' : targetAccountId);
          personnelToSave = personnelToSave.map((p: PersonnelRecord) => ({
            ...p,
            createdByAccountId: targetAccountId,
            unit: resolvedUnit,
            // Ensure attachments and logs are safely initialized
            attachments: Array.isArray(p.attachments) ? p.attachments : (p.logs?.attachments || []),
            logs: p.logs || {
              movement: [], attendance: [], medical: [], financial: [], security: [], armament: [], training: [], attachments: p.attachments || []
            }
          }));
        }

        if (mode === 'merge') {
          const current = this.getPersonnel();
          const pMap = new Map(current.map((p) => [p.militaryId, p]));
          personnelToSave.forEach((p: PersonnelRecord) => {
            if (p.militaryId) pMap.set(p.militaryId, p);
          });
          this.savePersonnel(Array.from(pMap.values()), 'استعادة ودمج نسخة احتياطية');
          counts.personnel = pMap.size;
        } else {
          this.savePersonnel(personnelToSave, 'استعادة شاملة لنسخة احتياطية');
          counts.personnel = personnelToSave.length;
        }
      }

      // 3. Restore Armory Weapons
      if (Array.isArray(data.armoryWeapons)) {
        let weaponsToSave: ArmoryWeaponPiece[] = data.armoryWeapons;
        if (reassignToCurrentAccount && targetAccountId && targetAccountId !== 'hq') {
          const resolvedUnit = targetUnitName || (targetAccountId === 'brigade1' ? 'اللواء الأول مشاة' : targetAccountId === 'brigade2' ? 'اللواء الثاني مشاة' : targetAccountId);
          weaponsToSave = weaponsToSave.map((w: ArmoryWeaponPiece) => ({
            ...w,
            currentHolderUnit: resolvedUnit
          }));
        }

        if (mode === 'merge') {
          const current = this.getArmoryWeapons();
          const wMap = new Map(current.map((w) => [w.id || w.serialNumber, w]));
          weaponsToSave.forEach((w: ArmoryWeaponPiece) => {
            wMap.set(w.id || w.serialNumber, w);
          });
          this.saveArmoryWeapons(Array.from(wMap.values()));
          counts.weapons = wMap.size;
        } else {
          this.saveArmoryWeapons(weaponsToSave);
          counts.weapons = weaponsToSave.length;
        }
      }

      // 4. Restore Armory Inventory
      if (Array.isArray(data.armoryInventory)) {
        this.saveArmoryInventory(data.armoryInventory);
        counts.inventory = data.armoryInventory.length;
      }

      // 5. Restore Armory Intakes & Issues & Lifecycle
      if (Array.isArray(data.armoryIntakes)) {
        this.saveArmoryIntakes(data.armoryIntakes);
      }
      if (Array.isArray(data.armoryIssues)) {
        this.saveArmoryIssues(data.armoryIssues);
      }
      if (Array.isArray(data.armoryLifecycle)) {
        this.saveWeaponLifecycle(data.armoryLifecycle);
      }
      if (Array.isArray(data.weaponTypes)) {
        this.saveWeaponTypesConfig(data.weaponTypes);
      }
      if (Array.isArray(data.ammoTypes)) {
        this.saveAmmoTypesConfig(data.ammoTypes);
      }

      // 6. Restore Vehicles & Fleet
      if (Array.isArray(data.vehicles)) {
        let vehiclesToSave: VehicleItem[] = data.vehicles;
        if (reassignToCurrentAccount && targetAccountId && targetAccountId !== 'hq') {
          const resolvedUnit = targetUnitName || (targetAccountId === 'brigade1' ? 'اللواء الأول مشاة' : targetAccountId === 'brigade2' ? 'اللواء الثاني مشاة' : targetAccountId);
          vehiclesToSave = vehiclesToSave.map((v: VehicleItem) => ({
            ...v,
            createdByAccountId: targetAccountId,
            assignedUnit: resolvedUnit
          }));
        }

        if (mode === 'merge') {
          const current = this.getVehicles();
          const vMap = new Map(current.map((v) => [v.id || v.plateNumber, v]));
          vehiclesToSave.forEach((v: VehicleItem) => {
            vMap.set(v.id || v.plateNumber, v);
          });
          this.saveVehicles(Array.from(vMap.values()));
          counts.vehicles = vMap.size;
        } else {
          this.saveVehicles(vehiclesToSave);
          counts.vehicles = vehiclesToSave.length;
        }
      }

      // 7. Restore Spare Parts & Vehicle Dispenses
      if (Array.isArray(data.spareParts)) {
        this.saveSpareParts(data.spareParts);
        counts.spareParts = data.spareParts.length;
      }
      if (Array.isArray(data.vehicleDispenses)) {
        this.saveVehicleDispenseOrders(data.vehicleDispenses);
      }

      // 8. Restore Salary Profiles, Payroll & Grants
      if (Array.isArray(data.salaryProfiles)) {
        this.saveSalaryProfiles(data.salaryProfiles);
      }
      if (Array.isArray(data.payrollRecords)) {
        let payrollToSave: PayrollMonthlyRecord[] = data.payrollRecords;
        if (reassignToCurrentAccount && targetAccountId && targetAccountId !== 'hq') {
          const resolvedUnit = targetUnitName || (targetAccountId === 'brigade1' ? 'اللواء الأول مشاة' : targetAccountId === 'brigade2' ? 'اللواء الثاني مشاة' : targetAccountId);
          payrollToSave = payrollToSave.map((r: PayrollMonthlyRecord) => ({
            ...r,
            unit: resolvedUnit
          }));
        }
        this.savePayrollRecords(payrollToSave);
        counts.payroll = payrollToSave.length;
      }
      if (Array.isArray(data.payrollBatches)) {
        this.savePayrollBatches(data.payrollBatches);
      }
      if (Array.isArray(data.financialGrants)) {
        this.saveFinancialGrants(data.financialGrants);
        counts.grants = data.financialGrants.length;
      }

      // 9. Restore Audit Logs, Alerts, RecycleBin, Replacements, Recalls
      if (Array.isArray(data.auditLogs)) {
        this.saveAuditLogs(data.auditLogs);
        counts.auditLogs = data.auditLogs.length;
      }
      if (Array.isArray(data.alerts)) {
        this.saveAlerts(data.alerts);
      }
      if (Array.isArray(data.recycleBin)) {
        this.saveRecycleBin(data.recycleBin);
      }
      if (Array.isArray(data.replacements)) {
        this.saveReplacements(data.replacements);
      }
      if (Array.isArray(data.emergencyRecalls)) {
        this.saveEmergencyRecallLogs(data.emergencyRecalls);
      }
      if (Array.isArray(data.accounts)) {
        this.saveAccounts(data.accounts);
      }

      // 10. Restore Tenant Users Map
      if (data.tenantUsersMap && typeof data.tenantUsersMap === 'object') {
        let totalU = 0;
        Object.entries(data.tenantUsersMap).forEach(([tId, users]) => {
          if (Array.isArray(users)) {
            this.saveTenantUsers(tId, users);
            totalU += users.length;
          }
        });
        counts.users = totalU;
      }

      // 11. Restore Multi-tenant sub-datasets if present
      if (data.tenantsDataMap && typeof data.tenantsDataMap === 'object') {
        Object.entries(data.tenantsDataMap).forEach(([tId, subData]: [string, any]) => {
          if (subData && typeof subData === 'object') {
            if (subData.personnel) safeSetLocalItem(`tenant_${tId}_${STORAGE_KEY_PERSONNEL}`, subData.personnel);
            if (subData.armoryWeapons) safeSetLocalItem(`tenant_${tId}_${STORAGE_KEY_ARMORY_WEAPONS}`, subData.armoryWeapons);
            if (subData.vehicles) safeSetLocalItem(`tenant_${tId}_${STORAGE_KEY_VEHICLES}`, subData.vehicles);
            if (subData.payroll) safeSetLocalItem(`${STORAGE_KEY_PAYROLL_RECORDS}_${tId}`, subData.payroll);
            if (subData.grants) safeSetLocalItem(`${STORAGE_KEY_FINANCIAL_GRANTS}_${tId}`, subData.grants);
          }
        });
      }

      // Clear memory cache so fresh records are read immediately
      this.clearMemoryCache();
      notifyDataChange();

      // Log the action to Audit Trail
      this.logAction(
        'قيادة_الفرقة',
        'القيادة الرئيسية',
        'استعادة نسخة احتياطية للنظام',
        'SYSTEM-BACKUP',
        'النسخة الاحتياطية الموحدة',
        `تمت استعادة النسخة الاحتياطية بنجاح (${mode === 'merge' ? 'وضع الدمج' : 'وضع الاستبدال الشامل'}${reassignToCurrentAccount ? ` مع تعيين السجلات لحساب ${targetAccountId}` : ''}). الأفراد: ${counts.personnel}، الأسلحة: ${counts.weapons}، الآليات: ${counts.vehicles}، المسيرات المالية: ${counts.payroll}، المؤسسات: ${counts.tenants}.`
      );

      return {
        success: true,
        message: 'تمت استعادة كافة البيانات والمنظومة العسكرية بنجاح تام!',
        restoredStats: `تمت استعادة (${counts.personnel}) فرد، و(${counts.weapons}) قطعة سلاح، و(${counts.vehicles}) آلية، و(${counts.payroll}) مسير مالي، و(${counts.grants}) منحة/سلفة، و(${counts.tenants}) تشكيل ومؤسسة عسكرية.`,
        details: counts
      };
    } catch (err: any) {
      console.error('[StorageService] restoreFullSystemBackup failed:', err);
      return {
        success: false,
        message: `حدث خطأ أثناء استعادة النسخة الاحتياطية: ${err.message || err}`
      };
    }
  }

  static reassignAllPersonnelToAccount(
    targetAccountId: string,
    targetUnitName?: string
  ): { updatedPersonnelCount: number; updatedVehiclesCount: number; updatedWeaponsCount: number; updatedPayrollCount: number } {
    const currentPersonnel = this.getPersonnel();
    const currentVehicles = this.getVehicles();
    const currentWeapons = this.getArmoryWeapons();
    const currentPayroll = this.getPayrollRecords();

    const finalUnit =
      targetUnitName ||
      (targetAccountId === 'brigade1'
        ? 'اللواء الأول مشاة'
        : targetAccountId === 'brigade2'
        ? 'اللواء الثاني مشاة'
        : targetAccountId === 'brigade3'
        ? 'اللواء الثالث مشاة'
        : targetAccountId === 'vehicles_readiness'
        ? 'كتيبة الدروع والآليات'
        : targetAccountId);

    let pCount = 0;
    const updatedPersonnel = currentPersonnel.map((p) => {
      pCount++;
      return {
        ...p,
        createdByAccountId: targetAccountId,
        unit: finalUnit
      };
    });
    this.savePersonnel(updatedPersonnel, `إعادة تعيين القوة للواء (${finalUnit})`);

    let vCount = 0;
    const updatedVehicles = currentVehicles.map((v) => {
      vCount++;
      return {
        ...v,
        createdByAccountId: targetAccountId,
        assignedUnit: finalUnit
      };
    });
    this.saveVehicles(updatedVehicles);

    let wCount = 0;
    const updatedWeapons = currentWeapons.map((w) => {
      wCount++;
      return {
        ...w,
        currentHolderUnit: finalUnit
      };
    });
    this.saveArmoryWeapons(updatedWeapons);

    let payCount = 0;
    const updatedPayroll = currentPayroll.map((rec) => {
      payCount++;
      return {
        ...rec,
        unit: finalUnit
      };
    });
    this.savePayrollRecords(updatedPayroll);

    this.clearMemoryCache();
    notifyDataChange();

    return {
      updatedPersonnelCount: pCount,
      updatedVehiclesCount: vCount,
      updatedWeaponsCount: wCount,
      updatedPayrollCount: payCount
    };
  }

  static purgeStorageCategory(categoryKey: string): void {
    if (typeof window !== 'undefined') {
      try {
        if (categoryKey === STORAGE_KEY_AUDIT) {
          this.saveAuditLogs([]);
        } else if (categoryKey === STORAGE_KEY_ALERTS) {
          this.saveAlerts([]);
        } else if (categoryKey === STORAGE_KEY_RECYCLE_BIN) {
          safeSetLocalItem(STORAGE_KEY_RECYCLE_BIN, JSON.stringify([]));
          notifyDataChange();
        }
      } catch (e) {}
    }
  }

  // ==========================================
  // DEDUPLICATION & DUPLICATE RECORDS ENGINE
  // ==========================================

  static findDuplicatePersonnelGroups(recordsList?: PersonnelRecord[]): DuplicateGroup[] {
    const list = recordsList || this.getPersonnel();
    const groupsMap = new Map<string, { type: 'fullName' | 'militaryId' | 'nationalId'; matchValue: string; records: PersonnelRecord[] }>();

    const cleanName = (str: string) => {
      if (!str) return '';
      return str
        .trim()
        .toLowerCase()
        .replace(/[\u064B-\u0652]/g, '') // remove Arabic diacritics/tashkeel
        .replace(/[أإآ]/g, 'ا') // normalize Alef
        .replace(/ة/g, 'ه') // normalize Teh Marbuta
        .replace(/ى/g, 'ي') // normalize Alef Maqsura
        .replace(/\s+/g, ' '); // normalize whitespace
    };

    // 1. Group by fullName + unit + rank (requires strong multi-field match to avoid merging different soldiers who share common Arabic names)
    const nameMap = new Map<string, PersonnelRecord[]>();
    list.forEach((p) => {
      if (p.fullName && p.fullName.trim()) {
        const key = `${cleanName(p.fullName)}_${cleanName(p.unit)}_${cleanName(p.rank)}`;
        if (!nameMap.has(key)) nameMap.set(key, []);
        nameMap.get(key)!.push(p);
      }
    });

    nameMap.forEach((records, cleanKey) => {
      if (records.length > 1) {
        const groupKey = `fn-${cleanKey}`;
        groupsMap.set(groupKey, {
          type: 'fullName',
          matchValue: `${records[0].fullName} (${records[0].rank} - ${records[0].unit})`,
          records
        });
      }
    });

    // 2. Group by militaryId
    const milMap = new Map<string, PersonnelRecord[]>();
    list.forEach((p) => {
      if (p.militaryId && p.militaryId.trim()) {
        const key = p.militaryId.trim().toLowerCase();
        if (!milMap.has(key)) milMap.set(key, []);
        milMap.get(key)!.push(p);
      }
    });

    milMap.forEach((records, cleanKey) => {
      if (records.length > 1) {
        const groupKey = `mil-${cleanKey}`;
        if (!groupsMap.has(groupKey)) {
          groupsMap.set(groupKey, {
            type: 'militaryId',
            matchValue: records[0].militaryId,
            records
          });
        }
      }
    });

    // 3. Group by nationalId (if present and > 5 chars)
    const natMap = new Map<string, PersonnelRecord[]>();
    list.forEach((p) => {
      if (p.nationalId && p.nationalId.trim().length > 5 && p.nationalId !== '0000000000') {
        const key = p.nationalId.trim();
        if (!natMap.has(key)) natMap.set(key, []);
        natMap.get(key)!.push(p);
      }
    });

    natMap.forEach((records, cleanKey) => {
      if (records.length > 1) {
        const groupKey = `nat-${cleanKey}`;
        if (!groupsMap.has(groupKey)) {
          groupsMap.set(groupKey, {
            type: 'nationalId',
            matchValue: cleanKey,
            records
          });
        }
      }
    });

    const result: DuplicateGroup[] = [];
    groupsMap.forEach((val, gKey) => {
      let bestRecord = val.records[0];
      let maxScore = -1;

      val.records.forEach((p) => {
        let score = 0;
        if (p.logs) {
          score += (p.logs.movement?.length || 0) * 2;
          score += (p.logs.attendance?.length || 0);
          score += (p.logs.medical?.length || 0);
          score += (p.logs.financial?.length || 0);
          score += (p.logs.security?.length || 0);
          score += (p.logs.armament?.length || 0);
          score += (p.logs.training?.length || 0);
          score += (p.logs.attachments?.length || 0) * 3;
          score += (p.logs.supply?.length || 0);
        }
        if (p.photoUrl) score += 5;
        if (p.biometricsRecorded) score += 5;
        if (p.nationalId && p.nationalId !== '0000000000') score += 5;

        if (score > maxScore) {
          maxScore = score;
          bestRecord = p;
        }
      });

      const unitDist: { [unit: string]: number } = {};
      val.records.forEach((r) => {
        const u = r.unit || 'غير محدد';
        unitDist[u] = (unitDist[u] || 0) + 1;
      });

      result.push({
        groupId: gKey,
        matchType: val.type,
        matchValue: val.matchValue,
        fullName: val.records[0].fullName,
        records: val.records,
        suggestedPrimaryMilitaryId: bestRecord.militaryId,
        unitDistribution: unitDist
      });
    });

    return result;
  }

  static mergeDuplicatePersonnelGroupRecords(
    primaryRecord: PersonnelRecord,
    duplicateRecords: PersonnelRecord[],
    actorRole: DepartmentRole = 'إدارة الموارد البشرية',
    actorAccountName?: string
  ): { success: boolean; message: string } {
    const list = this.getPersonnel();
    
    // Find primary in list
    const primaryIndex = list.findIndex(
      (p) =>
        p === primaryRecord ||
        (p.militaryId === primaryRecord.militaryId &&
          p.unit === primaryRecord.unit &&
          p.fullName === primaryRecord.fullName)
    );

    if (primaryIndex === -1) {
      return { success: false, message: 'تعذر العثور على القيد الرئيسي المحدد!' };
    }

    const primary = list[primaryIndex];

    // Find all duplicate indices in list
    const duplicateIndices: number[] = [];
    const validDuplicates: PersonnelRecord[] = [];

    duplicateRecords.forEach((dup) => {
      const idx = list.findIndex(
        (p, index) =>
          index !== primaryIndex &&
          !duplicateIndices.includes(index) &&
          (p === dup ||
            (p.militaryId === dup.militaryId && p.unit === dup.unit && p.fullName === dup.fullName) ||
            (p.militaryId === dup.militaryId && dup.militaryId === primary.militaryId) ||
            (p.fullName && p.fullName.trim().toLowerCase() === dup.fullName.trim().toLowerCase()))
      );

      if (idx !== -1) {
        duplicateIndices.push(idx);
        validDuplicates.push(list[idx]);
      }
    });

    if (validDuplicates.length === 0) {
      return { success: false, message: 'لم يتم العثور على قيود مكررة للدمج!' };
    }

    if (!primary.logs) {
      primary.logs = {
        movement: [],
        attendance: [],
        medical: [],
        financial: [],
        security: [],
        armament: [],
        training: [],
        attachments: [],
        supply: []
      };
    }

    validDuplicates.forEach((dup) => {
      if (!primary.nationalId || primary.nationalId === '0000000000') primary.nationalId = dup.nationalId;
      if (!primary.phone) primary.phone = dup.phone;
      if (!primary.bloodType) primary.bloodType = dup.bloodType;
      if (!primary.photoUrl) primary.photoUrl = dup.photoUrl;
      if (!primary.biometricsRecorded && dup.biometricsRecorded) primary.biometricsRecorded = true;
      if (!primary.secondedUnit && dup.secondedUnit) primary.secondedUnit = dup.secondedUnit;
      if (!primary.trainingCourseType && dup.trainingCourseType) primary.trainingCourseType = dup.trainingCourseType;
      if (!primary.education) primary.education = dup.education;
      if (!primary.specialization) primary.specialization = dup.specialization;
      if (!primary.motherName) primary.motherName = dup.motherName;
      if (!primary.guarantorName) primary.guarantorName = dup.guarantorName;
      if (!primary.relativeName) primary.relativeName = dup.relativeName;
      if (!primary.relativePhone) primary.relativePhone = dup.relativePhone;

      if (dup.logs) {
        if (dup.logs.movement) {
          dup.logs.movement.forEach((m) => {
            if (!primary.logs!.movement.some((ex) => ex.id === m.id)) {
              primary.logs!.movement.push(m);
            }
          });
        }
        if (dup.logs.attendance) {
          dup.logs.attendance.forEach((a) => {
            if (!primary.logs!.attendance.some((ex) => ex.id === a.id)) {
              primary.logs!.attendance.push(a);
            }
          });
        }
        if (dup.logs.medical) {
          dup.logs.medical.forEach((med) => {
            if (!primary.logs!.medical.some((ex) => ex.id === med.id)) {
              primary.logs!.medical.push(med);
            }
          });
        }
        if (dup.logs.financial) {
          dup.logs.financial.forEach((f) => {
            if (!primary.logs!.financial.some((ex) => ex.id === f.id)) {
              primary.logs!.financial.push(f);
            }
          });
        }
        if (dup.logs.security) {
          dup.logs.security.forEach((s) => {
            if (!primary.logs!.security.some((ex) => ex.id === s.id)) {
              primary.logs!.security.push(s);
            }
          });
        }
        if (dup.logs.armament) {
          dup.logs.armament.forEach((arm) => {
            if (!primary.logs!.armament.some((ex) => ex.id === arm.id)) {
              primary.logs!.armament.push(arm);
            }
          });
        }
        if (dup.logs.training) {
          dup.logs.training.forEach((tr) => {
            if (!primary.logs!.training.some((ex) => ex.id === tr.id)) {
              primary.logs!.training.push(tr);
            }
          });
        }
        if (dup.logs.attachments) {
          dup.logs.attachments.forEach((att) => {
            if (!primary.logs!.attachments.some((ex) => ex.id === att.id)) {
              primary.logs!.attachments.push(att);
            }
          });
        }
        if (dup.logs.supply) {
          dup.logs.supply.forEach((sup) => {
            if (!primary.logs!.supply.some((ex) => ex.id === sup.id)) {
              primary.logs!.supply.push(sup);
            }
          });
        }
      }
    });

    const today = new Date().toISOString().split('T')[0];
    primary.logs.movement.unshift({
      id: `mov-merge-${Date.now()}`,
      date: today,
      type: 'أمر إداري',
      details: `تم دمج وتوحيد السجلات والتحركات الميدانية لـ (${validDuplicates.length}) قيود مكررة في هذا القيد الرئيسي آلياً`,
      issuingAuthority: actorAccountName || actorRole,
      effectiveDate: today
    });

    // Remove duplicate indices ONLY from personnel list, preserving primary at primaryIndex
    const remainingPersonnel = list.filter((_, idx) => !duplicateIndices.includes(idx));

    this.savePersonnel(remainingPersonnel);

    const recycleBin = this.getRecycleBin();
    const newTrashItems: RecycledPersonnel[] = validDuplicates.map((dup) => ({
      id: `trash-dup-${Date.now()}-${Math.floor(Math.random() * 10000)}`,
      personnel: dup,
      deletedAt: new Date().toISOString(),
      deletedBy: actorAccountName || 'النظام الإداري',
      reason: `دمج قيد مكرر مع القيد الرئيسي رقم (${primary.militaryId}) - ${primary.fullName}`
    }));
    this.saveRecycleBin([...newTrashItems, ...recycleBin]);

    this.logAction(
      actorAccountName || 'المستخدِم',
      actorRole,
      'دمج السجلات المكررة',
      primary.militaryId,
      primary.fullName,
      `تم دمج (${validDuplicates.length}) قيود مكررة وتوثيق بياناتها بالسجل الرئيسي بنجاح`
    );

    return {
      success: true,
      message: `تم دمج (${validDuplicates.length}) قيود مكررة وتحديث بيانات القيد الرئيسي بنجاح!`
    };
  }

  static mergeDuplicatePersonnelGroup(
    primaryMilitaryId: string,
    duplicateMilitaryIds: string[],
    actorRole: DepartmentRole = 'إدارة الموارد البشرية',
    actorAccountName?: string
  ): { success: boolean; message: string } {
    const list = this.getPersonnel();
    const primary = list.find((p) => p.militaryId === primaryMilitaryId);
    if (!primary) {
      return { success: false, message: 'تعذر العثور على القيد الرئيسي المحدد!' };
    }

    const primaryIdx = list.indexOf(primary);
    const duplicates = list.filter((p, idx) => idx !== primaryIdx && (duplicateMilitaryIds.includes(p.militaryId) || p.fullName === primary.fullName));
    if (duplicates.length === 0) {
      return { success: false, message: 'لم يتم العثور على قيود مكررة للدمج!' };
    }

    return this.mergeDuplicatePersonnelGroupRecords(primary, duplicates, actorRole, actorAccountName);
  }

  static autoDeduplicateAllPersonnel(
    actorRole: DepartmentRole = 'إدارة الموارد البشرية',
    actorAccountName?: string
  ): { success: boolean; mergedGroupsCount: number; removedDuplicatesCount: number; message: string } {
    const groups = this.findDuplicatePersonnelGroups();
    if (groups.length === 0) {
      return {
        success: true,
        mergedGroupsCount: 0,
        removedDuplicatesCount: 0,
        message: 'سجل القوة البشرية خالي تماماً من أي أسماء أو قيود مكررة!'
      };
    }

    let mergedGroupsCount = 0;
    let removedDuplicatesCount = 0;

    groups.forEach((group) => {
      const primaryId = group.suggestedPrimaryMilitaryId || group.records[0].militaryId;
      const dupIds = group.records.map((r) => r.militaryId).filter((id) => id !== primaryId);

      if (dupIds.length > 0) {
        const res = this.mergeDuplicatePersonnelGroup(primaryId, dupIds, actorRole, actorAccountName);
        if (res.success) {
          mergedGroupsCount++;
          removedDuplicatesCount += dupIds.length;
        }
      }
    });

    return {
      success: true,
      mergedGroupsCount,
      removedDuplicatesCount,
      message: `تمت المعالجة التلقائية بنجاح: تم دمج (${mergedGroupsCount}) مجموعات تكرار وتنظيف (${removedDuplicatesCount}) قيود مكررة!`
    };
  }

  // ==========================================
  // ==========================================
  // PAYROLL & SALARY MANAGEMENT SYSTEM
  // ==========================================

  static getDefaultSalaryForRank(rank: string, jobTitle?: string): number {
    if (!rank && !jobTitle) return 1000;
    const r = (rank || '').trim();
    const j = (jobTitle || '').trim();
    
    // Specific positions / job titles
    if (r.includes('مدير دائرة') || j.includes('مدير دائرة') || r.includes('مدير الدائرة') || j.includes('مدير الدائرة')) return 4500;
    if (r.includes('نائب ركن') || j.includes('نائب ركن') || r.includes('نائب الركن') || j.includes('نائب الركن')) return 1500;

    // Military ranks
    if (r.includes('فريق أول')) return 7000;
    if (r.includes('فريق')) return 6500;
    if (r.includes('لواء')) return 6000;
    if (r.includes('عميد')) return 5000;
    if (r.includes('عقيد')) return 4000;
    if (r.includes('مقدم')) return 3500;
    if (r.includes('رائد')) return 3000;
    if (r.includes('نقيب')) return 1500;
    if (r.includes('ملازم أول') || r.includes('ملازم 1') || r.includes('ملازم ا')) return 1500;
    if (r.includes('ملازم')) return 1500;
    if (r.includes('رئيس رقباء')) return 1800;
    if (r.includes('نائب')) return 1500;
    if (r.includes('رقيب أول') || r.includes('رقيب 1')) return 1600;
    if (r.includes('مساعد أول') || r.includes('مساعد 1')) return 1500;
    if (r.includes('رقيب')) return 1400;
    if (r.includes('وكيل رقيب')) return 1300;
    if (r.includes('مساعد')) return 1300;
    if (r.includes('عريف')) return 1200;
    if (r.includes('جندي أول') || r.includes('جندي 1')) return 1100;
    return 1000; // جندي / أخرى
  }

  // High-performance batch salary profile updater for large personnel imports (100x faster)
  static batchUpdateSalariesOnImport(personnelList: PersonnelRecord[]): void {
    if (!personnelList || personnelList.length === 0) return;
    const profiles = this.getSalaryProfiles();
    const profileMap = new Map(profiles.map((p) => [p.militaryId, p]));
    let modified = false;

    personnelList.forEach((p) => {
      if (!p.militaryId || !p.rank) return;
      const newBasicSalary = this.getDefaultSalaryForRank(p.rank, p.jobTitle);
      const existing = profileMap.get(p.militaryId);
      if (existing) {
        if (existing.basicSalary !== newBasicSalary) {
          existing.basicSalary = newBasicSalary;
          modified = true;
        }
      } else {
        const newProf = {
          militaryId: p.militaryId,
          basicSalary: newBasicSalary,
          allowances: [],
          salaryStatus: 'نشط' as const
        };
        profiles.push(newProf);
        profileMap.set(p.militaryId, newProf);
        modified = true;
      }
    });

    if (modified) {
      this.saveSalaryProfiles(profiles);
    }
  }

  // Automatically synchronize and update salary in the payroll system upon rank or job modification
  static updateSalaryOnRankChange(militaryId: string, newRank: string, oldRank?: string, jobTitle?: string): void {
    if (!militaryId || !newRank) return;
    const newBasicSalary = this.getDefaultSalaryForRank(newRank, jobTitle);

    // 1. Update salary profile for this person
    const profiles = this.getSalaryProfiles();
    const profileIdx = profiles.findIndex((p) => p.militaryId === militaryId);
    if (profileIdx >= 0) {
      profiles[profileIdx].basicSalary = newBasicSalary;
    } else {
      profiles.push({
        militaryId,
        basicSalary: newBasicSalary,
        allowances: [],
        salaryStatus: 'نشط'
      });
    }
    this.saveSalaryProfiles(profiles);

    // 2. Update existing payroll records for this person across active / draft months
    const tenantKey = `${STORAGE_KEY_PAYROLL_RECORDS}_${this.getActiveTenantId()}`;
    const raw = safeGetLocalItem<PayrollMonthlyRecord[] | string>(tenantKey);
    let records: PayrollMonthlyRecord[] = [];
    if (raw) {
      if (Array.isArray(raw)) records = raw;
      else {
        try {
          records = JSON.parse(raw as string) as PayrollMonthlyRecord[];
        } catch {
          records = [];
        }
      }
    }

    let recordsUpdated = false;
    records.forEach((rec) => {
      if (rec.militaryId === militaryId) {
        rec.rank = newRank;
        // If not already disbursed, update basicSalary and recalculate netSalary
        if (rec.status !== 'تم الصرف') {
          rec.basicSalary = newBasicSalary;
          const totalAllowances = (rec.allowances || []).reduce((acc, a) => acc + (a.amount || 0), 0);
          rec.totalAllowances = totalAllowances;
          
          // Re-calculate auto deductions if any based on daily wage of the new salary
          const dailyWage = Math.max(1, Math.round(newBasicSalary / 30));
          if (rec.deductions && rec.deductions.length > 0) {
            rec.deductions.forEach((d) => {
              if (d.autoGenerated && d.category === 'غياب / فرار' && d.daysCount) {
                d.amount = Math.min(newBasicSalary, Math.round(d.daysCount * dailyWage));
                d.reason = `استقطاع غياب/فرار عن الخدمة (${d.daysCount} يوم من أصل 30 يوم × ${dailyWage.toLocaleString('ar-SA')} ريال/يوم)`;
              } else if (d.autoGenerated && d.category === 'عهدة لم تسلم' && d.reason.includes('تسليح')) {
                d.amount = Math.round(newBasicSalary * 0.25);
              }
            });
          }

          const rawTotalDeductions = (rec.deductions || []).reduce((acc, d) => acc + (d.amount || 0), 0);
          const maxAllowableDeductions = newBasicSalary + totalAllowances;
          rec.totalDeductions = Math.min(maxAllowableDeductions, rawTotalDeductions);
          rec.netSalary = Math.max(0, newBasicSalary + totalAllowances - rec.totalDeductions);
          recordsUpdated = true;
        }
      }
    });

    if (recordsUpdated) {
      this.savePayrollRecords(records);

      // Recalculate batches
      const batches = this.getPayrollBatches();
      let batchesUpdated = false;
      batches.forEach((b) => {
        const monthRecs = records.filter((r) => r.monthYear === b.monthYear);
        if (monthRecs.length > 0) {
          b.totalBasicSalary = monthRecs.reduce((acc, r) => acc + r.basicSalary, 0);
          b.totalAllowances = monthRecs.reduce((acc, r) => acc + r.totalAllowances, 0);
          b.totalDeductions = monthRecs.reduce((acc, r) => acc + r.totalDeductions, 0);
          b.totalNetPayout = monthRecs.reduce((acc, r) => acc + r.netSalary, 0);
          batchesUpdated = true;
        }
      });
      if (batchesUpdated) {
        this.savePayrollBatches(batches);
      }
    }

    // 3. Log an info alert and notification
    const diffMsg = oldRank ? `من (${oldRank}) إلى (${newRank})` : `إلى (${newRank})`;
    this.addAlert({
      level: 'info',
      title: `تحديث المرتب المالي للرتبة (${newRank})`,
      description: `تم تعديل الرتبة ${diffMsg} وتحديث المرتب الأساسي في مسير الرواتب تلقائياً ليصبح (${newBasicSalary.toLocaleString('ar-SA')} ر.س).`,
      militaryId
    });
  }

  static getSalaryProfiles(): PersonnelSalaryProfile[] {
    const raw = safeGetLocalItem<PersonnelSalaryProfile[] | string>(`${STORAGE_KEY_SALARY_PROFILES}_${this.getActiveTenantId()}`);
    if (!raw) return [];
    if (Array.isArray(raw)) return raw;
    try {
      return JSON.parse(raw as string) as PersonnelSalaryProfile[];
    } catch {
      return [];
    }
  }

  static saveSalaryProfiles(profiles: PersonnelSalaryProfile[]): void {
    const tenantKey = `${STORAGE_KEY_SALARY_PROFILES}_${this.getActiveTenantId()}`;
    safeSetLocalItem(tenantKey, profiles);
    syncDocToCloud(tenantKey, profiles);
    notifyDataChange();
  }

  static getSalaryProfileForMilitaryId(militaryId: string, rank: string, jobTitle?: string): PersonnelSalaryProfile {
    const profiles = this.getSalaryProfiles();
    const existing = profiles.find((p) => p.militaryId === militaryId);
    
    const defaultBasic = this.getDefaultSalaryForRank(rank, jobTitle);

    if (existing) {
      return existing;
    }

    return {
      militaryId,
      basicSalary: defaultBasic,
      allowances: [],
      salaryStatus: 'نشط'
    };
  }

  static saveOrUpdateSalaryProfile(profile: PersonnelSalaryProfile): void {
    const profiles = this.getSalaryProfiles();
    const idx = profiles.findIndex((p) => p.militaryId === profile.militaryId);
    if (idx >= 0) {
      profiles[idx] = profile;
    } else {
      profiles.push(profile);
    }
    this.saveSalaryProfiles(profiles);
  }

  static getPayrollRecords(monthYear?: string): PayrollMonthlyRecord[] {
    const raw = safeGetLocalItem<PayrollMonthlyRecord[] | string>(`${STORAGE_KEY_PAYROLL_RECORDS}_${this.getActiveTenantId()}`);
    let list: PayrollMonthlyRecord[] = [];
    if (raw) {
      if (Array.isArray(raw)) {
        list = raw;
      } else {
        try {
          list = JSON.parse(raw as string) as PayrollMonthlyRecord[];
        } catch {
          list = [];
        }
      }
    }

    // Auto-reconcile check: count active personnel
    const activePersonnel = this.getPersonnel().filter((p) => (p.currentStatus as string) !== 'مطرود' && p.currentStatus !== 'متقاعد');
    const targetMonth = monthYear || `${new Date().getFullYear()}-${String(new Date().getMonth() + 1).padStart(2, '0')}`;
    const monthRecs = list.filter((r) => r.monthYear === targetMonth);

    // If month count doesn't match active personnel count or list is empty, perform full auto-sync
    if (monthRecs.length !== activePersonnel.length) {
      const synced = this.syncPayrollWithPersonnel(targetMonth);
      return synced.syncedRecords;
    }

    if (monthYear) {
      return list.filter((r) => r.monthYear === monthYear);
    }
    return list;
  }

  static syncPayrollWithPersonnel(targetMonthYear?: string): { syncedRecords: PayrollMonthlyRecord[]; activePersonnelCount: number } {
    const currentMonthYear = targetMonthYear || `${new Date().getFullYear()}-${String(new Date().getMonth() + 1).padStart(2, '0')}`;
    
    // 1. Get current active personnel
    const allPersonnel = this.getPersonnel().filter((p) => (p.currentStatus as string) !== 'مطرود' && p.currentStatus !== 'متقاعد');
    
    // 2. Load existing stored payroll records
    const tenantKey = `${STORAGE_KEY_PAYROLL_RECORDS}_${this.getActiveTenantId()}`;
    const raw = safeGetLocalItem<PayrollMonthlyRecord[] | string>(tenantKey);
    let existingList: PayrollMonthlyRecord[] = [];
    if (raw) {
      if (Array.isArray(raw)) {
        existingList = raw;
      } else {
        try {
          existingList = JSON.parse(raw as string) as PayrollMonthlyRecord[];
        } catch {
          existingList = [];
        }
      }
    }

    // Safety Guard: If no active personnel found (e.g. during initialization or empty state), NEVER purge payroll or salary profiles!
    if (allPersonnel.length === 0) {
      const resultForMonth = existingList.filter((r) => r.monthYear === currentMonthYear);
      return { syncedRecords: resultForMonth, activePersonnelCount: 0 };
    }

    // Helper string normalizer
    const cleanStr = (s: string) =>
      s
        ? s
            .trim()
            .toLowerCase()
            .replace(/[\u064B-\u0652]/g, '')
            .replace(/[أإآ]/g, 'ا')
            .replace(/ة/g, 'ه')
            .replace(/ى/g, 'ي')
            .replace(/\s+/g, ' ')
        : '';

    // Fast maps for matching
    const milToPersonMap = new Map<string, PersonnelRecord>();
    const natToPersonMap = new Map<string, PersonnelRecord>();
    const nameToPersonMap = new Map<string, PersonnelRecord>();

    allPersonnel.forEach((p) => {
      if (p.militaryId) milToPersonMap.set(p.militaryId.trim().toLowerCase(), p);
      if (p.nationalId && p.nationalId.length > 5) natToPersonMap.set(p.nationalId.trim(), p);
      if (p.fullName) nameToPersonMap.set(cleanStr(p.fullName), p);
    });

    // 3. Purge orphan salary profiles that don't belong to any active person
    const salaryProfiles = this.getSalaryProfiles();
    const validSalaryProfiles = salaryProfiles.filter((sp) => {
      const cMil = sp.militaryId ? sp.militaryId.trim().toLowerCase() : '';
      return milToPersonMap.has(cMil);
    });
    if (validSalaryProfiles.length !== salaryProfiles.length) {
      this.saveSalaryProfiles(validSalaryProfiles);
    }

    // 4. Determine months present in system
    const monthsInPayroll = new Set<string>();
    existingList.forEach((r) => {
      if (r.monthYear) monthsInPayroll.add(r.monthYear);
    });
    monthsInPayroll.add(currentMonthYear);

    const cleanPayrollRecords: PayrollMonthlyRecord[] = [];

    // For every month, enforce EXACT 1-to-1 matching with active personnel
    monthsInPayroll.forEach((mYear) => {
      const recordsForMonth = existingList.filter((r) => r.monthYear === mYear);
      
      const monthMilMap = new Map<string, PayrollMonthlyRecord>();
      const monthNatMap = new Map<string, PayrollMonthlyRecord>();
      const monthNameMap = new Map<string, PayrollMonthlyRecord>();

      recordsForMonth.forEach((r) => {
        const cMil = r.militaryId ? r.militaryId.trim().toLowerCase() : '';
        const cName = cleanStr(r.fullName);
        
        // Find if this record belongs to a real active person
        const person = (cMil && milToPersonMap.get(cMil)) || (cName && nameToPersonMap.get(cName));
        if (person) {
          if (cMil && !monthMilMap.has(cMil)) monthMilMap.set(cMil, r);
          if (cName && !monthNameMap.has(cName)) monthNameMap.set(cName, r);
        }
      });

      // Loop through all active personnel to guarantee 100% exact matching
      allPersonnel.forEach((person) => {
        const cMil = person.militaryId ? person.militaryId.trim().toLowerCase() : '';
        const cName = cleanStr(person.fullName);

        const existingRec = (cMil && monthMilMap.get(cMil)) || (cName && monthNameMap.get(cName));

        const salProfile = this.getSalaryProfileForMilitaryId(person.militaryId, person.rank, person.jobTitle);
        const rankChanged = existingRec && existingRec.rank !== person.rank;
        const basicSalary = rankChanged
          ? this.getDefaultSalaryForRank(person.rank, person.jobTitle)
          : (existingRec?.basicSalary !== undefined && existingRec.basicSalary > 0 
              ? existingRec.basicSalary 
              : salProfile.basicSalary);
        const allowances = existingRec?.allowances && existingRec.allowances.length > 0 
          ? existingRec.allowances 
          : salProfile.allowances || [];
        const totalAllowances = allowances.reduce((acc, a) => acc + (a.amount || 0), 0);

        if (existingRec) {
          // Update personnel fields in case rank, unit, or name updated in HR records
          existingRec.fullName = person.fullName;
          existingRec.rank = person.rank;
          existingRec.unit = person.unit;
          existingRec.battalion = person.battalion;
          existingRec.company = person.company;
          existingRec.militaryId = person.militaryId;
          existingRec.basicSalary = basicSalary;
          existingRec.allowances = allowances;
          existingRec.totalAllowances = totalAllowances;
          
          const rawTotalDeductions = (existingRec.deductions || []).reduce((acc, d) => acc + (d.amount || 0), 0);
          const maxAllowableDeductions = basicSalary + totalAllowances;
          existingRec.totalDeductions = Math.min(maxAllowableDeductions, rawTotalDeductions);
          existingRec.netSalary = Math.max(0, basicSalary + totalAllowances - existingRec.totalDeductions);

          cleanPayrollRecords.push(existingRec);
        } else {
          // Create new record for missing active person
          const newRecord: PayrollMonthlyRecord = {
            id: `pay-${mYear}-${person.militaryId || Math.random().toString(36).substring(2, 9)}`,
            monthYear: mYear,
            militaryId: person.militaryId,
            fullName: person.fullName,
            rank: person.rank,
            unit: person.unit,
            battalion: person.battalion,
            company: person.company,
            basicSalary,
            allowances,
            totalAllowances,
            deductions: [],
            totalDeductions: 0,
            netSalary: basicSalary + totalAllowances,
            status: 'مسودة',
            bankName: salProfile.bankName,
            bankAccountNumber: salProfile.bankAccountNumber
          };
          cleanPayrollRecords.push(newRecord);
        }
      });
    });

    // Save purged & synced records
    this.savePayrollRecords(cleanPayrollRecords);

    // Sync batches
    const batches = this.getPayrollBatches();
    let batchesUpdated = false;
    batches.forEach((b) => {
      const monthRecs = cleanPayrollRecords.filter((r) => r.monthYear === b.monthYear);
      if (b.totalPersonnel !== monthRecs.length) {
        b.totalPersonnel = monthRecs.length;
        b.totalBasicSalary = monthRecs.reduce((acc, r) => acc + r.basicSalary, 0);
        b.totalAllowances = monthRecs.reduce((acc, r) => acc + r.totalAllowances, 0);
        b.totalDeductions = monthRecs.reduce((acc, r) => acc + r.totalDeductions, 0);
        b.totalNetPayout = monthRecs.reduce((acc, r) => acc + r.netSalary, 0);
        batchesUpdated = true;
      }
    });

    if (batchesUpdated) {
      this.savePayrollBatches(batches);
    }

    const resultForMonth = cleanPayrollRecords.filter((r) => r.monthYear === currentMonthYear);
    return { syncedRecords: resultForMonth, activePersonnelCount: allPersonnel.length };
  }

  static savePayrollRecords(records: PayrollMonthlyRecord[]): void {
    const tenantKey = `${STORAGE_KEY_PAYROLL_RECORDS}_${this.getActiveTenantId()}`;
    safeSetLocalItem(tenantKey, records);
    syncDocToCloud(tenantKey, records);
    notifyDataChange();
  }

  static getPayrollBatches(): PayrollMonthBatch[] {
    const raw = safeGetLocalItem<PayrollMonthBatch[] | string>(`${STORAGE_KEY_PAYROLL_BATCHES}_${this.getActiveTenantId()}`);
    if (!raw) return [];
    if (Array.isArray(raw)) return raw;
    try {
      return JSON.parse(raw as string) as PayrollMonthBatch[];
    } catch {
      return [];
    }
  }

  static savePayrollBatches(batches: PayrollMonthBatch[]): void {
    const tenantKey = `${STORAGE_KEY_PAYROLL_BATCHES}_${this.getActiveTenantId()}`;
    safeSetLocalItem(tenantKey, batches);
    syncDocToCloud(tenantKey, batches);
    notifyDataChange();
  }

  static generateMonthlyPayrollBatch(
    monthYear: string,
    actingUser: string = 'الإدارة المالية'
  ): { batch: PayrollMonthBatch; records: PayrollMonthlyRecord[] } {
    const allPersonnel = this.getPersonnel().filter((p) => (p.currentStatus as string) !== 'مطرود' && p.currentStatus !== 'متقاعد');
    const existingRecords = this.getPayrollRecords();
    const existingBatches = this.getPayrollBatches();

    const monthRecords: PayrollMonthlyRecord[] = [];

    allPersonnel.forEach((person) => {
      // Check existing record for this person in this month if user manually customized salary or added extra custom deductions
      const prevRecord = existingRecords.find((r) => r.monthYear === monthYear && r.militaryId === person.militaryId);
      const salProfile = this.getSalaryProfileForMilitaryId(person.militaryId, person.rank, person.jobTitle);

      // Prioritize existing modified basicSalary and allowances if saved in record, otherwise fallback to salProfile (or update if rank changed)
      const rankChanged = prevRecord && prevRecord.rank !== person.rank;
      const basicSalary = rankChanged
        ? this.getDefaultSalaryForRank(person.rank, person.jobTitle)
        : (prevRecord?.basicSalary !== undefined && prevRecord.basicSalary > 0 
            ? prevRecord.basicSalary 
            : salProfile.basicSalary);
      const allowances = prevRecord?.allowances && prevRecord.allowances.length > 0 
        ? prevRecord.allowances 
        : salProfile.allowances || [];
      const totalAllowances = allowances.reduce((acc, a) => acc + (a.amount || 0), 0);

      // Preserve all user-added manual deductions
      const manualDeductions = prevRecord ? prevRecord.deductions.filter((d) => !d.autoGenerated) : [];

      const autoDeductions: PayrollDeduction[] = [];

      // 1. Calculate Absence / Desertion Deductions for this specific month
      const dailyWage = Math.max(1, Math.round(basicSalary / 30));
      let absenceDays = 0;
      const today = new Date().toISOString().split('T')[0];
      const isAbsenceStatus = (s: string) => ['غياب', 'فرار', 'فرار بالسلاح'].includes(s);

      // A) Active ongoing streak for this month (day 0 = 1 day, day 1 = 2 days, etc.)
      if (isAbsenceStatus(person.currentStatus)) {
        const streakStart =
          person.absenceStreakStartDate ||
          person.lastStatusChangeDate ||
          person.logs?.attendance?.find((a) => isAbsenceStatus(a.type) && a.statusPeriodState === 'active')?.startDate ||
          today;
        const monthStart = `${monthYear}-01`;
        const effStart = streakStart < monthStart ? monthStart : streakStart;
        const startMs = new Date(effStart).getTime();
        const todayMs = new Date(today).getTime();
        const diffDays = Math.max(0, Math.floor((todayMs - startMs) / (1000 * 60 * 60 * 24)));
        absenceDays += diffDays + 1;
      }

      // B) Check past completed attendance logs for this month
      person.logs?.attendance?.forEach((att) => {
        if (isAbsenceStatus(att.type) && att.statusPeriodState === 'completed') {
          const logDate = att.startDate || att.date;
          // Count only logs for this specific month
          if (logDate && logDate.startsWith(monthYear)) {
            absenceDays += att.durationDays || 1;
          }
        }
      });

      // Maximum absence days deducted in any single month is capped at 30 days
      absenceDays = Math.min(30, Math.max(0, absenceDays));

      if (absenceDays > 0) {
        // Deduction amount is strictly capped at basicSalary for 30 days
        const dedAmount = Math.min(basicSalary, Math.round(absenceDays * dailyWage));
        const statusLabel =
          person.currentStatus === 'فرار بالسلاح'
            ? 'فرار بالسلاح'
            : person.currentStatus === 'فرار'
            ? 'فرار'
            : 'غياب';
        autoDeductions.push({
          id: `ded-abs-${person.militaryId}-${Date.now()}`,
          category: 'غياب / فرار',
          reason: `استقطاع ${statusLabel} عن الخدمة (${absenceDays} يوم من أصل 30 يوم × ${dailyWage.toLocaleString('ar-SA')} ريال/يوم) - محدث تلقائياً`,
          amount: dedAmount,
          daysCount: absenceDays,
          days: absenceDays,
          date: today,
          autoGenerated: true
        });
      }

      // 2. Calculate Unreturned Custody / Armament / Equipment Deductions (optional safety hold)
      const unreturnedWeapons = person.logs?.armament?.filter((w) => !w.returnDate) || [];
      if (unreturnedWeapons.length > 0) {
        autoDeductions.push({
          id: `ded-custody-${person.militaryId}-${Date.now()}`,
          category: 'عهدة لم تسلم',
          reason: `خصم احترازي عهدة تسليح غير مسترجعة (${unreturnedWeapons.length} قطعة/سلاح)`,
          amount: Math.round(basicSalary * 0.25), // 25% custody hold
          autoGenerated: true
        });
      }

      const unreturnedSupply = person.logs?.supply?.filter((s) => !s.returnDate && s.condition === 'مستهلك') || [];
      if (unreturnedSupply.length > 0) {
        autoDeductions.push({
          id: `ded-supp-${person.militaryId}-${Date.now()}`,
          category: 'عهدة لم تسلم',
          reason: `خصم حسميات مهمات تموين وعهدة تالفة/مفقودة (${unreturnedSupply.length} مهمة)`,
          amount: 250,
          autoGenerated: true
        });
      }

      // Combine auto and manual deductions
      const allDeductions = [...autoDeductions, ...manualDeductions];
      const rawTotalDeductions = allDeductions.reduce((acc, d) => acc + (d.amount || 0), 0);
      
      // Critical Safety: Total deductions can NEVER exceed total earnings (basic salary + allowances)
      const maxAllowableDeductions = basicSalary + totalAllowances;
      const totalDeductions = Math.min(maxAllowableDeductions, rawTotalDeductions);
      const netSalary = Math.max(0, basicSalary + totalAllowances - totalDeductions);

      const record: PayrollMonthlyRecord = {
        id: prevRecord?.id || `pay-${monthYear}-${person.militaryId}`,
        monthYear,
        militaryId: person.militaryId,
        fullName: person.fullName,
        rank: person.rank,
        unit: person.unit,
        battalion: person.battalion,
        company: person.company,
        basicSalary,
        allowances,
        totalAllowances,
        deductions: allDeductions,
        totalDeductions,
        netSalary,
        status: prevRecord?.status || 'مسودة',
        disbursementDate: prevRecord?.disbursementDate,
        disbursedBy: prevRecord?.disbursedBy,
        bankName: prevRecord?.bankName || salProfile.bankName,
        bankAccountNumber: prevRecord?.bankAccountNumber || salProfile.bankAccountNumber,
        notes: prevRecord?.notes
      };

      monthRecords.push(record);
    });

    // Update existingRecords array
    const filteredOtherMonths = existingRecords.filter((r) => r.monthYear !== monthYear);
    const updatedRecords = [...filteredOtherMonths, ...monthRecords];
    this.savePayrollRecords(updatedRecords);

    // Calculate Batch Totals
    const totalBasicSalary = monthRecords.reduce((acc, r) => acc + r.basicSalary, 0);
    const totalAllowances = monthRecords.reduce((acc, r) => acc + r.totalAllowances, 0);
    const totalDeductions = monthRecords.reduce((acc, r) => acc + r.totalDeductions, 0);
    const totalNetPayout = monthRecords.reduce((acc, r) => acc + r.netSalary, 0);

    const prevBatch = existingBatches.find((b) => b.monthYear === monthYear);
    const batch: PayrollMonthBatch = {
      id: prevBatch?.id || `BATCH-${monthYear}`,
      monthYear,
      title: `كشف مرتبات مسير شهر (${monthYear})`,
      status: prevBatch?.status || 'قيد الإعداد',
      createdAt: prevBatch?.createdAt || new Date().toISOString().split('T')[0],
      approvedAt: prevBatch?.approvedAt,
      approvedBy: prevBatch?.approvedBy,
      totalPersonnel: monthRecords.length,
      totalBasicSalary,
      totalAllowances,
      totalDeductions,
      totalNetPayout
    };

    const updatedBatches = [...existingBatches.filter((b) => b.monthYear !== monthYear), batch];
    this.savePayrollBatches(updatedBatches);

    this.logAction(
      actingUser,
      'الإدارة المالية',
      'احتساب وتوليد كشف المرتبات والخصميات الآلية',
      monthYear,
      batch.title,
      `إجمالي الأفراد: (${monthRecords.length}) | الصافي المعتمد للصرف: (${totalNetPayout.toLocaleString('ar-EG')} ريال) | إجمالي الخصميات: (${totalDeductions.toLocaleString('ar-EG')} ريال)`
    );

    return { batch, records: monthRecords };
  }

  static updatePayrollRecord(record: PayrollMonthlyRecord, actingUser: string = 'المكتب المالي'): void {
    const list = this.getPayrollRecords();
    const idx = list.findIndex((r) => r.id === record.id);

    record.totalAllowances = (record.allowances || []).reduce((acc, a) => acc + (a.amount || 0), 0);
    const rawTotalDeductions = (record.deductions || []).reduce((acc, d) => acc + (d.amount || 0), 0);
    const maxAllowableDeductions = record.basicSalary + record.totalAllowances;
    record.totalDeductions = Math.min(maxAllowableDeductions, rawTotalDeductions);
    record.netSalary = Math.max(0, record.basicSalary + record.totalAllowances - record.totalDeductions);

    if (idx >= 0) {
      list[idx] = record;
    } else {
      list.push(record);
    }
    this.savePayrollRecords(list);

    // Recalculate batch totals for this monthYear
    const monthRecords = list.filter((r) => r.monthYear === record.monthYear);
    const batches = this.getPayrollBatches();
    const batchIdx = batches.findIndex((b) => b.monthYear === record.monthYear);
    if (batchIdx >= 0) {
      batches[batchIdx].totalBasicSalary = monthRecords.reduce((acc, r) => acc + r.basicSalary, 0);
      batches[batchIdx].totalAllowances = monthRecords.reduce((acc, r) => acc + r.totalAllowances, 0);
      batches[batchIdx].totalDeductions = monthRecords.reduce((acc, r) => acc + r.totalDeductions, 0);
      batches[batchIdx].totalNetPayout = monthRecords.reduce((acc, r) => acc + r.netSalary, 0);
      this.savePayrollBatches(batches);
    }
  }

  static updatePayrollBatchStatus(
    monthYear: string,
    newStatus: 'قيد الإعداد' | 'معتمد' | 'تم صرف الكشف بالكامل',
    actingUser: string = 'مدير الإدارة المالية'
  ): void {
    const batches = this.getPayrollBatches();
    const batch = batches.find((b) => b.monthYear === monthYear);
    if (!batch) return;

    batch.status = newStatus;
    if (newStatus === 'معتمد' || newStatus === 'تم صرف الكشف بالكامل') {
      batch.approvedAt = new Date().toISOString().split('T')[0];
      batch.approvedBy = actingUser;
    }
    this.savePayrollBatches(batches);

    // Update all records status in that month if batch is set to 'تم صرف الكشف بالكامل'
    if (newStatus === 'تم صرف الكشف بالكامل') {
      const records = this.getPayrollRecords();
      records.forEach((r) => {
        if (r.monthYear === monthYear) {
          r.status = 'تم الصرف';
          r.disbursementDate = new Date().toISOString().split('T')[0];
          r.disbursedBy = actingUser;
        }
      });
      this.savePayrollRecords(records);
    }

    this.logAction(
      actingUser,
      'الإدارة المالية',
      `تحديث حالة كشف المرتبات إلى (${newStatus})`,
      monthYear,
      batch.title,
      `اعتماد مسير المرتبات لشهر [${monthYear}] - صافي المبلغ: (${batch.totalNetPayout.toLocaleString('ar-EG')} ريال)`
    );
  }

  // ==========================================
  // FINANCIAL GRANTS & ADVANCES (المساعدات والسلف المالية)
  // ==========================================

  static getFinancialGrants(): FinancialGrantRecord[] {
    const tenantKey = `${STORAGE_KEY_FINANCIAL_GRANTS}_${this.getActiveTenantId()}`;
    const raw = safeGetLocalItem<FinancialGrantRecord[] | string>(tenantKey);
    if (!raw) return [];
    if (Array.isArray(raw)) return raw;
    try {
      return JSON.parse(raw as string) as FinancialGrantRecord[];
    } catch {
      return [];
    }
  }

  static saveFinancialGrants(grants: FinancialGrantRecord[]): void {
    const tenantKey = `${STORAGE_KEY_FINANCIAL_GRANTS}_${this.getActiveTenantId()}`;
    safeSetLocalItem(tenantKey, grants);
    syncDocToCloud(tenantKey, grants);
    notifyDataChange();
  }

  static grantFinancialAidOrAdvance(params: {
    militaryId: string;
    grantType: 'مساعدة مالية' | 'سلفة مالية';
    amount: number;
    monthYear: string;
    date?: string;
    reason: string;
    notes?: string;
    actingUser?: string;
    actingDept?: DepartmentRole;
  }): { success: boolean; message: string; record?: FinancialGrantRecord; voucherNumber: string } {
    const personnel = this.getPersonnel();
    const person = personnel.find((p) => p.militaryId === params.militaryId);
    if (!person) {
      return {
        success: false,
        message: 'تعذر العثور على الفرد المستهدف في سجل القوة البشرية!',
        voucherNumber: ''
      };
    }

    const actingUser = params.actingUser || 'القيادة المالية';
    const actingDept = params.actingDept || 'الإدارة المالية';
    const now = new Date();
    const date = params.date || now.toISOString().split('T')[0];
    const monthYear = params.monthYear || date.slice(0, 7);
    const voucherNumber = `FIN-${params.grantType === 'سلفة مالية' ? 'LOAN' : 'GRANT'}-${Date.now().toString().slice(-6)}-${Math.floor(1000 + Math.random() * 9000)}`;

    const isDeducted = params.grantType === 'سلفة مالية';

    const grantRecord: FinancialGrantRecord = {
      id: `grant-${Date.now()}-${Math.random().toString(36).substring(2, 7)}`,
      militaryId: person.militaryId,
      fullName: person.fullName,
      rank: person.rank,
      unit: person.unit,
      battalion: person.battalion,
      company: person.company,
      grantType: params.grantType,
      amount: params.amount,
      monthYear,
      date,
      reason: params.reason || (isDeducted ? 'طلب سلفة مالية على المرتب' : 'مساعدة وإعانة مالية استثنائية'),
      notes: params.notes,
      approvedBy: actingUser,
      isDeductedFromSalary: isDeducted,
      deductionMonthYear: isDeducted ? monthYear : undefined,
      voucherNumber,
      createdAt: now.toISOString()
    };

    // 1. Save in Financial Grants archive
    const currentGrants = this.getFinancialGrants();
    currentGrants.unshift(grantRecord);
    this.saveFinancialGrants(currentGrants);

    // 2. Append to individual's Financial Log
    const newFinLog: FinancialLog = {
      id: `fin-${Date.now()}`,
      date,
      type: isDeducted ? 'سلفة' : 'مساعدة مالية',
      grantType: params.grantType,
      amount: params.amount,
      reason: `${params.grantType}: ${params.reason} (سند رقم: ${voucherNumber})`,
      transactionDate: date,
      approvedBy: actingUser,
      notes: params.notes,
      voucherNumber,
      monthYear,
      isDeductedFromSalary: isDeducted
    };
    if (!person.logs) {
      person.logs = {
        movement: [], attendance: [], medical: [], financial: [],
        security: [], armament: [], training: [], attachments: [], supply: []
      };
    }
    if (!person.logs.financial) person.logs.financial = [];
    person.logs.financial.unshift(newFinLog);
    this.savePersonnel(personnel);

    // 3. If Advance (سلفة مالية), update monthly payroll record immediately and calculate deduction
    if (isDeducted) {
      // Sync or get payroll records for this month
      this.syncPayrollWithPersonnel(monthYear);
      const payrollRecords = this.getPayrollRecords();
      let rec = payrollRecords.find((r) => r.monthYear === monthYear && r.militaryId === person.militaryId);

      if (!rec) {
        this.generateMonthlyPayrollBatch(monthYear, actingUser);
        const refreshed = this.getPayrollRecords();
        rec = refreshed.find((r) => r.monthYear === monthYear && r.militaryId === person.militaryId);
      }

      if (rec) {
        const newDeduction: PayrollDeduction = {
          id: `ded-advance-${grantRecord.id}`,
          category: 'سلفة / استقطاع',
          reason: `استقطاع سلفة مالية معتمدة (${params.reason}) - سند: ${voucherNumber}`,
          amount: params.amount,
          date,
          autoGenerated: false
        };

        const existingDeductions = rec.deductions ? [...rec.deductions] : [];
        existingDeductions.push(newDeduction);

        const updatedRec: PayrollMonthlyRecord = {
          ...rec,
          deductions: existingDeductions
        };

        this.updatePayrollRecord(updatedRec, actingUser);
      }
    }

    // 4. Log Action in Audit
    const actionTitle = isDeducted ? 'منح سلفة مالية واحتساب خصم من المرتب' : 'منح مساعدة مالية رسمية (بدون خصم)';
    const actionDetails = isDeducted
      ? `تم منح سلفة مالية بمبلغ (${params.amount.toLocaleString('ar-SA')} ر.س) للفرد (${person.rank} / ${person.fullName}) واحتسابها فوراً ضمن الخصميات بمسير مرتبات شهر (${monthYear}) وتحديث صافي المرتب - سند رقم: ${voucherNumber}`
      : `تم منح مساعدة مالية غير مستردة بمبلغ (${params.amount.toLocaleString('ar-SA')} ر.س) للفرد (${person.rank} / ${person.fullName}) بدون أي خصم من المرتب - سند رقم: ${voucherNumber}`;

    this.logAction(
      actingUser,
      actingDept,
      actionTitle,
      person.militaryId,
      person.fullName,
      actionDetails
    );

    // 5. System Alert
    this.addAlert({
      level: isDeducted ? 'warning' : 'info',
      title: `${params.grantType}: ${person.rank} / ${person.fullName}`,
      description: `${actionTitle} بمبلغ (${params.amount.toLocaleString('ar-SA')} ر.س) - ${params.reason}`,
      militaryId: person.militaryId
    });

    return {
      success: true,
      message: isDeducted
        ? `تم منح السلفة المالية بمبلغ (${params.amount.toLocaleString('ar-SA')} ر.س) واحتسابها فوراً ضمن خصميات مرتب الفرد لشهر (${monthYear}) بنجاح!`
        : `تم منح المساعدة المالية بمبلغ (${params.amount.toLocaleString('ar-SA')} ر.س) وتوثيقها رسمياً بدون أي خصم من مرتب الفرد!`,
      record: grantRecord,
      voucherNumber
    };
  }

  static cancelOrDeleteFinancialGrant(
    grantId: string,
    actingUser: string = 'المكتب المالي'
  ): { success: boolean; message: string } {
    const grants = this.getFinancialGrants();
    const grant = grants.find((g) => g.id === grantId);
    if (!grant) {
      return { success: false, message: 'تعذر العثور على سجل المساعدة أو السلفة!' };
    }

    // If it was a deducted advance, remove the deduction from payroll
    if (grant.isDeductedFromSalary && grant.monthYear) {
      const payrollRecords = this.getPayrollRecords();
      const rec = payrollRecords.find((r) => r.monthYear === grant.monthYear && r.militaryId === grant.militaryId);
      if (rec && rec.deductions) {
        const dedId = `ded-advance-${grant.id}`;
        const updatedDeductions = rec.deductions.filter(
          (d) => d.id !== dedId && !d.reason.includes(grant.voucherNumber)
        );
        const updatedRec: PayrollMonthlyRecord = {
          ...rec,
          deductions: updatedDeductions
        };
        this.updatePayrollRecord(updatedRec, actingUser);
      }
    }

    // Remove from grants list
    const updatedGrants = grants.filter((g) => g.id !== grantId);
    this.saveFinancialGrants(updatedGrants);

    // Remove from personnel logs
    const personnel = this.getPersonnel();
    const person = personnel.find((p) => p.militaryId === grant.militaryId);
    if (person && person.logs?.financial) {
      person.logs.financial = person.logs.financial.filter(
        (f) =>
          !f.reason?.includes(grant.voucherNumber) &&
          f.voucherNumber !== grant.voucherNumber &&
          f.id !== `fin-${grant.id}`
      );
      this.savePersonnel(personnel);
    }

    this.logAction(
      actingUser,
      'الإدارة المالية',
      `إلغاء / تسوية ${grant.grantType}`,
      grant.militaryId,
      grant.fullName,
      `تم إلغاء ${grant.grantType} رقم (${grant.voucherNumber}) بمبلغ (${grant.amount.toLocaleString('ar-SA')} ر.س) وإعادة تسوية مسير المرتبات.`
    );

    return {
      success: true,
      message: `تم إلغاء وتسوية ${grant.grantType} بنجاح وإعادة احتساب مرتب الفرد!`
    };
  }

  // Get synchronized financial logs for an individual, guaranteed to include all grants/advances
  static getSyncedPersonnelFinancialLogs(person: PersonnelRecord): FinancialLog[] {
    if (!person) return [];
    const logs = person.logs?.financial ? [...person.logs.financial] : [];
    const grants = this.getFinancialGrants().filter((g) => g.militaryId === person.militaryId);

    // Merge any grants from the archive that might be missing from person.logs.financial
    for (const g of grants) {
      const exists = logs.some(
        (l) =>
          (l.voucherNumber && l.voucherNumber === g.voucherNumber) ||
          l.id === `fin-${g.id}` ||
          (l.reason && l.reason.includes(g.voucherNumber))
      );
      if (!exists) {
        logs.unshift({
          id: `fin-${g.id}`,
          date: g.date,
          type: g.grantType === 'سلفة مالية' ? 'سلفة' : 'مساعدة مالية',
          grantType: g.grantType,
          amount: g.amount,
          reason: `${g.grantType}: ${g.reason} (سند رقم: ${g.voucherNumber})`,
          transactionDate: g.date,
          approvedBy: g.approvedBy,
          notes: g.notes,
          voucherNumber: g.voucherNumber,
          monthYear: g.monthYear,
          isDeductedFromSalary: g.isDeductedFromSalary
        });
      }
    }

    // Sort descending by date
    return logs.sort((a, b) => {
      const dateA = new Date(a.date || a.transactionDate || 0).getTime();
      const dateB = new Date(b.date || b.transactionDate || 0).getTime();
      return dateB - dateA;
    });
  }

  // ==========================================
  // AUTOMATIC ABSENCE & DESERTION PAYROLL DEDUCTION ENGINE
  // استقطاع خصم الغياب والفرار اليومي التلقائي بنظام المرتبات
  // ==========================================
  // ABSENCE & DESERTION PAYROLL DEDUCTION SYNC ENGINE
  // استقطاع أيام الغياب والفرار آلياً من مسيرات الرواتب اليومية والشهرية
  // ==========================================

  static syncAbsencePayrollDeduction(
    militaryId: string,
    targetMonthYear?: string,
    saveImmediately: boolean = true
  ): void {
    const today = new Date().toISOString().split('T')[0];
    const monthYear = targetMonthYear || today.slice(0, 7);
    const list = this.getPersonnel();
    const person = list.find((p) => p.militaryId === militaryId);
    if (!person) return;

    const isAbsenceStatus = (s: string) => ['غياب', 'فرار', 'فرار بالسلاح'].includes(s);
    const isCurrentlyAbsent = isAbsenceStatus(person.currentStatus);

    let absenceDaysThisMonth = 0;

    // 1. Calculate active ongoing streak for this month
    if (isCurrentlyAbsent) {
      const streakStart = person.absenceStreakStartDate || person.lastStatusChangeDate || today;
      const monthStart = `${monthYear}-01`;
      const effStart = streakStart < monthStart ? monthStart : streakStart;
      
      const startMs = new Date(effStart).getTime();
      const todayMs = new Date(today).getTime();
      const diffDays = Math.max(0, Math.floor((todayMs - startMs) / (1000 * 60 * 60 * 24)));
      absenceDaysThisMonth += (diffDays + 1);
    }

    // 2. Add past completed attendance logs within this month
    person.logs?.attendance?.forEach((att) => {
      if (isAbsenceStatus(att.type) && att.statusPeriodState === 'completed') {
        const attDate = att.startDate || att.date;
        if (attDate && attDate.startsWith(monthYear)) {
          absenceDaysThisMonth += att.durationDays || 1;
        }
      }
    });

    absenceDaysThisMonth = Math.min(30, Math.max(0, absenceDaysThisMonth));

    // 3. Update Payroll Records for this month
    const tenantKey = `${STORAGE_KEY_PAYROLL_RECORDS}_${this.getActiveTenantId()}`;
    const raw = safeGetLocalItem<PayrollMonthlyRecord[] | string>(tenantKey);
    let records: PayrollMonthlyRecord[] = [];
    if (raw) {
      if (Array.isArray(raw)) records = raw;
      else {
        try { records = JSON.parse(raw as string); } catch { records = []; }
      }
    }

    let rec = records.find((r) => r.monthYear === monthYear && r.militaryId === militaryId);
    const salProfile = this.getSalaryProfileForMilitaryId(person.militaryId, person.rank, person.jobTitle);
    const basicSalary = rec?.basicSalary || salProfile.basicSalary || this.getDefaultSalaryForRank(person.rank, person.jobTitle);
    const dailyWage = Math.max(1, Math.round(basicSalary / 30));
    const dedAmount = Math.min(basicSalary, Math.round(absenceDaysThisMonth * dailyWage));

    let updated = false;

    if (!rec) {
      const totalAllowances = (salProfile.allowances || []).reduce((acc, a) => acc + (a.amount || 0), 0);
      const deductions: PayrollDeduction[] = [];
      if (absenceDaysThisMonth > 0) {
        const statusLabel = person.currentStatus === 'فرار بالسلاح' ? 'فرار بالسلاح' : person.currentStatus === 'فرار' ? 'فرار' : 'غياب';
        deductions.push({
          id: `ded-abs-${militaryId}-${Date.now()}`,
          category: 'غياب / فرار',
          reason: `استقطاع ${statusLabel} عن الخدمة (${absenceDaysThisMonth} يوم من أصل 30 يوم × ${dailyWage.toLocaleString('ar-SA')} ريال/يوم)`,
          amount: dedAmount,
          daysCount: absenceDaysThisMonth,
          days: absenceDaysThisMonth,
          date: today,
          autoGenerated: true
        });
      }
      const totalDeductions = deductions.reduce((acc, d) => acc + d.amount, 0);
      rec = {
        id: `pay-${monthYear}-${militaryId}`,
        monthYear,
        militaryId,
        fullName: person.fullName,
        rank: person.rank,
        unit: person.unit,
        battalion: person.battalion,
        company: person.company,
        basicSalary,
        allowances: salProfile.allowances || [],
        totalAllowances,
        deductions,
        totalDeductions,
        netSalary: Math.max(0, basicSalary + totalAllowances - totalDeductions),
        status: 'مسودة',
        bankName: salProfile.bankName,
        bankAccountNumber: salProfile.bankAccountNumber
      };
      records.push(rec);
      updated = true;
    } else {
      if (!rec.deductions) rec.deductions = [];
      const dedIndex = rec.deductions.findIndex((d) => d.autoGenerated && d.category === 'غياب / فرار');
      
      if (absenceDaysThisMonth > 0) {
        const statusLabel = person.currentStatus === 'فرار بالسلاح' ? 'فرار بالسلاح' : person.currentStatus === 'فرار' ? 'فرار' : 'غياب';
        const reasonText = `استقطاع ${statusLabel} عن الخدمة (${absenceDaysThisMonth} يوم من أصل 30 يوم × ${dailyWage.toLocaleString('ar-SA')} ريال/يوم)`;
        if (dedIndex >= 0) {
          const currentDed = rec.deductions[dedIndex];
          if (
            currentDed.amount !== dedAmount ||
            currentDed.daysCount !== absenceDaysThisMonth ||
            currentDed.reason !== reasonText
          ) {
            currentDed.amount = dedAmount;
            currentDed.daysCount = absenceDaysThisMonth;
            currentDed.days = absenceDaysThisMonth;
            currentDed.reason = reasonText;
            currentDed.date = today;
            updated = true;
          }
        } else {
          rec.deductions.push({
            id: `ded-abs-${militaryId}-${Date.now()}`,
            category: 'غياب / فرار',
            reason: reasonText,
            amount: dedAmount,
            daysCount: absenceDaysThisMonth,
            days: absenceDaysThisMonth,
            date: today,
            autoGenerated: true
          });
          updated = true;
        }
      } else {
        if (dedIndex >= 0) {
          rec.deductions.splice(dedIndex, 1);
          updated = true;
        }
      }

      if (updated) {
        const totalAllowances = (rec.allowances || []).reduce((acc, a) => acc + (a.amount || 0), 0);
        const rawTotalDeductions = rec.deductions.reduce((acc, d) => acc + (d.amount || 0), 0);
        const maxAllowable = rec.basicSalary + totalAllowances;
        rec.totalDeductions = Math.min(maxAllowable, rawTotalDeductions);
        rec.netSalary = Math.max(0, rec.basicSalary + totalAllowances - rec.totalDeductions);
      }
    }

    if (updated && saveImmediately) {
      this.savePayrollRecords(records);

      // Also sync to batch totals
      const batches = this.getPayrollBatches();
      const bIndex = batches.findIndex((b) => b.monthYear === monthYear);
      if (bIndex >= 0) {
        const monthRecs = records.filter((r) => r.monthYear === monthYear);
        batches[bIndex].totalBasicSalary = monthRecs.reduce((acc, r) => acc + r.basicSalary, 0);
        batches[bIndex].totalAllowances = monthRecs.reduce((acc, r) => acc + r.totalAllowances, 0);
        batches[bIndex].totalDeductions = monthRecs.reduce((acc, r) => acc + r.totalDeductions, 0);
        batches[bIndex].totalNetPayout = monthRecs.reduce((acc, r) => acc + r.netSalary, 0);
        this.savePayrollBatches(batches);
      }
    }
  }

  static syncAllAbsencePayrollDeductions(targetMonthYear?: string): number {
    const today = new Date().toISOString().split('T')[0];
    const monthYear = targetMonthYear || today.slice(0, 7);
    const isAbsenceStatus = (s: string) => ['غياب', 'فرار', 'فرار بالسلاح'].includes(s);
    const list = this.getPersonnel();
    const relevantPersonnel = list.filter(
      (p) => isAbsenceStatus(p.currentStatus) || (p.logs?.attendance && p.logs.attendance.some((a) => isAbsenceStatus(a.type)))
    );

    if (relevantPersonnel.length === 0) return 0;

    const tenantKey = `${STORAGE_KEY_PAYROLL_RECORDS}_${this.getActiveTenantId()}`;
    const raw = safeGetLocalItem<PayrollMonthlyRecord[] | string>(tenantKey);
    let records: PayrollMonthlyRecord[] = [];
    if (raw) {
      if (Array.isArray(raw)) records = raw;
      else {
        try { records = JSON.parse(raw as string); } catch { records = []; }
      }
    }

    let changedAny = false;

    relevantPersonnel.forEach((person) => {
      const isCurrentlyAbsent = isAbsenceStatus(person.currentStatus);
      let absenceDaysThisMonth = 0;

      if (isCurrentlyAbsent) {
        const streakStart = person.absenceStreakStartDate || person.lastStatusChangeDate || today;
        const monthStart = `${monthYear}-01`;
        const effStart = streakStart < monthStart ? monthStart : streakStart;
        const startMs = new Date(effStart).getTime();
        const todayMs = new Date(today).getTime();
        const diffDays = Math.max(0, Math.floor((todayMs - startMs) / (1000 * 60 * 60 * 24)));
        absenceDaysThisMonth += (diffDays + 1);
      }

      person.logs?.attendance?.forEach((att) => {
        if (isAbsenceStatus(att.type) && att.statusPeriodState === 'completed') {
          const attDate = att.startDate || att.date;
          if (attDate && attDate.startsWith(monthYear)) {
            absenceDaysThisMonth += att.durationDays || 1;
          }
        }
      });

      absenceDaysThisMonth = Math.min(30, Math.max(0, absenceDaysThisMonth));

      let rec = records.find((r) => r.monthYear === monthYear && r.militaryId === person.militaryId);
      const salProfile = this.getSalaryProfileForMilitaryId(person.militaryId, person.rank, person.jobTitle);
      const basicSalary = rec?.basicSalary || salProfile.basicSalary || this.getDefaultSalaryForRank(person.rank, person.jobTitle);
      const dailyWage = Math.max(1, Math.round(basicSalary / 30));
      const dedAmount = Math.min(basicSalary, Math.round(absenceDaysThisMonth * dailyWage));

      if (!rec) {
        const totalAllowances = (salProfile.allowances || []).reduce((acc, a) => acc + (a.amount || 0), 0);
        const deductions: PayrollDeduction[] = [];
        if (absenceDaysThisMonth > 0) {
          const statusLabel = person.currentStatus === 'فرار بالسلاح' ? 'فرار بالسلاح' : person.currentStatus === 'فرار' ? 'فرار' : 'غياب';
          deductions.push({
            id: `ded-abs-${person.militaryId}-${Date.now()}`,
            category: 'غياب / فرار',
            reason: `استقطاع ${statusLabel} عن الخدمة (${absenceDaysThisMonth} يوم من أصل 30 يوم × ${dailyWage.toLocaleString('ar-SA')} ريال/يوم)`,
            amount: dedAmount,
            daysCount: absenceDaysThisMonth,
            days: absenceDaysThisMonth,
            date: today,
            autoGenerated: true
          });
        }
        const totalDeductions = deductions.reduce((acc, d) => acc + d.amount, 0);
        rec = {
          id: `pay-${monthYear}-${person.militaryId}`,
          monthYear,
          militaryId: person.militaryId,
          fullName: person.fullName,
          rank: person.rank,
          unit: person.unit,
          battalion: person.battalion,
          company: person.company,
          basicSalary,
          allowances: salProfile.allowances || [],
          totalAllowances,
          deductions,
          totalDeductions,
          netSalary: Math.max(0, basicSalary + totalAllowances - totalDeductions),
          status: 'مسودة',
          bankName: salProfile.bankName,
          bankAccountNumber: salProfile.bankAccountNumber
        };
        records.push(rec);
        changedAny = true;
      } else {
        if (!rec.deductions) rec.deductions = [];
        const dedIndex = rec.deductions.findIndex((d) => d.autoGenerated && d.category === 'غياب / فرار');
        
        if (absenceDaysThisMonth > 0) {
          const statusLabel = person.currentStatus === 'فرار بالسلاح' ? 'فرار بالسلاح' : person.currentStatus === 'فرار' ? 'فرار' : 'غياب';
          const reasonText = `استقطاع ${statusLabel} عن الخدمة (${absenceDaysThisMonth} يوم من أصل 30 يوم × ${dailyWage.toLocaleString('ar-SA')} ريال/يوم)`;
          if (dedIndex >= 0) {
            const currentDed = rec.deductions[dedIndex];
            if (
              currentDed.amount !== dedAmount ||
              currentDed.daysCount !== absenceDaysThisMonth ||
              currentDed.reason !== reasonText
            ) {
              currentDed.amount = dedAmount;
              currentDed.daysCount = absenceDaysThisMonth;
              currentDed.days = absenceDaysThisMonth;
              currentDed.reason = reasonText;
              currentDed.date = today;
              changedAny = true;
            }
          } else {
            rec.deductions.push({
              id: `ded-abs-${person.militaryId}-${Date.now()}`,
              category: 'غياب / فرار',
              reason: reasonText,
              amount: dedAmount,
              daysCount: absenceDaysThisMonth,
              days: absenceDaysThisMonth,
              date: today,
              autoGenerated: true
            });
            changedAny = true;
          }
        } else {
          if (dedIndex >= 0) {
            rec.deductions.splice(dedIndex, 1);
            changedAny = true;
          }
        }

        const totalAllowances = (rec.allowances || []).reduce((acc, a) => acc + (a.amount || 0), 0);
        const rawTotalDeductions = rec.deductions.reduce((acc, d) => acc + (d.amount || 0), 0);
        const maxAllowable = rec.basicSalary + totalAllowances;
        rec.totalDeductions = Math.min(maxAllowable, rawTotalDeductions);
        rec.netSalary = Math.max(0, rec.basicSalary + totalAllowances - rec.totalDeductions);
      }
    });

    if (changedAny) {
      this.savePayrollRecords(records);
      const batches = this.getPayrollBatches();
      const bIndex = batches.findIndex((b) => b.monthYear === monthYear);
      if (bIndex >= 0) {
        const monthRecs = records.filter((r) => r.monthYear === monthYear);
        batches[bIndex].totalBasicSalary = monthRecs.reduce((acc, r) => acc + r.basicSalary, 0);
        batches[bIndex].totalAllowances = monthRecs.reduce((acc, r) => acc + r.totalAllowances, 0);
        batches[bIndex].totalDeductions = monthRecs.reduce((acc, r) => acc + r.totalDeductions, 0);
        batches[bIndex].totalNetPayout = monthRecs.reduce((acc, r) => acc + r.netSalary, 0);
        this.savePayrollBatches(batches);
      }
    }

    return relevantPersonnel.length;
  }

  // ==========================================
  // AUTOMATIC LEAVE EXPIRY & DESERTION ESCALATION
  // تحويل منتهيي الإجازات للغياب وتصعيد غياب 30 يوماً إلى فرار
  // ==========================================

  static checkAndProcessAutoStatusTransitions(
    actingUser = 'النظام الإداري والسيطرة الآلية',
    actingDept: DepartmentRole = 'إدارة الموارد البشرية'
  ): { expiredLeavesConverted: number; desertersPromoted: number; deductionsUpdated: number } {
    if (this.isProcessingTransitions) {
      return { expiredLeavesConverted: 0, desertersPromoted: 0, deductionsUpdated: 0 };
    }
    this.isProcessingTransitions = true;

    try {
      const today = new Date().toISOString().split('T')[0];
      const list = this.getPersonnel();
      let expiredLeavesConverted = 0;
      let desertersPromoted = 0;
      let personnelUpdated = false;

      const getNextDay = (dateStr: string): string => {
        try {
          const d = new Date(dateStr);
          d.setDate(d.getDate() + 1);
          return d.toISOString().split('T')[0];
        } catch {
          return dateStr;
        }
      };

      list.forEach((person) => {
        if (!person.logs) {
          person.logs = { movement: [], attendance: [], medical: [], financial: [], security: [], armament: [], training: [], attachments: [] };
        }
        if (!person.logs.attendance) person.logs.attendance = [];
        if (!person.logs.movement) person.logs.movement = [];
        if (!person.logs.security) person.logs.security = [];

        // A) Check Expired Leaves / Permissions (إجازة / إذن)
        if (person.currentStatus === 'إجازة' || person.currentStatus === 'إذن') {
          if (person.leaveEndDate && person.leaveEndDate < today) {
            const oldStatus = person.currentStatus;
            const absenceStartDate = getNextDay(person.leaveEndDate);

            // 1. Seal previous leave in attendance logs
            const activeLeaveLog = person.logs.attendance.find(
              (a) => (a.type === oldStatus || a.type === 'إجازة' || a.type === 'إذن') && (!a.endDate || a.statusPeriodState === 'active')
            );
            if (activeLeaveLog) {
              activeLeaveLog.endDate = person.leaveEndDate;
              activeLeaveLog.statusPeriodState = 'completed';
              activeLeaveLog.notes = `انقضت مدة (${oldStatus}) بتاريخ [${person.leaveEndDate}] ولم يباشر الفرد؛ تم التحويل التلقائي لحالة (غياب)`;
            }

            // 2. Transition person to 'غياب'
            person.currentStatus = 'غياب';
            person.lastStatusChangeDate = absenceStartDate;
            person.absenceStreakStartDate = absenceStartDate;

            // 3. Open new attendance log for 'غياب'
            person.logs.attendance.unshift({
              id: `att-auto-abs-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
              date: today,
              type: 'غياب',
              reason: `تحويل تلقائي إلى (غياب) لانتهاء مدة الـ (${oldStatus}) المقررة بتاريخ [${person.leaveEndDate}] دون عودة أو مباشرة`,
              durationDays: 1,
              approvedBy: actingUser,
              startDate: absenceStartDate,
              statusPeriodState: 'active',
              notes: `سارية في التمام والجاهزية، وبدأ الاستقطاع المالي اليومي بالمرتبات منذ [${absenceStartDate}]`
            });

            // 4. Movement log
            person.logs.movement.unshift({
              id: `mov-auto-abs-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
              date: today,
              type: 'أمر إداري',
              details: `تحويل إداري تلقائي إلى (غياب) لانتهاء مدة (${oldStatus}) المقررة في [${person.leaveEndDate}] دون مباشرة الخدمة`,
              effectiveDate: absenceStartDate,
              issuingAuthority: actingUser
            });

            // 5. Security log
            person.logs.security.unshift({
              id: `sec-auto-abs-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
              date: today,
              violation: `تجاوز مدة ${oldStatus} المقررة والانقطاع عن الخدمة`,
              investigationDetails: `انقضت مدة (${oldStatus}) للفرد بتاريخ [${person.leaveEndDate}] ولم يباشر المعسكر، تم تحويله نظامياً لحالة (غياب) وتفعيل الاستقطاع المالي اليومي.`,
              penalty: `استقطاع خصم غياب يومي من المرتب وإحالة للتفتيش الانضباطي`,
              warningLevel: 'عالي',
              authority: actingDept,
              status: 'تم البت'
            });

            // 6. System Alert
            this.addAlert({
              level: 'warning',
              title: `انقضاء ${oldStatus} والتحويل التلقائي للغياب`,
              description: `انقضت مدة (${oldStatus}) للفرد (${person.rank} / ${person.fullName}) بتاريخ [${person.leaveEndDate}]، وتم تحويله تلقائياً لحالة (غياب) وتفعيل الاستقطاع المالي اليومي بنظام المرتبات.`,
              militaryId: person.militaryId
            });

            expiredLeavesConverted++;
            personnelUpdated = true;
          }
        }

        // B) Check 30 Days in Absence -> Auto promote to Desertion (غياب -> فرار)
        if (person.currentStatus === 'غياب') {
          const streakStart = person.absenceStreakStartDate || person.lastStatusChangeDate || (person.logs.attendance?.find(a => a.type === 'غياب')?.startDate) || today;
          const startMs = new Date(streakStart).getTime();
          const todayMs = new Date(today).getTime();
          const diffDays = Math.max(0, Math.floor((todayMs - startMs) / (1000 * 60 * 60 * 24)));

          if (diffDays >= 30) {
            // 1. Seal 'غياب' log
            const activeAbsLog = person.logs.attendance.find(
              (a) => a.type === 'غياب' && (!a.endDate || a.statusPeriodState === 'active')
            );
            if (activeAbsLog) {
              activeAbsLog.endDate = today;
              activeAbsLog.statusPeriodState = 'completed';
              activeAbsLog.durationDays = diffDays;
              activeAbsLog.reason = `فترة (غياب) من تاريخ [${streakStart}] إلى تاريخ [${today}] (${diffDays} يوماً)`;
              activeAbsLog.notes = `تم إغلاق فترة الغياب والتحويل التلقائي إلى (فرار) بعد انقضاء مهلة الشهر (30 يوماً)`;
            }

            // 2. Transition person to 'فرار'
            person.currentStatus = 'فرار';
            person.lastStatusChangeDate = today;
            // IMPORTANT: Keep original streak start so continuous payroll deductions don't drop or reset!
            if (!person.absenceStreakStartDate) {
              person.absenceStreakStartDate = streakStart;
            }

            // 3. Open new attendance log for 'فرار'
            person.logs.attendance.unshift({
              id: `att-auto-des-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
              date: today,
              type: 'فرار',
              reason: `⚠️ تصعيد إداري وعملياتي تلقائي إلى (فرار) بعد انقضاء شهر كامل (30 يوماً) من الغياب المتواصل دون عودة`,
              durationDays: 1,
              approvedBy: actingUser,
              startDate: today,
              statusPeriodState: 'active',
              notes: `سارية في التمام والجاهزية، مع استمرار الاستقطاع المالي اليومي بالمرتبات منذ بداية الغياب [${streakStart}]`
            });

            // 4. Movement log
            person.logs.movement.unshift({
              id: `mov-auto-des-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
              date: today,
              type: 'أمر إداري',
              details: `تصعيد إداري وعملياتي تلقائي من (غياب) إلى (فرار) بعد مرور شهر كامل (30 يوماً) عن الخدمة العسكرية`,
              effectiveDate: today,
              issuingAuthority: actingUser
            });

            // 5. Security log
            person.logs.security.unshift({
              id: `sec-auto-des-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
              date: today,
              violation: `فرار عن المعسكر والخدمة العسكرية (انقضاء 30 يوماً من الغياب)`,
              investigationDetails: `تجاوز الفرد مهلة الغياب النظامية (30 يوماً) دون عودة، تم تصعيده رسمياً إلى قيد (فرار) واستمرار الاستقطاع المالي اليومي وتعميم بلاغ أمني.`,
              penalty: `تثبيت قيد فرار بالسجل العسكري واستمرار الاستقطاع المالي وإصدار أمر ملاحقة`,
              warningLevel: 'شديد الخطورة',
              authority: actingDept,
              status: 'تم البت'
            });

            // 6. System Alert
            this.addAlert({
              level: 'urgent',
              title: `⚠️ تصعيد تلقائي: تحويل من غياب إلى فرار`,
              description: `انقضت مهلة 30 يوماً على غياب الفرد (${person.rank} / ${person.fullName}) دون عودة، وتم تصعيده تلقائياً إلى حالة (فرار) مع استمرار الاستقطاع المالي اليومي بنظام المرتبات.`,
              militaryId: person.militaryId
            });

            desertersPromoted++;
            personnelUpdated = true;
          }
        }
      });

      if (personnelUpdated) {
        this.savePersonnel(list);
      }

      // Run deduction sync for active absence personnel
      const deductionsUpdated = this.syncAllAbsencePayrollDeductions();

      return { expiredLeavesConverted, desertersPromoted, deductionsUpdated };
    } finally {
      this.isProcessingTransitions = false;
    }
  }

  // =========================================================================
  // EMERGENCY DATA RECOVERY ENGINE (FOR 1262 PERSONNEL OR LOST IMPORTED DATA)
  // =========================================================================

  static async scanAndRecoverLostPersonnelDataset(): Promise<{
    found: boolean;
    count: number;
    records: PersonnelRecord[];
    source: string;
    details: string;
  }> {
    try {
      let largestCandidate: { records: PersonnelRecord[]; source: string; details: string; count: number } | null = null;

      const evaluateCandidate = (list: any[], sourceName: string, desc: string) => {
        if (!Array.isArray(list) || list.length <= 25) return;
        const validPersonnel = list.filter(
          (p) => p && typeof p === 'object' && (p.militaryId || p.fullName) && (p.rank || p.unit)
        );
        const deduplicated = this.deduplicatePersonnelList(validPersonnel);
        if (deduplicated.length > 25) {
          if (!largestCandidate || deduplicated.length > largestCandidate.count) {
            largestCandidate = {
              records: deduplicated,
              source: sourceName,
              details: desc,
              count: deduplicated.length
            };
          }
        }
      };

      // 1. Scan snapshots in SNAPSHOTS_STORE (IndexedDB)
      try {
        const snapshots = await getDeviceSnapshots();
        for (const snap of snapshots) {
          if (snap && snap.data) {
            for (const [k, val] of Object.entries(snap.data)) {
              if (Array.isArray(val)) {
                evaluateCandidate(
                  val,
                  `اللقطة الاحتياطية للجهاز [${new Date(snap.timestamp).toLocaleTimeString('ar-EG')}]`,
                  `تم العثور على (${val.length}) فرد في لقطات النظام التلقائية.`
                );
              }
            }
          }
        }
      } catch (eSnap) {}

      // 2. Scan IndexedDB raw records store directly
      try {
        const idbEntries = await getAllIDBEntries();
        for (const [k, val] of Object.entries(idbEntries)) {
          if (Array.isArray(val)) {
            evaluateCandidate(
              val,
              `مستودع التخزين الممتد للجهاز (IndexedDB - ${k})`,
              `تم العثور على (${val.length}) فرد مسجلين في مستودع الجهاز.`
            );
          }
        }
      } catch (eIdb) {}

      // 3. Scan Firestore Cloud Storage Chunks
      try {
        const cloudPersonnel = await fetchCloudDoc<PersonnelRecord[]>('personnel_tenant-hq-main');
        if (cloudPersonnel && Array.isArray(cloudPersonnel)) {
          evaluateCandidate(
            cloudPersonnel,
            'قاعدة بيانات السحابة المركزية (Firebase)',
            `تم العثور على (${cloudPersonnel.length}) فرد مسجلين في السحابة المركزية.`
          );
        }
      } catch (eCld) {}

      // 4. Scan localStorage and recover keys
      if (typeof window !== 'undefined') {
        const found = this.recoverLocalPersonnelFromAllKeys();
        if (found && found.length > 25) {
          evaluateCandidate(
            found,
            'مخزن المتصفح المحلي (LocalStorage)',
            `تم العثور على (${found.length}) فرد في مفاتيح المتصفح.`
          );
        }
      }

      if (largestCandidate) {
        return {
          found: true,
          count: largestCandidate.count,
          records: largestCandidate.records,
          source: largestCandidate.source,
          details: `تم العثور على كشف أفراد يحتوي على (${largestCandidate.count}) فرد [المصدر: ${largestCandidate.source}]!`
        };
      }

      return {
        found: false,
        count: 0,
        records: [],
        source: '',
        details: 'لم يتم العثور على كشف أفراد مفقود.'
      };
    } catch (err: any) {
      console.error('Error scanning for lost personnel:', err);
      return { found: false, count: 0, records: [], source: '', details: err.message || String(err) };
    }
  }

  // Dedicated System Optimizer: Purge Obsolete & Replaced Data to Accelerate Navigation and Eliminate UI Freeze
  static async purgeReplacedAndObsoleteData(): Promise<{
    success: boolean;
    preservedPersonnelCount: number;
    purgedSnapshotsCount: number;
    purgedLocalStorageKeysCount: number;
    reclaimedEstimateKB: number;
    details: string;
  }> {
    try {
      // 1. Get current pristine active personnel list
      const currentPersonnel = this.getPersonnel();
      const cleanPersonnel = this.deduplicatePersonnelList(currentPersonnel);
      
      // 2. Compact and save pristine personnel list to ensure zero loss of active records
      if (cleanPersonnel.length > 0) {
        this.savePersonnel(cleanPersonnel, 'تنظيف وضغط السجلات المعتمدة');
      }

      // 3. Compact and prune old audit logs to prevent memory bloat (keep last 120 most recent)
      const auditLogs = this.getAuditLogs();
      if (auditLogs.length > 120) {
        const prunedLogs = auditLogs.slice(0, 120);
        const auditKey = this.getKeyForTenant(STORAGE_KEY_AUDIT);
        safeSetLocalItem(auditKey, prunedLogs);
        safeSetLocalItem(STORAGE_KEY_AUDIT, prunedLogs);
      }

      // 4. Run deep on-device purge of obsolete snapshots, dead keys, and legacy caches
      const purgeResult = await purgeObsoleteReplacedData(STORAGE_KEY_PERSONNEL);

      // 5. Clear transient memory cache so fresh compact references are used
      this.clearMemoryCache();
      this.memoizedPersonnel = {
        tenantId: this.getActiveTenantId(),
        data: cleanPersonnel
      };

      // 6. Log successful maintenance action
      this.logAction(
        'مدير المنظومة',
        'القيادة الرئيسية',
        'تنظيف وحذف البيانات المستبدلة',
        'CLEANUP',
        'تحسين أداء المنظومة',
        `تم تنظيف وحذف (${purgeResult.purgedSnapshotsCount}) لقطة قديمة و(${purgeResult.purgedLocalStorageKeysCount}) مفتاح مؤقت مع الحفاظ على (${cleanPersonnel.length}) فرد معتمد وتسريع التنقل.`
      );

      notifyDataChange();

      return {
        success: true,
        preservedPersonnelCount: cleanPersonnel.length,
        purgedSnapshotsCount: purgeResult.purgedSnapshotsCount,
        purgedLocalStorageKeysCount: purgeResult.purgedLocalStorageKeysCount,
        reclaimedEstimateKB: purgeResult.reclaimedEstimateKB,
        details: `تم بنجاح تنظيف وحذف كافة البيانات السابقة والمستبدلة، وتحرير مساحة الذاكرة، مع تثبيت (${cleanPersonnel.length}) فرد معتمد.`
      };
    } catch (err: any) {
      console.error('Error during purgeReplacedAndObsoleteData:', err);
      return {
        success: false,
        preservedPersonnelCount: 0,
        purgedSnapshotsCount: 0,
        purgedLocalStorageKeysCount: 0,
        reclaimedEstimateKB: 0,
        details: err?.message || String(err)
      };
    }
  }

  // Restore and commit recovered dataset to primary storage
  static applyRecoveredPersonnel(records: PersonnelRecord[], reason = 'استعادة كشف الأفراد المفقود (1262 فرد)'): boolean {
    if (!records || records.length === 0) return false;
    const clean = this.deduplicatePersonnelList(records);
    this.savePersonnel(clean, reason);
    this.batchUpdateSalariesOnImport(clean);
    this.logAction(
      'مدير المنظومة',
      'إدارة الموارد البشرية',
      'استعادة كشف الأفراد المفقود',
      'RECOVERY',
      'استعادة بيانات معتمدة',
      `تم استعادة واعتماد (${clean.length}) فرد بنجاح وإلغاء البيانات الافتراضية السابقة.`
    );
    notifyDataChange();
    return true;
  }
}

