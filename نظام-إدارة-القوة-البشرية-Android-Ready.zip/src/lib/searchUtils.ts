import React from 'react';
import { PersonnelRecord } from '../types';

/**
 * Normalizes Arabic text for flexible, error-tolerant search:
 * - Normalizes Alef forms (أ, إ, آ, ٱ) -> ا
 * - Normalizes Taa Marbuta (ة) -> ه
 * - Normalizes Alef Maqsura (ى) -> ي
 * - Normalizes Hamza on Waw/Yaa (ؤ, ئ) -> و, ي
 * - Strips Tashkeel / Harakat (َ ً ُ ٌ ِ ٍ ْ ّ)
 * - Strips Tatweel / Kashida (ـ)
 * - Converts Arabic-Indic numerals (٠-٩) to Western (0-9)
 * - Normalizes whitespace and converts to lower case
 */
export function normalizeArabicText(text: any): string {
  if (text === null || text === undefined) return '';
  return String(text)
    .trim()
    .toLowerCase()
    // Convert Arabic-Indic numerals to standard ASCII digits
    .replace(/[\u0660-\u0669]/g, (d) => String(d.charCodeAt(0) - 0x0660))
    // Convert Persian numerals
    .replace(/[\u06F0-\u06F9]/g, (d) => String(d.charCodeAt(0) - 0x06F0))
    // Strip Arabic diacritics / Tashkeel
    .replace(/[\u064B-\u065F\u0670]/g, '')
    // Strip Tatweel (Kashida)
    .replace(/\u0640/g, '')
    // Normalize Alef forms
    .replace(/[أإآٱ]/g, 'ا')
    // Normalize Taa Marbuta to Haa
    .replace(/ة/g, 'ه')
    // Normalize Alef Maqsura to Yaa
    .replace(/ى/g, 'ي')
    // Normalize Hamza forms
    .replace(/ؤ/g, 'و')
    .replace(/ئ/g, 'ي')
    // Normalize multiple spaces
    .replace(/\s+/g, ' ');
}

/**
 * Breaks a query into distinct normalized search tokens
 */
export function getSearchTokens(query: string): string[] {
  if (!query) return [];
  const norm = normalizeArabicText(query);
  if (!norm) return [];
  return norm.split(' ').filter(token => token.length > 0);
}

/**
 * Checks if all query tokens match against the given searchable fields
 */
export function matchesSearchTokens(searchableFields: (string | number | null | undefined)[], query: string): boolean {
  if (!query) return true;
  const tokens = getSearchTokens(query);
  if (tokens.length === 0) return true;

  // Combine and normalize all target fields into a single searchable buffer
  const combinedBuffer = (searchableFields || [])
    .filter(f => f !== null && f !== undefined)
    .map(f => normalizeArabicText(f))
    .join(' ');

  // All tokens must be present in the buffer (Boolean AND)
  return tokens.every(token => combinedBuffer.includes(token));
}

/**
 * Comprehensive Personnel record search matching.
 * Checks Name, Military ID, National ID, Rank, Unit, Battalion, Company, Platoon,
 * Job title, Phone, Relatives, Mother name, POB, Blood type, Status, and Armament serials.
 */
export function matchesPersonnelRecord(person: PersonnelRecord, query: string): boolean {
  if (!person) return false;
  if (!query || !query.trim()) return true;

  try {
    const tokens = getSearchTokens(query);
    if (tokens.length === 0) return true;

    // Collect all relevant searchable text strings from the person record
    const fields: (string | number | undefined | null)[] = [
      person.fullName,
      person.militaryId,
      person.nationalId,
      person.rank,
      person.unit,
      person.battalion,
      person.company,
      person.platoon,
      person.jobTitle,
      person.specialization,
      person.currentStatus,
      person.phone,
      person.pob,
      person.bloodType,
      person.motherName,
      person.guarantorName,
      person.relativeName,
      person.relativePhone,
      person.secondedUnit,
      person.trainingCourseType,
      person.education,
      person.maritalStatus
    ];

    // Include weapons serials and weapon types from logs
    if (person.logs?.armament && Array.isArray(person.logs.armament)) {
      person.logs.armament.forEach(w => {
        if (w) {
          fields.push(w.weaponSerial, w.weaponType, w.technicalNotes);
        }
      });
    }

    // Include attachments or file names
    if (person.logs?.attachments && Array.isArray(person.logs.attachments)) {
      person.logs.attachments.forEach(att => {
        if (att) fields.push(att.title, att.category);
      });
    }

    return matchesSearchTokens(fields, query);
  } catch (err) {
    console.error('Error in matchesPersonnelRecord:', err);
    return false;
  }
}

/**
 * Calculates a relevance score for a person given a search query:
 * - Exact militaryId match: +1000
 * - Exact nationalId match: +900
 * - Prefix militaryId match: +500
 * - Exact full name match: +600
 * - Name starts with query: +350
 * - Token count and density bonus
 */
export function scorePersonnelMatch(person: PersonnelRecord, query: string): number {
  if (!person || !query || !query.trim()) return 0;

  try {
    const cleanQ = normalizeArabicText(query);
    const rawQ = String(query).trim().toLowerCase();
    if (!cleanQ && !rawQ) return 0;

    let score = 0;

    const rawMil = String(person.militaryId ?? '').trim();
    const rawNat = String(person.nationalId ?? '').trim();
    const rawName = String(person.fullName ?? '').trim();
    const rawUnit = String(person.unit ?? '').trim();
    const rawRank = String(person.rank ?? '').trim();

    const normMil = normalizeArabicText(rawMil);
    const normNat = normalizeArabicText(rawNat);
    const normName = normalizeArabicText(rawName);
    const normUnit = normalizeArabicText(rawUnit);
    const normRank = normalizeArabicText(rawRank);

    // Exact ID matches
    if ((normMil && normMil === cleanQ) || (rawMil && rawMil.toLowerCase() === rawQ)) {
      score += 1000;
    } else if (normMil && cleanQ && normMil.startsWith(cleanQ)) {
      score += 500;
    } else if (normMil && cleanQ && normMil.includes(cleanQ)) {
      score += 250;
    }

    // National ID matches
    if ((normNat && normNat === cleanQ) || (rawNat && rawNat.toLowerCase() === rawQ)) {
      score += 900;
    } else if (normNat && cleanQ && normNat.startsWith(cleanQ)) {
      score += 400;
    } else if (normNat && cleanQ && normNat.includes(cleanQ)) {
      score += 200;
    }

    // Name matches
    if (normName && normName === cleanQ) {
      score += 600;
    } else if (normName && cleanQ && normName.startsWith(cleanQ)) {
      score += 350;
    } else if (normName && cleanQ && normName.includes(cleanQ)) {
      score += 150;
    }

    // Rank / Unit
    if (normRank && normRank === cleanQ) score += 100;
    if (normUnit && normUnit === cleanQ) score += 80;

    // Multi-token name density bonus (e.g. searching "محمد علي" matching both tokens in order)
    const tokens = getSearchTokens(query);
    if (tokens.length > 1 && normName) {
      let allFound = true;
      for (const t of tokens) {
        if (!normName.includes(t)) {
          allFound = false;
          break;
        }
      }
      if (allFound) score += 200;
    }

    // Check armament serials
    if (person.logs?.armament && Array.isArray(person.logs.armament)) {
      for (const w of person.logs.armament) {
        if (w && w.weaponSerial) {
          const rawW = String(w.weaponSerial).trim();
          const normW = normalizeArabicText(rawW);
          if (normW === cleanQ || rawW.toLowerCase() === rawQ) {
            score += 700;
          } else if (cleanQ && normW.includes(cleanQ)) {
            score += 300;
          }
        }
      }
    }

    return score;
  } catch (err) {
    console.error('Error in scorePersonnelMatch:', err);
    return 0;
  }
}

/**
 * Searches and automatically ranks personnel records by relevance
 */
export function searchAndRankPersonnel(
  personnelList: PersonnelRecord[],
  query: string
): PersonnelRecord[] {
  if (!personnelList || !Array.isArray(personnelList)) return [];
  if (!query || !query.trim()) return personnelList;

  try {
    const matched = personnelList.filter(p => p && matchesPersonnelRecord(p, query));

    // Sort by calculated relevance score descending on a safe copy
    return matched.slice().sort((a, b) => {
      const scoreA = scorePersonnelMatch(a, query);
      const scoreB = scorePersonnelMatch(b, query);
      return scoreB - scoreA;
    });
  } catch (err) {
    console.error('Error in searchAndRankPersonnel:', err);
    return personnelList;
  }
}
