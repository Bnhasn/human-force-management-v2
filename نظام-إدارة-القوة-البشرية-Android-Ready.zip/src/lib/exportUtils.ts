/**
 * Multiplatform Export Utility for Web, Android (Capacitor/WebView), and Windows (Electron/WebView2)
 * Handles Excel (.xlsx) and CSV exports with robust fallbacks for mobile share sheets, file system pickers,
 * native Capacitor plugins, and standard browser downloads.
 */

import * as XLSX from 'xlsx';

export interface ExportResult {
  success: boolean;
  method: 'capacitor' | 'share' | 'save_picker' | 'blob_download' | 'data_uri' | 'fallback';
  fileName: string;
  message?: string;
  error?: any;
}

// Convert Uint8Array to Base64 safely without stack overflow for large arrays
function uint8ArrayToBase64(bytes: Uint8Array): string {
  let binary = '';
  const len = bytes.byteLength;
  const chunkSize = 0x8000; // 32KB chunks
  for (let i = 0; i < len; i += chunkSize) {
    const chunk = bytes.subarray(i, Math.min(i + chunkSize, len));
    binary += String.fromCharCode.apply(null, Array.from(chunk));
  }
  return btoa(binary);
}

// Toast notification helper for user feedback
export function showExportToast(type: 'success' | 'error' | 'info', message: string) {
  try {
    const event = new CustomEvent('military_export_notification', {
      detail: { type, message, timestamp: Date.now() }
    });
    window.dispatchEvent(event);
  } catch {
    // ignore in environments without CustomEvent
  }

  // Also log to console for debugging in Android WebView / Windows Electron
  if (type === 'error') {
    console.error(`[ExportService] ${message}`);
  } else {
    console.log(`[ExportService] ${message}`);
  }
}

/**
 * Saves or shares an XLSX workbook across Web, Android, and Windows platforms
 */
export async function exportExcelWorkbook(
  workbook: XLSX.WorkBook,
  fileName: string
): Promise<ExportResult> {
  const cleanFileName = fileName.endsWith('.xlsx') ? fileName : `${fileName}.xlsx`;

  try {
    // Generate array buffer from SheetJS workbook
    const wbout = XLSX.write(workbook, { bookType: 'xlsx', type: 'array' });
    const u8 = new Uint8Array(wbout);
    const mimeType = 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet';
    const blob = new Blob([u8], { type: mimeType });

    // 1. Check for Capacitor native runtime (Android / iOS)
    const capacitor = (window as any).Capacitor;
    if (capacitor && typeof capacitor.isNativePlatform === 'function' && capacitor.isNativePlatform()) {
      if (capacitor.Plugins?.Filesystem) {
        try {
          const base64Data = uint8ArrayToBase64(u8);
          const saved = await capacitor.Plugins.Filesystem.writeFile({
            path: cleanFileName,
            data: base64Data,
            directory: 'CACHE'
          });

          if (capacitor.Plugins?.Share) {
            await capacitor.Plugins.Share.share({
              title: cleanFileName,
              text: `كشف إكسل معتمد: ${cleanFileName}`,
              url: saved.uri,
              dialogTitle: 'مشاركة أو حفظ كشف الإكسل'
            });
            showExportToast('success', `تم تصدير الكشف بنجاح: ${cleanFileName}`);
            return { success: true, method: 'capacitor', fileName: cleanFileName };
          }
        } catch (capErr) {
          console.warn('[ExportService] Capacitor Filesystem/Share failed, trying web fallback:', capErr);
        }
      }
    }

    // 2. Web Share API with File (Standard & most reliable for Android WebViews)
    const isMobile = /Android|iPhone|iPad|iPod|Mobile/i.test(navigator.userAgent);
    if (isMobile && typeof navigator.share === 'function') {
      try {
        const file = new File([blob], cleanFileName, { type: mimeType });
        if (typeof navigator.canShare === 'function' && navigator.canShare({ files: [file] })) {
          await navigator.share({
            files: [file],
            title: cleanFileName,
            text: `كشف إكسل عسكري رسمي: ${cleanFileName}`
          });
          showExportToast('success', `تمت مشاركة وتصدير الكشف بنجاح: ${cleanFileName}`);
          return { success: true, method: 'share', fileName: cleanFileName };
        }
      } catch (shareErr: any) {
        if (shareErr.name === 'AbortError') {
          // User cancelled the share dialog
          return { success: true, method: 'share', fileName: cleanFileName };
        }
        console.warn('[ExportService] Web Share API failed, falling back:', shareErr);
      }
    }

    // 3. Modern Windows / Desktop File System Access API (Edge, Chrome, Electron)
    if (typeof (window as any).showSaveFilePicker === 'function' && !isMobile) {
      try {
        const handle = await (window as any).showSaveFilePicker({
          suggestedName: cleanFileName,
          types: [{
            description: 'ملف إكسل (Excel Spreadsheet)',
            accept: { [mimeType]: ['.xlsx'] }
          }]
        });
        const writable = await handle.createWritable();
        await writable.write(blob);
        await writable.close();
        showExportToast('success', `تم حفظ ملف الإكسل بنجاح في جهازك: ${cleanFileName}`);
        return { success: true, method: 'save_picker', fileName: cleanFileName };
      } catch (pickerErr: any) {
        if (pickerErr.name === 'AbortError') {
          return { success: true, method: 'save_picker', fileName: cleanFileName };
        }
        console.warn('[ExportService] File System Picker failed, falling back to download:', pickerErr);
      }
    }

    // 4. Standard Browser Blob URL Download (<a download>)
    try {
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = cleanFileName;
      a.style.display = 'none';
      document.body.appendChild(a);
      a.click();
      setTimeout(() => {
        if (document.body.contains(a)) document.body.removeChild(a);
        URL.revokeObjectURL(url);
      }, 4000);
      showExportToast('success', `جاري تنزيل كشف الإكسل: ${cleanFileName}`);
      return { success: true, method: 'blob_download', fileName: cleanFileName };
    } catch (blobErr) {
      console.warn('[ExportService] Blob download failed, trying data URI:', blobErr);
    }

    // 5. Base64 Data URI fallback (for Android WebViews that block blob URLs)
    try {
      const base64 = uint8ArrayToBase64(u8);
      const dataUri = `data:${mimeType};base64,${base64}`;
      const a = document.createElement('a');
      a.href = dataUri;
      a.download = cleanFileName;
      a.style.display = 'none';
      document.body.appendChild(a);
      a.click();
      setTimeout(() => {
        if (document.body.contains(a)) document.body.removeChild(a);
      }, 2000);
      showExportToast('success', `تم استخراج وتنزيل كشف الإكسل: ${cleanFileName}`);
      return { success: true, method: 'data_uri', fileName: cleanFileName };
    } catch (dataErr) {
      console.error('[ExportService] All automatic export methods failed:', dataErr);
      showExportToast('error', `تعذر تنزيل كشف الإكسل (${cleanFileName}) في هذه البيئة.`);
      return { success: false, method: 'fallback', fileName: cleanFileName, error: dataErr };
    }
  } catch (err) {
    console.error('[ExportService] Fatal error exporting workbook:', err);
    showExportToast('error', 'حدث خطأ أثناء إعداد كشف الإكسل.');
    return { success: false, method: 'fallback', fileName: cleanFileName, error: err };
  }
}

/**
 * Exports arbitrary structured data to an Excel file with optional column widths
 */
export async function exportDataToExcel<T extends Record<string, any>>(
  data: T[],
  fileName: string,
  sheetName = 'البيانات',
  colWidths?: { wch: number }[]
): Promise<ExportResult> {
  const ws = XLSX.utils.json_to_sheet(data);
  if (colWidths && colWidths.length > 0) {
    ws['!cols'] = colWidths;
  }
  const wb = XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(wb, ws, sheetName.slice(0, 31));
  return exportExcelWorkbook(wb, fileName);
}

/**
 * Saves or shares a CSV file with UTF-8 BOM across Web, Android, and Windows platforms
 */
export async function exportCSVContent(
  csvContent: string,
  fileName: string
): Promise<ExportResult> {
  const cleanFileName = fileName.endsWith('.csv') ? fileName : `${fileName}.csv`;
  // Add UTF-8 BOM (\uFEFF) so Excel on Windows and Android renders Arabic letters correctly
  const bom = '\uFEFF';
  const blob = new Blob([bom + csvContent], { type: 'text/csv;charset=utf-8;' });
  const mimeType = 'text/csv;charset=utf-8;';

  const isMobile = /Android|iPhone|iPad|iPod|Mobile/i.test(navigator.userAgent);
  if (isMobile && typeof navigator.share === 'function') {
    try {
      const file = new File([blob], cleanFileName, { type: mimeType });
      if (typeof navigator.canShare === 'function' && navigator.canShare({ files: [file] })) {
        await navigator.share({
          files: [file],
          title: cleanFileName,
          text: `ملف بيانات CSV: ${cleanFileName}`
        });
        showExportToast('success', `تمت مشاركة الملف بنجاح: ${cleanFileName}`);
        return { success: true, method: 'share', fileName: cleanFileName };
      }
    } catch (shareErr: any) {
      if (shareErr.name === 'AbortError') {
        return { success: true, method: 'share', fileName: cleanFileName };
      }
    }
  }

  // Windows File Picker
  if (typeof (window as any).showSaveFilePicker === 'function' && !isMobile) {
    try {
      const handle = await (window as any).showSaveFilePicker({
        suggestedName: cleanFileName,
        types: [{
          description: 'ملف نصي CSV (Comma Separated Values)',
          accept: { 'text/csv': ['.csv'] }
        }]
      });
      const writable = await handle.createWritable();
      await writable.write(blob);
      await writable.close();
      showExportToast('success', `تم حفظ ملف CSV بنجاح: ${cleanFileName}`);
      return { success: true, method: 'save_picker', fileName: cleanFileName };
    } catch (pickerErr: any) {
      if (pickerErr.name === 'AbortError') {
        return { success: true, method: 'save_picker', fileName: cleanFileName };
      }
    }
  }

  // Standard Download
  try {
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = cleanFileName;
    a.style.display = 'none';
    document.body.appendChild(a);
    a.click();
    setTimeout(() => {
      if (document.body.contains(a)) document.body.removeChild(a);
      URL.revokeObjectURL(url);
    }, 4000);
    showExportToast('success', `جاري تنزيل ملف CSV: ${cleanFileName}`);
    return { success: true, method: 'blob_download', fileName: cleanFileName };
  } catch (err) {
    console.error('[ExportService] CSV download failed:', err);
    showExportToast('error', `تعذر تنزيل ملف CSV (${cleanFileName}).`);
    return { success: false, method: 'fallback', fileName: cleanFileName, error: err };
  }
}
