import html2canvas from 'html2canvas';
import { jsPDF } from 'jspdf';

/**
 * Unified Print & Document Preparation Service
 * Designed specifically for multi-environment compatibility:
 * - Web browsers & Google AI Studio Preview
 * - Android (Capacitor / Android WebView)
 * - Windows (Electron / WebView2 / PWA)
 *
 * Guarantees that:
 * 1. Document content, fonts, and images are fully decoded and rendered before printing begins.
 * 2. Report content is never cleared or unmounted prematurely.
 * 3. Fallbacks (Share Sheet, Standalone Document Export) are provided if the platform's WebView disables window.print().
 */

export interface UnifiedPrintOptions {
  element: HTMLElement | null;
  documentTitle?: string;
  orientation?: 'portrait' | 'landscape';
  onBeforePrint?: () => void;
  onAfterPrint?: () => void;
}

export interface UnifiedPrintResult {
  success: boolean;
  method: 'native_print' | 'share_document' | 'file_export' | 'fallback';
  message?: string;
  error?: any;
}

/**
 * Prepares the DOM element for printing:
 * Waits for Arabic web fonts, all image elements, and QR code canvases to be fully decoded.
 */
export async function preparePrintableDocument(target: HTMLElement | null): Promise<boolean> {
  if (!target) return false;

  try {
    // 1. Wait for document fonts to load completely
    if (document.fonts && typeof document.fonts.ready?.then === 'function') {
      try {
        await document.fonts.ready;
      } catch (fontErr) {
        console.warn('[PrintService] Font ready check warning:', fontErr);
      }
    }

    // 2. Wait for all <img> tags inside target to finish decoding
    const images = Array.from(target.querySelectorAll('img'));
    if (images.length > 0) {
      await Promise.all(
        images.map((img) => {
          if (img.complete && img.naturalWidth > 0) return Promise.resolve();
          return new Promise<void>((resolve) => {
            if (typeof img.decode === 'function') {
              img.decode().then(() => resolve()).catch(() => resolve());
            } else {
              img.onload = () => resolve();
              img.onerror = () => resolve();
            }
            // Absolute safety timeout of 1200ms per image to prevent hanging
            setTimeout(resolve, 1200);
          });
        })
      );
    }

    // 3. Small frame pause for CSS reflow and QR code canvases to flush
    await new Promise((r) => requestAnimationFrame(() => setTimeout(r, 60)));

    return true;
  } catch (err) {
    console.warn('[PrintService] Error during document preparation:', err);
    return true; // continue anyway
  }
}

/**
 * Render a report to a real PDF. The report is rasterized after browser layout,
 * which preserves Arabic shaping, RTL layout, logos, tables and CSS styling.
 */
async function renderElementToPdfBlob(
  element: HTMLElement,
  title: string,
  orientation: 'portrait' | 'landscape'
): Promise<Blob> {
  await preparePrintableDocument(element);

  const canvas = await html2canvas(element, {
    backgroundColor: '#ffffff',
    scale: Math.min(2, Math.max(1, window.devicePixelRatio || 1)),
    useCORS: true,
    allowTaint: false,
    logging: false,
    width: Math.max(element.scrollWidth, element.clientWidth),
    height: Math.max(element.scrollHeight, element.clientHeight),
    windowWidth: Math.max(document.documentElement.clientWidth, element.scrollWidth),
    windowHeight: Math.max(document.documentElement.clientHeight, element.scrollHeight),
    scrollX: 0,
    scrollY: 0,
    ignoreElements: (el) => el.matches('button, input, select, textarea, .no-print, .print\\:hidden, [data-no-print]'),
    onclone: (clonedDocument) => {
      const cloned = clonedDocument.querySelector('[data-pdf-export-clone="true"]') as HTMLElement | null;
      if (cloned) {
        cloned.style.maxHeight = 'none';
        cloned.style.height = 'auto';
        cloned.style.overflow = 'visible';
      }
    }
  });

  const isLandscape = orientation === 'landscape';
  const pageWidth = isLandscape ? 297 : 210;
  const pageHeight = isLandscape ? 210 : 297;
  const margin = 8;
  const contentWidth = pageWidth - margin * 2;
  const contentHeight = pageHeight - margin * 2;
  const pdf = new jsPDF({ orientation, unit: 'mm', format: 'a4', compress: true });
  const pixelsPerPage = Math.max(1, Math.floor((canvas.width * contentHeight) / contentWidth));
  let pageIndex = 0;

  for (let y = 0; y < canvas.height; y += pixelsPerPage) {
    const sliceHeight = Math.min(pixelsPerPage, canvas.height - y);
    const pageCanvas = document.createElement('canvas');
    pageCanvas.width = canvas.width;
    pageCanvas.height = sliceHeight;
    const ctx = pageCanvas.getContext('2d');
    if (!ctx) throw new Error('تعذر تجهيز صفحة PDF.');
    ctx.fillStyle = '#ffffff';
    ctx.fillRect(0, 0, pageCanvas.width, pageCanvas.height);
    ctx.drawImage(canvas, 0, y, canvas.width, sliceHeight, 0, 0, canvas.width, sliceHeight);

    if (pageIndex > 0) pdf.addPage('a4', orientation);
    const imageHeightMm = (sliceHeight * contentWidth) / canvas.width;
    pdf.addImage(pageCanvas.toDataURL('image/jpeg', 0.92), 'JPEG', margin, margin, contentWidth, imageHeightMm, undefined, 'FAST');
    pageIndex++;
    pageCanvas.width = 1;
    pageCanvas.height = 1;
  }

  // Metadata is useful when the saved report is archived or shared.
  pdf.setProperties({ title, subject: 'تقرير إداري', creator: 'نظام إدارة القوة البشرية' });
  return pdf.output('blob');
}

function safePdfFileName(title: string): string {
  const clean = (title || 'تقرير_إداري').replace(/[\\/:*?"<>|]/g, '_').replace(/\.pdf$/i, '').trim();
  return `${clean || 'تقرير_إداري'}.pdf`;
}

async function saveOrSharePdf(blob: Blob, title: string): Promise<'share_document' | 'file_export'> {
  const fileName = safePdfFileName(title);
  const isMobile = /Android|iPhone|iPad|iPod|Mobile/i.test(navigator.userAgent);

  if (isMobile && typeof navigator.share === 'function') {
    try {
      const file = new File([blob], fileName, { type: 'application/pdf' });
      if (typeof navigator.canShare !== 'function' || navigator.canShare({ files: [file] })) {
        await navigator.share({ files: [file], title, text: `تقرير PDF: ${title}` });
        return 'share_document';
      }
    } catch (err: any) {
      if (err?.name === 'AbortError') return 'share_document';
      console.warn('[PrintService] PDF share failed; trying download:', err);
    }
  }

  const url = URL.createObjectURL(blob);
  const anchor = document.createElement('a');
  anchor.href = url;
  anchor.download = fileName;
  anchor.style.display = 'none';
  document.body.appendChild(anchor);
  anchor.click();
  window.setTimeout(() => {
    anchor.remove();
    URL.revokeObjectURL(url);
  }, 15000);
  return 'file_export';
}

/**
 * Creates a real PDF instead of relying on window.print(), which is unavailable
 * or unreliable in some Android WebViews and can produce a blank Windows preview.
 */
export async function executeUnifiedPrint(
  targetOrOptions: HTMLElement | null | UnifiedPrintOptions,
  secondaryOptions?: Omit<UnifiedPrintOptions, 'element'>
): Promise<UnifiedPrintResult> {
  let element: HTMLElement | null = null;
  let documentTitle = 'تقرير عسكري رسمي';
  let orientation: 'portrait' | 'landscape' = 'portrait';
  let onBeforePrint: (() => void) | undefined;
  let onAfterPrint: (() => void) | undefined;

  if (targetOrOptions && 'nodeType' in targetOrOptions) {
    element = targetOrOptions as HTMLElement;
    if (secondaryOptions) {
      documentTitle = secondaryOptions.documentTitle || documentTitle;
      orientation = secondaryOptions.orientation || orientation;
      onBeforePrint = secondaryOptions.onBeforePrint;
      onAfterPrint = secondaryOptions.onAfterPrint;
    }
  } else if (targetOrOptions && typeof targetOrOptions === 'object') {
    const opts = targetOrOptions as UnifiedPrintOptions;
    element = opts.element;
    documentTitle = opts.documentTitle || documentTitle;
    orientation = opts.orientation || orientation;
    onBeforePrint = opts.onBeforePrint;
    onAfterPrint = opts.onAfterPrint;
  }

  if (!element) {
    return { success: false, method: 'fallback', message: 'لم يتم العثور على محتوى المستند المراد حفظه.' };
  }

  try {
    if (onBeforePrint) onBeforePrint();
    element.setAttribute('data-pdf-export-clone', 'true');
    const blob = await renderElementToPdfBlob(element, documentTitle, orientation);
    const method = await saveOrSharePdf(blob, documentTitle);
    if (onAfterPrint) onAfterPrint();
    return {
      success: true,
      method: method === 'share_document' ? 'share_document' : 'file_export',
      message: method === 'share_document'
        ? 'تم إنشاء ملف PDF وفتح خيارات المشاركة أو الحفظ.'
        : `تم إنشاء ملف PDF: ${safePdfFileName(documentTitle)}`
    };
  } catch (error) {
    console.error('[PrintService] PDF generation failed:', error);
    try {
      if (onAfterPrint) onAfterPrint();
    } catch {}
    return {
      success: false,
      method: 'fallback',
      message: 'تعذر إنشاء ملف PDF. تحقق من محتوى التقرير ثم أعد المحاولة.',
      error
    };
  } finally {
    element.removeAttribute('data-pdf-export-clone');
  }
}

/** Create/share/save a PDF report. Kept under the existing name for compatibility. */
export async function shareOrSavePrintableDocument(
  element: HTMLElement | null,
  titleOrOptions: string | { title?: string; filename?: string; orientation?: 'portrait' | 'landscape' },
  orientationParam: 'portrait' | 'landscape' = 'portrait'
): Promise<boolean> {
  if (!element) return false;
  let title = 'وثيقة عسكرية رسمية';
  let orientation = orientationParam;
  if (typeof titleOrOptions === 'string') {
    title = titleOrOptions;
  } else if (titleOrOptions && typeof titleOrOptions === 'object') {
    title = titleOrOptions.title || titleOrOptions.filename?.replace(/\.pdf$/i, '') || title;
    orientation = titleOrOptions.orientation || orientation;
  }
  try {
    const blob = await renderElementToPdfBlob(element, title, orientation);
    await saveOrSharePdf(blob, title);
    return true;
  } catch (error) {
    console.error('[PrintService] Failed to create PDF:', error);
    return false;
  }
}


/** Select the active report near a clicked print button and export it as PDF. */
export async function exportActivePrintableContentToPdf(
  title = 'تقرير إداري',
  sourceElement?: HTMLElement | null,
  orientation: 'portrait' | 'landscape' = 'portrait'
): Promise<boolean> {
  const fromButton = sourceElement
    ? (sourceElement.closest('.printable-modal-card') as HTMLElement | null)
      || (sourceElement.closest('[data-printable-content="true"]') as HTMLElement | null)
      || (sourceElement.closest('.space-y-4') as HTMLElement | null)
      || (sourceElement.closest('section') as HTMLElement | null)
    : null;
  const visibleModal = Array.from(document.querySelectorAll('.printable-modal-card'))
    .find((el) => (el as HTMLElement).getClientRects().length > 0) as HTMLElement | undefined;
  const target = fromButton
    || visibleModal
    || (document.querySelector('[data-printable-content="true"]') as HTMLElement | null)
    || (document.querySelector('main') as HTMLElement | null);
  if (!target) {
    console.error('[PrintService] No visible printable content was found.');
    return false;
  }
  return shareOrSavePrintableDocument(target, { title, orientation });
}
