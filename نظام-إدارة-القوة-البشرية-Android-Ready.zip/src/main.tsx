import {StrictMode} from 'react';
import {createRoot} from 'react-dom/client';
import App from './App.tsx';
import './index.css';
import { registerServiceWorker } from './lib/pwa.ts';
import { ErrorBoundary } from './components/ErrorBoundary.tsx';
import { initSafeStorage } from './lib/safeLocalStorage.ts';

// Ensure any legacy desktop-forced-mode or zoom is reset to standard responsive mobile/web layout
try {
  localStorage.removeItem('military_app_display_mode');
  localStorage.removeItem('military_app_display_zoom');
  if (typeof document !== 'undefined') {
    document.documentElement.classList.remove('desktop-forced-mode');
    document.body?.classList.remove('desktop-forced-mode');
    (document.documentElement.style as any).zoom = '';
    if (document.body) (document.body.style as any).zoom = '';
    const root = document.getElementById('root');
    if (root) {
      root.style.minWidth = '';
      root.style.width = '';
    }
  }
} catch {}

let isMounted = false;

function mountApplication() {
  if (isMounted) return;
  isMounted = true;

  try {
    registerServiceWorker();
  } catch (err) {
    console.warn('[PWA] Service Worker initialization skipped:', err);
  }

  const container = document.getElementById('root');
  if (container) {
    createRoot(container).render(
      <StrictMode>
        <ErrorBoundary>
          <App />
        </ErrorBoundary>
      </StrictMode>,
    );
  }
}

// Do not mount React until local IndexedDB hydration has completed.
// A fixed short timeout can make the app read an empty/default dataset before saved records load.
initSafeStorage()
  .catch((err) => {
    console.error('[Storage] Local database initialization failed:', err);
    return false;
  })
  .finally(() => {
    mountApplication();
  });

