import React, { useState, useEffect } from 'react';
import {
  Trash2,
  Zap,
  ShieldCheck,
  CheckCircle2,
  AlertTriangle,
  RefreshCw,
  HardDrive,
  Activity,
  Layers,
  Sparkles,
  X
} from 'lucide-react';
import { StorageService } from '../lib/storage';
import { getStorageHealth } from '../lib/safeLocalStorage';

interface PurgeReplacedDataModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSuccess: () => void;
  currentPersonnelCount: number;
}

export const PurgeReplacedDataModal: React.FC<PurgeReplacedDataModalProps> = ({
  isOpen,
  onClose,
  onSuccess,
  currentPersonnelCount
}) => {
  const [isProcessing, setIsProcessing] = useState<boolean>(false);
  const [healthInfo, setHealthInfo] = useState<any>(null);
  const [result, setResult] = useState<{
    success: boolean;
    preservedPersonnelCount: number;
    purgedSnapshotsCount: number;
    purgedLocalStorageKeysCount: number;
    reclaimedEstimateKB: number;
    details: string;
  } | null>(null);

  useEffect(() => {
    if (isOpen) {
      setResult(null);
      getStorageHealth().then(setHealthInfo).catch(() => {});
    }
  }, [isOpen]);

  if (!isOpen) return null;

  const handleExecutePurge = async () => {
    setIsProcessing(true);
    try {
      const res = await StorageService.purgeReplacedAndObsoleteData();
      setResult(res);
      const updatedHealth = await getStorageHealth();
      setHealthInfo(updatedHealth);
      onSuccess();
    } catch (err: any) {
      setResult({
        success: false,
        preservedPersonnelCount: currentPersonnelCount,
        purgedSnapshotsCount: 0,
        purgedLocalStorageKeysCount: 0,
        reclaimedEstimateKB: 0,
        details: err?.message || 'حدث خطأ أثناء تنظيف البيانات'
      });
    } finally {
      setIsProcessing(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-md animate-in fade-in select-none">
      <div className="bg-slate-900 border border-slate-700 w-full max-w-xl rounded-3xl shadow-2xl overflow-hidden flex flex-col text-right font-['Cairo',sans-serif]">
        
        {/* Header */}
        <div className="p-6 bg-gradient-to-r from-emerald-950 via-slate-900 to-teal-950 border-b border-emerald-800/60 flex items-center justify-between">
          <div className="flex items-center space-x-3 space-x-reverse">
            <div className="p-3 bg-emerald-500 text-slate-950 rounded-2xl shadow-lg">
              <Zap className="w-6 h-6" />
            </div>
            <div>
              <h3 className="text-lg font-black text-white font-['Tajawal']">
                تنظيف البيانات السابقة والمستبدلة وتسريع المنظومة
              </h3>
              <p className="text-xs text-emerald-300">
                إزالة النسخ القديمة والمفاتيح المؤقتة لضمان التنقل اللحظي بدون أي تجمد
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-2 text-slate-400 hover:text-white rounded-xl hover:bg-slate-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="p-6 space-y-5 max-h-[75vh] overflow-y-auto">
          
          {/* Active Data Safety Shield Card */}
          <div className="p-4 bg-emerald-950/40 border border-emerald-600/50 rounded-2xl flex items-center justify-between">
            <div className="flex items-center space-x-3 space-x-reverse">
              <ShieldCheck className="w-8 h-8 text-emerald-400 shrink-0" />
              <div>
                <div className="font-extrabold text-sm text-emerald-200">
                  حماية وتثبيت السجلات المعتمدة الحالية
                </div>
                <div className="text-xs text-emerald-400/80 mt-0.5">
                  السجلات النشطة الحالية ({currentPersonnelCount} فرد) مؤمنة ومحفوظة بالكامل ولن تتأثر.
                </div>
              </div>
            </div>
            <span className="bg-emerald-500 text-slate-950 font-black text-xs px-3 py-1.5 rounded-xl">
              {currentPersonnelCount} فرد نشط
            </span>
          </div>

          {/* Storage & Replaced Data Stats */}
          <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
            <div className="bg-slate-950 p-3.5 rounded-2xl border border-slate-800 text-center">
              <HardDrive className="w-5 h-5 text-amber-400 mx-auto mb-1.5" />
              <div className="text-[11px] text-slate-400 font-bold">اللقطات المؤرشفة</div>
              <div className="text-base font-black text-white font-mono mt-0.5">
                {healthInfo ? `${healthInfo.hasSnapshots} لقطات` : '...'}
              </div>
            </div>

            <div className="bg-slate-950 p-3.5 rounded-2xl border border-slate-800 text-center">
              <Layers className="w-5 h-5 text-teal-400 mx-auto mb-1.5" />
              <div className="text-[11px] text-slate-400 font-bold">حالة التخزين الدائم</div>
              <div className="text-base font-black text-emerald-400 mt-0.5">
                {healthInfo?.persisted ? 'مؤمن ودائم' : 'نشط'}
              </div>
            </div>

            <div className="bg-slate-950 p-3.5 rounded-2xl border border-slate-800 text-center col-span-2 sm:col-span-1">
              <Activity className="w-5 h-5 text-cyan-400 mx-auto mb-1.5" />
              <div className="text-[11px] text-slate-400 font-bold">استجابة التنقل</div>
              <div className="text-base font-black text-cyan-400 mt-0.5">
                فائقة السرعة ⚡
              </div>
            </div>
          </div>

          {/* Explanation Box */}
          <div className="bg-slate-950/80 border border-slate-800 p-4 rounded-2xl space-y-2 text-xs text-slate-300 leading-relaxed">
            <div className="font-extrabold text-amber-300 flex items-center space-x-1.5 space-x-reverse">
              <Sparkles className="w-4 h-4 text-amber-400" />
              <span>ماذا يقوم به محرك التنظيف والتسريع؟</span>
            </div>
            <ul className="space-y-1.5 text-slate-300 list-disc list-inside">
              <li>حذف اللقطات القديمة والنسخ التجريبية السابقة التي تم استبدالها.</li>
              <li>تنظيف المفاتيح المؤقتة والتجزئات المتراكمة في ذاكرة التخزين المحلية.</li>
              <li>تحرير ذاكرة المتصفح وتقليل استهلاك المعالج لإلغاء أي تجمد عند التنقل بين الأقسام.</li>
              <li>تأمين قاعدة بيانات الـ ({currentPersonnelCount}) فرد وتثبيتها كنسخة رئيسية نقية.</li>
            </ul>
          </div>

          {/* Results Display */}
          {result && (
            <div
              className={`p-4 rounded-2xl border text-xs leading-relaxed animate-in fade-in ${
                result.success
                  ? 'bg-emerald-950/60 border-emerald-500 text-emerald-100'
                  : 'bg-rose-950/60 border-rose-500 text-rose-100'
              }`}
            >
              <div className="flex items-center space-x-2 space-x-reverse font-black text-sm mb-1.5">
                {result.success ? (
                  <CheckCircle2 className="w-5 h-5 text-emerald-400" />
                ) : (
                  <AlertTriangle className="w-5 h-5 text-rose-400" />
                )}
                <span>{result.success ? 'تمت عملية التنظيف والتسريع بنجاح تام!' : 'تنبيه العملية'}</span>
              </div>
              <p>{result.details}</p>
              {result.success && (
                <div className="mt-2.5 pt-2.5 border-t border-emerald-800/80 flex flex-wrap gap-4 text-[11px] font-bold text-emerald-300">
                  <span>✅ السجلات النشطة المثبتة: {result.preservedPersonnelCount} فرد</span>
                  <span>🧹 اللقطات المحذوفة: {result.purgedSnapshotsCount}</span>
                  <span>📦 المفاتيح المنظفة: {result.purgedLocalStorageKeysCount}</span>
                  <span>💾 المساحة المحررة: ~{result.reclaimedEstimateKB} KB</span>
                </div>
              )}
            </div>
          )}

        </div>

        {/* Footer */}
        <div className="p-5 bg-slate-950 border-t border-slate-800 flex items-center justify-between gap-3">
          <button
            type="button"
            onClick={onClose}
            className="px-5 py-2.5 bg-slate-800 hover:bg-slate-700 text-slate-300 font-bold text-xs rounded-xl transition-all cursor-pointer"
          >
            {result ? 'إغلاق النافذة' : 'إلغاء'}
          </button>

          {!result ? (
            <button
              type="button"
              disabled={isProcessing}
              onClick={handleExecutePurge}
              className="flex-1 sm:flex-initial px-6 py-3 bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white font-black text-xs rounded-xl shadow-lg transition-all flex items-center justify-center space-x-2 space-x-reverse cursor-pointer border border-emerald-400/30"
            >
              <RefreshCw className={`w-4 h-4 ${isProcessing ? 'animate-spin' : ''}`} />
              <span>{isProcessing ? 'جارِ تنظيف وتسريع المنظومة...' : 'تنظيف وحذف البيانات المستبدلة وتسريع التنقل الآن 🚀'}</span>
            </button>
          ) : (
            <button
              type="button"
              onClick={() => {
                onClose();
              }}
              className="px-6 py-2.5 bg-emerald-600 hover:bg-emerald-500 text-white font-black text-xs rounded-xl shadow-md transition-all cursor-pointer"
            >
              تم واعتماد الاستقرار ✓
            </button>
          )}
        </div>

      </div>
    </div>
  );
};
