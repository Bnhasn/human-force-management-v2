import React, { useState, useEffect, useMemo } from 'react';
import {
  DollarSign,
  Plus,
  Edit,
  Trash2,
  Printer,
  Search,
  Filter,
  CheckCircle,
  AlertTriangle,
  FileText,
  Building2,
  Calendar,
  Sparkles,
  Shield,
  ArrowRightLeft,
  UserCheck,
  CreditCard,
  Building,
  RefreshCw,
  Lock,
  Layers,
  ChevronDown,
  ChevronLeft,
  ChevronRight,
  HandCoins,
  Gift,
  History,
  FileSpreadsheet,
  ShieldCheck,
  ShieldAlert,
  ArrowRight,
  Wallet,
  Check,
  AlertCircle,
  Landmark,
  X,
  Receipt,
  RotateCcw,
  BadgeCheck,
  Coins
} from 'lucide-react';
import {
  PayrollMonthlyRecord,
  PayrollMonthBatch,
  PersonnelSalaryProfile,
  PayrollDeduction,
  PayrollAllowance,
  DepartmentRole,
  PersonnelRecord,
  FinancialGrantRecord
} from '../types';
import { StorageService } from '../lib/storage';
import { PayrollPrintReportModal } from './PayrollPrintReportModal';
import { ApprovalVoucherModal, VoucherData } from './ApprovalVoucherModal';
import { TargetPersonnelSearchSelect } from './TargetPersonnelSearchSelect';
import { PersonnelAvatar } from './PersonnelAvatar';
import { matchesSearchTokens, matchesPersonnelRecord } from '../lib/searchUtils';

interface PayrollManagementWorkspaceProps {
  currentRole: DepartmentRole;
  currentUserAccountName?: string;
}

export const PayrollManagementWorkspace: React.FC<PayrollManagementWorkspaceProps> = ({
  currentRole,
  currentUserAccountName = 'المستخدم الحالي'
}) => {
  const currentMonthStr = new Date().toISOString().slice(0, 7); // "2026-08"

  // Tab Navigation
  const [activeTab, setActiveTab] = useState<'payroll_sheet' | 'grant_advance' | 'grants_archive'>('payroll_sheet');

  const [selectedMonth, setSelectedMonth] = useState<string>(currentMonthStr);
  const [batch, setBatch] = useState<PayrollMonthBatch | null>(null);
  const [records, setRecords] = useState<PayrollMonthlyRecord[]>([]);
  const [searchTerm, setSearchTerm] = useState<string>('');
  const [unitFilter, setUnitFilter] = useState<string>('الكل');
  const [deductionFilter, setDeductionFilter] = useState<'الكل' | 'مع_خصميات' | 'بدون_خصميات'>('الكل');

  // Pagination state for ultra-fast performance
  const [currentPage, setCurrentPage] = useState<number>(1);
  const PAGE_SIZE = 25;

  // Print Modal state
  const [showPrintModal, setShowPrintModal] = useState<boolean>(false);
  const [selectedIndividualForPrint, setSelectedIndividualForPrint] = useState<PayrollMonthlyRecord | null>(null);

  // Edit Salary Profile Modal state
  const [editingRecord, setEditingRecord] = useState<PayrollMonthlyRecord | null>(null);
  const [editBasicSalary, setEditBasicSalary] = useState<number>(2000);
  const [editBankName, setEditBankName] = useState<string>('');
  const [editBankAccountNumber, setEditBankAccountNumber] = useState<string>('');
  const [editAllowances, setEditAllowances] = useState<PayrollAllowance[]>([]);

  // Custom Deduction Modal state
  const [deductionTargetRecord, setDeductionTargetRecord] = useState<PayrollMonthlyRecord | null>(null);
  const [dedCategory, setDedCategory] = useState<PayrollDeduction['category']>('جزاء مسلكي');
  const [dedReason, setDedReason] = useState<string>('');
  const [dedAmount, setDedAmount] = useState<number>(50);
  const [dedDays, setDedDays] = useState<number>(1);

  // --- Financial Grants / Advances State ---
  const [allPersonnel, setAllPersonnel] = useState<PersonnelRecord[]>([]);
  const [financialGrants, setFinancialGrants] = useState<FinancialGrantRecord[]>([]);
  const [selectedGrantMilitaryId, setSelectedGrantMilitaryId] = useState<string>('');
  const [grantType, setGrantType] = useState<'مساعدة مالية' | 'سلفة مالية'>('مساعدة مالية');
  const [grantAmount, setGrantAmount] = useState<number>(1000);
  const [grantMonth, setGrantMonth] = useState<string>(currentMonthStr);
  const [grantDate, setGrantDate] = useState<string>(new Date().toISOString().split('T')[0]);
  const [grantReason, setGrantReason] = useState<string>('');
  const [grantNotes, setGrantNotes] = useState<string>('');
  const [grantSubmitting, setGrantSubmitting] = useState<boolean>(false);
  const [grantFilterType, setGrantFilterType] = useState<'الكل' | 'مساعدة مالية' | 'سلفة مالية'>('الكل');
  const [grantSearchQuery, setGrantSearchQuery] = useState<string>('');

  // Official Approval Voucher Modal State
  const [voucherData, setVoucherData] = useState<VoucherData | null>(null);
  const [isVoucherOpen, setIsVoucherOpen] = useState<boolean>(false);

  // Load / Refresh Payroll Data for selectedMonth & personnel
  const refreshPayrollData = () => {
    // 1. Process automatic leave expiry transitions and 30-day desertion promotions
    StorageService.checkAndProcessAutoStatusTransitions();

    // 2. Synchronize all daily absence / desertion deductions for this month
    StorageService.syncAllAbsencePayrollDeductions(selectedMonth);

    const list = StorageService.getPersonnel();
    setAllPersonnel(list);

    // Perform auto-sync to eliminate orphan/default records and force 100% 1-to-1 matching with active personnel
    const syncRes = StorageService.syncPayrollWithPersonnel(selectedMonth);
    let monthRecords = syncRes.syncedRecords;

    let batches = StorageService.getPayrollBatches();
    let curBatch = batches.find((b) => b.monthYear === selectedMonth);

    if (!curBatch) {
      const gen = StorageService.generateMonthlyPayrollBatch(selectedMonth, currentUserAccountName);
      curBatch = gen.batch;
      monthRecords = gen.records;
    }

    setBatch(curBatch || null);
    setRecords(monthRecords);
    setFinancialGrants(StorageService.getFinancialGrants());
  };

  useEffect(() => {
    refreshPayrollData();
  }, [selectedMonth]);

  // Reset pagination when search or filters change
  useEffect(() => {
    setCurrentPage(1);
  }, [searchTerm, unitFilter, deductionFilter, selectedMonth]);

  // Compute Units List for Filter
  const unitsList = useMemo(() => {
    const units = Array.from(new Set(records.map((r) => r.unit))).filter(Boolean);
    return ['الكل', ...units];
  }, [records]);

  // Filtered Records List
  const filteredRecords = useMemo(() => {
    return records.filter((r) => {
      const matchSearch =
        !searchTerm.trim() ||
        matchesSearchTokens([r.fullName, r.militaryId, r.unit, r.rank, r.bankName, r.bankAccountNumber], searchTerm);

      const matchUnit = unitFilter === 'الكل' || r.unit === unitFilter;

      let matchDeduction = true;
      if (deductionFilter === 'مع_خصميات') {
        matchDeduction = r.totalDeductions > 0;
      } else if (deductionFilter === 'بدون_خصميات') {
        matchDeduction = r.totalDeductions === 0;
      }

      return matchSearch && matchUnit && matchDeduction;
    });
  }, [records, searchTerm, unitFilter, deductionFilter]);

  // Paginated Records for quick rendering without lag
  const totalPages = Math.ceil(filteredRecords.length / PAGE_SIZE) || 1;
  const paginatedRecords = useMemo(() => {
    const start = (currentPage - 1) * PAGE_SIZE;
    return filteredRecords.slice(start, start + PAGE_SIZE);
  }, [filteredRecords, currentPage]);

  // Batch Summary Calculations
  const totalBasic = useMemo(() => records.reduce((acc, r) => acc + (r.basicSalary || 0), 0), [records]);
  const totalAllowances = useMemo(() => records.reduce((acc, r) => acc + (r.totalAllowances || 0), 0), [records]);
  const totalDeductions = useMemo(() => records.reduce((acc, r) => acc + (r.totalDeductions || 0), 0), [records]);
  const totalNetPayout = useMemo(() => records.reduce((acc, r) => acc + (r.netSalary || 0), 0), [records]);

  // Selected Target Personnel for Financial Grant/Advance
  const selectedGrantPerson = useMemo(() => {
    return allPersonnel.find((p) => p.militaryId === selectedGrantMilitaryId);
  }, [allPersonnel, selectedGrantMilitaryId]);

  // Selected Person's Current Payroll Record
  const selectedPersonPayrollRecord = useMemo(() => {
    if (!selectedGrantMilitaryId) return null;
    return records.find((r) => r.militaryId === selectedGrantMilitaryId) || null;
  }, [records, selectedGrantMilitaryId]);

  // Filtered Financial Grants Archive
  const filteredFinancialGrants = useMemo(() => {
    return financialGrants.filter((g) => {
      const matchType = grantFilterType === 'الكل' || g.grantType === grantFilterType;
      const matchQuery =
        !grantSearchQuery.trim() ||
        matchesSearchTokens([g.fullName, g.militaryId, g.unit, g.voucherNumber, g.reason, g.approvedBy, g.notes], grantSearchQuery);
      return matchType && matchQuery;
    });
  }, [financialGrants, grantFilterType, grantSearchQuery]);

  // Grants Summary KPI Calculations
  const totalGrantsAidAmount = useMemo(() => {
    return financialGrants
      .filter((g) => g.grantType === 'مساعدة مالية')
      .reduce((acc, g) => acc + (g.amount || 0), 0);
  }, [financialGrants]);

  const totalGrantsAdvanceAmount = useMemo(() => {
    return financialGrants
      .filter((g) => g.grantType === 'سلفة مالية')
      .reduce((acc, g) => acc + (g.amount || 0), 0);
  }, [financialGrants]);

  // Active Absentees & Deserters currently subject to continuous daily deduction
  const activeAbsenteesList = useMemo(() => {
    return allPersonnel.filter((p) => ['غياب', 'فرار', 'فرار بالسلاح'].includes(p.currentStatus));
  }, [allPersonnel]);

  // Total absence deductions for the current selected month
  const totalAbsenceDeductionsForMonth = useMemo(() => {
    return records.reduce((acc, r) => {
      const absDeds = (r.deductions || []).filter((d) => d.autoGenerated && d.category === 'غياب / فرار');
      return acc + absDeds.reduce((dAcc, d) => dAcc + (d.amount || 0), 0);
    }, 0);
  }, [records]);

  // Handle Regenerate Batch & Re-sync with Personnel
  const handleRegenerateBatch = () => {
    StorageService.checkAndProcessAutoStatusTransitions();
    StorageService.syncAllAbsencePayrollDeductions(selectedMonth);
    StorageService.syncPayrollWithPersonnel(selectedMonth);
    const gen = StorageService.generateMonthlyPayrollBatch(selectedMonth, currentUserAccountName);
    setBatch(gen.batch);
    setRecords(gen.records);
  };

  // Open Edit Salary Profile Modal
  const handleOpenEditSalary = (rec: PayrollMonthlyRecord) => {
    setEditingRecord(rec);
    setEditBasicSalary(rec.basicSalary);
    setEditBankName(rec.bankName || '');
    setEditBankAccountNumber(rec.bankAccountNumber || '');
    setEditAllowances([...rec.allowances]);
  };

  // Save Salary Profile
  const handleSaveSalaryProfile = (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingRecord) return;

    // Save profile
    const profile: PersonnelSalaryProfile = {
      militaryId: editingRecord.militaryId,
      basicSalary: editBasicSalary,
      allowances: editAllowances,
      bankName: editBankName,
      bankAccountNumber: editBankAccountNumber,
      salaryStatus: 'نشط'
    };
    StorageService.saveOrUpdateSalaryProfile(profile);

    // Update current monthly record
    const updatedRec: PayrollMonthlyRecord = {
      ...editingRecord,
      basicSalary: editBasicSalary,
      allowances: editAllowances,
      bankName: editBankName,
      bankAccountNumber: editBankAccountNumber
    };
    StorageService.updatePayrollRecord(updatedRec, currentUserAccountName);

    setEditingRecord(null);
    refreshPayrollData();
  };

  // Add Allowance Row
  const handleAddAllowanceRow = () => {
    setEditAllowances([
      ...editAllowances,
      { id: `alw-${Date.now()}`, title: '', amount: 0 }
    ]);
  };

  // Remove Allowance Row
  const handleRemoveAllowanceRow = (id: string) => {
    setEditAllowances(editAllowances.filter((a) => a.id !== id));
  };

  // Open Custom Deduction Modal
  const handleOpenAddDeduction = (rec: PayrollMonthlyRecord) => {
    setDeductionTargetRecord(rec);
    setDedCategory('غياب / فرار');
    setDedReason('');
    const dailyWage = Math.max(1, Math.round(rec.basicSalary / 30));
    setDedAmount(dailyWage);
    setDedDays(1);
  };

  // Save Custom Deduction
  const handleSaveCustomDeduction = (e: React.FormEvent) => {
    e.preventDefault();
    if (!deductionTargetRecord) return;

    const newDeduction: PayrollDeduction = {
      id: `ded-custom-${Date.now()}`,
      category: dedCategory,
      reason: dedReason.trim() || `استقطاع (${dedCategory})`,
      amount: dedAmount,
      daysCount: dedDays > 0 ? dedDays : undefined,
      date: new Date().toISOString().split('T')[0],
      autoGenerated: false
    };

    const updatedDeductions = [...deductionTargetRecord.deductions, newDeduction];
    const updatedRec: PayrollMonthlyRecord = {
      ...deductionTargetRecord,
      deductions: updatedDeductions
    };

    StorageService.updatePayrollRecord(updatedRec, currentUserAccountName);
    setDeductionTargetRecord(null);
    refreshPayrollData();
  };

  // Delete Individual Deduction
  const handleDeleteDeduction = (rec: PayrollMonthlyRecord, dedId: string) => {
    const updatedDeductions = rec.deductions.filter((d) => d.id !== dedId);
    const updatedRec: PayrollMonthlyRecord = {
      ...rec,
      deductions: updatedDeductions
    };

    StorageService.updatePayrollRecord(updatedRec, currentUserAccountName);
    refreshPayrollData();
  };

  // Update Batch Status (Disburse / Approve)
  const handleBatchStatusChange = (newStatus: 'قيد الإعداد' | 'معتمد' | 'تم صرف الكشف بالكامل') => {
    StorageService.updatePayrollBatchStatus(selectedMonth, newStatus, currentUserAccountName);
    refreshPayrollData();
  };

  // Handle Printing Official Voucher for Grant/Advance
  const handlePrintGrantVoucher = (grant: FinancialGrantRecord) => {
    const person = allPersonnel.find((p) => p.militaryId === grant.militaryId);
    if (!person) return;

    const isAdvance = grant.grantType === 'سلفة مالية';

    const voucher: VoucherData = {
      id: grant.id,
      type: isAdvance ? 'financial_advance' : 'financial_grant',
      title: isAdvance ? 'سند صرف سلفة مالية واحتساب خصم مسير' : 'سند منح مساعدة مالية رسمية (غير مستردة)',
      personnel: person,
      timestamp: grant.createdAt || new Date().toISOString(),
      referenceNumber: grant.voucherNumber,
      department: 'الإدارة المالية',
      approvedBy: grant.approvedBy || currentUserAccountName,
      details: `${grant.grantType}: ${grant.reason} بمبلغ (${grant.amount.toLocaleString('ar-SA')} ر.س)`,
      additionalInfo: [
        { label: 'نوع المعاملة المالية', value: grant.grantType },
        { label: 'المبلغ المعتمد للصرف', value: `${grant.amount.toLocaleString('ar-SA')} ريال سعودي` },
        { label: 'شهر المسير المالي', value: grant.monthYear },
        { label: 'تاريخ الصرف والمنح', value: grant.date },
        {
          label: 'حالة الخصم من المرتب',
          value: isAdvance
            ? `⚠️ سلفة مستقطعة من مرتب شهر (${grant.monthYear})`
            : '✅ مساعدة مالية غير مستردة (لا تُخصم من المرتب)'
        },
        { label: 'المبرر والسبب', value: grant.reason },
        { label: 'الملاحظات والتوجيهات', value: grant.notes || 'معتمد للصرف وفق الضوابط والتعليمات المالية' }
      ]
    };

    setVoucherData(voucher);
    setIsVoucherOpen(true);
  };

  // Submit Financial Grant or Advance
  const handleGrantSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedGrantMilitaryId) {
      alert('يرجى اختيار الفرد المستهدف أولاً!');
      return;
    }
    if (grantAmount <= 0) {
      alert('يرجى إدخال مبلغ مالي صحيح!');
      return;
    }

    setGrantSubmitting(true);
    try {
      const res = StorageService.grantFinancialAidOrAdvance({
        militaryId: selectedGrantMilitaryId,
        grantType,
        amount: grantAmount,
        monthYear: grantMonth || selectedMonth,
        date: grantDate,
        reason: grantReason.trim() || (grantType === 'سلفة مالية' ? 'طلب سلفة مالية مؤقتة' : 'مساعدة مالية استثنائية'),
        notes: grantNotes.trim() || 'معتمد من القيادة المالية',
        actingUser: currentUserAccountName,
        actingDept: 'الإدارة المالية'
      });

      if (res.success && res.record) {
        refreshPayrollData();
        setFinancialGrants(StorageService.getFinancialGrants());
        
        // Print voucher
        handlePrintGrantVoucher(res.record);

        // Reset form inputs (keep selected person or reset reason/amount)
        setGrantReason('');
        setGrantNotes('');
      } else {
        alert(res.message || 'حدث خطأ أثناء معالجة الطلب');
      }
    } catch (err: any) {
      alert(`خطأ: ${err.message || 'تعذر إتمام العملية'}`);
    } finally {
      setGrantSubmitting(false);
    }
  };

  // Cancel or Settle Financial Grant / Advance
  const handleCancelGrant = (grantId: string) => {
    if (!window.confirm('هل أنت متأكد من إلغاء وتسوية هذا السجل؟ إذا كانت سلفة فسيتم إرجاع المبلغ لمرتب الفرد تلقائياً.')) {
      return;
    }
    const res = StorageService.cancelOrDeleteFinancialGrant(grantId, currentUserAccountName);
    if (res.success) {
      refreshPayrollData();
      setFinancialGrants(StorageService.getFinancialGrants());
    }
  };

  return (
    <div className="space-y-6 font-['Cairo',sans-serif] text-right select-none animate-fadeIn pb-12">
      
      {/* Page Workspace Header */}
      <div className="bg-gradient-to-r from-teal-950 via-slate-900 to-slate-950 text-white rounded-3xl p-6 shadow-2xl border border-teal-800/40 relative overflow-hidden">
        <div className="absolute top-0 left-0 w-96 h-96 bg-teal-500/10 rounded-full blur-3xl pointer-events-none"></div>

        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 relative z-10">
          <div className="flex items-center space-x-4 space-x-reverse">
            <div className="w-14 h-14 rounded-2xl bg-teal-500/20 border-2 border-teal-400/50 flex items-center justify-center text-teal-300 shadow-inner">
              <DollarSign className="w-8 h-8" />
            </div>
            <div>
              <div className="flex items-center space-x-2 space-x-reverse">
                <h1 className="font-black text-2xl text-white font-['Tajawal']">
                  نظام مرتبات الأفراد والحسابات المالية 💵
                </h1>
                <span className="bg-teal-500/30 text-teal-300 text-xs px-3 py-1 rounded-full font-bold border border-teal-400/40">
                  الإدارة المالية والقيادة
                </span>
              </div>
              <p className="text-xs text-slate-300 mt-1">
                إدارة مسيرات الرواتب الشهرية، منح المساعدات والسلف المالية المباشرة، واحتساب الاستقطاعات والخصميات آلياً
              </p>
            </div>
          </div>

          {/* Month Picker & Batch Status */}
          <div className="flex items-center gap-3 bg-slate-900/90 p-2.5 rounded-2xl border border-teal-500/30">
            <div className="flex items-center space-x-2 space-x-reverse">
              <Calendar className="w-4 h-4 text-teal-400" />
              <span className="text-xs text-slate-300 font-bold">شهر المرتبات:</span>
            </div>
            <input
              type="month"
              value={selectedMonth}
              onChange={(e) => setSelectedMonth(e.target.value)}
              className="bg-slate-800 text-teal-300 border border-teal-500/40 rounded-xl px-3 py-1.5 text-xs font-mono font-bold outline-hidden focus:border-teal-400 cursor-pointer"
            />

            <button
              onClick={handleRegenerateBatch}
              type="button"
              title="إعادة احتساب وتحديث الخصميات الآلية"
              className="px-3 py-1.5 bg-teal-700 hover:bg-teal-600 text-white rounded-xl text-xs font-black transition-all flex items-center space-x-1 space-x-reverse cursor-pointer shadow-xs"
            >
              <RefreshCw className="w-3.5 h-3.5" />
              <span>تحديث آلي ⚡</span>
            </button>
          </div>
        </div>

        {/* Navigation Tabs Bar */}
        <div className="mt-6 pt-4 border-t border-slate-800 flex flex-wrap items-center justify-between gap-3 relative z-10">
          <div className="flex flex-wrap items-center gap-2">
            
            {/* Tab 1: Payroll Sheet */}
            <button
              type="button"
              onClick={() => setActiveTab('payroll_sheet')}
              className={`px-4 py-2.5 rounded-2xl font-black text-xs transition-all flex items-center space-x-2 space-x-reverse cursor-pointer ${
                activeTab === 'payroll_sheet'
                  ? 'bg-teal-500 text-slate-950 shadow-lg shadow-teal-500/30 scale-102'
                  : 'bg-slate-800/80 text-slate-300 hover:bg-slate-800 hover:text-white border border-slate-700'
              }`}
            >
              <FileSpreadsheet className="w-4 h-4" />
              <span>مسير المرتبات الشهري العام</span>
              <span className={`px-2 py-0.5 rounded-full text-[10px] font-mono font-bold ${
                activeTab === 'payroll_sheet' ? 'bg-slate-900 text-teal-300' : 'bg-slate-700 text-slate-300'
              }`}>
                {records.length} فرد
              </span>
            </button>

            {/* Tab 2: Grant Financial Aid or Advance (Target Feature) */}
            <button
              type="button"
              onClick={() => setActiveTab('grant_advance')}
              className={`px-4 py-2.5 rounded-2xl font-black text-xs transition-all flex items-center space-x-2 space-x-reverse cursor-pointer ${
                activeTab === 'grant_advance'
                  ? 'bg-amber-400 text-slate-950 shadow-lg shadow-amber-400/30 scale-102'
                  : 'bg-slate-800/80 text-amber-300 hover:bg-slate-800 hover:text-amber-200 border border-amber-500/40'
              }`}
            >
              <HandCoins className="w-4 h-4 text-amber-400" />
              <span>منح مساعدة مالية أو سلفة مالية</span>
              <span className="bg-amber-500/20 text-amber-300 border border-amber-400/40 px-2 py-0.5 rounded-full text-[10px] font-bold">
                جديد ⚡
              </span>
            </button>

            {/* Tab 3: Grants & Advances Archive */}
            <button
              type="button"
              onClick={() => setActiveTab('grants_archive')}
              className={`px-4 py-2.5 rounded-2xl font-black text-xs transition-all flex items-center space-x-2 space-x-reverse cursor-pointer ${
                activeTab === 'grants_archive'
                  ? 'bg-teal-500 text-slate-950 shadow-lg shadow-teal-500/30 scale-102'
                  : 'bg-slate-800/80 text-slate-300 hover:bg-slate-800 hover:text-white border border-slate-700'
              }`}
            >
              <History className="w-4 h-4" />
              <span>سجل المساعدات والسلف</span>
              <span className={`px-2 py-0.5 rounded-full text-[10px] font-mono font-bold ${
                activeTab === 'grants_archive' ? 'bg-slate-900 text-teal-300' : 'bg-slate-700 text-slate-300'
              }`}>
                {financialGrants.length}
              </span>
            </button>

          </div>

          {/* Quick Actions for Batch Status & Print */}
          {activeTab === 'payroll_sheet' && (
            <div className="flex items-center gap-2">
              {batch?.status !== 'تم صرف الكشف بالكامل' && (
                <button
                  onClick={() =>
                    handleBatchStatusChange(
                      batch?.status === 'معتمد' ? 'تم صرف الكشف بالكامل' : 'معتمد'
                    )
                  }
                  type="button"
                  className="px-3.5 py-2 bg-emerald-600 hover:bg-emerald-500 text-white rounded-xl font-bold text-xs transition-all flex items-center space-x-1.5 space-x-reverse cursor-pointer shadow-xs"
                >
                  <CheckCircle className="w-3.5 h-3.5" />
                  <span>
                    {batch?.status === 'معتمد' ? 'تأكيد صرف المرتبات بالكامل 💳' : 'اعتماد كشف المسير للصرف ⚖️'}
                  </span>
                </button>
              )}

              <button
                onClick={() => {
                  setSelectedIndividualForPrint(null);
                  setShowPrintModal(true);
                }}
                type="button"
                className="px-3.5 py-2 bg-slate-800 hover:bg-slate-700 text-teal-300 border border-teal-500/40 rounded-xl font-bold text-xs transition-all flex items-center space-x-1.5 space-x-reverse cursor-pointer"
              >
                <Printer className="w-3.5 h-3.5" />
                <span>طباعة كشف المسير الرسمي 🖨️</span>
              </button>
            </div>
          )}
        </div>

      </div>

      {/* ======================================================== */}
      {/* TAB 1: MONTHLY PAYROLL MASTER SHEET                      */}
      {/* ======================================================== */}
      {activeTab === 'payroll_sheet' && (
        <div className="space-y-6">
          
          {/* KPI Financial Statistics Cards */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-4">
            
            {/* Total Force Count */}
            <div className="bg-white border border-slate-200 rounded-2xl p-4 shadow-xs flex items-center justify-between">
              <div>
                <span className="text-[11px] font-bold text-slate-500 block">إجمالي قوة الكشف</span>
                <span className="text-xl font-black text-slate-900 font-mono mt-0.5 block">
                  {records.length} فرد
                </span>
              </div>
              <div className="w-11 h-11 rounded-2xl bg-slate-100 text-slate-700 flex items-center justify-center">
                <Building2 className="w-6 h-6" />
              </div>
            </div>

            {/* Total Basic Salaries */}
            <div className="bg-white border border-slate-200 rounded-2xl p-4 shadow-xs flex items-center justify-between">
              <div>
                <span className="text-[11px] font-bold text-slate-500 block">إجمالي الراتب الأساسي</span>
                <span className="text-lg font-black text-slate-900 font-mono mt-0.5 block">
                  {totalBasic.toLocaleString('ar-SA')} <span className="text-xs text-slate-500">ر.س</span>
                </span>
              </div>
              <div className="w-11 h-11 rounded-2xl bg-blue-50 text-blue-700 flex items-center justify-center border border-blue-200">
                <DollarSign className="w-6 h-6" />
              </div>
            </div>

            {/* Total Allowances */}
            <div className="bg-white border border-slate-200 rounded-2xl p-4 shadow-xs flex items-center justify-between">
              <div>
                <span className="text-[11px] font-bold text-slate-500 block">إجمالي البدلات والمكافآت</span>
                <span className="text-lg font-black text-emerald-800 font-mono mt-0.5 block">
                  +{totalAllowances.toLocaleString('ar-SA')} <span className="text-xs text-emerald-600">ر.س</span>
                </span>
              </div>
              <div className="w-11 h-11 rounded-2xl bg-emerald-50 text-emerald-700 flex items-center justify-center border border-emerald-200">
                <Sparkles className="w-6 h-6" />
              </div>
            </div>

            {/* Total Deductions */}
            <div className="bg-white border border-slate-200 rounded-2xl p-4 shadow-xs flex items-center justify-between">
              <div>
                <span className="text-[11px] font-bold text-rose-700 block">إجمالي الخصميات والجزاءات</span>
                <span className="text-lg font-black text-rose-800 font-mono mt-0.5 block">
                  -{totalDeductions.toLocaleString('ar-SA')} <span className="text-xs text-rose-600">ر.س</span>
                </span>
              </div>
              <div className="w-11 h-11 rounded-2xl bg-rose-50 text-rose-700 flex items-center justify-center border border-rose-200">
                <AlertTriangle className="w-6 h-6" />
              </div>
            </div>

            {/* Total Net Payout */}
            <div className="bg-gradient-to-br from-teal-900 to-slate-900 text-white rounded-2xl p-4 shadow-md flex items-center justify-between border border-teal-700">
              <div>
                <span className="text-[11px] font-extrabold text-teal-300 block">الصافي المعتمد للصرف</span>
                <span className="text-xl font-black text-white font-mono mt-0.5 block">
                  {totalNetPayout.toLocaleString('ar-SA')} <span className="text-xs text-teal-300">ر.س</span>
                </span>
              </div>
              <div className="w-11 h-11 rounded-2xl bg-teal-500/20 text-teal-300 border border-teal-400/40 flex items-center justify-center">
                <CreditCard className="w-6 h-6" />
              </div>
            </div>

          </div>

          {/* Live Automatic Daily Absence & Desertion Deduction Monitoring Banner */}
          <div className="bg-gradient-to-r from-red-950 via-slate-900 to-amber-950 border-2 border-red-500/40 rounded-3xl p-5 shadow-lg text-white">
            <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
              <div className="flex items-start space-x-3 space-x-reverse">
                <div className="w-12 h-12 rounded-2xl bg-red-500/20 border border-red-500/50 flex items-center justify-center text-red-400 shrink-0 shadow-inner">
                  <ShieldAlert className="w-6 h-6 animate-pulse" />
                </div>
                <div>
                  <div className="flex items-center gap-2 flex-wrap">
                    <h3 className="text-sm font-black text-white font-['Tajawal']">
                      نظام الاستقطاع والخصم المالي اليومي للغياب والفرار (مفعل آلياً) ⚡
                    </h3>
                    <span className="bg-red-500/30 text-red-300 text-[10px] font-bold px-2 py-0.5 rounded-full border border-red-500/40">
                      يُحدث يومياً بمعدل أجر اليوم (الراتب ÷ 30)
                    </span>
                  </div>
                  <p className="text-xs text-slate-300 mt-1 leading-relaxed">
                    يتم استقطاع خصم الغياب من مرتب الفرد تلقائياً فور تحويله إلى <strong className="text-red-300">غياب أو فرار أو فرار بالسلاح</strong>، وتتراكم الخصميات يومياً بعد مرور كل يوم كامل حتى يتم تحديث حالته لأي حالة أخرى.
                  </p>
                  <div className="flex flex-wrap items-center gap-3 mt-2.5 text-xs font-mono font-bold">
                    <span className="bg-slate-800/90 text-amber-300 px-3 py-1 rounded-xl border border-amber-500/40 shadow-xs">
                      الأفراد تحت طائلة الاستقطاع حالياً: {activeAbsenteesList.length} فرد
                    </span>
                    <span className="bg-slate-800/90 text-rose-300 px-3 py-1 rounded-xl border border-rose-500/40 shadow-xs">
                      إجمالي مخصومات الغياب والفرار لشهر ({selectedMonth}): -{totalAbsenceDeductionsForMonth.toLocaleString('ar-SA')} ر.س
                    </span>
                  </div>
                </div>
              </div>

              <div className="shrink-0 flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => {
                    const res = StorageService.checkAndProcessAutoStatusTransitions();
                    StorageService.syncAllAbsencePayrollDeductions(selectedMonth);
                    refreshPayrollData();
                    alert(`تم التدقيق الآلي الشامل بنجاح:\n• تحويل إجازات منتهية إلى غياب: ${res.expiredLeavesConverted}\n• تصعيد غياب 30 يوماً إلى فرار: ${res.desertersPromoted}\n• تحديث الاستقطاعات المالية اليومية: ${res.deductionsUpdated}`);
                  }}
                  className="px-4 py-2.5 bg-gradient-to-r from-red-600 to-amber-600 hover:from-red-500 hover:to-amber-500 text-white rounded-xl text-xs font-black shadow-md transition-all flex items-center space-x-1.5 space-x-reverse cursor-pointer active:scale-95"
                >
                  <RefreshCw className="w-4 h-4" />
                  <span>تدقيق وتحديث الاستقطاعات اليومية الآن ⚡</span>
                </button>
              </div>
            </div>
          </div>

          {/* Filter and Search Bar */}
          <div className="bg-white border border-slate-200 rounded-2xl p-4 shadow-xs flex flex-col md:flex-row items-center justify-between gap-4">
            
            {/* Search Input */}
            <div className="relative w-full md:w-80">
              <Search className="w-4 h-4 text-slate-400 absolute top-3 right-3" />
              <input
                type="text"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                placeholder="بحث بالاسم، الرقم العسكري..."
                className="w-full pr-9 pl-3 py-2 bg-slate-50 border border-slate-300 rounded-xl text-xs font-bold text-slate-800 focus:bg-white focus:border-teal-600 outline-hidden transition-colors"
              />
            </div>

            {/* Filters */}
            <div className="flex flex-wrap items-center gap-3 w-full md:w-auto">
              
              {/* Unit Filter */}
              <div className="flex items-center space-x-2 space-x-reverse text-xs">
                <span className="font-bold text-slate-600">الوحدة:</span>
                <select
                  value={unitFilter}
                  onChange={(e) => setUnitFilter(e.target.value)}
                  className="px-3 py-2 bg-slate-50 border border-slate-300 rounded-xl text-xs font-bold text-slate-800 outline-hidden focus:border-teal-600"
                >
                  {unitsList.map((u) => (
                    <option key={u} value={u}>
                      {u}
                    </option>
                  ))}
                </select>
              </div>

              {/* Deduction Filter */}
              <div className="flex items-center space-x-2 space-x-reverse text-xs">
                <span className="font-bold text-slate-600">الخصميات:</span>
                <select
                  value={deductionFilter}
                  onChange={(e) => setDeductionFilter(e.target.value as any)}
                  className="px-3 py-2 bg-slate-50 border border-slate-300 rounded-xl text-xs font-bold text-slate-800 outline-hidden focus:border-teal-600"
                >
                  <option value="الكل">جميع الأفراد</option>
                  <option value="مع_خصميات">أفراد مع خصميات جارية ⚠️</option>
                  <option value="بدون_خصميات">أفراد بدون خصميات (صافي كامل)</option>
                </select>
              </div>

            </div>

          </div>

          {/* Main Personnel Payroll Table */}
          <div className="bg-white border border-slate-200 rounded-2xl shadow-xs overflow-hidden">
            <div className="overflow-x-auto">
              <table className="w-full text-right text-xs border-collapse">
                <thead>
                  <tr className="bg-slate-900 text-white font-extrabold font-['Tajawal'] text-xs">
                    <th className="p-3.5 text-center">#</th>
                    <th className="p-3.5">الفرد والرقم العسكري</th>
                    <th className="p-3.5">الوحدة والكتيبة</th>
                    <th className="p-3.5 text-center">الراتب الأساسي</th>
                    <th className="p-3.5 text-center">البدلات (+)</th>
                    <th className="p-3.5 text-center min-w-[220px]">الخصميات والاستقطاعات (-)</th>
                    <th className="p-3.5 text-center">الصافي المستحق</th>
                    <th className="p-3.5 text-center">الحالة</th>
                    <th className="p-3.5 text-center">الإجراءات والخيارات</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-200">
                  {filteredRecords.length === 0 ? (
                    <tr>
                      <td colSpan={9} className="p-8 text-center text-slate-500 font-bold">
                        لا توجد مرتبات أو بيانات مطابقة للبحث المحدد!
                      </td>
                    </tr>
                  ) : (
                    paginatedRecords.map((r, idx) => (
                      <tr key={r.id} className="hover:bg-slate-50 transition-colors">
                        <td className="p-3 font-mono font-bold text-center text-slate-400">
                          {(currentPage - 1) * PAGE_SIZE + idx + 1}
                        </td>
                        
                        {/* Personnel Info */}
                        <td className="p-3">
                          <div className="font-black text-slate-900 text-xs">
                            {r.rank} / {r.fullName}
                          </div>
                          <div className="text-[11px] font-mono text-teal-800 font-bold mt-0.5">
                            {r.militaryId}
                          </div>
                        </td>

                        {/* Unit & Battalion */}
                        <td className="p-3">
                          <div className="font-bold text-slate-800 text-xs">{r.unit}</div>
                          {r.battalion && <div className="text-[10px] text-slate-500">{r.battalion}</div>}
                        </td>

                        {/* Basic Salary */}
                        <td className="p-3 font-mono font-black text-center text-slate-900 text-xs">
                          {r.basicSalary.toLocaleString('ar-SA')} <span className="text-[10px] text-slate-400">ر.س</span>
                        </td>

                        {/* Allowances */}
                        <td className="p-3 font-mono text-center text-emerald-800 font-black text-xs">
                          +{r.totalAllowances.toLocaleString('ar-SA')} ر.س
                        </td>

                        {/* Deductions Breakdown */}
                        <td className="p-3 text-right">
                          {r.deductions.length === 0 ? (
                            <span className="text-[11px] text-slate-400 font-bold block text-center">— لا توجد خصميات —</span>
                          ) : (
                            <div className="space-y-1.5">
                              {r.deductions.map((d) => (
                                <div
                                  key={d.id}
                                  className={`rounded-lg p-1.5 text-[11px] flex items-center justify-between gap-2 border ${
                                    d.category === 'غياب / فرار'
                                      ? 'bg-red-50/90 border-red-300 shadow-xs'
                                      : 'bg-rose-50 border-rose-200'
                                  }`}
                                >
                                  <div className="space-y-0.5">
                                    <div className="flex items-center gap-1.5 flex-wrap">
                                      <span className="font-black text-rose-900 block">[{d.category}]</span>
                                      {d.category === 'غياب / فرار' && (
                                        <span className="bg-amber-200 text-amber-900 border border-amber-400 text-[9px] px-1.5 py-0.2 rounded font-black">
                                          ⚡ خصم يومي ({d.daysCount || d.days || 1} يوم)
                                        </span>
                                      )}
                                    </div>
                                    <span className="text-[10px] text-rose-800 block leading-tight">{d.reason}</span>
                                  </div>
                                  <div className="flex items-center space-x-1 space-x-reverse shrink-0">
                                    <span className="font-mono font-black text-rose-800">
                                      -{d.amount.toLocaleString('ar-SA')} ر.س
                                    </span>
                                    <button
                                      type="button"
                                      onClick={() => handleDeleteDeduction(r, d.id)}
                                      title="حذف الخصم"
                                      className="p-1 hover:bg-rose-200 rounded text-rose-700 transition-colors cursor-pointer"
                                    >
                                      <Trash2 className="w-3 h-3" />
                                    </button>
                                  </div>
                                </div>
                              ))}
                            </div>
                          )}
                        </td>

                        {/* Net Salary */}
                        <td className="p-3 text-center bg-teal-50/60 border-x border-teal-100">
                          <span className="font-mono font-black text-sm text-teal-900 block">
                            {r.netSalary.toLocaleString('ar-SA')}
                          </span>
                          <span className="text-[10px] text-teal-700 font-bold block">ر.س صافي</span>
                        </td>

                        {/* Status */}
                        <td className="p-3 text-center">
                          <span
                            className={`inline-block px-2.5 py-1 rounded-lg font-black text-[10px] border ${
                              r.status === 'تم الصرف'
                                ? 'bg-emerald-100 text-emerald-900 border-emerald-300'
                                : 'bg-amber-100 text-amber-900 border-amber-300'
                            }`}
                          >
                            {r.status}
                          </span>
                        </td>

                        {/* Actions */}
                        <td className="p-3 text-center space-y-1">
                          <div className="flex items-center justify-center gap-1.5">
                            
                            {/* Custom Deduction Button */}
                            <button
                              type="button"
                              onClick={() => handleOpenAddDeduction(r)}
                              className="px-2.5 py-1 bg-rose-50 hover:bg-rose-100 text-rose-800 border border-rose-300 rounded-lg text-[11px] font-black transition-colors flex items-center space-x-1 space-x-reverse cursor-pointer"
                            >
                              <Plus className="w-3 h-3 text-rose-700" />
                              <span>إضافة خصم ⚠️</span>
                            </button>

                            {/* Edit Salary & Allowances Button */}
                            <button
                              type="button"
                              onClick={() => handleOpenEditSalary(r)}
                              className="px-2.5 py-1 bg-slate-100 hover:bg-slate-200 text-slate-800 border border-slate-300 rounded-lg text-[11px] font-bold transition-colors flex items-center space-x-1 space-x-reverse cursor-pointer"
                            >
                              <Edit className="w-3 h-3 text-slate-600" />
                              <span>الراتب/البدلات</span>
                            </button>

                          </div>

                          <div>
                            {/* Individual Payslip Print Button */}
                            <button
                              type="button"
                              onClick={() => {
                                setSelectedIndividualForPrint(r);
                                setShowPrintModal(true);
                              }}
                              className="w-full py-1 bg-teal-50 hover:bg-teal-100 text-teal-900 border border-teal-300 rounded-lg text-[10px] font-black transition-colors flex items-center justify-center space-x-1 space-x-reverse cursor-pointer"
                            >
                              <Printer className="w-3 h-3 text-teal-700" />
                              <span>قسيمة راتب الفرد 📄</span>
                            </button>
                          </div>
                        </td>

                      </tr>
                    ))
                  )}
                </tbody>
              </table>
            </div>

            {/* Pagination Controls Bar */}
            {filteredRecords.length > 0 && (
              <div className="bg-slate-50 border-t border-slate-200 p-3 flex flex-col sm:flex-row items-center justify-between gap-3 text-xs">
                <div className="font-bold text-slate-600">
                  عرض البيانات: <span className="font-mono text-teal-800">{(currentPage - 1) * PAGE_SIZE + 1}</span> إلى{' '}
                  <span className="font-mono text-teal-800">{Math.min(currentPage * PAGE_SIZE, filteredRecords.length)}</span> من إجمالي{' '}
                  <span className="font-mono text-slate-900 font-extrabold">{filteredRecords.length}</span> فرد
                </div>

                {totalPages > 1 && (
                  <div className="flex items-center space-x-2 space-x-reverse">
                    <button
                      type="button"
                      disabled={currentPage === 1}
                      onClick={() => setCurrentPage((p) => Math.max(1, p - 1))}
                      className="px-3 py-1.5 bg-white border border-slate-300 hover:bg-slate-100 disabled:opacity-40 disabled:hover:bg-white rounded-lg font-bold text-slate-700 flex items-center space-x-1 space-x-reverse transition-colors cursor-pointer"
                    >
                      <ChevronRight className="w-4 h-4" />
                      <span>الصفحة السابقة</span>
                    </button>

                    <div className="px-3 py-1 font-mono font-bold text-slate-800 bg-white border border-slate-200 rounded-lg">
                      {currentPage} / {totalPages}
                    </div>

                    <button
                      type="button"
                      disabled={currentPage === totalPages}
                      onClick={() => setCurrentPage((p) => Math.min(totalPages, p + 1))}
                      className="px-3 py-1.5 bg-white border border-slate-300 hover:bg-slate-100 disabled:opacity-40 disabled:hover:bg-white rounded-lg font-bold text-slate-700 flex items-center space-x-1 space-x-reverse transition-colors cursor-pointer"
                    >
                      <span>الصفحة التالية</span>
                      <ChevronLeft className="w-4 h-4" />
                    </button>
                  </div>
                )}
              </div>
            )}
          </div>

        </div>
      )}

      {/* ======================================================== */}
      {/* TAB 2: GRANT FINANCIAL AID OR SALARY ADVANCE (USER TASK) */}
      {/* ======================================================== */}
      {activeTab === 'grant_advance' && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          
          {/* Right Column: Grant Form */}
          <div className="lg:col-span-8 bg-white border border-slate-200 rounded-3xl p-6 shadow-sm space-y-6">
            
            <div className="border-b border-slate-100 pb-4">
              <div className="flex items-center space-x-3 space-x-reverse">
                <div className="w-10 h-10 rounded-2xl bg-amber-50 border border-amber-200 flex items-center justify-center text-amber-600">
                  <HandCoins className="w-5 h-5" />
                </div>
                <div>
                  <h2 className="text-lg font-black text-slate-900 font-['Tajawal']">
                    نموذج اعتماد منح مساعدة مالية أو سلفة مالية للأفراد
                  </h2>
                  <p className="text-xs text-slate-500 mt-0.5">
                    اختر الفرد وحدد نوع المعاملة المالية (مساعدة غير مستردة أو سلفة يتم استقطاعها فوراً من المرتب)
                  </p>
                </div>
              </div>
            </div>

            <form onSubmit={handleGrantSubmit} className="space-y-6">
              
              {/* Target Personnel Selection */}
              <div>
                <label className="text-xs font-black text-slate-800 block mb-2 font-['Tajawal']">
                  1. اختيار الفرد المستهدف بالمنحة أو السلفة المالية *
                </label>
                <TargetPersonnelSearchSelect
                  personnel={allPersonnel}
                  selectedMilitaryId={selectedGrantMilitaryId}
                  onSelect={(id) => setSelectedGrantMilitaryId(id)}
                  label=""
                  placeholder="ابحث بالاسم، الرقم العسكري، الرتبة، أو الوحدة..."
                />
              </div>

              {/* Grant Type Switcher */}
              <div>
                <label className="text-xs font-black text-slate-800 block mb-2 font-['Tajawal']">
                  2. نوع المعاملة المالية المعتمدة *
                </label>
                
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  
                  {/* Option 1: Financial Aid / Grant (مساعدة مالية - غير مخصومة) */}
                  <div
                    onClick={() => setGrantType('مساعدة مالية')}
                    className={`p-4 rounded-2xl border-2 cursor-pointer transition-all ${
                      grantType === 'مساعدة مالية'
                        ? 'border-emerald-600 bg-emerald-50/50 shadow-md ring-2 ring-emerald-500/20'
                        : 'border-slate-200 bg-slate-50/60 hover:border-slate-300'
                    }`}
                  >
                    <div className="flex items-start justify-between">
                      <div className="flex items-center space-x-2 space-x-reverse">
                        <div className={`w-8 h-8 rounded-xl flex items-center justify-center ${
                          grantType === 'مساعدة مالية' ? 'bg-emerald-600 text-white' : 'bg-slate-200 text-slate-600'
                        }`}>
                          <Gift className="w-4 h-4" />
                        </div>
                        <span className="font-extrabold text-sm text-slate-900 font-['Tajawal']">
                          مساعدة مالية (إعانة) 🎁
                        </span>
                      </div>
                      <span className="px-2.5 py-0.5 rounded-full text-[10px] font-black bg-emerald-100 text-emerald-800 border border-emerald-300">
                        لا تُخصم من المرتب
                      </span>
                    </div>
                    <p className="text-xs text-slate-600 mt-2.5 leading-relaxed">
                      منحة ومكافأة مالية استثنائية (زواج، علاج، أعباء أسرية، تميز). <strong>لا يتم خصمها من مرتب الفرد إطلاقاً</strong> وتُصرف كاملة بدون استقطاع.
                    </p>
                  </div>

                  {/* Option 2: Financial Advance (سلفة مالية - مستقطعة من المرتب) */}
                  <div
                    onClick={() => setGrantType('سلفة مالية')}
                    className={`p-4 rounded-2xl border-2 cursor-pointer transition-all ${
                      grantType === 'سلفة مالية'
                        ? 'border-amber-600 bg-amber-50/50 shadow-md ring-2 ring-amber-500/20'
                        : 'border-slate-200 bg-slate-50/60 hover:border-slate-300'
                    }`}
                  >
                    <div className="flex items-start justify-between">
                      <div className="flex items-center space-x-2 space-x-reverse">
                        <div className={`w-8 h-8 rounded-xl flex items-center justify-center ${
                          grantType === 'سلفة مالية' ? 'bg-amber-600 text-white' : 'bg-slate-200 text-slate-600'
                        }`}>
                          <CreditCard className="w-4 h-4" />
                        </div>
                        <span className="font-extrabold text-sm text-slate-900 font-['Tajawal']">
                          سلفة مالية (تُخصم من المرتب) 💳
                        </span>
                      </div>
                      <span className="px-2.5 py-0.5 rounded-full text-[10px] font-black bg-amber-100 text-amber-800 border border-amber-300">
                        استقطاع وخصم مسير
                      </span>
                    </div>
                    <p className="text-xs text-slate-600 mt-2.5 leading-relaxed">
                      سلفة مالية مؤقتة. <strong>يتم تحديث مرتب الفرد مباشرة</strong> واحتساب المبلغ السلفة ضمن الخصميات في كشف المسير لحظياً.
                    </p>
                  </div>

                </div>
              </div>

              {/* Amount and Month Fields */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                
                {/* Amount Input */}
                <div>
                  <div className="flex items-center justify-between mb-1">
                    <label className="text-xs font-bold text-slate-700">المبلغ المالي المعتمد (ر.س) *</label>
                    <span className="text-[10px] text-slate-400 font-mono">ريال سعودي</span>
                  </div>
                  <input
                    type="number"
                    required
                    min={50}
                    step={50}
                    value={grantAmount}
                    onChange={(e) => setGrantAmount(Math.max(1, Number(e.target.value)))}
                    className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-300 rounded-xl text-base font-mono font-black text-slate-900 focus:bg-white focus:border-teal-600 outline-hidden"
                  />

                  {/* Fast Amount Quick Select Chips */}
                  <div className="flex flex-wrap items-center gap-1.5 mt-2">
                    {[500, 1000, 1500, 2000, 3000, 5000].map((amt) => (
                      <button
                        key={amt}
                        type="button"
                        onClick={() => setGrantAmount(amt)}
                        className={`px-2 py-0.5 rounded-lg text-[10px] font-mono font-bold transition-all ${
                          grantAmount === amt
                            ? 'bg-slate-900 text-white'
                            : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
                        }`}
                      >
                        {amt.toLocaleString('ar-SA')} ر.س
                      </button>
                    ))}
                  </div>
                </div>

                {/* Target Payroll Month or Grant Date */}
                <div>
                  <label className="text-xs font-bold text-slate-700 block mb-1">
                    {grantType === 'سلفة مالية' ? 'شهر المسير للاستقطاع والخصم *' : 'تاريخ الصرف والمنح *'}
                  </label>
                  {grantType === 'سلفة مالية' ? (
                    <input
                      type="month"
                      required
                      value={grantMonth}
                      onChange={(e) => setGrantMonth(e.target.value)}
                      className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-300 rounded-xl text-xs font-mono font-bold text-slate-900 focus:bg-white focus:border-teal-600 outline-hidden"
                    />
                  ) : (
                    <input
                      type="date"
                      required
                      value={grantDate}
                      onChange={(e) => setGrantDate(e.target.value)}
                      className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-300 rounded-xl text-xs font-mono font-bold text-slate-900 focus:bg-white focus:border-teal-600 outline-hidden"
                    />
                  )}
                  <span className="text-[10px] text-slate-400 mt-1 block">
                    {grantType === 'سلفة مالية'
                      ? 'سيتم احتساب الخصم في كشف مسير هذا الشهر مباشرة'
                      : 'تاريخ توثيق المساعدة المالية وسند الصرف'}
                  </span>
                </div>

              </div>

              {/* Reason / Justification */}
              <div>
                <label className="text-xs font-bold text-slate-700 block mb-1">
                  مبرر وسبب {grantType === 'سلفة مالية' ? 'طلب السلفة المالية' : 'منح المساعدة المالية'} *
                </label>
                <input
                  type="text"
                  required
                  value={grantReason}
                  onChange={(e) => setGrantReason(e.target.value)}
                  placeholder={
                    grantType === 'سلفة مالية'
                      ? 'مثال: سلفة طارئة لظروف عائلية / علاج أسري / صيانة مركبة...'
                      : 'مثال: إعانة زواج / مساعدة تكاليف علاج / مكافأة انضباط وتميز ميداني...'
                  }
                  className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-300 rounded-xl text-xs font-bold text-slate-900 focus:bg-white focus:border-teal-600 outline-hidden"
                />

                {/* Predefined Suggestions */}
                <div className="flex flex-wrap gap-1.5 mt-2">
                  {(grantType === 'مساعدة مالية'
                    ? ['إعانة زواج', 'مساعدة علاجية طارئة', 'أعباء وظروف أسرية', 'مكافأة تميز وانضباط', 'تعويض نفقات']
                    : ['سلفة طارئة مؤقتة', 'ظروف عائلية', 'نفقات سفر والتزامات', 'سلفة علاجية']
                  ).map((sug) => (
                    <button
                      key={sug}
                      type="button"
                      onClick={() => setGrantReason(sug)}
                      className="px-2 py-0.5 bg-slate-100 hover:bg-slate-200 text-slate-600 rounded-md text-[10px] font-medium transition-colors"
                    >
                      {sug}
                    </button>
                  ))}
                </div>
              </div>

              {/* Administrative Notes */}
              <div>
                <label className="text-xs font-bold text-slate-700 block mb-1">
                  التوجيه الإداري ورقم أمر الصرف (اختياري)
                </label>
                <input
                  type="text"
                  value={grantNotes}
                  onChange={(e) => setGrantNotes(e.target.value)}
                  placeholder="مثال: بناءً على توجيهات قائد اللواء / موافقة الركن المالي..."
                  className="w-full px-3.5 py-2 bg-slate-50 border border-slate-300 rounded-xl text-xs font-bold text-slate-800 focus:bg-white focus:border-teal-600 outline-hidden"
                />
              </div>

              {/* Submit Button */}
              <div className="pt-4 border-t border-slate-100 flex items-center justify-between">
                <div className="text-xs text-slate-500">
                  {grantType === 'مساعدة مالية' ? (
                    <span className="text-emerald-700 font-bold flex items-center gap-1">
                      <Check className="w-3.5 h-3.5" />
                      سيتم إصدار سند مساعدة معتمد دون المساس بالراتب
                    </span>
                  ) : (
                    <span className="text-amber-700 font-bold flex items-center gap-1">
                      <AlertTriangle className="w-3.5 h-3.5" />
                      سيتم خصم المبلغ وتحديث صافي راتب الفرد في المسير فوراً
                    </span>
                  )}
                </div>

                <button
                  type="submit"
                  disabled={grantSubmitting || !selectedGrantMilitaryId}
                  className={`px-6 py-3 rounded-2xl text-xs font-black transition-all flex items-center space-x-2 space-x-reverse cursor-pointer shadow-lg disabled:opacity-50 disabled:cursor-not-allowed ${
                    grantType === 'مساعدة مالية'
                      ? 'bg-emerald-600 hover:bg-emerald-500 text-white shadow-emerald-600/30'
                      : 'bg-amber-600 hover:bg-amber-500 text-white shadow-amber-600/30'
                  }`}
                >
                  {grantType === 'مساعدة مالية' ? (
                    <>
                      <Gift className="w-4 h-4" />
                      <span>اعتماد وصرف المساعدة المالية (بدون خصم) 🎁</span>
                    </>
                  ) : (
                    <>
                      <CreditCard className="w-4 h-4" />
                      <span>اعتماد وصرف السلفة وتحديث المرتب فوراً 💳⚡</span>
                    </>
                  )}
                </button>
              </div>

            </form>

          </div>

          {/* Left Column: Live Target Financial Status & Simulation Card */}
          <div className="lg:col-span-4 space-y-6">
            
            {/* Selected Personnel Financial Profile */}
            <div className="bg-white border border-slate-200 rounded-3xl p-5 shadow-sm space-y-4">
              <h3 className="text-xs font-black text-slate-800 font-['Tajawal'] flex items-center justify-between border-b border-slate-100 pb-3">
                <span className="flex items-center gap-1.5">
                  <UserCheck className="w-4 h-4 text-teal-600" />
                  الملف المالي للفرد المستهدف
                </span>
                {selectedGrantPerson && (
                  <span className="text-[10px] text-teal-800 bg-teal-50 px-2 py-0.5 rounded-md font-mono font-bold">
                    {selectedGrantPerson.militaryId}
                  </span>
                )}
              </h3>

              {!selectedGrantPerson ? (
                <div className="py-10 text-center text-slate-400 space-y-2">
                  <UserCheck className="w-10 h-10 mx-auto text-slate-300 opacity-60" />
                  <p className="text-xs font-bold">لم يتم اختيار أي فرد بعد</p>
                  <p className="text-[11px] text-slate-400">
                    يرجى اختيار الفرد من القائمة لعرض رصيده المالي ومحاكاة الأثر
                  </p>
                </div>
              ) : (
                <div className="space-y-4 text-xs">
                  
                  {/* Personnel Mini Header */}
                  <div className="flex items-center space-x-3 space-x-reverse bg-slate-50 p-3 rounded-2xl border border-slate-200">
                    <PersonnelAvatar
                      photoUrl={selectedGrantPerson.photoUrl}
                      fullName={selectedGrantPerson.fullName}
                      rank={selectedGrantPerson.rank}
                      militaryId={selectedGrantPerson.militaryId}
                      size="lg"
                      shape="rounded"
                    />
                    <div className="truncate">
                      <div className="font-extrabold text-slate-900 text-xs">
                        {selectedGrantPerson.rank} / {selectedGrantPerson.fullName}
                      </div>
                      <div className="text-[11px] text-slate-500 font-medium mt-0.5">
                        {selectedGrantPerson.unit} {selectedGrantPerson.battalion ? `• ${selectedGrantPerson.battalion}` : ''}
                      </div>
                      <div className="text-[10px] text-teal-800 font-bold mt-0.5">
                        الحالة: {selectedGrantPerson.currentStatus}
                      </div>
                    </div>
                  </div>

                  {/* Current Financial Breakdown */}
                  <div className="space-y-2 pt-1">
                    <div className="flex items-center justify-between p-2 bg-slate-50 rounded-xl">
                      <span className="text-slate-600 font-bold">الراتب الأساسي:</span>
                      <span className="font-mono font-black text-slate-900">
                        {(selectedPersonPayrollRecord?.basicSalary || 2000).toLocaleString('ar-SA')} ر.س
                      </span>
                    </div>

                    <div className="flex items-center justify-between p-2 bg-emerald-50/60 rounded-xl">
                      <span className="text-emerald-800 font-bold">إجمالي البدلات (+):</span>
                      <span className="font-mono font-black text-emerald-800">
                        +{(selectedPersonPayrollRecord?.totalAllowances || 0).toLocaleString('ar-SA')} ر.س
                      </span>
                    </div>

                    <div className="flex items-center justify-between p-2 bg-rose-50/60 rounded-xl">
                      <span className="text-rose-800 font-bold">الخصميات السابقة (-):</span>
                      <span className="font-mono font-black text-rose-800">
                        -{(selectedPersonPayrollRecord?.totalDeductions || 0).toLocaleString('ar-SA')} ر.س
                      </span>
                    </div>

                    <div className="flex items-center justify-between p-2.5 bg-teal-50 border border-teal-200 rounded-xl">
                      <span className="text-teal-900 font-black">الصافي الحالي المعتمد:</span>
                      <span className="font-mono font-black text-sm text-teal-950">
                        {(selectedPersonPayrollRecord?.netSalary || 2000).toLocaleString('ar-SA')} ر.س
                      </span>
                    </div>
                  </div>

                  {/* Bank Info */}
                  {selectedPersonPayrollRecord?.bankName && (
                    <div className="bg-slate-50 p-2.5 rounded-xl border border-slate-200 text-[11px] text-slate-600 flex items-center space-x-2 space-x-reverse">
                      <Landmark className="w-4 h-4 text-slate-400 shrink-0" />
                      <div className="truncate">
                        <span className="font-bold">{selectedPersonPayrollRecord.bankName}</span>
                        {selectedPersonPayrollRecord.bankAccountNumber && (
                          <span className="font-mono text-slate-500 mr-2">
                            ({selectedPersonPayrollRecord.bankAccountNumber})
                          </span>
                        )}
                      </div>
                    </div>
                  )}

                </div>
              )}
            </div>

            {/* Live Financial Impact Simulator */}
            {selectedGrantPerson && (
              <div className="bg-gradient-to-br from-slate-900 to-slate-950 text-white rounded-3xl p-5 shadow-lg border border-slate-800 space-y-4">
                <div className="flex items-center justify-between border-b border-slate-800 pb-3">
                  <span className="text-xs font-black text-teal-300 font-['Tajawal'] flex items-center gap-1.5">
                    <Sparkles className="w-4 h-4 text-teal-400" />
                    حاسبة الأثر المالي على مسير المرتب
                  </span>
                  <span className="text-[10px] font-mono text-slate-400">{grantMonth || selectedMonth}</span>
                </div>

                <div className="space-y-2.5 text-xs">
                  
                  {/* Current Net */}
                  <div className="flex items-center justify-between text-slate-300">
                    <span>صافي المرتب قبل المعاملة:</span>
                    <span className="font-mono font-bold">
                      {(selectedPersonPayrollRecord?.netSalary || 2000).toLocaleString('ar-SA')} ر.س
                    </span>
                  </div>

                  {/* Transaction Impact */}
                  <div className={`flex items-center justify-between p-2 rounded-xl border ${
                    grantType === 'مساعدة مالية'
                      ? 'bg-emerald-500/10 text-emerald-300 border-emerald-500/30'
                      : 'bg-rose-500/10 text-rose-300 border-rose-500/30'
                  }`}>
                    <span className="font-bold">
                      {grantType === 'مساعدة مالية' ? 'مساعدة مالية (لا تُخصم):' : 'سلفة مالية (خصم مستقطع):'}
                    </span>
                    <span className="font-mono font-black">
                      {grantType === 'مساعدة مالية' ? '0 ر.س (بدون خصم)' : `-${grantAmount.toLocaleString('ar-SA')} ر.س`}
                    </span>
                  </div>

                  {/* Calculated Net Result */}
                  <div className="pt-2 border-t border-slate-800 flex items-center justify-between">
                    <span className="text-xs font-black text-white">الصافي المتوقع بعد الاعتماد:</span>
                    <span className="text-lg font-black font-mono text-teal-300">
                      {grantType === 'مساعدة مالية'
                        ? (selectedPersonPayrollRecord?.netSalary || 2000).toLocaleString('ar-SA')
                        : Math.max(0, (selectedPersonPayrollRecord?.netSalary || 2000) - grantAmount).toLocaleString('ar-SA')}
                      <span className="text-xs text-slate-400 mr-1">ر.س</span>
                    </span>
                  </div>

                  {/* Safeguard Alert */}
                  {grantType === 'سلفة مالية' && selectedPersonPayrollRecord && grantAmount > selectedPersonPayrollRecord.netSalary && (
                    <div className="bg-rose-950/80 border border-rose-700 text-rose-300 p-2.5 rounded-xl text-[11px] leading-relaxed flex items-start gap-2">
                      <AlertTriangle className="w-4 h-4 text-rose-400 shrink-0 mt-0.5" />
                      <span>
                        تنبيه: مبلغ السلفة المطلوب ({grantAmount.toLocaleString('ar-SA')} ر.س) يتجاوز صافي مرتب الفرد للشهر المحدد!
                      </span>
                    </div>
                  )}

                </div>
              </div>
            )}

          </div>

        </div>
      )}

      {/* ======================================================== */}
      {/* TAB 3: GRANTS & ADVANCES ARCHIVE & MANAGEMENT           */}
      {/* ======================================================== */}
      {activeTab === 'grants_archive' && (
        <div className="space-y-6">
          
          {/* Archive KPI Summary Cards */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            
            {/* Total Financial Aid (Non-deducted) */}
            <div className="bg-white border border-slate-200 rounded-2xl p-4 shadow-xs flex items-center justify-between">
              <div>
                <span className="text-[11px] font-bold text-slate-500 block">إجمالي المساعدات الممنوحة (غير مستردة)</span>
                <span className="text-lg font-black text-emerald-800 font-mono mt-0.5 block">
                  {totalGrantsAidAmount.toLocaleString('ar-SA')} <span className="text-xs text-emerald-600">ر.س</span>
                </span>
                <span className="text-[10px] text-slate-400 mt-0.5 block font-bold">
                  {financialGrants.filter((g) => g.grantType === 'مساعدة مالية').length} سند مساعدة معتمد
                </span>
              </div>
              <div className="w-11 h-11 rounded-2xl bg-emerald-50 text-emerald-700 flex items-center justify-center border border-emerald-200">
                <Gift className="w-6 h-6" />
              </div>
            </div>

            {/* Total Financial Advances (Deducted from salary) */}
            <div className="bg-white border border-slate-200 rounded-2xl p-4 shadow-xs flex items-center justify-between">
              <div>
                <span className="text-[11px] font-bold text-slate-500 block">إجمالي السلف المالية المستقطعة</span>
                <span className="text-lg font-black text-amber-800 font-mono mt-0.5 block">
                  {totalGrantsAdvanceAmount.toLocaleString('ar-SA')} <span className="text-xs text-amber-600">ر.س</span>
                </span>
                <span className="text-[10px] text-slate-400 mt-0.5 block font-bold">
                  {financialGrants.filter((g) => g.grantType === 'سلفة مالية').length} سلفة مستقطعة من الرواتب
                </span>
              </div>
              <div className="w-11 h-11 rounded-2xl bg-amber-50 text-amber-700 flex items-center justify-center border border-amber-200">
                <CreditCard className="w-6 h-6" />
              </div>
            </div>

            {/* Total Operations Count */}
            <div className="bg-white border border-slate-200 rounded-2xl p-4 shadow-xs flex items-center justify-between">
              <div>
                <span className="text-[11px] font-bold text-slate-500 block">إجمالي القيود والسندات المالية</span>
                <span className="text-lg font-black text-slate-900 font-mono mt-0.5 block">
                  {financialGrants.length} <span className="text-xs text-slate-500">معاملة</span>
                </span>
                <span className="text-[10px] text-slate-400 mt-0.5 block font-bold">
                  موثقة بالسجل المالي الرسمي
                </span>
              </div>
              <div className="w-11 h-11 rounded-2xl bg-slate-100 text-slate-700 flex items-center justify-center">
                <FileText className="w-6 h-6" />
              </div>
            </div>

          </div>

          {/* Filter Bar */}
          <div className="bg-white border border-slate-200 rounded-2xl p-4 shadow-xs flex flex-col md:flex-row items-center justify-between gap-4">
            
            {/* Search Input */}
            <div className="relative w-full md:w-80">
              <Search className="w-4 h-4 text-slate-400 absolute top-3 right-3" />
              <input
                type="text"
                value={grantSearchQuery}
                onChange={(e) => setGrantSearchQuery(e.target.value)}
                placeholder="بحث بالاسم، الرقم العسكري، أو رقم السند..."
                className="w-full pr-9 pl-3 py-2 bg-slate-50 border border-slate-300 rounded-xl text-xs font-bold text-slate-800 focus:bg-white focus:border-teal-600 outline-hidden"
              />
            </div>

            {/* Type Filter */}
            <div className="flex items-center space-x-2 space-x-reverse text-xs">
              <span className="font-bold text-slate-600">نوع المعاملة:</span>
              <select
                value={grantFilterType}
                onChange={(e) => setGrantFilterType(e.target.value as any)}
                className="px-3 py-2 bg-slate-50 border border-slate-300 rounded-xl text-xs font-bold text-slate-800 outline-hidden focus:border-teal-600"
              >
                <option value="الكل">جميع المعاملات (مساعدات وسلف)</option>
                <option value="مساعدة مالية">مساعدات مالية فقط 🎁</option>
                <option value="سلفة مالية">سلف مالية مستقطعة فقط 💳</option>
              </select>
            </div>

          </div>

          {/* Archive Table */}
          <div className="bg-white border border-slate-200 rounded-2xl shadow-xs overflow-hidden">
            <div className="overflow-x-auto">
              <table className="w-full text-right text-xs border-collapse">
                <thead>
                  <tr className="bg-slate-900 text-white font-extrabold font-['Tajawal'] text-xs">
                    <th className="p-3.5 text-center">#</th>
                    <th className="p-3.5">رقم وتاريخ السند</th>
                    <th className="p-3.5">الفرد والرقم العسكري</th>
                    <th className="p-3.5">نوع المعاملة</th>
                    <th className="p-3.5 text-center">المبلغ المعتمد</th>
                    <th className="p-3.5 text-center">شهر المسير / التاريخ</th>
                    <th className="p-3.5">حالة الخصم من المرتب</th>
                    <th className="p-3.5">السبب والتوجيه</th>
                    <th className="p-3.5 text-center">الإجراءات</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-200">
                  {filteredFinancialGrants.length === 0 ? (
                    <tr>
                      <td colSpan={9} className="p-8 text-center text-slate-500 font-bold">
                        لا توجد سجلات مساعدة أو سلفة مالية مطابقة للبحث!
                      </td>
                    </tr>
                  ) : (
                    filteredFinancialGrants.map((g, idx) => (
                      <tr key={g.id} className="hover:bg-slate-50 transition-colors">
                        <td className="p-3 font-mono font-bold text-center text-slate-400">
                          {idx + 1}
                        </td>

                        {/* Voucher Info */}
                        <td className="p-3">
                          <div className="font-mono font-black text-slate-900 text-[11px]">
                            {g.voucherNumber}
                          </div>
                          <div className="text-[10px] text-slate-400 font-mono mt-0.5">
                            {g.date}
                          </div>
                        </td>

                        {/* Personnel Info */}
                        <td className="p-3">
                          <div className="font-black text-slate-900 text-xs">
                            {g.rank} / {g.fullName}
                          </div>
                          <div className="text-[11px] font-mono text-teal-800 font-bold mt-0.5">
                            {g.militaryId} • {g.unit}
                          </div>
                        </td>

                        {/* Grant Type Badge */}
                        <td className="p-3">
                          <span
                            className={`inline-flex items-center gap-1 px-2.5 py-1 rounded-lg font-black text-[10px] border ${
                              g.grantType === 'مساعدة مالية'
                                ? 'bg-emerald-100 text-emerald-900 border-emerald-300'
                                : 'bg-amber-100 text-amber-900 border-amber-300'
                            }`}
                          >
                            {g.grantType === 'مساعدة مالية' ? <Gift className="w-3 h-3" /> : <CreditCard className="w-3 h-3" />}
                            {g.grantType}
                          </span>
                        </td>

                        {/* Amount */}
                        <td className="p-3 font-mono font-black text-center text-slate-900 text-xs">
                          {g.amount.toLocaleString('ar-SA')} <span className="text-[10px] text-slate-400">ر.س</span>
                        </td>

                        {/* Month / Date */}
                        <td className="p-3 font-mono text-center text-slate-700 font-bold text-xs">
                          {g.monthYear || g.date}
                        </td>

                        {/* Salary Deduction Status */}
                        <td className="p-3">
                          {g.isDeductedFromSalary ? (
                            <span className="text-rose-800 bg-rose-50 border border-rose-200 px-2 py-0.5 rounded text-[10px] font-bold">
                              ⚠️ مخصومة من مسير ({g.monthYear})
                            </span>
                          ) : (
                            <span className="text-emerald-800 bg-emerald-50 border border-emerald-200 px-2 py-0.5 rounded text-[10px] font-bold">
                              ✅ مساعدة غير مستردة (بدون خصم)
                            </span>
                          )}
                        </td>

                        {/* Reason / Notes */}
                        <td className="p-3 max-w-[200px]">
                          <div className="font-bold text-slate-800 text-xs truncate" title={g.reason}>
                            {g.reason}
                          </div>
                          {g.notes && (
                            <div className="text-[10px] text-slate-400 truncate" title={g.notes}>
                              {g.notes}
                            </div>
                          )}
                        </td>

                        {/* Actions */}
                        <td className="p-3 text-center">
                          <div className="flex items-center justify-center gap-1.5">
                            
                            {/* Print Official Voucher */}
                            <button
                              type="button"
                              onClick={() => handlePrintGrantVoucher(g)}
                              title="طباعة السند الرسمي"
                              className="p-1.5 bg-teal-50 hover:bg-teal-100 text-teal-800 border border-teal-300 rounded-lg text-xs font-bold transition-colors cursor-pointer"
                            >
                              <Printer className="w-3.5 h-3.5" />
                            </button>

                            {/* Cancel / Settle Grant */}
                            <button
                              type="button"
                              onClick={() => handleCancelGrant(g.id)}
                              title="إلغاء وتسوية المعاملة"
                              className="p-1.5 bg-rose-50 hover:bg-rose-100 text-rose-700 border border-rose-200 rounded-lg text-xs font-bold transition-colors cursor-pointer"
                            >
                              <Trash2 className="w-3.5 h-3.5" />
                            </button>

                          </div>
                        </td>

                      </tr>
                    ))
                  )}
                </tbody>
              </table>
            </div>
          </div>

        </div>
      )}

      {/* Edit Salary & Allowances Modal */}
      {editingRecord && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/70 backdrop-blur-xs font-['Cairo',sans-serif]">
          <div className="bg-white border-2 border-teal-600 rounded-3xl max-w-lg w-full shadow-2xl overflow-hidden text-right animate-fadeIn">
            
            <div className="bg-slate-900 p-4 text-white flex items-center justify-between">
              <div className="flex items-center space-x-2 space-x-reverse">
                <DollarSign className="w-5 h-5 text-teal-400" />
                <h3 className="font-extrabold text-sm text-teal-300">
                  تحديث راتب وبدلات الفرد: {editingRecord.fullName}
                </h3>
              </div>
              <button
                type="button"
                onClick={() => setEditingRecord(null)}
                className="p-1 rounded-lg bg-slate-800 text-slate-300 hover:text-white"
              >
                ✕
              </button>
            </div>

            <form onSubmit={handleSaveSalaryProfile} className="p-5 space-y-4 max-h-[80vh] overflow-y-auto">
              <div>
                <label className="text-xs font-bold text-slate-700 block mb-1">الراتب الأساسي (ريال)</label>
                <input
                  type="number"
                  required
                  min={0}
                  value={editBasicSalary}
                  onChange={(e) => setEditBasicSalary(Number(e.target.value))}
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-xl text-xs font-mono font-black text-slate-900 focus:border-teal-600 outline-hidden"
                />
              </div>

              {/* Allowances Editor */}
              <div className="space-y-2 pt-2 border-t border-slate-200">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-extrabold text-emerald-900">البدلات والعلاوات المعتمدة</span>
                  <button
                    type="button"
                    onClick={handleAddAllowanceRow}
                    className="text-[11px] font-bold text-teal-700 bg-teal-50 px-2.5 py-1 rounded-lg border border-teal-200 hover:bg-teal-100 cursor-pointer"
                  >
                    + إضافة بدل جديد
                  </button>
                </div>

                {editAllowances.map((alw) => (
                  <div key={alw.id} className="flex items-center gap-2">
                    <input
                      type="text"
                      required
                      value={alw.title}
                      onChange={(e) => {
                        const newAlws = editAllowances.map((a) =>
                          a.id === alw.id ? { ...a, title: e.target.value } : a
                        );
                        setEditAllowances(newAlws);
                      }}
                      placeholder="عنوان البدل (مثال: بدل سكن)"
                      className="flex-1 px-3 py-1.5 bg-slate-50 border border-slate-300 rounded-xl text-xs font-bold"
                    />
                    <input
                      type="number"
                      required
                      value={alw.amount}
                      onChange={(e) => {
                        const newAlws = editAllowances.map((a) =>
                          a.id === alw.id ? { ...a, amount: Number(e.target.value) } : a
                        );
                        setEditAllowances(newAlws);
                      }}
                      placeholder="المبلغ"
                      className="w-28 px-3 py-1.5 bg-slate-50 border border-slate-300 rounded-xl text-xs font-mono font-bold"
                    />
                    <button
                      type="button"
                      onClick={() => handleRemoveAllowanceRow(alw.id)}
                      className="p-1 text-rose-600 hover:bg-rose-50 rounded-lg cursor-pointer"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                ))}
              </div>

              {/* Bank Details */}
              <div className="grid grid-cols-2 gap-3 pt-2 border-t border-slate-200">
                <div>
                  <label className="text-xs font-bold text-slate-700 block mb-1">جهة الصرف / البنك</label>
                  <input
                    type="text"
                    value={editBankName}
                    onChange={(e) => setEditBankName(e.target.value)}
                    placeholder="مصرف الكريمي / بنك القطيبي..."
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-xl text-xs font-bold"
                  />
                </div>
                <div>
                  <label className="text-xs font-bold text-slate-700 block mb-1">رقم الحساب / الآيبان</label>
                  <input
                    type="text"
                    value={editBankAccountNumber}
                    onChange={(e) => setEditBankAccountNumber(e.target.value)}
                    placeholder="رقم الحساب..."
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-xl text-xs font-mono font-bold"
                  />
                </div>
              </div>

              <div className="pt-3 border-t border-slate-200 flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setEditingRecord(null)}
                  className="px-4 py-2 bg-slate-100 text-slate-700 rounded-xl text-xs font-bold"
                >
                  إلغاء
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 bg-teal-700 hover:bg-teal-800 text-white rounded-xl text-xs font-black shadow-md"
                >
                  حفظ وتحديث الراتب ⚡
                </button>
              </div>
            </form>

          </div>
        </div>
      )}

      {/* Add Custom Deduction Modal */}
      {deductionTargetRecord && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/70 backdrop-blur-xs font-['Cairo',sans-serif]">
          <div className="bg-white border-2 border-rose-600 rounded-3xl max-w-md w-full shadow-2xl overflow-hidden text-right animate-fadeIn">
            
            <div className="bg-slate-900 p-4 text-white flex items-center justify-between">
              <div className="flex items-center space-x-2 space-x-reverse">
                <AlertTriangle className="w-5 h-5 text-rose-400" />
                <h3 className="font-extrabold text-sm text-rose-300">
                  إضافة خصم / جزاء على الفرد: {deductionTargetRecord.fullName}
                </h3>
              </div>
              <button
                type="button"
                onClick={() => setDeductionTargetRecord(null)}
                className="p-1 rounded-lg bg-slate-800 text-slate-300 hover:text-white"
              >
                ✕
              </button>
            </div>

            <form onSubmit={handleSaveCustomDeduction} className="p-5 space-y-4">
              <div>
                <label className="text-xs font-bold text-slate-700 block mb-1">تصنيف الخصم *</label>
                <select
                  value={dedCategory}
                  onChange={(e) => setDedCategory(e.target.value as any)}
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-xl text-xs font-bold outline-hidden focus:border-rose-600"
                >
                  <option value="غياب / فرار">غياب / فرار عن الخدمة ⚠️</option>
                  <option value="عهدة لم تسلم">عهدة لم تسلم (تسليح / تموين) 🔫</option>
                  <option value="جزاء مسلكي">جزاء مسلكي / عقوبة انضباطية ⚖️</option>
                  <option value="سلفة / استقطاع">سلفة / استقطاع مالي 💵</option>
                  <option value="أخرى">أسباب أخرى 📝</option>
                </select>
              </div>

              <div>
                <label className="text-xs font-bold text-slate-700 block mb-1">سبب الاستقطاع والجزاء *</label>
                <input
                  type="text"
                  required
                  value={dedReason}
                  onChange={(e) => setDedReason(e.target.value)}
                  placeholder="مثال: خصم 3 أيام غياب بدورية الاستطلاع / عدم تسليم الخوذة..."
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-xl text-xs font-bold text-slate-900 outline-hidden focus:border-rose-600"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-xs font-bold text-slate-700 block mb-1">مبلغ الخصم (ريال) *</label>
                  <input
                    type="number"
                    required
                    min={1}
                    value={dedAmount}
                    onChange={(e) => setDedAmount(Number(e.target.value))}
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-xl text-xs font-mono font-black text-rose-800 outline-hidden focus:border-rose-600"
                  />
                </div>
                <div>
                  <label className="text-xs font-bold text-slate-700 block mb-1">عدد الأيام (إن وجد)</label>
                  <input
                    type="number"
                    min={0}
                    max={30}
                    value={dedDays}
                    onChange={(e) => {
                      const days = Math.min(30, Math.max(0, Number(e.target.value)));
                      setDedDays(days);
                      if (dedCategory === 'غياب / فرار' && deductionTargetRecord) {
                        const daily = Math.max(1, Math.round(deductionTargetRecord.basicSalary / 30));
                        setDedAmount(Math.min(deductionTargetRecord.basicSalary, days * daily));
                      }
                    }}
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-300 rounded-xl text-xs font-mono font-bold text-slate-800 outline-hidden"
                  />
                </div>
              </div>

              <div className="pt-3 border-t border-slate-200 flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setDeductionTargetRecord(null)}
                  className="px-4 py-2 bg-slate-100 text-slate-700 rounded-xl text-xs font-bold"
                >
                  إلغاء
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 bg-rose-700 hover:bg-rose-800 text-white rounded-xl text-xs font-black shadow-md"
                >
                  اعتماد خصم المبلغ ⚡
                </button>
              </div>
            </form>

          </div>
        </div>
      )}

      {/* Printable Payroll Ledger / Payslip Modal */}
      <PayrollPrintReportModal
        isOpen={showPrintModal}
        onClose={() => {
          setShowPrintModal(false);
          setSelectedIndividualForPrint(null);
        }}
        batch={batch}
        records={records}
        unitFilter={unitFilter}
        selectedIndividualRecord={selectedIndividualForPrint}
      />

      {/* Official Approval Voucher Modal for Grants & Advances */}
      <ApprovalVoucherModal
        isOpen={isVoucherOpen}
        onClose={() => {
          setIsVoucherOpen(false);
          setVoucherData(null);
        }}
        voucherData={voucherData}
      />

    </div>
  );
};
