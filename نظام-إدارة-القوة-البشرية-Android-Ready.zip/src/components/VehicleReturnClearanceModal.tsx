import React, { useState, useEffect } from 'react';
import { VehicleItem, VehicleReturnClearanceOrder, MilitaryRank } from '../types';
import { StorageService } from '../lib/storage';
import {
  X,
  Save,
  Truck,
  FileText,
  UserCheck,
  Wrench,
  CheckCircle2,
  AlertTriangle,
  ClipboardList,
  Shield,
  Gauge,
  Fuel,
  Info
} from 'lucide-react';

interface VehicleReturnClearanceModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSaveSuccess: (order: VehicleReturnClearanceOrder) => void;
  activeVehicles: VehicleItem[];
  preselectedVehicle?: VehicleItem | null;
  editingOrder?: VehicleReturnClearanceOrder | null;
  currentAccountName?: string;
}

const MILITARY_RANKS: MilitaryRank[] = [
  'جندي',
  'جندي أول',
  'عريف',
  'وكيل رقيب',
  'رقيب',
  'رقيب أول',
  'رئيس رقباء',
  'ملازم',
  'ملازم أول',
  'نقيب',
  'رائد',
  'مقدم',
  'عقيد',
  'عميد',
  'لواء',
  'فريق'
];

const CONDITION_OPTIONS = [
  { value: 'صالحة وجاهزة للخدمة', label: 'صالحة وجاهزة للخدمة (ممتازة)', color: 'text-emerald-400 border-emerald-500/50 bg-emerald-950/30' },
  { value: 'مستعملة بحالة متوسطة', label: 'مستعملة بحالة متوسطة (تعمل)', color: 'text-sky-400 border-sky-500/50 bg-sky-950/30' },
  { value: 'معطلة بحاجة لإصلاح', label: 'معطلة بحاجة لإصلاح جزئي', color: 'text-amber-400 border-amber-500/50 bg-amber-950/30' },
  { value: 'بحاجة لعمرة شاملة', label: 'بحاجة لعمرة شاملة وصيانة كبرى', color: 'text-orange-400 border-orange-500/50 bg-orange-950/30' },
  { value: 'خارجة عن الجاهزية / تالفة', label: 'خارجة عن الجاهزية / تالفة تماماً', color: 'text-rose-400 border-rose-500/50 bg-rose-950/30' }
];

export const VehicleReturnClearanceModal: React.FC<VehicleReturnClearanceModalProps> = ({
  isOpen,
  onClose,
  onSaveSuccess,
  activeVehicles,
  preselectedVehicle = null,
  editingOrder = null,
  currentAccountName = 'مسؤول ركن الفنية والحركة'
}) => {
  const [selectedVehicleId, setSelectedVehicleId] = useState<string>('');
  const [returnNumber, setReturnNumber] = useState<string>('');
  const [returnDate, setReturnDate] = useState<string>('');
  const [returnTime, setReturnTime] = useState<string>('');

  // Vehicle info
  const [vehicleName, setVehicleName] = useState('');
  const [vehicleCategory, setVehicleCategory] = useState('طقم قتالي');
  const [plateNumber, setPlateNumber] = useState('');
  const [engineSerial, setEngineSerial] = useState('');
  const [yearOfModel, setYearOfModel] = useState('');
  const [mileageKmAtReturn, setMileageKmAtReturn] = useState<number>(0);
  const [fuelLevelAtReturn, setFuelLevelAtReturn] = useState('متوسط (1/2)');

  // Handover Person (المسلّم ومخلِي العهدة)
  const [handoverPersonName, setHandoverPersonName] = useState('');
  const [handoverPersonMilitaryId, setHandoverPersonMilitaryId] = useState('');
  const [handoverPersonRank, setHandoverPersonRank] = useState('مساعد أول');
  const [handoverPersonUnit, setHandoverPersonUnit] = useState('');
  const [handoverPersonBattalion, setHandoverPersonBattalion] = useState('');
  const [handoverPersonPhone, setHandoverPersonPhone] = useState('');
  const [handoverPersonNationalId, setHandoverPersonNationalId] = useState('');

  // Receiving Branch & Officer (المستلم في فرع الفنية والحركة المركزي)
  const [recipientBranch, setRecipientBranch] = useState('فرع الفنية والحركة المركزي الرئيسي');
  const [receivingOfficerName, setReceivingOfficerName] = useState('الرائد / خالد بن عبد العزيز السالم');
  const [receivingOfficerRank, setReceivingOfficerRank] = useState('رائد');
  const [receivingOfficerMilitaryId, setReceivingOfficerMilitaryId] = useState('401928');
  const [receivingTechnicianName, setReceivingTechnicianName] = useState('المهندس الفني / بدر الحارثي');
  const [headOfBranchApproval, setHeadOfBranchApproval] = useState('مدير فرع الفنية والحركة المركزي - العميد ركن / مسعد القحطاني');

  // Reason & Authority
  const [returnReason, setReturnReason] = useState('انتهاء المهمة الميدانية وتسليم العهدة للفنية والحركة');
  const [returnAuthority, setReturnAuthority] = useState('توجيهات قيادة اللواء وركن الفنية والحركة');

  // Technical Condition at Handover (حالة العربة وقت تسليمها للفنية والحركة الرئيسي)
  const [conditionAtHandover, setConditionAtHandover] = useState('صالحة وجاهزة للخدمة');
  const [handoverConditionNotes, setHandoverConditionNotes] = useState('');
  const [technicalDefects, setTechnicalDefects] = useState('');

  // Accessories Checklist
  const [spareTire, setSpareTire] = useState(true);
  const [jackAndTools, setJackAndTools] = useState(true);
  const [radioComms, setRadioComms] = useState(true);
  const [fireExtinguisher, setFireExtinguisher] = useState(true);
  const [keysHandedOver, setKeysHandedOver] = useState(true);
  const [registrationDocs, setRegistrationDocs] = useState(true);
  const [otherEquipment, setOtherEquipment] = useState('');

  const [clearanceStatus, setClearanceStatus] = useState<'تم إخلاء العهدة بالكامل' | 'إخلاء عهدة مشروط' | 'قيد الفحص والمطابقة'>('تم إخلاء العهدة بالكامل');
  const [notes, setNotes] = useState('');

  const [errorMessage, setErrorMessage] = useState('');
  const [isSaving, setIsSaving] = useState(false);

  useEffect(() => {
    if (!isOpen) return;

    if (editingOrder) {
      // Load editing data
      setSelectedVehicleId(editingOrder.vehicleId || '');
      setReturnNumber(editingOrder.returnNumber);
      setReturnDate(editingOrder.returnDate);
      setReturnTime(editingOrder.returnTime || '10:00');
      setVehicleName(editingOrder.vehicleName);
      setVehicleCategory(editingOrder.vehicleCategory);
      setPlateNumber(editingOrder.plateNumber);
      setEngineSerial(editingOrder.engineSerial || '');
      setYearOfModel(editingOrder.yearOfModel || '');
      setMileageKmAtReturn(editingOrder.mileageKmAtReturn || 0);
      setFuelLevelAtReturn(editingOrder.fuelLevelAtReturn || 'متوسط (1/2)');

      setHandoverPersonName(editingOrder.handoverPersonName);
      setHandoverPersonMilitaryId(editingOrder.handoverPersonMilitaryId);
      setHandoverPersonRank(editingOrder.handoverPersonRank);
      setHandoverPersonUnit(editingOrder.handoverPersonUnit);
      setHandoverPersonBattalion(editingOrder.handoverPersonBattalion || '');
      setHandoverPersonPhone(editingOrder.handoverPersonPhone || '');
      setHandoverPersonNationalId(editingOrder.handoverPersonNationalId || '');

      setRecipientBranch(editingOrder.recipientBranch || 'فرع الفنية والحركة المركزي الرئيسي');
      setReceivingOfficerName(editingOrder.receivingOfficerName);
      setReceivingOfficerRank(editingOrder.receivingOfficerRank);
      setReceivingOfficerMilitaryId(editingOrder.receivingOfficerMilitaryId || '');
      setReceivingTechnicianName(editingOrder.receivingTechnicianName || '');
      setHeadOfBranchApproval(editingOrder.headOfBranchApproval || '');

      setReturnReason(editingOrder.returnReason);
      setReturnAuthority(editingOrder.returnAuthority);

      setConditionAtHandover(editingOrder.conditionAtHandover);
      setHandoverConditionNotes(editingOrder.handoverConditionNotes);
      setTechnicalDefects(editingOrder.technicalDefects || '');

      if (editingOrder.accessoriesChecklist) {
        setSpareTire(editingOrder.accessoriesChecklist.spareTire);
        setJackAndTools(editingOrder.accessoriesChecklist.jackAndTools);
        setRadioComms(editingOrder.accessoriesChecklist.radioComms);
        setFireExtinguisher(editingOrder.accessoriesChecklist.fireExtinguisher);
        setKeysHandedOver(editingOrder.accessoriesChecklist.keysHandedOver);
        setRegistrationDocs(editingOrder.accessoriesChecklist.registrationDocs);
        setOtherEquipment(editingOrder.accessoriesChecklist.otherEquipment || '');
      }

      setClearanceStatus(editingOrder.clearanceStatus);
      setNotes(editingOrder.notes || '');
    } else {
      // New return voucher
      const randomNum = Math.floor(1000 + Math.random() * 9000);
      setReturnNumber(`RET-${randomNum}/فنية-مركزية`);
      const now = new Date();
      setReturnDate(now.toISOString().split('T')[0]);
      setReturnTime(now.toTimeString().substring(0, 5));

      if (preselectedVehicle) {
        handleSelectVehicle(preselectedVehicle);
      } else {
        setSelectedVehicleId('');
        setVehicleName('');
        setVehicleCategory('طقم قتالي');
        setPlateNumber('');
        setEngineSerial('');
        setYearOfModel('');
        setMileageKmAtReturn(0);
        setHandoverPersonName('');
        setHandoverPersonMilitaryId('');
        setHandoverPersonUnit('');
        setHandoverConditionNotes('');
        setTechnicalDefects('');
      }

      setRecipientBranch('فرع الفنية والحركة المركزي الرئيسي');
      setReceivingOfficerName('الرائد / خالد بن عبد العزيز السالم');
      setReceivingOfficerRank('رائد');
      setReceivingOfficerMilitaryId('401928');
      setReceivingTechnicianName('المهندس الفني / بدر الحارثي');
      setHeadOfBranchApproval('مدير فرع الفنية والحركة المركزي - العميد ركن / مسعد القحطاني');
      setReturnReason('انتهاء المهمة الميدانية وتسليم العهدة لفرع الفنية والحركة');
      setReturnAuthority('توجيهات قيادة اللواء وركن الفنية والحركة رقم (912/ف)');
      setConditionAtHandover('صالحة وجاهزة للخدمة');
      setSpareTire(true);
      setJackAndTools(true);
      setRadioComms(true);
      setFireExtinguisher(true);
      setKeysHandedOver(true);
      setRegistrationDocs(true);
      setOtherEquipment('');
      setClearanceStatus('تم إخلاء العهدة بالكامل');
      setNotes('');
    }
    setErrorMessage('');
  }, [isOpen, editingOrder, preselectedVehicle]);

  const handleSelectVehicle = (veh: VehicleItem) => {
    setSelectedVehicleId(veh.id);
    setVehicleName(veh.name);
    setVehicleCategory(veh.category);
    setPlateNumber(veh.plateNumber);
    setEngineSerial(veh.engineSerial || '');
    setYearOfModel(veh.yearOfModel || '');
    setMileageKmAtReturn(veh.mileageKm || 0);
    setFuelLevelAtReturn(veh.fuelLevel || 'متوسط (1/2)');
    setHandoverPersonName(veh.assignedDriverName || '');
    setHandoverPersonMilitaryId(veh.assignedDriverMilitaryId || '');
    setHandoverPersonUnit(veh.assignedUnit || '');
    
    // Suggest default condition notes based on readiness percentage
    if (veh.readinessPercentage >= 80) {
      setConditionAtHandover('صالحة وجاهزة للخدمة');
      setHandoverConditionNotes(`تم فحص الآلية (${veh.name}) عند تسليمها لفرع الفنية والحركة الرئيسي، المحرك وناقل الحركة بحالة ممتازة، كفاءة الأداء ${veh.readinessPercentage}%، خالية من التهريبات الرئيسية.`);
    } else if (veh.readinessPercentage >= 50) {
      setConditionAtHandover('معطلة بحاجة لإصلاح');
      setHandoverConditionNotes(`تم استلام الآلية بفرع الفنية والحركة المركزي مع وجود نقص في الكفاءة الفنية (${veh.readinessPercentage}%)، تحتاج لفحص المنظومة الميكانيكية وإجراء صيانة.`);
    } else {
      setConditionAtHandover('بحاجة لعمرة شاملة');
      setHandoverConditionNotes(`الآلية بحاجة إلى عمرة وصيانة شاملة وتجديد في ورش فرع الفنية والحركة المركزي، جاهزيتها ${veh.readinessPercentage}%.`);
    }
  };

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMessage('');

    if (!vehicleName.trim()) {
      setErrorMessage('يرجى تحديد أو إدخال اسم الآلية أو المعدة');
      return;
    }
    if (!plateNumber.trim()) {
      setErrorMessage('يرجى إدخال رقم اللوحة أو السيريال العسكري');
      return;
    }
    if (!handoverPersonName.trim()) {
      setErrorMessage('يرجى إدخال اسم المسلّم (مخلِي العهدة)');
      return;
    }
    if (!receivingOfficerName.trim()) {
      setErrorMessage('يرجى إدخال اسم ضابط الاستلام بفرع الفنية والحركة الرئيسي');
      return;
    }
    if (!handoverConditionNotes.trim()) {
      setErrorMessage('يرجى كتابة ملاحظة عن حالة العربة وقت تسليمها إلى فرع الفنية والحركة الرئيسي (مطلب أساسي للسند)');
      return;
    }

    setIsSaving(true);

    try {
      const orderPayload = {
        returnNumber,
        returnDate,
        returnTime,
        vehicleId: selectedVehicleId || undefined,
        vehicleName,
        vehicleCategory,
        plateNumber,
        engineSerial,
        yearOfModel,
        mileageKmAtReturn: Number(mileageKmAtReturn) || 0,
        fuelLevelAtReturn,

        handoverPersonName,
        handoverPersonMilitaryId,
        handoverPersonRank,
        handoverPersonUnit,
        handoverPersonBattalion,
        handoverPersonPhone,
        handoverPersonNationalId,

        recipientBranch,
        receivingOfficerName,
        receivingOfficerRank,
        receivingOfficerMilitaryId,
        receivingTechnicianName,
        headOfBranchApproval,

        returnReason,
        returnAuthority,

        conditionAtHandover,
        handoverConditionNotes,
        technicalDefects,

        accessoriesChecklist: {
          spareTire,
          jackAndTools,
          radioComms,
          fireExtinguisher,
          keysHandedOver,
          registrationDocs,
          otherEquipment
        },

        clearanceStatus,
        notes,
        createdByName: currentAccountName
      };

      if (editingOrder) {
        StorageService.updateVehicleReturnOrder(editingOrder.id, orderPayload, currentAccountName);
        onSaveSuccess({ ...editingOrder, ...orderPayload });
      } else {
        const created = StorageService.addVehicleReturnOrder(orderPayload, currentAccountName);
        onSaveSuccess(created);
      }

      setIsSaving(false);
      onClose();
    } catch (err: any) {
      console.error(err);
      setErrorMessage('حدث خطأ أثناء حفظ سند إخلاء العهدة');
      setIsSaving(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-950/85 backdrop-blur-md flex items-center justify-center p-3 sm:p-4 overflow-y-auto">
      <div className="bg-slate-900 border border-indigo-500/50 rounded-3xl w-full max-w-4xl overflow-hidden shadow-2xl animate-fadeIn my-6">
        {/* Modal Header */}
        <div className="bg-gradient-to-l from-indigo-950 via-slate-900 to-indigo-900 border-b border-indigo-500/40 p-5 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-indigo-500/20 border border-indigo-500/40 flex items-center justify-center text-indigo-400">
              <FileText className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-lg font-black text-white flex items-center gap-2">
                {editingOrder ? 'تعديل سند إخلاء عهدة وملاحظة الإرجاع' : 'تسجيل إرجاع آلية وسند إخلاء عهدة رسمي'}
              </h2>
              <p className="text-xs text-indigo-300 font-semibold mt-0.5">
                إرجاع وتسليم الآلية إلى <strong className="text-white">فرع الفنية والحركة المركزي الرئيسي</strong> وإثبات حالتها الفنية
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="text-slate-400 hover:text-white p-2 rounded-xl bg-slate-800/80 border border-slate-700 cursor-pointer transition-all"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Form Body */}
        <form onSubmit={handleSubmit} className="p-6 space-y-6 max-h-[82vh] overflow-y-auto">
          {errorMessage && (
            <div className="bg-rose-950/60 border border-rose-800 text-rose-300 px-4 py-3 rounded-2xl text-xs flex items-center gap-2">
              <AlertTriangle className="w-4 h-4 flex-shrink-0" />
              <span>{errorMessage}</span>
            </div>
          )}

          {/* SECTION 1: Select Active Vehicle or Enter Details */}
          <div className="bg-slate-950/60 border border-slate-800 p-4 rounded-2xl space-y-4">
            <div className="text-xs font-black text-indigo-400 flex items-center justify-between border-b border-slate-800 pb-2">
              <span className="flex items-center gap-2">
                <Truck className="w-4 h-4" />
                بيانات الآلية / المعدة المراد إرجاعها وإخلاء عهدتها
              </span>
              <span className="text-[11px] text-slate-400 font-normal">
                اختر من الأسطول الحالي أو أدخل البيانات يدوياً
              </span>
            </div>

            {!editingOrder && (
              <div>
                <label className="block text-xs font-bold text-slate-300 mb-1.5">
                  اختيار من العربات المسجلة في الجاهزية (تعبئة تلقائية):
                </label>
                <select
                  value={selectedVehicleId}
                  onChange={(e) => {
                    const found = activeVehicles.find((v) => v.id === e.target.value);
                    if (found) {
                      handleSelectVehicle(found);
                    } else {
                      setSelectedVehicleId('');
                    }
                  }}
                  className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3.5 py-2.5 text-xs text-amber-300 font-bold focus:border-indigo-500 outline-none cursor-pointer"
                >
                  <option value="">-- اختر آلية من الأسطول (أو اكتب البيانات أدناه) --</option>
                  {activeVehicles
                    .filter((v) => v.status !== 'مرجعة للفنية والحركة المركزية')
                    .map((v) => (
                      <option key={v.id} value={v.id}>
                        {v.name} - [اللوحة: {v.plateNumber}] - ({v.status}) - العهدة: {v.assignedDriverName || 'غير معين'}
                      </option>
                    ))}
                </select>
              </div>
            )}

            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-3">
              <div>
                <label className="block text-xs font-bold text-slate-300 mb-1.5">
                  اسم أو طراز الآلية / المعدة <span className="text-rose-400">*</span>
                </label>
                <input
                  type="text"
                  value={vehicleName}
                  onChange={(e) => setVehicleName(e.target.value)}
                  className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-xs text-white focus:border-indigo-500 outline-none"
                  placeholder="مثال: طقم تويوتا شاص قتالي 2024"
                  required
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-300 mb-1.5">
                  رقم اللوحة / السيريال <span className="text-rose-400">*</span>
                </label>
                <input
                  type="text"
                  value={plateNumber}
                  onChange={(e) => setPlateNumber(e.target.value)}
                  className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-xs text-amber-400 font-mono focus:border-indigo-500 outline-none"
                  placeholder="مثال: طقم-1042/عسكري"
                  required
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-300 mb-1.5">
                  فئة الآلية أو المعدة
                </label>
                <input
                  type="text"
                  value={vehicleCategory}
                  onChange={(e) => setVehicleCategory(e.target.value)}
                  className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-xs text-white focus:border-indigo-500 outline-none"
                  placeholder="طقم قتالي، هايلكس، معدة..."
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-300 mb-1.5">
                  رقم المحرك / رقم الشاسي
                </label>
                <input
                  type="text"
                  value={engineSerial}
                  onChange={(e) => setEngineSerial(e.target.value)}
                  className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-xs text-white font-mono focus:border-indigo-500 outline-none"
                  placeholder="ENG-TOY-2024-..."
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-300 mb-1.5">
                  قراءة العداد (كم) أو ساعات التشغيل عند الإرجاع
                </label>
                <div className="relative">
                  <input
                    type="number"
                    value={mileageKmAtReturn}
                    onChange={(e) => setMileageKmAtReturn(Number(e.target.value))}
                    className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-xs text-white focus:border-indigo-500 outline-none pr-8"
                    placeholder="0"
                  />
                  <Gauge className="w-3.5 h-3.5 text-slate-400 absolute left-2.5 top-2.5" />
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-300 mb-1.5">
                  مستوى الوقود وقت التسليم
                </label>
                <div className="relative">
                  <select
                    value={fuelLevelAtReturn}
                    onChange={(e) => setFuelLevelAtReturn(e.target.value)}
                    className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-xs text-white focus:border-indigo-500 outline-none cursor-pointer"
                  >
                    <option value="ممتاز (ممتلئ)">ممتاز (ممتلئ)</option>
                    <option value="جيد (3/4)">جيد (3/4)</option>
                    <option value="متوسط (1/2)">متوسط (1/2)</option>
                    <option value="منخفض (1/4)">منخفض (1/4)</option>
                    <option value="حرج (خالي)">حرج (خالي)</option>
                    <option value="غير مطبق">غير مطبق</option>
                  </select>
                  <Fuel className="w-3.5 h-3.5 text-amber-400 absolute left-2.5 top-2.5 pointer-events-none" />
                </div>
              </div>
            </div>
          </div>

          {/* SECTION 2: Return Voucher Data */}
          <div className="bg-slate-950/60 border border-slate-800 p-4 rounded-2xl space-y-4">
            <div className="text-xs font-black text-indigo-400 flex items-center gap-2 border-b border-slate-800 pb-2">
              <FileText className="w-4 h-4" />
              بيانات سند إخلاء العهدة والسبب
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-3">
              <div>
                <label className="block text-xs font-bold text-slate-300 mb-1.5">
                  رقم سند إخلاء العهدة <span className="text-rose-400">*</span>
                </label>
                <input
                  type="text"
                  value={returnNumber}
                  onChange={(e) => setReturnNumber(e.target.value)}
                  className="w-full bg-slate-900 border border-indigo-500/50 rounded-xl px-3 py-2 text-xs text-amber-400 font-mono font-bold focus:border-indigo-500 outline-none"
                  required
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-300 mb-1.5">
                  تاريخ التسليم والإرجاع <span className="text-rose-400">*</span>
                </label>
                <input
                  type="date"
                  value={returnDate}
                  onChange={(e) => setReturnDate(e.target.value)}
                  className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-xs text-white focus:border-indigo-500 outline-none"
                  required
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-300 mb-1.5">
                  وقت التسليم
                </label>
                <input
                  type="time"
                  value={returnTime}
                  onChange={(e) => setReturnTime(e.target.value)}
                  className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-xs text-white focus:border-indigo-500 outline-none"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-300 mb-1.5">
                  حالة إخلاء العهدة
                </label>
                <select
                  value={clearanceStatus}
                  onChange={(e) => setClearanceStatus(e.target.value as any)}
                  className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-xs text-emerald-400 font-bold focus:border-indigo-500 outline-none cursor-pointer"
                >
                  <option value="تم إخلاء العهدة بالكامل">تم إخلاء العهدة بالكامل وبراءة الذمة</option>
                  <option value="إخلاء عهدة مشروط">إخلاء عهدة مشروط (بانتظار مطابقة نواقص)</option>
                  <option value="قيد الفحص والمطابقة">قيد الفحص الفني والمطابقة</option>
                </select>
              </div>

              <div className="md:col-span-2">
                <label className="block text-xs font-bold text-slate-300 mb-1.5">
                  سبب ومبرر إرجاع الآلية <span className="text-rose-400">*</span>
                </label>
                <input
                  type="text"
                  value={returnReason}
                  onChange={(e) => setReturnReason(e.target.value)}
                  className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-xs text-white focus:border-indigo-500 outline-none"
                  placeholder="انتهاء المهمة، بحاجة لصيانة كبرى، انتهاء التكليف، استبدال..."
                  required
                />
              </div>

              <div className="md:col-span-2">
                <label className="block text-xs font-bold text-slate-300 mb-1.5">
                  الجهة الآمرة بالإرجاع ومصدر التوجيه
                </label>
                <input
                  type="text"
                  value={returnAuthority}
                  onChange={(e) => setReturnAuthority(e.target.value)}
                  className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-xs text-white focus:border-indigo-500 outline-none"
                  placeholder="مثال: برقية عمليات قيادة اللواء رقم (1042/ع) وتوجيهات ركن الفنية"
                />
              </div>
            </div>
          </div>

          {/* SECTION 3: Handover Person (المسلّم ومخلِي العهدة) */}
          <div className="bg-slate-950/60 border border-slate-800 p-4 rounded-2xl space-y-4">
            <div className="text-xs font-black text-amber-400 flex items-center gap-2 border-b border-slate-800 pb-2">
              <UserCheck className="w-4 h-4" />
              بيانات المسلّم (مخلِي العهدة)
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-3">
              <div>
                <label className="block text-xs font-bold text-slate-300 mb-1.5">
                  اسم المسلّم الكامل <span className="text-rose-400">*</span>
                </label>
                <input
                  type="text"
                  value={handoverPersonName}
                  onChange={(e) => setHandoverPersonName(e.target.value)}
                  className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-xs text-white focus:border-indigo-500 outline-none"
                  placeholder="الاسم الرباعي واللقب"
                  required
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-300 mb-1.5">
                  الرقم العسكري للمسلّم <span className="text-rose-400">*</span>
                </label>
                <input
                  type="text"
                  value={handoverPersonMilitaryId}
                  onChange={(e) => setHandoverPersonMilitaryId(e.target.value)}
                  className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-xs text-white font-mono focus:border-indigo-500 outline-none"
                  placeholder="الرقم العسكري"
                  required
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-300 mb-1.5">
                  الرتبة العسكرية
                </label>
                <select
                  value={handoverPersonRank}
                  onChange={(e) => setHandoverPersonRank(e.target.value)}
                  className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-xs text-white focus:border-indigo-500 outline-none cursor-pointer"
                >
                  {MILITARY_RANKS.map((r) => (
                    <option key={r} value={r}>
                      {r}
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-300 mb-1.5">
                  الوحدة / اللواء التابع له
                </label>
                <input
                  type="text"
                  value={handoverPersonUnit}
                  onChange={(e) => setHandoverPersonUnit(e.target.value)}
                  className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-xs text-white focus:border-indigo-500 outline-none"
                  placeholder="مثال: اللواء الأول - كتيبة التدخل"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-300 mb-1.5">
                  رقم الهاتف للتواصل
                </label>
                <input
                  type="text"
                  value={handoverPersonPhone}
                  onChange={(e) => setHandoverPersonPhone(e.target.value)}
                  className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-xs text-white focus:border-indigo-500 outline-none"
                  placeholder="77xxxxxxx"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-300 mb-1.5">
                  الرقم الوطني / البطاقة
                </label>
                <input
                  type="text"
                  value={handoverPersonNationalId}
                  onChange={(e) => setHandoverPersonNationalId(e.target.value)}
                  className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-xs text-white focus:border-indigo-500 outline-none"
                  placeholder="رقم الهوية الوطنية"
                />
              </div>
            </div>
          </div>

          {/* SECTION 4: Receiving Branch & Officers (المستلم في فرع الفنية والحركة المركزي) */}
          <div className="bg-slate-950/60 border border-slate-800 p-4 rounded-2xl space-y-4">
            <div className="text-xs font-black text-indigo-400 flex items-center gap-2 border-b border-slate-800 pb-2">
              <Shield className="w-4 h-4" />
              لجنة الاستلام بفرع الفنية والحركة المركزي الرئيسي
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-3">
              <div>
                <label className="block text-xs font-bold text-slate-300 mb-1.5">
                  جهة وفرع الاستلام <span className="text-rose-400">*</span>
                </label>
                <input
                  type="text"
                  value={recipientBranch}
                  onChange={(e) => setRecipientBranch(e.target.value)}
                  className="w-full bg-slate-900 border border-indigo-500/50 rounded-xl px-3 py-2 text-xs text-indigo-300 font-bold focus:border-indigo-500 outline-none"
                  required
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-300 mb-1.5">
                  اسم ضابط الاستلام بالفنية والحركة <span className="text-rose-400">*</span>
                </label>
                <input
                  type="text"
                  value={receivingOfficerName}
                  onChange={(e) => setReceivingOfficerName(e.target.value)}
                  className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-xs text-white focus:border-indigo-500 outline-none"
                  placeholder="اسم ضابط الاستلام"
                  required
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-300 mb-1.5">
                  رتبة ضابط الاستلام
                </label>
                <select
                  value={receivingOfficerRank}
                  onChange={(e) => setReceivingOfficerRank(e.target.value)}
                  className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-xs text-white focus:border-indigo-500 outline-none cursor-pointer"
                >
                  {MILITARY_RANKS.map((r) => (
                    <option key={r} value={r}>
                      {r}
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-300 mb-1.5">
                  الرقم العسكري لضابط الاستلام
                </label>
                <input
                  type="text"
                  value={receivingOfficerMilitaryId}
                  onChange={(e) => setReceivingOfficerMilitaryId(e.target.value)}
                  className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-xs text-white font-mono focus:border-indigo-500 outline-none"
                  placeholder="الرقم العسكري"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-300 mb-1.5">
                  اسم الفني الفاحص
                </label>
                <input
                  type="text"
                  value={receivingTechnicianName}
                  onChange={(e) => setReceivingTechnicianName(e.target.value)}
                  className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-xs text-white focus:border-indigo-500 outline-none"
                  placeholder="المهندس / الفني المختص بالفحص"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-300 mb-1.5">
                  مصادقة مدير فرع الفنية والحركة
                </label>
                <input
                  type="text"
                  value={headOfBranchApproval}
                  onChange={(e) => setHeadOfBranchApproval(e.target.value)}
                  className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-xs text-white focus:border-indigo-500 outline-none"
                  placeholder="مدير فرع الفنية والحركة المركزي"
                />
              </div>
            </div>
          </div>

          {/* SECTION 5: TECHNICAL CONDITION & NOTES AT HANDOVER (CRITICAL USER REQUIREMENT) */}
          <div className="bg-gradient-to-br from-indigo-950/70 via-slate-950 to-slate-900 border-2 border-indigo-500/70 p-5 rounded-2xl space-y-4 shadow-lg">
            <div className="flex items-center justify-between border-b border-indigo-500/40 pb-3">
              <div className="flex items-center gap-2 text-sm font-black text-indigo-300">
                <Wrench className="w-5 h-5 text-amber-400" />
                <span>حالة العربة والآلية وقت تسليمها إلى فرع الفنية والحركة الرئيسي</span>
              </div>
              <span className="text-[11px] bg-indigo-500/20 text-indigo-300 border border-indigo-500/40 px-3 py-1 rounded-full font-bold">
                مطلب فني إلزامي
              </span>
            </div>

            {/* Condition Radio Selector */}
            <div>
              <label className="block text-xs font-bold text-slate-200 mb-2">
                التقييم الفني العام لحالة العربة وقت التسليم:
              </label>
              <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-2.5">
                {CONDITION_OPTIONS.map((opt) => (
                  <button
                    type="button"
                    key={opt.value}
                    onClick={() => setConditionAtHandover(opt.value)}
                    className={`p-3 rounded-xl border text-right transition-all cursor-pointer flex items-center justify-between ${
                      conditionAtHandover === opt.value
                        ? `${opt.color} ring-2 ring-indigo-500 font-bold shadow-md`
                        : 'bg-slate-900/80 border-slate-800 text-slate-400 hover:border-slate-700'
                    }`}
                  >
                    <span className="text-xs">{opt.label}</span>
                    {conditionAtHandover === opt.value && <CheckCircle2 className="w-4 h-4 text-indigo-400" />}
                  </button>
                ))}
              </div>
            </div>

            {/* Handover Condition Notes Textarea */}
            <div>
              <label className="block text-xs font-bold text-amber-300 mb-1.5 flex items-center gap-2">
                <Info className="w-4 h-4 text-amber-400" />
                <span>ملاحظة تفصيلية عن حالة العربة وقت تسليمها إلى فرع الفنية والحركة الرئيسي:</span>
                <span className="text-rose-400 font-black">*</span>
              </label>
              <textarea
                value={handoverConditionNotes}
                onChange={(e) => setHandoverConditionNotes(e.target.value)}
                rows={4}
                required
                className="w-full bg-slate-900 border border-indigo-500/60 rounded-xl p-3.5 text-xs text-white focus:border-amber-400 focus:ring-1 focus:ring-amber-400 outline-none leading-relaxed resize-none shadow-inner"
                placeholder="اكتب وصفاً فنياً شاملاً لحالة العربة وقت الاستلام في فرع الفنية والحركة: حالة المحرك، ناقل الحركة، البودي الخارجي والدروع، الإطارات، وجود أي تهريبات سوائل، أداء المنظومة الكهربائية، وجاهزيتها الميدانية..."
              />
            </div>

            {/* Technical Defects Observed */}
            <div>
              <label className="block text-xs font-bold text-slate-300 mb-1.5">
                النواقص أو الأعطال المرصودة وقت الاستلام (إن وجدت):
              </label>
              <input
                type="text"
                value={technicalDefects}
                onChange={(e) => setTechnicalDefects(e.target.value)}
                className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-xs text-rose-300 focus:border-rose-500 outline-none"
                placeholder="مثال: تهريب زيت صوفة كرنك، زجاج الباب الأيمن مكسور، عطل في مؤشر السرعة..."
              />
            </div>

            {/* Accessories Checklist */}
            <div className="bg-slate-900/90 border border-slate-800 p-3.5 rounded-xl space-y-2">
              <span className="text-xs font-bold text-slate-300 block mb-1">
                جرد وتدقيق ملحقات وتجهيزات الآلية المستلمة:
              </span>
              <div className="grid grid-cols-2 sm:grid-cols-3 gap-2.5 text-xs">
                <label className="flex items-center gap-2 cursor-pointer text-slate-300 hover:text-white">
                  <input
                    type="checkbox"
                    checked={spareTire}
                    onChange={(e) => setSpareTire(e.target.checked)}
                    className="accent-indigo-500 w-4 h-4 rounded cursor-pointer"
                  />
                  <span>الإطار الاحتياطي (الاستبنة)</span>
                </label>

                <label className="flex items-center gap-2 cursor-pointer text-slate-300 hover:text-white">
                  <input
                    type="checkbox"
                    checked={jackAndTools}
                    onChange={(e) => setJackAndTools(e.target.checked)}
                    className="accent-indigo-500 w-4 h-4 rounded cursor-pointer"
                  />
                  <span>العفريتة ومعدات الطوارئ</span>
                </label>

                <label className="flex items-center gap-2 cursor-pointer text-slate-300 hover:text-white">
                  <input
                    type="checkbox"
                    checked={radioComms}
                    onChange={(e) => setRadioComms(e.target.checked)}
                    className="accent-indigo-500 w-4 h-4 rounded cursor-pointer"
                  />
                  <span>جهاز اللاسلكي والاتصالات</span>
                </label>

                <label className="flex items-center gap-2 cursor-pointer text-slate-300 hover:text-white">
                  <input
                    type="checkbox"
                    checked={fireExtinguisher}
                    onChange={(e) => setFireExtinguisher(e.target.checked)}
                    className="accent-indigo-500 w-4 h-4 rounded cursor-pointer"
                  />
                  <span>طفاية الحريق</span>
                </label>

                <label className="flex items-center gap-2 cursor-pointer text-slate-300 hover:text-white">
                  <input
                    type="checkbox"
                    checked={keysHandedOver}
                    onChange={(e) => setKeysHandedOver(e.target.checked)}
                    className="accent-indigo-500 w-4 h-4 rounded cursor-pointer"
                  />
                  <span>تسليم المفاتيح الأصلية</span>
                </label>

                <label className="flex items-center gap-2 cursor-pointer text-slate-300 hover:text-white">
                  <input
                    type="checkbox"
                    checked={registrationDocs}
                    onChange={(e) => setRegistrationDocs(e.target.checked)}
                    className="accent-indigo-500 w-4 h-4 rounded cursor-pointer"
                  />
                  <span>وثائق وكروت الآلية</span>
                </label>
              </div>

              <div className="pt-2">
                <input
                  type="text"
                  value={otherEquipment}
                  onChange={(e) => setOtherEquipment(e.target.value)}
                  placeholder="تجهيزات أو ملحقات إضافية (مثل: قاعدة سلاح، ونش سحب، مظلة تمويه...)"
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-1.5 text-xs text-white focus:border-indigo-500 outline-none"
                />
              </div>
            </div>
          </div>

          {/* Form Actions */}
          <div className="border-t border-slate-800 pt-4 flex items-center justify-end gap-3">
            <button
              type="button"
              onClick={onClose}
              className="px-5 py-2.5 rounded-2xl bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-bold transition-all cursor-pointer"
            >
              إلغاء
            </button>

            <button
              type="submit"
              disabled={isSaving}
              className="px-6 py-2.5 rounded-2xl bg-gradient-to-r from-indigo-500 to-indigo-600 hover:from-indigo-600 hover:to-indigo-700 text-white font-black text-xs shadow-lg shadow-indigo-500/20 flex items-center gap-2 transition-all cursor-pointer disabled:opacity-50"
            >
              <Save className="w-4 h-4" />
              {isSaving ? 'جارٍ الحفظ...' : editingOrder ? 'تحديث سند إخلاء العهدة' : 'اعتماد وحفظ سند إخلاء العهدة'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
