import React, { useState, useEffect } from 'react';
import { Calendar, Clock, X, Check, FileText, Sparkles, Shield, AlertTriangle } from 'lucide-react';
import { PersonnelRecord } from '../types';

interface StatusDateModalProps {
  isOpen: boolean;
  onClose: () => void;
  personnel: PersonnelRecord | null;
  onConfirm: (militaryId: string, statusDate: string, notes?: string) => void;
}

export const StatusDateModal: React.FC<StatusDateModalProps> = ({
  isOpen,
  onClose,
  personnel,
  onConfirm
}) => {
  const todayStr = new Date().toISOString().split('T')[0];
  const [statusDate, setStatusDate] = useState<string>(todayStr);
  const [notes, setNotes] = useState<string>('');
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (isOpen && personnel) {
      const initialDate =
        personnel.lastStatusChangeDate ||
        personnel.logs?.attendance?.[0]?.startDate ||
        personnel.logs?.attendance?.[0]?.date ||
        todayStr;
      setStatusDate(initialDate);
      setNotes('');
      setError(null);
    }
  }, [isOpen, personnel, todayStr]);

  if (!isOpen || !personnel) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!statusDate) {
      setError('يرجى اختيار أو إدخال تاريخ الحالة.');
      return;
    }
    onConfirm(personnel.militaryId, statusDate, notes.trim() || undefined);
    onClose();
  };

  const handleQuickDaysAgo = (days: number) => {
    const d = new Date();
    d.setDate(d.getDate() - days);
    setStatusDate(d.toISOString().split('T')[0]);
    setError(null);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/70 backdrop-blur-xs font-['Cairo',sans-serif] select-none animate-fadeIn">
      <div className="bg-white border-2 border-emerald-500/40 rounded-3xl max-w-md w-full shadow-2xl overflow-hidden text-right">
        
        {/* Header */}
        <div className="bg-gradient-to-r from-slate-900 via-slate-800 to-slate-900 p-5 text-white flex items-center justify-between">
          <div className="flex items-center space-x-3 space-x-reverse">
            <div className="w-10 h-10 rounded-2xl bg-emerald-500/20 border border-emerald-400 flex items-center justify-center text-emerald-300">
              <Calendar className="w-6 h-6" />
            </div>
            <div>
              <h3 className="font-black text-base text-emerald-300 font-['Tajawal']">
                تحديد وتعديل تاريخ الحالة ({personnel.currentStatus}) 🗓️
              </h3>
              <p className="text-xs text-slate-300">
                توثيق تاريخ بدء أو وقوع الحالة بسجلات التمام والانضباط
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            type="button"
            className="p-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white transition-colors border border-slate-700 cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Form Body */}
        <form onSubmit={handleSubmit} className="p-6 space-y-4">
          
          {/* Target Personnel Badge */}
          <div className="bg-slate-50 border border-slate-200 rounded-2xl p-3.5 flex items-center space-x-3 space-x-reverse">
            <div className="w-11 h-11 rounded-xl bg-emerald-700 text-white flex items-center justify-center font-black text-xs shrink-0 shadow-xs">
              {personnel.rank}
            </div>
            <div className="space-y-0.5 flex-1 min-w-0">
              <div className="font-black text-slate-900 text-sm truncate">
                {personnel.rank} / {personnel.fullName}
              </div>
              <div className="text-xs text-slate-500 flex items-center space-x-2 space-x-reverse">
                <span className="font-mono bg-slate-200 text-slate-800 px-1.5 py-0.5 rounded text-[11px] font-bold">
                  {personnel.militaryId}
                </span>
                <span>•</span>
                <span className="font-bold text-emerald-800 bg-emerald-50 px-2 py-0.5 rounded border border-emerald-200">
                  الحالة: {personnel.currentStatus}
                </span>
              </div>
            </div>
          </div>

          {/* Date Input */}
          <div className="space-y-1.5">
            <label className="text-xs font-black text-slate-800 flex items-center space-x-1.5 space-x-reverse">
              <Clock className="w-3.5 h-3.5 text-emerald-600" />
              <span>تاريخ الحالة المعتمد *</span>
            </label>
            <input
              type="date"
              required
              value={statusDate}
              onChange={(e) => {
                setStatusDate(e.target.value);
                setError(null);
              }}
              className="w-full px-3.5 py-2.5 bg-slate-50 border-2 border-slate-300 focus:border-emerald-600 focus:bg-white rounded-xl text-sm font-bold text-slate-800 outline-hidden transition-colors font-mono"
            />
          </div>

          {/* Quick Preset Buttons */}
          <div className="flex flex-wrap items-center gap-1.5 pt-1">
            <span className="text-[11px] font-bold text-slate-500 ml-1">اختيار سريع:</span>
            <button
              type="button"
              onClick={() => handleQuickDaysAgo(0)}
              className="text-[11px] px-2.5 py-1 rounded-lg font-bold border border-slate-300 hover:border-emerald-500 hover:bg-emerald-50 text-slate-700 transition-colors"
            >
              اليوم
            </button>
            <button
              type="button"
              onClick={() => handleQuickDaysAgo(1)}
              className="text-[11px] px-2.5 py-1 rounded-lg font-bold border border-slate-300 hover:border-emerald-500 hover:bg-emerald-50 text-slate-700 transition-colors"
            >
              أمس
            </button>
            <button
              type="button"
              onClick={() => handleQuickDaysAgo(3)}
              className="text-[11px] px-2.5 py-1 rounded-lg font-bold border border-slate-300 hover:border-emerald-500 hover:bg-emerald-50 text-slate-700 transition-colors"
            >
              قبل 3 أيام
            </button>
            <button
              type="button"
              onClick={() => handleQuickDaysAgo(7)}
              className="text-[11px] px-2.5 py-1 rounded-lg font-bold border border-slate-300 hover:border-emerald-500 hover:bg-emerald-50 text-slate-700 transition-colors"
            >
              قبل أسبوع
            </button>
          </div>

          {/* Notes Input */}
          <div className="space-y-1.5">
            <label className="text-xs font-bold text-slate-600 flex items-center space-x-1.5 space-x-reverse">
              <FileText className="w-3.5 h-3.5 text-slate-500" />
              <span>ملاحظات أو أمر التغيير (اختياري)</span>
            </label>
            <input
              type="text"
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              placeholder="مثال: توثيق تاريخ الحالة بأمر العمليات..."
              className="w-full px-3 py-2 bg-slate-50 border border-slate-300 focus:border-emerald-600 focus:bg-white rounded-xl text-xs text-slate-700 outline-hidden transition-colors"
            />
          </div>

          {error && (
            <p className="text-[11px] font-bold text-rose-600">
              {error}
            </p>
          )}

          {/* Action Buttons */}
          <div className="pt-3 border-t border-slate-200 flex items-center justify-end gap-2">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2.5 bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-bold rounded-xl transition-colors cursor-pointer"
            >
              إلغاء
            </button>
            <button
              type="submit"
              className="px-5 py-2.5 bg-emerald-700 hover:bg-emerald-800 text-white text-xs font-black rounded-xl transition-all shadow-md hover:shadow-lg flex items-center space-x-1.5 space-x-reverse cursor-pointer"
            >
              <Check className="w-4 h-4 text-white" />
              <span>حفظ واعتماد التاريخ 💾</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
