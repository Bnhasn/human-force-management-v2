import React, { useState, useMemo } from 'react';
import * as XLSX from 'xlsx';
import { exportExcelWorkbook } from '../lib/exportUtils';
import {
  Copy,
  Layers,
  Trash2,
  CheckCircle2,
  AlertTriangle,
  Search,
  Filter,
  Download,
  RotateCcw,
  ShieldCheck,
  Building2,
  Eye,
  Zap,
  ShieldAlert,
  User,
  ArrowRightLeft,
  FileSpreadsheet
} from 'lucide-react';
import { PersonnelRecord, DepartmentRole, DuplicateGroup } from '../types';
import { StorageService } from '../lib/storage';
import { PersonnelAvatar } from './PersonnelAvatar';
import { normalizeArabicText, matchesSearchTokens } from '../lib/searchUtils';

interface DeduplicationViewProps {
  personnel: PersonnelRecord[];
  onSelectPersonnel: (militaryId: string) => void;
  onRefreshData: () => void;
  currentRole: DepartmentRole;
}

export const DeduplicationView: React.FC<DeduplicationViewProps> = ({
  personnel,
  onSelectPersonnel,
  onRefreshData,
  currentRole
}) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [filterType, setFilterType] = useState<'all' | 'fullName' | 'militaryId' | 'nationalId'>('all');
  const [processingGroupId, setProcessingGroupId] = useState<string | null>(null);
  const [actionSuccessMsg, setActionSuccessMsg] = useState<string | null>(null);

  // Calculate duplicate groups dynamically
  const duplicateGroups = useMemo(() => {
    return StorageService.findDuplicatePersonnelGroups(personnel);
  }, [personnel]);

  // Total duplicate records count
  const totalDuplicateRecordsCount = useMemo(() => {
    return duplicateGroups.reduce((acc, g) => acc + g.records.length, 0);
  }, [duplicateGroups]);

  // Filter groups by search and type
  const filteredGroups = useMemo(() => {
    return duplicateGroups.filter((group) => {
      // Filter by match type
      if (filterType !== 'all' && group.matchType !== filterType) {
        return false;
      }

      // Filter by search term
      if (!searchTerm.trim()) return true;

      const q = searchTerm.trim();
      const matchName = matchesSearchTokens([group.fullName], q);
      const matchVal = matchesSearchTokens([group.matchValue], q);
      const matchInRecords = group.records.some(
        (r) =>
          matchesSearchTokens([r.fullName, r.militaryId, r.nationalId, r.unit, r.rank, r.jobTitle], q)
      );

      return matchName || matchVal || matchInRecords;
    });
  }, [duplicateGroups, filterType, searchTerm]);

  // Auto Deduplicate All
  const handleAutoDeduplicateAll = () => {
    if (duplicateGroups.length === 0) {
      alert('لا توجد أي أسماء أو قيود مكررة حالياً في سجل القوة البشرية!');
      return;
    }

    if (
      confirm(
        `هل أنت تأكد من إجراء المعالجة التلقائية لكافة الأسماء المكررة؟\n\nسيتم دمج وتجميع السجلات والتحركات الميدانية لـ (${duplicateGroups.length}) مجموعات مكررة تلقائياً دون إغفال أي بيانات.`
      )
    ) {
      const res = StorageService.autoDeduplicateAllPersonnel(currentRole, 'المستخدم الحالي');
      setActionSuccessMsg(res.message);
      onRefreshData();
      setTimeout(() => setActionSuccessMsg(null), 5000);
    }
  };

  // Merge Single Group
  const handleMergeGroup = (group: DuplicateGroup, primaryIdOverride?: string) => {
    const primaryRecord = primaryIdOverride
      ? group.records.find((r) => r.militaryId === primaryIdOverride) || group.records[0]
      : group.records.find((r) => r.militaryId === group.suggestedPrimaryMilitaryId) || group.records[0];

    const dupRecords = group.records.filter((r) => r !== primaryRecord);

    if (dupRecords.length === 0) return;

    setProcessingGroupId(group.groupId);
    setTimeout(() => {
      const res = StorageService.mergeDuplicatePersonnelGroupRecords(
        primaryRecord,
        dupRecords,
        currentRole,
        'مسؤول السجلات'
      );
      if (res.success) {
        setActionSuccessMsg(res.message);
        onRefreshData();
      } else {
        alert(res.message);
      }
      setProcessingGroupId(null);
      setTimeout(() => setActionSuccessMsg(null), 4000);
    }, 150);
  };

  // Delete Individual Duplicate Record
  const handleDeleteDuplicate = (targetRecord: PersonnelRecord) => {
    if (
      confirm(
        `هل أنت تأكد من حذف هذا القيد المكرر للفرد (${targetRecord.fullName} - ${targetRecord.militaryId} - وحدة: ${targetRecord.unit}) ونقله إلى سلة المحذوفات؟`
      )
    ) {
      StorageService.deletePersonnelToRecycleBin(
        targetRecord.militaryId,
        'مسؤول السجلات',
        currentRole,
        'حذف قيد مكرر يدويًا عبر تبويب إدارة وتصفية الأسماء المكررة',
        targetRecord
      );
      setActionSuccessMsg(`تم حذف القيد المكرر (${targetRecord.fullName} - ${targetRecord.unit}) ونقله لسلة المحذوفات.`);
      onRefreshData();
      setTimeout(() => setActionSuccessMsg(null), 4000);
    }
  };

  // Export Duplicates to Excel
  const handleExportExcel = () => {
    if (duplicateGroups.length === 0) {
      alert('لا توجد بيانات مكررة للتصدير.');
      return;
    }

    const rows: any[] = [];
    duplicateGroups.forEach((group, idx) => {
      group.records.forEach((r, rIdx) => {
        rows.push({
          'رقم المجموعة': idx + 1,
          'معيار التكرار':
            group.matchType === 'fullName'
              ? 'تكرار الاسم الرباعي'
              : group.matchType === 'militaryId'
              ? 'تكرار الرقم العسكري'
              : 'تكرار الرقم الوطني',
          'الاسم المطابق': group.fullName,
          'الرقم العسكري': r.militaryId,
          'الرقم الوطني': r.nationalId,
          'الاسم الرباعي الكامل': r.fullName,
          'الرتبة': r.rank,
          'الوحدة / اللواء': r.unit,
          'الكتيبة': r.battalion || '-',
          'السرية': r.company || '-',
          'الوظيفة': r.jobTitle || '-',
          'الحالة الحالية': r.currentStatus,
          'تاريخ الالتحاق': r.enlistmentDate,
          'القيد المقترح كرئيسي': r.militaryId === group.suggestedPrimaryMilitaryId ? 'نعم (رئيسي)' : 'لا (قيد فرعي مكرر)'
        });
      });
    });

    const worksheet = XLSX.utils.json_to_sheet(rows);
    const workbook = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(workbook, worksheet, 'الأسماء المكررة');
    const fileName = `سجل_الأسماء_المكررة_${new Date().toISOString().split('T')[0]}.xlsx`;
    exportExcelWorkbook(workbook, fileName);
  };

  return (
    <div className="space-y-6 pb-12 font-['Tajawal'] dir-rtl">
      {/* Top Banner & Title */}
      <div className="bg-gradient-to-r from-slate-900 via-purple-950 to-slate-900 text-white rounded-3xl p-6 shadow-2xl border border-purple-500/30 relative overflow-hidden">
        <div className="absolute left-0 top-0 bottom-0 w-1/3 bg-purple-500/10 backdrop-blur-3xl rounded-full blur-3xl pointer-events-none" />

        <div className="relative z-10 flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
          <div className="flex items-center space-x-4 space-x-reverse">
            <div className="w-14 h-14 rounded-2xl bg-purple-500/20 text-purple-300 border border-purple-400/40 flex items-center justify-center shadow-inner shrink-0">
              <Copy className="w-8 h-8 text-purple-300 animate-pulse" />
            </div>
            <div>
              <div className="flex items-center space-x-2 space-x-reverse">
                <h1 className="text-2xl font-black text-white">تبويب فرز وإدارة الأسماء القيود المكررة</h1>
                <span className="bg-purple-500/30 text-purple-200 text-xs font-bold px-3 py-0.5 rounded-full border border-purple-400/30">
                  نظام التوحيد الآلي
                </span>
              </div>
              <p className="text-sm text-purple-200/80 mt-1 font-medium">
                فحص شامل لكافة سجلات القوة البشرية، اكتشاف حالات التكرار بالاسم أو الرقم العسكري/الوطني، وتوفير أدوات الدمج والحل الفوري.
              </p>
            </div>
          </div>

          <div className="flex items-center space-x-3 space-x-reverse w-full md:w-auto">
            <button
              type="button"
              onClick={handleAutoDeduplicateAll}
              className="flex-1 md:flex-none px-5 py-3 rounded-2xl bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-500 hover:to-indigo-500 text-white font-black text-sm shadow-xl hover:shadow-purple-500/25 transition-all flex items-center justify-center space-x-2 space-x-reverse border border-purple-400/40 cursor-pointer"
            >
              <Zap className="w-5 h-5 text-amber-300 shrink-0" />
              <span>معالجة ودمج كافة التكرارات آلياً ⚡</span>
            </button>

            <button
              type="button"
              onClick={handleExportExcel}
              className="px-4 py-3 rounded-2xl bg-white/10 hover:bg-white/20 text-white font-bold text-sm border border-white/20 transition-all flex items-center space-x-2 space-x-reverse cursor-pointer"
              title="تصدير المكررات إلى ملف إكسل"
            >
              <FileSpreadsheet className="w-5 h-5 text-emerald-400" />
              <span className="hidden sm:inline">تصدير Excel</span>
            </button>
          </div>
        </div>

        {/* Action Success Toast / Notification */}
        {actionSuccessMsg && (
          <div className="mt-4 p-3 rounded-2xl bg-emerald-500/20 border border-emerald-400/50 text-emerald-200 text-xs font-bold flex items-center space-x-2 space-x-reverse animate-fade-in">
            <CheckCircle2 className="w-5 h-5 text-emerald-400 shrink-0" />
            <span>{actionSuccessMsg}</span>
          </div>
        )}
      </div>

      {/* Analytics Summary Metric Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="bg-white border border-slate-200 rounded-2xl p-4 shadow-2xs flex items-center justify-between">
          <div>
            <div className="text-xs text-slate-500 font-bold">إجمالي سجل القوة البشرية</div>
            <div className="text-2xl font-black text-slate-800 font-mono mt-1">{personnel.length}</div>
            <div className="text-[10px] text-slate-500 font-medium mt-0.5">قيد إجمالي في القاعدة</div>
          </div>
          <div className="w-12 h-12 rounded-2xl bg-slate-100 text-slate-700 flex items-center justify-center font-bold text-lg">
            👥
          </div>
        </div>

        <div className="bg-white border border-purple-200 rounded-2xl p-4 shadow-2xs flex items-center justify-between">
          <div>
            <div className="text-xs text-purple-700 font-bold">مجموعات التكرار المرصودة</div>
            <div className="text-2xl font-black text-purple-900 font-mono mt-1">{duplicateGroups.length}</div>
            <div className="text-[10px] text-purple-600 font-medium mt-0.5">مجموعة تحتوي أسماء مكررة</div>
          </div>
          <div className="w-12 h-12 rounded-2xl bg-purple-50 text-purple-700 border border-purple-200 flex items-center justify-center font-bold">
            <Layers className="w-6 h-6" />
          </div>
        </div>

        <div className="bg-white border border-rose-200 rounded-2xl p-4 shadow-2xs flex items-center justify-between">
          <div>
            <div className="text-xs text-rose-700 font-bold">إجمالي القيود المكررة الزائدة</div>
            <div className="text-2xl font-black text-rose-800 font-mono mt-1">
              {totalDuplicateRecordsCount > 0 ? totalDuplicateRecordsCount - duplicateGroups.length : 0}
            </div>
            <div className="text-[10px] text-rose-600 font-medium mt-0.5">قيود يجب دمجها أو حذفها</div>
          </div>
          <div className="w-12 h-12 rounded-2xl bg-rose-50 text-rose-700 border border-rose-200 flex items-center justify-center font-bold">
            <Copy className="w-6 h-6" />
          </div>
        </div>

        <div className="bg-white border border-emerald-200 rounded-2xl p-4 shadow-2xs flex items-center justify-between">
          <div>
            <div className="text-xs text-emerald-700 font-bold">مؤشر نقاء وجودة البيانات</div>
            <div className="text-2xl font-black text-emerald-800 font-mono mt-1">
              {personnel.length > 0
                ? `${Math.round(
                    ((personnel.length - (totalDuplicateRecordsCount - duplicateGroups.length)) / personnel.length) * 100
                  )}%`
                : '100%'}
            </div>
            <div className="text-[10px] text-emerald-600 font-medium mt-0.5">سلامة السجلات والبيانات</div>
          </div>
          <div className="w-12 h-12 rounded-2xl bg-emerald-50 text-emerald-700 border border-emerald-200 flex items-center justify-center font-bold">
            <ShieldCheck className="w-6 h-6" />
          </div>
        </div>
      </div>

      {/* Filters and Search Bar */}
      <div className="bg-white border border-slate-200 rounded-2xl p-4 shadow-2xs flex flex-col md:flex-row items-center justify-between gap-4">
        {/* Search Input */}
        <div className="relative flex-1 w-full">
          <Search className="w-4 h-4 absolute right-3.5 top-1/2 -translate-y-1/2 text-slate-400" />
          <input
            type="text"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            placeholder="بحث في الأسماء المكررة، الرقم العسكري، اللواء، الرقم الوطني..."
            className="w-full bg-slate-50 border border-slate-200 rounded-xl pr-10 pl-4 py-2 text-xs text-slate-800 placeholder-slate-400 focus:outline-none focus:bg-white focus:border-purple-600 font-medium transition-all"
          />
          {searchTerm && (
            <button
              onClick={() => setSearchTerm('')}
              className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600 text-xs"
            >
              إلغاء
            </button>
          )}
        </div>

        {/* Filter Type Pills */}
        <div className="flex items-center space-x-1.5 space-x-reverse overflow-x-auto w-full md:w-auto shrink-0 pb-1 md:pb-0">
          <span className="text-xs text-slate-500 font-bold ml-1">تصفية التكرار:</span>

          <button
            onClick={() => setFilterType('all')}
            className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all ${
              filterType === 'all'
                ? 'bg-purple-900 text-white shadow-xs'
                : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
            }`}
          >
            الكل ({duplicateGroups.length})
          </button>

          <button
            onClick={() => setFilterType('fullName')}
            className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all ${
              filterType === 'fullName'
                ? 'bg-purple-900 text-white shadow-xs'
                : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
            }`}
          >
            الاسم الرباعي
          </button>

          <button
            onClick={() => setFilterType('militaryId')}
            className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all ${
              filterType === 'militaryId'
                ? 'bg-purple-900 text-white shadow-xs'
                : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
            }`}
          >
            الرقم العسكري
          </button>

          <button
            onClick={() => setFilterType('nationalId')}
            className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all ${
              filterType === 'nationalId'
                ? 'bg-purple-900 text-white shadow-xs'
                : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
            }`}
          >
            الرقم الوطني
          </button>
        </div>
      </div>

      {/* Groups List */}
      {filteredGroups.length === 0 ? (
        <div className="bg-white border border-slate-200 rounded-3xl p-12 text-center space-y-4 shadow-2xs">
          <div className="w-16 h-16 rounded-full bg-emerald-50 text-emerald-600 border border-emerald-200 flex items-center justify-center mx-auto">
            <CheckCircle2 className="w-8 h-8" />
          </div>
          <div>
            <h3 className="text-lg font-black text-slate-900">سجل القوة البشرية خالي من التكرارات</h3>
            <p className="text-xs text-slate-500 mt-1 max-w-md mx-auto">
              {searchTerm || filterType !== 'all'
                ? 'لا يوجد نتائج طابقت معايير البحث أو التصفية المحددة.'
                : 'لم يتم العثور على أي أسماء أو أرقام عسكرية مكررة في قاعدة البيانات. السجلات متكاملة وموحدة بنجاح.'}
            </p>
          </div>
          {(searchTerm || filterType !== 'all') && (
            <button
              onClick={() => {
                setSearchTerm('');
                setFilterType('all');
              }}
              className="px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-800 text-xs font-bold rounded-xl transition-all"
            >
              إعادة ضبط الفلاتر
            </button>
          )}
        </div>
      ) : (
        <div className="space-y-6">
          {filteredGroups.map((group, groupIdx) => {
            const isProcessing = processingGroupId === group.groupId;

            return (
              <div
                key={group.groupId}
                className="bg-white border-2 border-purple-200 rounded-3xl overflow-hidden shadow-md hover:border-purple-400 transition-all"
              >
                {/* Group Header */}
                <div className="bg-gradient-to-r from-purple-950 via-slate-900 to-slate-950 px-6 py-4 text-white flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 border-b border-purple-900/50">
                  <div className="flex items-center space-x-3 space-x-reverse">
                    <span className="w-8 h-8 rounded-xl bg-purple-500/30 text-purple-200 border border-purple-400/40 font-bold text-xs flex items-center justify-center shrink-0">
                      {groupIdx + 1}
                    </span>

                    <div>
                      <div className="flex items-center space-x-2 space-x-reverse">
                        <h3 className="text-base font-black text-white">{group.fullName}</h3>
                        <span className="bg-purple-500/20 text-purple-200 text-[10px] font-bold px-2.5 py-0.5 rounded-full border border-purple-400/30">
                          {group.matchType === 'fullName'
                            ? 'تكرار بالاسم الرباعي'
                            : group.matchType === 'militaryId'
                            ? 'تكرار بالرقم العسكري'
                            : 'تكرار بالرقم الوطني'}
                        </span>
                      </div>

                      <div className="flex items-center space-x-3 space-x-reverse text-xs text-purple-200/80 mt-1 font-medium">
                        <span>إجمالي القيود المكررة: {group.records.length}</span>
                        <span>•</span>
                        <span>
                          توزيع الوحدات:{' '}
                          {Object.entries(group.unitDistribution || {})
                            .map(([u, c]) => `${u} (${c})`)
                            .join('، ')}
                        </span>
                      </div>
                    </div>
                  </div>

                  <button
                    type="button"
                    disabled={isProcessing}
                    onClick={() => handleMergeGroup(group)}
                    className="w-full sm:w-auto px-4 py-2 bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-500 hover:to-indigo-500 text-white font-extrabold text-xs rounded-xl shadow-md transition-all flex items-center justify-center space-x-1.5 space-x-reverse border border-purple-300/40 cursor-pointer"
                  >
                    <Zap className="w-4 h-4 text-amber-300 shrink-0" />
                    <span>{isProcessing ? 'جاري الدمج والتوحيد...' : 'دمج كافة قيود المجموعة تلقائياً ⚡'}</span>
                  </button>
                </div>

                {/* Duplicate Records List in Side-by-Side Grid */}
                <div className="p-6 bg-slate-50/50">
                  <div className="text-xs font-bold text-slate-500 mb-3 flex items-center justify-between">
                    <span>مقارنة القيود المكررة ضمن هذه المجموعة ({group.records.length} قيود):</span>
                    <span className="text-[11px] text-purple-800 bg-purple-50 px-2 py-0.5 rounded border border-purple-200">
                      💡 القيد المظلل بالأخضر هو القيد الأكفأ والمقترح كرئيسي
                    </span>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                    {group.records.map((p) => {
                      const isSuggestedPrimary = p.militaryId === group.suggestedPrimaryMilitaryId;

                      const logsCount =
                        (p.logs?.movement?.length || 0) +
                        (p.logs?.attendance?.length || 0) +
                        (p.logs?.medical?.length || 0) +
                        (p.logs?.financial?.length || 0) +
                        (p.logs?.armament?.length || 0) +
                        (p.logs?.training?.length || 0) +
                        (p.logs?.attachments?.length || 0);

                      return (
                        <div
                          key={p.militaryId}
                          className={`relative rounded-2xl p-4 border transition-all flex flex-col justify-between ${
                            isSuggestedPrimary
                              ? 'bg-emerald-50/80 border-2 border-emerald-400 shadow-sm'
                              : 'bg-white border-slate-200 hover:border-purple-300 shadow-2xs'
                          }`}
                        >
                          {/* Suggested Primary Badge */}
                          {isSuggestedPrimary && (
                            <div className="absolute -top-3 left-4 bg-emerald-600 text-white text-[10px] font-black px-2.5 py-0.5 rounded-full shadow-xs flex items-center space-x-1 space-x-reverse">
                              <ShieldCheck className="w-3 h-3" />
                              <span>القيد المقترح كرئيسي</span>
                            </div>
                          )}

                          <div className="space-y-3">
                            <div className="flex items-start space-x-3 space-x-reverse">
                              <PersonnelAvatar
                                photoUrl={p.photoUrl}
                                fullName={p.fullName}
                                rank={p.rank}
                                militaryId={p.militaryId}
                                size="lg"
                                shape="rounded"
                              />

                              <div className="flex-1 min-w-0">
                                <div className="text-xs font-black text-slate-900 truncate">{p.fullName}</div>
                                <div className="text-[11px] text-purple-900 font-bold mt-0.5">
                                  {p.rank} • {p.jobTitle || 'عسكري'}
                                </div>
                                <div className="text-[10px] text-slate-500 font-mono mt-0.5">
                                  الرقم العسكري: <span className="font-bold text-slate-800">{p.militaryId}</span>
                                </div>
                              </div>
                            </div>

                            <div className="pt-2 border-t border-slate-200/80 space-y-1 text-[11px]">
                              <div className="flex justify-between">
                                <span className="text-slate-500 font-bold">الوحدة واللواء:</span>
                                <span className="text-slate-900 font-extrabold">{p.unit}</span>
                              </div>

                              <div className="flex justify-between">
                                <span className="text-slate-500 font-bold">الرقم الوطني:</span>
                                <span className="text-slate-800 font-mono font-bold">{p.nationalId || '-'}</span>
                              </div>

                              <div className="flex justify-between">
                                <span className="text-slate-500 font-bold">الحالة الميدانية:</span>
                                <span
                                  className={`px-1.5 py-0.2 rounded font-bold text-[10px] ${
                                    ['متواجد', 'في الميدان'].includes(p.currentStatus)
                                      ? 'bg-emerald-100 text-emerald-800'
                                      : ['إجازة', 'إذن'].includes(p.currentStatus)
                                      ? 'bg-amber-100 text-amber-800'
                                      : 'bg-rose-100 text-rose-800'
                                  }`}
                                >
                                  {p.currentStatus}
                                </span>
                              </div>

                              <div className="flex justify-between">
                                <span className="text-slate-500 font-bold">حالة البصمة الحيوية:</span>
                                <span className={p.biometricsRecorded ? 'text-emerald-700 font-bold' : 'text-slate-400'}>
                                  {p.biometricsRecorded ? 'مبصم حيويًا ✓' : 'غير مبصم'}
                                </span>
                              </div>

                              <div className="flex justify-between">
                                <span className="text-slate-500 font-bold">حجم البيانات والسجلات:</span>
                                <span className="text-purple-800 font-mono font-black">{logsCount} سجلات موثقة</span>
                              </div>
                            </div>
                          </div>

                          {/* Record Individual Actions */}
                          <div className="pt-3 mt-3 border-t border-slate-200/80 flex items-center justify-between gap-1.5">
                            <button
                              type="button"
                              onClick={() => onSelectPersonnel(p.militaryId)}
                              className="px-2 py-1 bg-slate-100 hover:bg-slate-200 text-slate-700 text-[10px] font-bold rounded-lg flex items-center space-x-1 space-x-reverse transition-all"
                              title="معاينة الملف الكامل"
                            >
                              <Eye className="w-3 h-3 text-slate-500" />
                              <span>معاينة</span>
                            </button>

                            {!isSuggestedPrimary && (
                              <button
                                type="button"
                                onClick={() => handleMergeGroup(group, p.militaryId)}
                                className="px-2 py-1 bg-purple-100 hover:bg-purple-200 text-purple-900 text-[10px] font-bold rounded-lg transition-all"
                                title="اعتماد هذا القيد كرئيسي ودمج باقي القيود فيه"
                              >
                                اعتماده كرئيسي 👑
                              </button>
                            )}

                            <button
                              type="button"
                              onClick={() => handleDeleteDuplicate(p)}
                              className="p-1 text-rose-600 hover:bg-rose-100 rounded-lg transition-all"
                              title="حذف هذا القيد المكرر فقط"
                            >
                              <Trash2 className="w-3.5 h-3.5" />
                            </button>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
};
