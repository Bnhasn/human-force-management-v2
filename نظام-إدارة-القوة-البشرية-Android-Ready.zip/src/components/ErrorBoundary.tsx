import React, { Component, ErrorInfo, ReactNode } from 'react';
import { AlertTriangle, RefreshCw, Home, ShieldCheck } from 'lucide-react';

interface Props {
  children: ReactNode;
  fallbackTitle?: string;
  fallbackMessage?: string;
  onReset?: () => void;
}

interface State {
  hasError: boolean;
  error?: Error;
}

export class ErrorBoundary extends React.Component<Props, State> {
  constructor(props: Props) {
    super(props);
    this.state = { hasError: false };
  }

  public static getDerivedStateFromError(error: Error): State {
    return { hasError: true, error };
  }

  public componentDidCatch(error: Error, errorInfo: ErrorInfo) {
    console.error('[ErrorBoundary] Caught runtime component error:', error, errorInfo);
  }

  private handleReset = () => {
    this.setState({ hasError: false, error: undefined });
    if (this.props.onReset) {
      try {
        this.props.onReset();
      } catch (e) {
        console.warn('onReset callback exception:', e);
      }
    }
  };

  private handleGoToDashboard = () => {
    this.setState({ hasError: false, error: undefined });
    try {
      window.dispatchEvent(new CustomEvent('military_navigate_tab', { detail: { tab: 'dashboard' } }));
    } catch {}
  };

  public render() {
    if (this.state.hasError) {
      return (
        <div className="p-8 bg-slate-900/95 text-white rounded-3xl border border-red-500/30 shadow-2xl my-6 mx-auto max-w-2xl text-center font-['Tajawal']" dir="rtl">
          <div className="w-16 h-16 bg-red-500/10 text-red-400 rounded-2xl flex items-center justify-center mx-auto mb-4 border border-red-500/20">
            <AlertTriangle className="w-8 h-8 animate-pulse" />
          </div>
          <h3 className="text-lg font-bold text-slate-100 mb-2">
            {this.props.fallbackTitle || 'تم احتواء التنبيه ومواصلة العمل بأمان'}
          </h3>
          <p className="text-xs sm:text-sm text-slate-400 mb-6 leading-relaxed">
            {this.props.fallbackMessage || 'تم عزل الخطأ بنجاح لحماية وتأمين بياناتك وسجلاتك. يمكنك استئناف العمل فوراً بالنقر أدناه.'}
          </p>

          <div className="flex flex-wrap items-center justify-center gap-3">
            <button
              onClick={this.handleReset}
              className="flex items-center gap-2 px-5 py-2.5 bg-emerald-600 hover:bg-emerald-500 text-white rounded-xl text-xs font-bold transition-all shadow-md cursor-pointer"
            >
              <RefreshCw className="w-4 h-4" />
              <span>استئناف ومواصلة العرض</span>
            </button>
            <button
              onClick={this.handleGoToDashboard}
              className="flex items-center gap-2 px-4 py-2.5 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded-xl text-xs font-medium transition-all border border-slate-700 cursor-pointer"
            >
              <Home className="w-4 h-4 text-emerald-400" />
              <span>العودة للوحة الجاهزية الرئيسية</span>
            </button>
          </div>
        </div>
      );
    }

    return this.props.children;
  }
}
