import React, { useState, useEffect } from 'react';
import { Building2, X, Check, ShieldCheck, Landmark, MapPin, FileText, Sparkles } from 'lucide-react';
import { PersonnelRecord } from '../types';

interface SecondedUnitModalProps {
  isOpen: boolean;
  onClose: () => void;
  personnel: PersonnelRecord | null;
  onConfirm: (militaryId: string, secondedUnit: string, reason?: string) => void;
}

const COMMON_SECONDED_UNITS = [
  'قيادة قوات الطوارئ اليمنية / الفرقة الثالثة',
  'قيادة القوات المشتركة',
  'قيادة القوات البحرية والدفاع الساحلي',
  'قيادة المنطقة العسكرية الأولى',
  'قيادة المنطقة العسكرية الثانية',
  'قيادة المنطقة العسكرية الرابعة',
  'دائرة الاستخبارات والاستطلاع العسكري',
  'دائرة شؤون الأفراد والاحتياط العام',
  'قيادة حرس الحدود',
  'قيادة الشرطة العسكرية المركزية',
  'اللواء الأول مشاة بحري',
  'اللواء الثاني حرس حدود'
];

export const SecondedUnitModal: React.FC<SecondedUnitModalProps> = ({
  isOpen,
  onClose,
  personnel,
  onConfirm
}) => {
  const [secondedUnit, setSecondedUnit] = useState('');
  const [reason, setReason] = useState('انتداب رسمي بقرار وتوجيهات القيادة العسكرية');
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (isOpen && personnel) {
      setSecondedUnit(personnel.secondedUnit || '');
      setReason(personnel.currentStatus === 'منتدب' && personnel.secondedUnit ? `تحديث بيانات الانتداب لدى [${personnel.secondedUnit}]` : 'انتداب رسمي بقرار وتوجيهات القيادة العسكرية');
      setError(null);
    }
  }, [isOpen, personnel]);

  if (!isOpen || !personnel) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const trimmedUnit = secondedUnit.trim();
    if (!trimmedUnit) {
      setError('يرجى كتابة أو اختيار الوحدة / الجهة المنتدب إليها الفرد.');
      return;
    }

    onConfirm(personnel.militaryId, trimmedUnit, reason.trim() || undefined);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/70 backdrop-blur-xs font-['Cairo',sans-serif] select-none animate-fadeIn">
      <div className="bg-white border-2 border-purple-500/40 rounded-3xl max-w-lg w-full shadow-2xl overflow-hidden text-right">
        
        {/* Header */}
        <div className="bg-gradient-to-r from-purple-900 via-indigo-900 to-slate-900 p-5 text-white flex items-center justify-between">
          <div className="flex items-center space-x-3 space-x-reverse">
            <div className="w-10 h-10 rounded-2xl bg-purple-500/20 border border-purple-400 flex items-center justify-center text-purple-300">
              <Building2 className="w-6 h-6" />
            </div>
            <div>
              <h3 className="font-black text-lg text-purple-200">
                تحديد الوحدة والجهة المنتدب إليها 🏛️
              </h3>
              <p className="text-xs text-purple-300">
                توثيق الانتداب الخارجي وتحديث تمام الجاهزية العسكرية
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            type="button"
            className="p-1.5 rounded-xl bg-purple-950/50 hover:bg-purple-800 text-purple-200 hover:text-white transition-colors border border-purple-700/50 cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Form Body */}
        <form onSubmit={handleSubmit} className="p-6 space-y-5">
          
          {/* Target Personnel Badge */}
          <div className="bg-purple-50/70 border border-purple-200 rounded-2xl p-4 flex items-center space-x-3 space-x-reverse">
            <div className="w-12 h-12 rounded-xl bg-purple-600 text-white flex items-center justify-center font-black text-sm shrink-0 shadow-xs">
              {personnel.rank}
            </div>
            <div className="space-y-1">
              <div className="font-black text-slate-800 text-sm">
                {personnel.rank} / {personnel.fullName}
              </div>
              <div className="text-xs text-slate-600 flex items-center space-x-2 space-x-reverse">
                <span className="font-mono bg-purple-100 text-purple-900 px-2 py-0.5 rounded font-bold">
                  {personnel.militaryId}
                </span>
                <span>•</span>
                <span className="text-slate-500">{personnel.unit || 'القوة العسكرية'}</span>
              </div>
            </div>
          </div>

          {/* Quick Select Presets */}
          <div className="space-y-2">
            <label className="text-xs font-black text-slate-700 flex items-center space-x-1.5 space-x-reverse">
              <Sparkles className="w-3.5 h-3.5 text-purple-600" />
              <span>اختيار سريع للجهات والوحدات الشائعة:</span>
            </label>
            <div className="flex flex-wrap gap-1.5 max-h-32 overflow-y-auto p-1 bg-slate-50 border border-slate-200 rounded-xl">
              {COMMON_SECONDED_UNITS.map((unit) => (
                <button
                  key={unit}
                  type="button"
                  onClick={() => {
                    setSecondedUnit(unit);
                    setError(null);
                  }}
                  className={`text-[11px] px-2.5 py-1 rounded-lg font-bold border transition-all cursor-pointer ${
                    secondedUnit === unit
                      ? 'bg-purple-700 text-white border-purple-800 shadow-xs'
                      : 'bg-white text-slate-700 border-slate-300 hover:border-purple-400 hover:bg-purple-50'
                  }`}
                >
                  {unit}
                </button>
              ))}
            </div>
          </div>

          {/* Seconded Unit Input */}
          <div className="space-y-1.5">
            <label className="text-xs font-black text-purple-900 flex items-center space-x-1.5 space-x-reverse">
              <Landmark className="w-4 h-4 text-purple-700" />
              <span>اسم الوحدة / الجهة المنتدب لديها *</span>
            </label>
            <input
              type="text"
              required
              value={secondedUnit}
              onChange={(e) => {
                setSecondedUnit(e.target.value);
                if (error) setError(null);
              }}
              placeholder="مثال: قيادة المنطقة البحرية الأولى - غرفة العمليات..."
              className="w-full px-3.5 py-2.5 bg-slate-50 border-2 border-slate-300 focus:border-purple-600 focus:bg-white rounded-xl text-sm font-bold text-slate-800 outline-hidden transition-colors"
            />
            {error && (
              <p className="text-[11px] font-bold text-rose-600 mt-1">
                {error}
              </p>
            )}
          </div>

          {/* Reason / Administrative Reference */}
          <div className="space-y-1.5">
            <label className="text-xs font-bold text-slate-600 flex items-center space-x-1.5 space-x-reverse">
              <FileText className="w-3.5 h-3.5 text-slate-500" />
              <span>رقم / مستند أمر الانتداب الإداري (اختياري)</span>
            </label>
            <input
              type="text"
              value={reason}
              onChange={(e) => setReason(e.target.value)}
              placeholder="انتداب رسمي بقرار القيادة..."
              className="w-full px-3 py-2 bg-slate-50 border border-slate-300 focus:border-purple-600 focus:bg-white rounded-xl text-xs text-slate-700 outline-hidden transition-colors"
            />
          </div>

          {/* Action Buttons */}
          <div className="pt-3 border-t border-slate-200 flex items-center justify-end gap-2">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2.5 bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-bold rounded-xl transition-colors cursor-pointer"
            >
              إلغاء الأمر
            </button>
            <button
              type="submit"
              className="px-5 py-2.5 bg-purple-700 hover:bg-purple-800 text-white text-xs font-black rounded-xl transition-all shadow-md hover:shadow-lg flex items-center space-x-1.5 space-x-reverse cursor-pointer"
            >
              <Check className="w-4 h-4 text-white" />
              <span>تأكيد واعتماد الانتداب ⚡</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
