import React, { useState, useRef } from 'react';
import { X, FileSpreadsheet, Download, Upload, CheckCircle2, AlertTriangle, RefreshCw, FileText, ArrowLeft, ShieldCheck, Database, Check, Layers, Sliders, ChevronDown, ChevronUp, Sparkles } from 'lucide-react';
import * as XLSX from 'xlsx';
import { exportExcelWorkbook } from '../lib/exportUtils';
import { PersonnelRecord, MilitaryRank, PersonnelStatus } from '../types';
import { ArmoryWeaponPiece, ArmoryIssueOrder } from '../data/armamentData';
import { StorageService } from '../lib/storage';
import { BRIGADE_ACCOUNTS, getAccountIdForUnit } from '../data/accountsData';

// Canonical schema matching Export 100%
export const CANONICAL_PERSONNEL_COLUMNS = [
  { key: 'serial', header: 'م', width: 6 },
  { key: 'militaryId', header: 'الرقم العسكري', width: 16 },
  { key: 'fullName', header: 'الاسم الكامل', width: 28 },
  { key: 'rank', header: 'الرتبة العسكرية', width: 15 },
  { key: 'nationalId', header: 'رقم الهوية الوطنية', width: 18 },
  { key: 'unit', header: 'الوحدة / اللواء', width: 24 },
  { key: 'battalion', header: 'الكتيبة', width: 18 },
  { key: 'company', header: 'السرية', width: 16 },
  { key: 'platoon', header: 'الفصيل', width: 14 },
  { key: 'currentStatus', header: 'حالة الجاهزية الحالية', width: 20 },
  { key: 'jobTitle', header: 'التخصص / المسمى الوظيفي', width: 24 },
  { key: 'phone', header: 'رقم التواصل', width: 16 },
  { key: 'bloodType', header: 'فصيلة الدم', width: 12 },
  { key: 'education', header: 'المؤهل العلمي', width: 16 },
  { key: 'enlistmentDate', header: 'تاريخ التجنيد', width: 14 },
  { key: 'pob', header: 'المحافظة / مكان الميلاد', width: 18 },
  { key: 'dob', header: 'تاريخ الميلاد', width: 14 },
  { key: 'maritalStatus', header: 'الحالة الاجتماعية', width: 14 },
  { key: 'motherName', header: 'اسم الأم', width: 20 },
  { key: 'guarantorName', header: 'اسم الضمين', width: 20 },
  { key: 'relativeName', header: 'اسم القريب (طوارئ)', width: 22 },
  { key: 'relativePhone', header: 'رقم هاتف القريب', width: 16 },
  { key: 'secondedUnit', header: 'الوحدة المنتدب إليها', width: 20 }
];

export const CANONICAL_ARMAMENT_COLUMNS = [
  { key: 'serial', header: 'م', width: 6 },
  { key: 'militaryId', header: 'الرقم الوظيفي', width: 16 },
  { key: 'fullName', header: 'الاسم الكامل', width: 28 },
  { key: 'weaponType', header: 'نوع السلاح العهدة', width: 24 },
  { key: 'weaponSerial', header: 'رقم السلاح', width: 18 },
  { key: 'magazinesCount', header: 'عدد المخازن', width: 14 },
  { key: 'ammoQty', header: 'عدد الذخيرة المنصرفة', width: 20 },
  { key: 'condition', header: 'حالة السلاح', width: 16 },
  { key: 'issueDate', header: 'تاريخ الصرف', width: 16 },
  { key: 'status', header: 'الحالة', width: 20 }
];

interface ExcelImportModalProps {
  isOpen: boolean;
  onClose: () => void;
  importType?: 'personnel' | 'armament';
  onPersonnelImported?: (updatedPersonnel: PersonnelRecord[]) => void;
  onArmamentImported?: (newPieces: ArmoryWeaponPiece[]) => void;
  currentPersonnelList?: PersonnelRecord[];
}

export const ExcelImportModal: React.FC<ExcelImportModalProps> = ({
  isOpen,
  onClose,
  importType = 'personnel',
  onPersonnelImported,
  onArmamentImported,
  currentPersonnelList = []
}) => {
  const [activeType, setActiveType] = useState<'personnel' | 'armament'>(importType);
  const [parsedData, setParsedData] = useState<any[]>([]);
  const [fileInfo, setFileInfo] = useState<{ name: string; rowsCount: number; matchedColumnsCount: number } | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [importSuccess, setImportSuccess] = useState<string | null>(null);
  const [importError, setImportError] = useState<string | null>(null);

  const [sheetsList, setSheetsList] = useState<string[]>([]);
  const [selectedSheet, setSelectedSheet] = useState<string>('');
  const [rawWorkbook, setRawWorkbook] = useState<XLSX.WorkBook | null>(null);
  const [detectedColumns, setDetectedColumns] = useState<string[]>([]);
  const [customMapping, setCustomMapping] = useState<Record<string, string>>({});
  const [showMappingDrawer, setShowMappingDrawer] = useState<boolean>(false);
  const [isDragging, setIsDragging] = useState<boolean>(false);

  const fileInputRef = useRef<HTMLInputElement | null>(null);

  if (!isOpen) return null;

  // Comprehensive Arabic text and key normalizer
  const normalizeArabicKey = (str: any): string => {
    if (str === null || str === undefined) return '';
    return String(str)
      .trim()
      .replace(/[\u064B-\u065F\u0670\u0640]/g, '') // remove Arabic diacritics & tatweel
      .replace(/[أإآءٱ]/g, 'ا')
      .replace(/ة/g, 'ه')
      .replace(/ى/g, 'ي')
      .replace(/ؤ/g, 'و')
      .replace(/ئ/g, 'ي')
      .replace(/[\s_\-\.\/\#\(\)\:\,\–\—\t\r\n\[\]]/g, '')
      .toLowerCase();
  };

  // Safe cleaner for cell value (cleans placeholders like '-', 'غير مسجل', 'N/A')
  const cleanCellValue = (val: any): string => {
    if (val === undefined || val === null) return '';
    const str = String(val).trim();
    if (
      str === '-' ||
      str === '--' ||
      str === 'غير مسجل' ||
      str === 'غير محدد' ||
      str === 'لا يوجد' ||
      str === 'لايوجد' ||
      str === 'N/A' ||
      str === 'n/a' ||
      str === 'null' ||
      str === 'undefined'
    ) {
      return '';
    }
    return str;
  };

  // Safe cleaner for IDs and numeric codes
  const cleanIdOrNumber = (val: any): string => {
    if (val === undefined || val === null) return '';
    let str = String(val).trim();
    if (str === '-' || str === 'غير مسجل' || str === 'لا يوجد' || str === 'N/A' || str === 'null') return '';
    if (/^\d+\.0$/.test(str)) {
      str = str.replace(/\.0$/, '');
    }
    return str;
  };

  // Parse Excel date formats cleanly into 'YYYY-MM-DD'
  const parseExcelDate = (val: any): string => {
    if (!val) return '';
    if (val instanceof Date) {
      if (isNaN(val.getTime())) return '';
      return val.toISOString().split('T')[0];
    }
    const strVal = String(val).trim();
    if (!strVal || strVal === '-' || strVal === 'غير مسجل' || strVal === 'N/A') return '';

    // If numeric Excel timestamp (e.g. 45230)
    if (/^\d{4,6}$/.test(strVal) && !isNaN(Number(strVal))) {
      const num = Number(strVal);
      const jsDate = new Date((num - 25569) * 86400 * 1000);
      if (!isNaN(jsDate.getTime())) {
        return jsDate.toISOString().split('T')[0];
      }
    }

    // If YYYY-MM-DD
    if (/^\d{4}-\d{1,2}-\d{1,2}$/.test(strVal)) {
      const parts = strVal.split('-');
      return `${parts[0]}-${parts[1].padStart(2, '0')}-${parts[2].padStart(2, '0')}`;
    }

    // If DD/MM/YYYY or DD-MM-YYYY
    if (/^\d{1,2}[\/\-\.]\d{1,2}[\/\-\.]\d{4}$/.test(strVal)) {
      const parts = strVal.split(/[\/\-\.]/);
      return `${parts[2]}-${parts[1].padStart(2, '0')}-${parts[0].padStart(2, '0')}`;
    }

    return strVal;
  };

  // Normalize Rank
  const normalizeRank = (rawRank: string): MilitaryRank => {
    if (!rawRank) return 'جندي';
    const clean = normalizeArabicKey(rawRank);
    if (clean.includes('فريقاول')) return 'فريق أول';
    if (clean.includes('فريق')) return 'فريق';
    if (clean.includes('لواء')) return 'لواء';
    if (clean.includes('عميد')) return 'عميد';
    if (clean.includes('عقيد')) return 'عقيد';
    if (clean.includes('مقدم')) return 'مقدم';
    if (clean.includes('رائد')) return 'رائد';
    if (clean.includes('نقيب')) return 'نقيب';
    if (clean.includes('ملازماول')) return 'ملازم أول';
    if (clean.includes('ملازم')) return 'ملازم';
    if (clean.includes('رئيسرقباء') || clean.includes('رئس在上')) return 'رئيس رقباء';
    if (clean.includes('رقيباول')) return 'رقيب أول';
    if (clean.includes('وكيلرقيب') || clean.includes('وكيل')) return 'وكيل رقيب';
    if (clean.includes('رقيب')) return 'رقيب';
    if (clean.includes('عريف')) return 'عريف';
    if (clean.includes('جندياول')) return 'جندي أول';
    if (clean.includes('جندي')) return 'جندي';
    return 'جندي';
  };

  // Normalize Status
  const normalizeStatus = (rawStatus: string): PersonnelStatus => {
    if (!rawStatus) return 'متواجد';
    const clean = normalizeArabicKey(rawStatus);
    if (clean.includes('اسير') || clean.includes('أسر') || clean.includes('اسر')) return 'اسير';
    if (clean.includes('شهيد') || clean.includes('استشهد')) return 'شهيد';
    if (clean.includes('معاق') || clean.includes('اعاقه')) return 'معاق';
    if (clean.includes('جريح') || clean.includes('مصاب') || clean.includes('اصابه')) return 'جريح';
    if (clean.includes('مفقود') || clean.includes('فقد')) return 'مفقود';
    if (clean.includes('خارجيه') || clean.includes('ابتعاث')) return 'دورة تدريبية خارجية';
    if (clean.includes('دوره') || clean.includes('تدريب') || clean.includes('معهد')) return 'دورة تدريبية داخلية';
    if (clean.includes('ميدان')) return 'في الميدان';
    if (clean.includes('اجازه') || clean.includes('مجاز') || clean.includes('عطله')) return 'إجازة';
    if (clean.includes('اذن') || clean.includes('ماذون') || clean.includes('استئذان') || clean.includes('تصريح')) return 'إذن';
    if (clean.includes('مستشفي') || clean.includes('مرضي') || clean.includes('منوم') || clean.includes('مريض') || clean.includes('علاج')) return 'مستشفى';
    if (clean.includes('غياب') || clean.includes('غائب') || clean.includes('متغيب')) return 'غياب';
    if (clean.includes('فرار') || clean.includes('فار') || clean.includes('هارب')) return 'فرار';
    if (clean.includes('ماموريه') || clean.includes('مهمه') || clean.includes('مكلف')) return 'مأمورية';
    if (clean.includes('منتدب') || clean.includes('انتداب')) return 'منتدب';
    if (clean.includes('موقوف') || clean.includes('سجن') || clean.includes('احتجاز') || clean.includes('حبس')) return 'موقوف';
    if (clean.includes('احتياط')) return 'احتياط';
    if (clean.includes('عمل') || clean.includes('راس العمل') || clean.includes('حاضر') || clean.includes('متواجد') || clean.includes('موجود')) return 'متواجد';
    return 'متواجد';
  };

  // Find header row in 2D array by scoring matches across top 30 rows
  const findHeaderRowIndex = (rawRows: any[][]): number => {
    if (!rawRows || rawRows.length === 0) return 0;
    
    const keywords = [
      'اسم', 'رقم', 'رتبه', 'جاهزيه', 'وحده', 'لواء',
      'كتيبه', 'سريه', 'فصيل', 'سلسله', 'سيريال', 'نوع', 'سلاح',
      'هويه', 'وطني', 'هاتف', 'جوال', 'تخصص', 'وظيفه', 'بيان', 'ملاحظات',
      'name', 'id', 'military', 'rank', 'unit', 'serial', 'type', 'status', 'phone'
    ];

    let bestRowIdx = 0;
    let maxMatches = 0;

    for (let r = 0; r < Math.min(rawRows.length, 30); r++) {
      const row = rawRows[r];
      if (!Array.isArray(row)) continue;
      let matchCount = 0;
      row.forEach((cell: any) => {
        const cellNorm = normalizeArabicKey(cell);
        if (cellNorm && keywords.some(kw => cellNorm.includes(normalizeArabicKey(kw)))) {
          matchCount++;
        }
      });
      if (matchCount > maxMatches) {
        maxMatches = matchCount;
        bestRowIdx = r;
      }
    }
    return bestRowIdx;
  };

  // Pre-resolve header key for a list of aliases from a sample row object
  const buildColumnResolver = (sampleRow: Record<string, any>, manualOverrides: Record<string, string> = {}) => {
    if (!sampleRow) return (aliases: string[], fieldKey?: string) => null;
    const rawKeys = Object.keys(sampleRow);
    const keyMap = new Map<string, string>(); // normalizedKey -> originalKey
    rawKeys.forEach(k => keyMap.set(normalizeArabicKey(k), k));

    return (aliases: string[], fieldKey?: string): string | null => {
      // 1. Check if user manually mapped this specific fieldKey
      if (fieldKey && manualOverrides[fieldKey] && sampleRow[manualOverrides[fieldKey]] !== undefined) {
        return manualOverrides[fieldKey];
      }

      const normAliases = aliases.map(a => normalizeArabicKey(a));
      // 2. Direct exact normalized match
      for (const alias of normAliases) {
        for (const [normKey, origKey] of keyMap.entries()) {
          if (normKey === alias) return origKey;
        }
      }
      // 3. Substring match (skip tiny keys like 'م' to avoid false positives)
      for (const alias of normAliases) {
        if (alias.length < 3) continue;
        for (const [normKey, origKey] of keyMap.entries()) {
          if (normKey.includes(alias) || alias.includes(normKey)) return origKey;
        }
      }
      return null;
    };
  };

  // Helper to extract value safely using resolved column key
  const getValueByCol = (row: Record<string, any>, colKey: string | null): string => {
    if (!row || !colKey) return '';
    const val = row[colKey];
    return cleanCellValue(val);
  };

  // Parse a specific sheet from workbook
  const parseSheetData = (wb: XLSX.WorkBook, sheetName: string) => {
    try {
      const ws = wb.Sheets[sheetName];
      if (!ws) return;

      const raw2D: any[][] = XLSX.utils.sheet_to_json(ws, { header: 1, defval: '' });
      if (!raw2D || raw2D.length === 0) {
        setImportError(`الورقة "${sheetName}" فارغة ولا تحتوي على بيانات.`);
        return;
      }

      const headerIndex = findHeaderRowIndex(raw2D);
      const headers = (raw2D[headerIndex] || []).map((h: any) => String(h || '').trim()).filter((h: string) => h !== '');
      const rawHeaderRow = raw2D[headerIndex] || [];
      const dataRows = raw2D.slice(headerIndex + 1);

      const parsedObjects: any[] = [];
      dataRows.forEach((rowArray: any[]) => {
        if (!Array.isArray(rowArray) || rowArray.every(cell => String(cell || '').trim() === '')) {
          return;
        }
        const obj: any = {};
        let hasContent = false;
        rawHeaderRow.forEach((h: any, colIdx: number) => {
          const colHeader = String(h || '').trim() || `عمود_${colIdx + 1}`;
          const val = rowArray[colIdx] !== undefined ? rowArray[colIdx] : '';
          obj[colHeader] = val;
          if (String(val).trim() !== '') {
            hasContent = true;
          }
        });
        if (hasContent) {
          parsedObjects.push(obj);
        }
      });

      if (parsedObjects.length === 0) {
        setImportError(`لم يتم العثور على صفوف بيانات بعد قراءة عناوين الأعمدة في الورقة "${sheetName}".`);
        return;
      }

      const allDetectedCols = Object.keys(parsedObjects[0] || {});
      setDetectedColumns(allDetectedCols);

      // Count matched columns with smart normalizer
      const resolver = buildColumnResolver(parsedObjects[0], customMapping);
      let matchCount = 0;
      if (activeType === 'personnel') {
        CANONICAL_PERSONNEL_COLUMNS.forEach(col => {
          if (col.key !== 'serial' && resolver([col.header, col.key], col.key)) {
            matchCount++;
          }
        });
      } else {
        CANONICAL_ARMAMENT_COLUMNS.forEach(col => {
          if (col.key !== 'serial' && resolver([col.header, col.key], col.key)) {
            matchCount++;
          }
        });
      }

      setParsedData(parsedObjects);
      setSelectedSheet(sheetName);
      setFileInfo(prev => ({
        name: prev?.name || 'الملف المرفوع',
        rowsCount: parsedObjects.length,
        matchedColumnsCount: matchCount
      }));
      setImportError(null);
    } catch (err: any) {
      console.error('Error parsing sheet:', err);
      setImportError('حدث خطأ أثناء معالجة بيانات الورقة المحددة.');
    }
  };

  // Handle Excel/CSV file upload & parsing
  const processUploadedFile = (file: File) => {
    if (!file) return;

    setIsLoading(true);
    setImportError(null);
    setImportSuccess(null);
    setCustomMapping({});
    setShowMappingDrawer(false);

    const reader = new FileReader();

    reader.onload = (evt) => {
      setTimeout(() => {
        try {
          const data = new Uint8Array(evt.target?.result as ArrayBuffer);
          const wb = XLSX.read(data, { type: 'array', cellDates: true, raw: false });
          
          if (!wb.SheetNames || wb.SheetNames.length === 0) {
            setImportError('الملف المرفوع فارغ أو لا يحتوي على أوراق عمل صالحة.');
            setIsLoading(false);
            return;
          }

          setRawWorkbook(wb);
          setSheetsList(wb.SheetNames);

          // Find the best sheet with actual data rows
          let bestSheet = wb.SheetNames[0];
          let maxRows = 0;

          wb.SheetNames.forEach((sName) => {
            const ws = wb.Sheets[sName];
            if (ws) {
              const rows: any[][] = XLSX.utils.sheet_to_json(ws, { header: 1, defval: '' });
              if (rows && rows.length > maxRows) {
                maxRows = rows.length;
                bestSheet = sName;
              }
            }
          });

          setSelectedSheet(bestSheet);
          setFileInfo({
            name: file.name,
            rowsCount: 0,
            matchedColumnsCount: 0
          });

          parseSheetData(wb, bestSheet);
        } catch (err: any) {
          console.error('Error parsing Excel file:', err);
          setImportError('تعذر قراءة ملف الإكسل. يرجى التأكد من صيغة الملف (.xlsx, .xls, .csv).');
        } finally {
          setIsLoading(false);
          // Clear input so re-selecting same file works
          if (fileInputRef.current) {
            fileInputRef.current.value = '';
          }
        }
      }, 50);
    };

    reader.onerror = () => {
      setImportError('حدث خطأ أثناء قراءة الملف من جهازك.');
      setIsLoading(false);
      if (fileInputRef.current) {
        fileInputRef.current.value = '';
      }
    };

    reader.readAsArrayBuffer(file);
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      processUploadedFile(file);
    }
  };

  // Drag and Drop handlers
  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDragging(true);
  };

  const handleDragLeave = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDragging(false);
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDragging(false);
    const file = e.dataTransfer.files?.[0];
    if (file) {
      processUploadedFile(file);
    }
  };

  // Process Personnel Import & Readiness Update
  const processPersonnelImport = () => {
    if (parsedData.length === 0) return;

    try {
      const existingRecords = StorageService.getPersonnel();
      let updatedCount = 0;
      let addedCount = 0;

      const resultMap = new Map<string, PersonnelRecord>();
      const militaryIdIndex = new Map<string, PersonnelRecord>();
      const nationalIdIndex = new Map<string, PersonnelRecord>();
      const fullNameIndex = new Map<string, PersonnelRecord>();

      existingRecords.forEach(p => {
        const copy = { ...p };
        resultMap.set(p.militaryId, copy);
        if (p.militaryId) militaryIdIndex.set(normalizeArabicKey(p.militaryId), copy);
        if (p.nationalId) nationalIdIndex.set(normalizeArabicKey(p.nationalId), copy);
        if (p.fullName) fullNameIndex.set(normalizeArabicKey(p.fullName), copy);
      });

      const activeCode = typeof window !== 'undefined' ? localStorage.getItem('military_active_account_v1') : 'hq';
      const activeAcc = BRIGADE_ACCOUNTS.find(a => a.id === activeCode || a.shortCode === activeCode || a.customAccessKey === activeCode);
      const currentAccId = activeAcc ? activeAcc.id : 'hq';

      // Pre-resolve all columns matching export headers & aliases
      const resolver = buildColumnResolver(parsedData[0], customMapping);
      
      const colMilitaryId = resolver([
        'الرقم العسكري', 'الرقم الوظيفي', 'رقم الوظيفة', 'الرقم العسكري/الوظيفي', 'الرقم', 'رقم الفرد', 'رقم الضابط', 'الكود', 'رقم القيد', 'رقم السجل', 'السيريال',
        'militaryId', 'military_id', 'Job ID', 'jobId', 'ID', 'id', 'No', 'no', 'code', 'serial'
      ], 'militaryId');

      const colFullName = resolver([
        'الاسم الكامل', 'الاسم الرباعي', 'الاسم الثلاثي', 'الاسم', 'اسم الفرد', 'اسم الضابط', 'اسم الجندي', 'اسم المنتسب', 'الاسم والشهرة', 'الاسم واللقب', 'البيان', 'اسم الموظف', 'الاسم رباعي', 'الاسم ثلاثي',
        'fullName', 'full_name', 'Name', 'name', 'employee_name', 'person_name'
      ], 'fullName');

      const colRank = resolver(['الرتبة العسكرية', 'الرتبة', 'رتبة', 'الرتبه', 'الدرجة', 'الصفة', 'rank', 'Rank', 'grade'], 'rank');
      
      const colNationalId = resolver([
        'رقم الهوية الوطنية', 'الرقم الوطني', 'رقم الهوية', 'الهوية', 'السجل المدني', 'بطاقة شخصية', 'رقم البطاقة', 'الرقم القومي', 'اثبات الهوية',
        'nationalId', 'national_id', 'National ID', 'civilId', 'nid'
      ], 'nationalId');

      const colUnit = resolver(['الوحدة / اللواء', 'الوحدة', 'اللواء', 'التشكيل', 'التشكيل العسكري', 'القوة', 'الجهة', 'الكتيبة/اللواء', 'المعسكر', 'unit', 'Unit', 'brigade'], 'unit');
      const colBattalion = resolver(['الكتيبة', 'كتيبة', 'battalion', 'Battalion'], 'battalion');
      const colCompany = resolver(['السرية', 'سرية', 'company', 'Company'], 'company');
      const colPlatoon = resolver(['الفصيل', 'فصيل', 'platoon', 'Platoon'], 'platoon');
      
      const colStatus = resolver([
        'حالة الجاهزية الحالية', 'حالة الجاهزية', 'الجاهزية', 'الحالة الحالية', 'الحالة', 'حالة الفرد', 'تمام الفرد', 'التمام', 'الموقف', 'الموقف اليومي',
        'currentStatus', 'status', 'Status', 'readiness'
      ], 'currentStatus');

      const colJobTitle = resolver([
        'التخصص / المسمى الوظيفي', 'المسمى الوظيفي', 'الوظيفة', 'العمل', 'الموقع الوظيفي', 'التخصص', 'التخصص العسكري', 'المهنة', 'الاختصاص',
        'jobTitle', 'job_title', 'Job', 'roleTitle', 'specialization', 'role'
      ], 'jobTitle');

      const colPhone = resolver(['رقم التواصل', 'رقم الهاتف', 'الهاتف', 'الجوال', 'رقم الجوال', 'تلفون', 'موبايل', 'phone', 'Phone', 'mobile', 'contact'], 'phone');
      const colBloodType = resolver(['فصيلة الدم', 'فصيلة', 'زمرة الدم', 'الدم', 'bloodType', 'blood_type'], 'bloodType');
      const colEducation = resolver(['المؤهل العلمي', 'المؤهل التعليمي', 'المؤهل', 'المستوى التعليمي', 'الشهادة', 'الدرجة العلمية', 'education', 'educationLevel', 'degree'], 'education');
      const colEnlistmentDate = resolver(['تاريخ التجنيد', 'تاريخ الالتحاق', 'تاريخ التعيين', 'تاريخ المباشرة', 'enlistmentDate', 'enlistment_date', 'joinDate', 'hireDate'], 'enlistmentDate');
      const colPob = resolver(['المحافظة / مكان الميلاد', 'المحافظة / السكن', 'مكان الميلاد', 'المحافظة', 'السكن', 'العنوان', 'pob', 'address', 'governorate', 'birthPlace'], 'pob');
      const colDob = resolver(['تاريخ الميلاد', 'الميلاد', 'تاريخ الولادة', 'dob', 'birthDate', 'birth_date'], 'dob');
      const colMaritalStatus = resolver(['الحالة الاجتماعية', 'الحالة العائلية', 'الزواج', 'maritalStatus', 'marital_status'], 'maritalStatus');
      const colMotherName = resolver(['اسم الأم', 'الأم', 'اسم والدة الفرد', 'motherName', 'mother'], 'motherName');
      const colGuarantorName = resolver(['اسم الضمين', 'الضمين', 'الكفيل', 'اسم الكفيل', 'guarantorName', 'guarantor', 'sponsor'], 'guarantorName');
      const colRelativeName = resolver(['اسم القريب (طوارئ)', 'اسم القريب طوارئ', 'اسم أقرب الأقارب', 'اسم القريب', 'أقرب أقارب', 'قريب', 'الطوارئ', 'relativeName', 'nextOfKinName', 'emergencyContact'], 'relativeName');
      const colRelativePhone = resolver(['رقم هاتف القريب', 'هاتف القريب', 'جوال القريب', 'رقم هاتف أقرب الأقارب', 'هاتف الطوارئ', 'relativePhone', 'nextOfKinPhone', 'emergencyPhone'], 'relativePhone');
      const colSecondedUnit = resolver(['الوحدة المنتدب إليها', 'الانتداب', 'الجهة المنتدب لها', 'منتدب إلى', 'secondedUnit', 'deputation'], 'secondedUnit');
      const colTrainingCourse = resolver(['نوع ومسمى الدورة التدريبية', 'نوع ومسمى الدورة', 'الدورة التدريبية', 'الدورة', 'نوع الدورة', 'مسمى الدورة', 'course', 'trainingCourse', 'courseType'], 'trainingCourseType');

      parsedData.forEach((row: any, idx: number) => {
        const rawMilitaryId = cleanIdOrNumber(getValueByCol(row, colMilitaryId));
        const rawFullName = getValueByCol(row, colFullName);
        const rawRank = getValueByCol(row, colRank);
        const rawNationalId = cleanIdOrNumber(getValueByCol(row, colNationalId));
        const rawUnit = getValueByCol(row, colUnit);
        const rawBattalion = getValueByCol(row, colBattalion);
        const rawCompany = getValueByCol(row, colCompany);
        const rawPlatoon = getValueByCol(row, colPlatoon);
        const rawStatus = getValueByCol(row, colStatus);
        const rawJobTitle = getValueByCol(row, colJobTitle);
        const rawPhone = cleanIdOrNumber(getValueByCol(row, colPhone));
        const rawBloodType = getValueByCol(row, colBloodType);
        const rawEducation = getValueByCol(row, colEducation);
        const rawEnlistmentDate = parseExcelDate(getValueByCol(row, colEnlistmentDate));
        const rawPob = getValueByCol(row, colPob);
        const rawDob = parseExcelDate(getValueByCol(row, colDob));
        const rawMaritalStatus = getValueByCol(row, colMaritalStatus) as any;
        const rawMotherName = getValueByCol(row, colMotherName);
        const rawGuarantorName = getValueByCol(row, colGuarantorName);
        const rawRelativeName = getValueByCol(row, colRelativeName);
        const rawRelativePhone = cleanIdOrNumber(getValueByCol(row, colRelativePhone));
        const rawSecondedUnit = getValueByCol(row, colSecondedUnit);
        const rawTrainingCourse = getValueByCol(row, colTrainingCourse);

        // Skip completely empty rows
        if (!rawFullName && !rawMilitaryId && !rawNationalId) return;

        const militaryId = rawMilitaryId || `MIL-${Math.floor(100000 + Math.random() * 900000)}`;
        const matchedRank = normalizeRank(rawRank);
        const matchedStatus = normalizeStatus(rawStatus);

        // Fast O(1) indexed lookup for existing record
        const existing = (rawMilitaryId ? militaryIdIndex.get(normalizeArabicKey(rawMilitaryId)) : null)
          || (rawNationalId ? nationalIdIndex.get(normalizeArabicKey(rawNationalId)) : null)
          || (rawFullName ? fullNameIndex.get(normalizeArabicKey(rawFullName)) : null);

        if (existing) {
          // Update existing personnel record
          const updatedRecord: PersonnelRecord = {
            ...existing,
            fullName: rawFullName || existing.fullName,
            rank: matchedRank || existing.rank,
            unit: rawUnit || existing.unit,
            battalion: rawBattalion || existing.battalion,
            company: rawCompany || existing.company,
            platoon: rawPlatoon || existing.platoon,
            currentStatus: matchedStatus,
            jobTitle: rawJobTitle || existing.jobTitle,
            phone: rawPhone || existing.phone,
            nationalId: rawNationalId || existing.nationalId,
            bloodType: (['A+', 'A-', 'B+', 'B-', 'AB+', 'AB-', 'O+', 'O-'].includes(rawBloodType) ? rawBloodType : existing.bloodType) as any,
            education: rawEducation || existing.education,
            enlistmentDate: rawEnlistmentDate || existing.enlistmentDate,
            pob: rawPob || existing.pob,
            dob: rawDob || existing.dob,
            maritalStatus: (['أعزب', 'متزوج', 'مطلق', 'أرمل'].includes(rawMaritalStatus) ? rawMaritalStatus : existing.maritalStatus) as any,
            motherName: rawMotherName || existing.motherName,
            guarantorName: rawGuarantorName || existing.guarantorName,
            relativeName: rawRelativeName || existing.relativeName,
            relativePhone: rawRelativePhone || existing.relativePhone,
            secondedUnit: rawSecondedUnit || existing.secondedUnit,
            trainingCourseType: rawTrainingCourse || existing.trainingCourseType
          };

          if (existing.currentStatus !== matchedStatus) {
            updatedRecord.logs = {
              ...existing.logs,
              attendance: [
                {
                  id: `att-upd-${Date.now()}-${idx}`,
                  date: new Date().toISOString().split('T')[0],
                  type: matchedStatus === 'متواجد' || matchedStatus === 'في الميدان' ? 'حضور' : 'إجازة',
                  reason: `تحديث جاهزية يومي مستورد من ملف إكسل (${matchedStatus})`,
                  durationDays: 1,
                  approvedBy: 'تحديث الجاهزية اليومية',
                  startDate: new Date().toISOString().split('T')[0]
                },
                ...(existing.logs?.attendance || [])
              ]
            };
          }

          resultMap.set(existing.militaryId, updatedRecord);
          updatedCount++;
        } else {
          // Add brand new personnel record
          const newRecord: PersonnelRecord = {
            militaryId,
            nationalId: rawNationalId || `10${Math.floor(100000000 + Math.random() * 900000000)}`,
            fullName: rawFullName || `فرد عسكري جديد ${idx + 1}`,
            rank: matchedRank,
            dob: rawDob || '1998-01-01',
            pob: rawPob || 'صنعاء',
            maritalStatus: (['أعزب', 'متزوج', 'مطلق', 'أرمل'].includes(rawMaritalStatus) ? rawMaritalStatus : 'أعزب') as any,
            education: rawEducation || 'ثانوية عامة',
            specialization: rawJobTitle || 'مشاة عام',
            bloodType: (['A+', 'A-', 'B+', 'B-', 'AB+', 'AB-', 'O+', 'O-'].includes(rawBloodType) ? rawBloodType : 'O+') as any,
            phone: rawPhone || 'غير مسجل',
            motherName: rawMotherName || 'غير مسجل',
            guarantorName: rawGuarantorName || 'غير مسجل',
            relativeName: rawRelativeName || 'غير مسجل',
            relativePhone: rawRelativePhone || 'غير مسجل',
            photoUrl: '',
            biometricsRecorded: true,
            unit: rawUnit || 'اللواء الأول المدرع',
            battalion: rawBattalion || 'الكتيبة الأولى',
            company: rawCompany || 'السرية الأولى',
            platoon: rawPlatoon || 'الفصيل الأول',
            jobTitle: rawJobTitle || 'فرد عسكري',
            enlistmentDate: rawEnlistmentDate || new Date().toISOString().split('T')[0],
            currentStatus: matchedStatus,
            secondedUnit: rawSecondedUnit || '',
            trainingCourseType: rawTrainingCourse || '',
            createdByAccountId: getAccountIdForUnit(rawUnit, currentAccId),
            logs: {
              movement: [],
              attendance: [
                {
                  id: `att-init-${Date.now()}-${idx}`,
                  date: new Date().toISOString().split('T')[0],
                  type: matchedStatus === 'متواجد' || matchedStatus === 'في الميدان' ? 'حضور' : 'إجازة',
                  reason: `تسجيل الجاهزية الأولية (${matchedStatus})`,
                  durationDays: 1,
                  approvedBy: 'نظام كشوفات الجاهزية',
                  startDate: new Date().toISOString().split('T')[0]
                }
              ],
              medical: [],
              financial: [],
              security: [],
              armament: [],
              training: [],
              attachments: [],
              supply: []
            }
          };
          resultMap.set(militaryId, newRecord);
          addedCount++;
        }
      });

      if (updatedCount === 0 && addedCount === 0) {
        setImportSuccess(null);
        setImportError(
          `⚠️ تم قراءة ملف الإكسل وفحص ${parsedData.length} صف، ولكن تعذر التعرف على بيانات الأفراد.\n💡 يرجى التأكد من عناوين الأعمدة أو تنزيل "القالب المعتمد للإكسل" لتعبئة بياناتك.`
        );
      } else {
        const updatedList = Array.from(resultMap.values());
        StorageService.savePersonnel(updatedList);

        // High-performance batch synchronize rank salaries in payroll system (100x faster)
        StorageService.batchUpdateSalariesOnImport(updatedList);

        // Audit Log
        StorageService.logAction(
          'مدير المنظومة',
          'إدارة الموارد البشرية',
          'استيراد كشف إكسل أفراد',
          'BATCH-EXCEL',
          'استيراد أفراد وتحديث جاهزية',
          `تم استيراد ملف إكسل شامل: إدراج (${addedCount}) فرد جديد وتحديث جاهزية وبيانات (${updatedCount}) فرد.`
        );

        if (onPersonnelImported) {
          onPersonnelImported(updatedList);
        }

        setImportError(null);
        setImportSuccess(`✅ تم استيراد وتحديث البيانات بنجاح تام وبدون أي أخطاء! تم إضافة (${addedCount}) فرد جديد، وتحديث بيانات وجاهزية (${updatedCount}) فرد في قاعدة البيانات. 🛡️ (إجمالي السجلات: ${addedCount + updatedCount})`);
      }

      setParsedData([]);
      setFileInfo(null);
    } catch (err: any) {
      console.error('Personnel import error:', err);
      setImportError('حدث خطأ أثناء معالجة بيانات الأفراد. يرجى التأكد من مطابقة الأعمدة.');
    }
  };

  // Helper to map weapon name to caliber, ammo name, and category
  const getCaliberAndAmmoForWeapon = (wType: string) => {
    const t = (wType || '').trim().toLowerCase();
    if (t.includes('كلاش') || t.includes('ak') || t.includes('صيني')) {
      return { caliber: '7.62×39mm', ammoName: 'ذخيرة 7.62×39mm (كلاش صيني)', category: 'بنادق هجومية' };
    }
    if (t.includes('دراغانوف') || t.includes('دراغنوف') || t.includes('قناصة دراغانوف')) {
      return { caliber: '7.62×54mmR', ammoName: 'ذخيرة 7.62×54mmR (دراغانوف / شيكي)', category: 'بنادق قنص' };
    }
    if (t.includes('50') || t.includes('٥٠') || t.includes('شتاير')) {
      return { caliber: '12.7×99mm (.50 BMG)', ammoName: 'ذخيرة 12.7×99mm (قناصة عيار 50)', category: 'بنادق قنص ثقيلة' };
    }
    if (t.includes('23') || t.includes('٢٣')) {
      return { caliber: '23×152mm', ammoName: 'ذخيرة عيار 23mm (مضاد طائرات)', category: 'أسلحة ثقيلة ومضاد طائرات' };
    }
    if (t.includes('14') || t.includes('١٤')) {
      return { caliber: '14.5×114mm', ammoName: 'ذخيرة عيار 14.5mm', category: 'رشاشات ثقيلة' };
    }
    if (t.includes('12') || t.includes('١٢') || t.includes('دوشكا') || t.includes('براونينغ')) {
      return { caliber: '12.7×108mm', ammoName: 'ذخيرة عيار 12.7mm (دوشكا)', category: 'رشاشات ثقيلة' };
    }
    if (t.includes('شيكي') || t.includes('معدل') || t.includes('بكت') || t.includes('pkm') || t.includes('pkt')) {
      return { caliber: '7.62×54mmR', ammoName: 'ذخيرة معدل شيكي 7.62mm', category: 'رشاشات متوسطة' };
    }
    if (t.includes('106') || t.includes('١٠٦')) {
      return { caliber: '106mm HEAT', ammoName: 'قذائف مدفع 106mm مضادة للدروع', category: 'مدفعية عديمة الارتداد' };
    }
    if (t.includes('راجمة') || t.includes('صاروخ') || t.includes('107') || t.includes('122')) {
      return { caliber: '107mm / 122mm Rocket', ammoName: 'صواريخ راجمة 107mm / 122mm', category: 'مدفعية صواريخ' };
    }
    if (t.includes('هاون 120') || t.includes('هاون ١٢٠')) {
      return { caliber: '120mm Mortar', ammoName: 'قذائف هاون 120mm', category: 'سلاح المدفعية والهاونات' };
    }
    if (t.includes('هاون 80') || t.includes('هاون 81') || t.includes('هاون 82') || t.includes('هاون ٨٠')) {
      return { caliber: '80mm Mortar', ammoName: 'قذائف هاون 80mm', category: 'سلاح المدفعية والهاونات' };
    }
    if (t.includes('هاون 60') || t.includes('هاون ٦٠') || t.includes('هاون')) {
      return { caliber: '60mm Mortar', ammoName: 'قذائف هاون 60mm', category: 'سلاح المدفعية والهاونات' };
    }
    if (t.includes('m4') || t.includes('m16') || t.includes('5.56') || t.includes('ام فور')) {
      return { caliber: '5.56×45mm NATO', ammoName: 'ذخيرة حية 5.56mm NATO', category: 'بنادق هجومية' };
    }
    if (t.includes('غلوك') || t.includes('جلوك') || t.includes('glock') || t.includes('مسدس')) {
      return { caliber: '9×19mm Parabellum', ammoName: 'ذخيرة حية 9×19mm Parabellum', category: 'مسدسات شخصية' };
    }
    return { caliber: '7.62×39mm', ammoName: 'ذخيرة 7.62×39mm (كلاش صيني)', category: 'بنادق هجومية' };
  };

  // Process Armament Import & Comprehensive Multi-System Synchronization
  const processArmamentImport = () => {
    if (parsedData.length === 0) return;

    try {
      const resolver = buildColumnResolver(parsedData[0]);

      // Resolve 10 canonical columns + all variants
      const colMilitaryId = resolver([
        'الرقم الوظيفي', 'الرقم العسكري', 'رقم الوظيفة', 'الرقم', 'رقم الفرد', 'الكود', 'كود الفرد',
        'militaryId', 'military_id', 'jobId', 'id', 'ID', 'no', 'No'
      ]);
      const colFullName = resolver([
        'الاسم الكامل', 'الاسم الرباعي', 'الاسم الثلاثي', 'الاسم', 'اسم الفرد', 'اسم المستلم', 'المستلم', 'اسم الضابط',
        'fullName', 'full_name', 'name', 'Name', 'recipientName'
      ]);
      const colWeaponType = resolver([
        'نوع السلاح العهدة', 'نوع السلاح', 'السلاح', 'نوع العهدة', 'اسم السلاح', 'موديل السلاح', 'قطعة السلاح',
        'weaponType', 'weapon_type', 'weapon', 'type', 'Type', 'model'
      ]);
      const colWeaponSerial = resolver([
        'رقم السلاح', 'الرقم التسلسلي', 'سيريال السلاح', 'السيريال', 'رقم القطعة', 'سلسلة السلاح', 'رقم السلاح العهدة',
        'weaponSerial', 'weapon_serial', 'serialNumber', 'serial_number', 'serial', 'Serial', 'sn', 'SN'
      ]);
      const colMagazinesCount = resolver([
        'عدد المخازن', 'المخازن', 'عدد الخزن', 'الخزائن', 'خزائن', 'خزنات', 'عدد خزن السلاح', 'خطوط النار', 'عدد خطوط النار',
        'magazinesCount', 'magazines_count', 'magazines', 'firelinesCount', 'firelines'
      ]);
      const colAmmoQty = resolver([
        'عدد الذخيرة المنصرفة', 'الذخيرة المنصرفة', 'عدد الذخيرة', 'الذخيرة', 'طلقات الذخيرة', 'عدد الطلقات', 'الطلقات', 'كمية الذخيرة', 'المنصرف من الذخيرة',
        'ammoQty', 'ammo_qty', 'ammoCount', 'ammo', 'issuedAmmoQty', 'quantity'
      ]);
      const colCondition = resolver([
        'حالة السلاح', 'الحالة الفنية', 'حالة القطعة', 'الحالة الفنية للسلاح', 'فحص السلاح', 'صلاحية السلاح',
        'technicalCondition', 'condition', 'technical_condition', 'weaponCondition'
      ]);
      const colIssueDate = resolver([
        'تاريخ الصرف', 'تاريخ الاستلام', 'تاريخ التسليم', 'تاريخ العهدة', 'تاريخ القيد', 'تاريخ التسجيل', 'التاريخ',
        'issueDate', 'issue_date', 'date', 'Date', 'entryDate', 'entry_date'
      ]);
      const colStatus = resolver([
        'الحالة', 'حالة الفرد', 'حالة الجاهزية', 'تمام الفرد', 'حالة العهدة', 'حالة التواجد',
        'currentStatus', 'status', 'Status', 'readinessStatus', 'personnelStatus'
      ]);

      const existingPersonnel = StorageService.getPersonnel();
      const existingWeapons = StorageService.getArmoryWeapons();
      const existingInventory = StorageService.getArmoryInventory();
      const existingIssues = StorageService.getArmoryIssues();

      const personnelMap = new Map<string, PersonnelRecord>();
      const personnelMilitaryIdMap = new Map<string, PersonnelRecord>();
      const personnelFullNameMap = new Map<string, PersonnelRecord>();

      existingPersonnel.forEach(p => {
        const copy = { ...p };
        personnelMap.set(p.militaryId, copy);
        if (p.militaryId) personnelMilitaryIdMap.set(normalizeArabicKey(p.militaryId), copy);
        if (p.fullName) personnelFullNameMap.set(normalizeArabicKey(p.fullName), copy);
      });

      const weaponsMap = new Map<string, ArmoryWeaponPiece>();
      existingWeapons.forEach(w => {
        if (w.serialNumber) weaponsMap.set(normalizeArabicKey(w.serialNumber), { ...w });
      });

      const activeCode = typeof window !== 'undefined' ? localStorage.getItem('military_active_account_v1') : 'hq';
      const activeAcc = BRIGADE_ACCOUNTS.find(a => a.id === activeCode || a.shortCode === activeCode || a.customAccessKey === activeCode);
      const currentAccId = activeAcc ? activeAcc.id : 'hq';

      let totalAmmoImported = 0;
      let totalMagazinesImported = 0;
      let totalWeaponsProcessed = 0;
      let updatedPersonnelCount = 0;
      let addedPersonnelCount = 0;

      const newArmoryPiecesList: ArmoryWeaponPiece[] = [];

      parsedData.forEach((row: any, idx: number) => {
        const rawMilitaryId = cleanIdOrNumber(getValueByCol(row, colMilitaryId));
        const rawFullName = getValueByCol(row, colFullName);
        const rawWeaponType = getValueByCol(row, colWeaponType) || 'كلاش صيني';
        const rawWeaponSerial = cleanIdOrNumber(getValueByCol(row, colWeaponSerial));
        const rawMagazinesVal = cleanCellValue(getValueByCol(row, colMagazinesCount));
        const magazinesCount = rawMagazinesVal && !isNaN(Number(rawMagazinesVal)) ? Math.max(0, parseInt(rawMagazinesVal, 10)) : 6;
        const rawAmmoVal = cleanCellValue(getValueByCol(row, colAmmoQty));
        const ammoQty = rawAmmoVal && !isNaN(Number(rawAmmoVal)) ? Math.max(0, parseInt(rawAmmoVal, 10)) : 180;
        const rawCondition = getValueByCol(row, colCondition);
        const issueDate = parseExcelDate(getValueByCol(row, colIssueDate)) || new Date().toISOString().split('T')[0];
        const rawStatus = getValueByCol(row, colStatus);

        // Skip completely empty rows
        if (!rawFullName && !rawMilitaryId && !rawWeaponSerial && !rawWeaponType) return;

        totalAmmoImported += ammoQty;
        totalMagazinesImported += magazinesCount;
        totalWeaponsProcessed++;

        const statusText = (rawStatus || '').trim() || 'متواجد';
        const isStorage = statusText.includes('مخازن') || statusText.includes('مخزن') || statusText.includes('مستودع') || statusText.includes('مورد') || statusText.includes('توريد');
        const isEscaped = statusText.includes('فرار') || statusText.includes('فار') || statusText.includes('هروب');
        const isMission = statusText.includes('مامورية') || statusText.includes('مأمورية') || statusText.includes('مهمة');
        const isField = statusText.includes('ميدان');
        const isLeave = statusText.includes('إجازة') || statusText.includes('اجازة');
        const isPerm = statusText.includes('إذن') || statusText.includes('اذن');
        const isHospital = statusText.includes('مستشفى') || statusText.includes('مرض');
        const isAbsent = statusText.includes('غياب');

        let targetPersonnelStatus: PersonnelStatus = 'متواجد';
        if (isEscaped) targetPersonnelStatus = 'فرار';
        else if (isMission) targetPersonnelStatus = 'مأمورية';
        else if (isField) targetPersonnelStatus = 'في الميدان';
        else if (isLeave) targetPersonnelStatus = 'إجازة';
        else if (isPerm) targetPersonnelStatus = 'إذن';
        else if (isHospital) targetPersonnelStatus = 'مستشفى';
        else if (isAbsent) targetPersonnelStatus = 'غياب';
        else targetPersonnelStatus = 'متواجد';

        // Parse technical condition
        const condClean = (rawCondition || '').trim();
        let technicalCondition: 'جاهز' | 'تحتاج صيانة' | 'غير جاهز' | 'معطوبة' = 'جاهز';
        let armLogCondition: 'ممتازة' | 'جيدة' | 'تحتاج صيانة' | 'معطوبة' = 'ممتازة';

        if (condClean.includes('معطوب') || condClean.includes('تالف') || condClean.includes('خارج')) {
          technicalCondition = 'معطوبة';
          armLogCondition = 'معطوبة';
        } else if (condClean.includes('صيانة') || condClean.includes('فحص') || condClean.includes('عطل')) {
          technicalCondition = 'تحتاج صيانة';
          armLogCondition = 'تحتاج صيانة';
        } else if (condClean.includes('غير جاهز') || condClean.includes('رديء')) {
          technicalCondition = 'غير جاهز';
          armLogCondition = 'معطوبة';
        } else if (condClean.includes('جيد') && !condClean.includes('جدا')) {
          technicalCondition = 'جاهز';
          armLogCondition = 'جيدة';
        } else {
          technicalCondition = 'جاهز';
          armLogCondition = 'ممتازة';
        }

        const { caliber, ammoName } = getCaliberAndAmmoForWeapon(rawWeaponType);
        const finalSerial = rawWeaponSerial || `WP-${Math.floor(100000 + Math.random() * 900000)}`;
        const militaryId = rawMilitaryId || (rawFullName ? `MIL-${Math.abs(rawFullName.split('').reduce((a, b) => ((a << 5) - a) + b.charCodeAt(0), 0)).toString().slice(0, 6)}` : `MIL-${Date.now().toString().slice(-6)}`);
        const fullName = rawFullName || `فرد عسكري (${militaryId})`;

        // 1. UPDATE OR CREATE PERSONNEL RECORD
        let targetPerson = (rawMilitaryId ? personnelMilitaryIdMap.get(rawMilitaryId) : null)
          || (rawFullName ? personnelFullNameMap.get(rawFullName) : null);

        const armamentLogEntry = {
          id: `arm-imp-${Date.now()}-${idx}`,
          weaponSerial: finalSerial,
          weaponType: rawWeaponType,
          issueDate: issueDate,
          returnDate: isStorage ? issueDate : undefined,
          ammoQty: ammoQty,
          firelinesCount: magazinesCount,
          condition: armLogCondition,
          technicalNotes: `كشف التسليح والجاهزية - الحالة: ${statusText} | عدد المخازن: ${magazinesCount} | الذخيرة: ${ammoQty}`,
          ammoHistory: [
            {
              id: `ammo-act-${Date.now()}-${idx}`,
              type: (isStorage ? 'استرجاع' : 'صرف') as any,
              quantity: ammoQty,
              date: issueDate,
              reason: `عهدة مقيدة عبر كشف التسليح (${statusText})`,
              issuedBy: 'فرع التسليح والعمليات'
            }
          ]
        };

        if (targetPerson) {
          // Update existing personnel
          const existingArmLogs = targetPerson.logs?.armament || [];
          const updatedArmLogs = [
            armamentLogEntry,
            ...existingArmLogs.filter(a => a.weaponSerial !== finalSerial)
          ];

          const updatedLogs = {
            ...(targetPerson.logs || {}),
            movement: targetPerson.logs?.movement || [],
            attendance: [
              {
                id: `att-arm-${Date.now()}-${idx}`,
                date: issueDate,
                type: (targetPersonnelStatus === 'متواجد' || targetPersonnelStatus === 'في الميدان' ? 'حضور' : 'إجازة') as any,
                reason: `تحديث كشف التسليح والجاهزية (${statusText})`,
                durationDays: 1,
                approvedBy: 'فرع التسليح والعمليات',
                startDate: issueDate,
                withWeapon: !isStorage,
                weaponDetails: {
                  primaryWeapon: {
                    weaponType: rawWeaponType,
                    weaponSerial: finalSerial,
                    magazinesCount: magazinesCount,
                    ammoCount: ammoQty
                  },
                  totalAmmo: ammoQty,
                  totalMagazines: magazinesCount
                }
              },
              ...(targetPerson.logs?.attendance || [])
            ],
            medical: targetPerson.logs?.medical || [],
            financial: targetPerson.logs?.financial || [],
            security: isEscaped ? [
              {
                id: `sec-esc-${Date.now()}-${idx}`,
                date: issueDate,
                violation: 'فرار بالعهدة العسكرية والسلاح المسند',
                investigationDetails: `تم رصد فرار بالسلاح لقطعة: ${rawWeaponType} برقم (${finalSerial}) مع ${magazinesCount} مخازن و ${ammoQty} طلقة حية.`,
                penalty: 'تعميم أمني وإحالة للنيابة والقضاء العسكري وضبط وإحضار',
                warningLevel: 'شديد الخطورة' as const,
                detentionOrder: 'أمر ضبط وإحضار عسكري فوري',
                authority: 'شعبة الاستخبارات والشرطة العسكرية',
                status: 'قيد التحقيق' as const
              },
              ...(targetPerson.logs?.security || [])
            ] : (targetPerson.logs?.security || []),
            armament: updatedArmLogs,
            training: targetPerson.logs?.training || [],
            attachments: targetPerson.logs?.attachments || [],
            supply: targetPerson.logs?.supply || []
          };

          const updatedPerson: PersonnelRecord = {
            ...targetPerson,
            fullName: rawFullName || targetPerson.fullName,
            currentStatus: targetPersonnelStatus,
            logs: updatedLogs
          };

          personnelMap.set(targetPerson.militaryId, updatedPerson);
          updatedPersonnelCount++;
        } else {
          // Create new Personnel Record
          const newPerson: PersonnelRecord = {
            militaryId: militaryId,
            nationalId: `10${Math.floor(100000000 + Math.random() * 900000000)}`,
            fullName: fullName,
            rank: 'جندي',
            dob: '1998-01-01',
            pob: 'صنعاء',
            maritalStatus: 'أعزب',
            education: 'ثانوية عامة',
            specialization: 'مشاة عام',
            bloodType: 'O+',
            phone: 'غير مسجل',
            motherName: 'غير مسجل',
            guarantorName: 'غير مسجل',
            relativeName: 'غير مسجل',
            relativePhone: 'غير مسجل',
            photoUrl: '',
            biometricsRecorded: true,
            unit: 'اللواء الأول المدرع',
            battalion: 'الكتيبة الأولى',
            company: 'السرية الأولى',
            platoon: 'الفصيل الأول',
            jobTitle: 'فرد عسكري',
            enlistmentDate: issueDate,
            currentStatus: targetPersonnelStatus,
            secondedUnit: '',
            createdByAccountId: getAccountIdForUnit('اللواء الأول المدرع', currentAccId),
            logs: {
              movement: [],
              attendance: [
                {
                  id: `att-init-${Date.now()}-${idx}`,
                  date: issueDate,
                  type: (targetPersonnelStatus === 'متواجد' || targetPersonnelStatus === 'في الميدان' ? 'حضور' : 'إجازة') as any,
                  reason: `قيد أولي عبر كشف التسليح (${statusText})`,
                  durationDays: 1,
                  approvedBy: 'فرع التسليح والعمليات',
                  startDate: issueDate,
                  withWeapon: !isStorage,
                  weaponDetails: {
                    primaryWeapon: {
                      weaponType: rawWeaponType,
                      weaponSerial: finalSerial,
                      magazinesCount: magazinesCount,
                      ammoCount: ammoQty
                    },
                    totalAmmo: ammoQty,
                    totalMagazines: magazinesCount
                  }
                }
              ],
              medical: [],
              financial: [],
              security: isEscaped ? [
                {
                  id: `sec-esc-${Date.now()}-${idx}`,
                  date: issueDate,
                  violation: 'فرار بالعهدة العسكرية والسلاح المسند',
                  investigationDetails: `فرار بالسلاح لقطعة: ${rawWeaponType} برقم (${finalSerial}) مع ${magazinesCount} مخازن و ${ammoQty} طلقة.`,
                  penalty: 'تعميم أمني فوري',
                  warningLevel: 'شديد الخطورة',
                  authority: 'الشرطة العسكرية',
                  status: 'قيد التحقيق'
                }
              ] : [],
              armament: [armamentLogEntry],
              training: [],
              attachments: [],
              supply: []
            }
          };

          personnelMap.set(militaryId, newPerson);
          personnelMilitaryIdMap.set(militaryId, newPerson);
          personnelFullNameMap.set(fullName, newPerson);
          targetPerson = newPerson;
          addedPersonnelCount++;
        }

        // 2. UPDATE OR CREATE ARMORY WEAPON PIECE
        const serialLower = finalSerial.trim().toLowerCase();
        const existingPiece = weaponsMap.get(serialLower);

        const updatedPiece: ArmoryWeaponPiece = {
          id: existingPiece ? existingPiece.id : `wpn-imp-${Date.now()}-${idx}`,
          serialNumber: finalSerial,
          weaponType: rawWeaponType,
          caliber: caliber,
          manufactureYear: existingPiece?.manufactureYear || '2024',
          technicalCondition: technicalCondition,
          status: isStorage ? 'في المخزن' : (technicalCondition === 'تحتاج صيانة' ? 'في الصيانة' : 'منصرف للفرد'),
          currentHolderMilitaryId: isStorage ? undefined : targetPerson.militaryId,
          currentHolderName: isStorage ? undefined : targetPerson.fullName,
          currentHolderRank: isStorage ? undefined : targetPerson.rank,
          currentHolderUnit: isStorage ? undefined : targetPerson.unit,
          storageLocation: isStorage ? 'مستودع التسليح المركزي' : 'عهدة فردية مسندة',
          entryDate: issueDate,
          notes: `كشف التسليح - الحالة: ${statusText} | مخازن: ${magazinesCount} | ذخيرة: ${ammoQty}`
        };

        weaponsMap.set(serialLower, updatedPiece);
        newArmoryPiecesList.push(updatedPiece);

        // 3. CREATE ISSUE ORDER AUDIT
        if (!isStorage) {
          const newOrder: ArmoryIssueOrder = {
            id: `ORD-IMP-${Date.now()}-${idx}`,
            orderNumber: `ORD-${Math.floor(10000 + Math.random() * 90000)}`,
            date: issueDate,
            recipientName: targetPerson.fullName,
            recipientMilitaryId: targetPerson.militaryId,
            recipientRank: targetPerson.rank,
            unit: targetPerson.unit,
            weaponType: rawWeaponType,
            weaponSerial: finalSerial,
            ammoType: ammoName,
            ammoCaliber: caliber,
            issuedAmmoQty: ammoQty,
            issueReason: `صرف عهدة تسليح بموجب كشف التسليح والجاهزية (${statusText})`,
            orderReference: 'كشف استيراد إكسل فرع التسليح',
            responsibleOfficer: 'رئيس فرع التسليح والعمليات',
            status: 'نشط',
            notes: `عدد المخازن: ${magazinesCount} | الحالة الفنية: ${armLogCondition}`
          };
          existingIssues.unshift(newOrder);
        }
      });

      if (totalWeaponsProcessed === 0) {
        setImportSuccess(null);
        setImportError(
          `⚠️ تم قراءة ملف الإكسل وفحص ${parsedData.length} صف، ولكن تعذر التعرف على بيانات التسليح والعهد.\n💡 يرجى التأكد من عناوين الأعمدة أو تنزيل "القالب المعتمد للإكسل" لتعبئة بياناتك.`
        );
        return;
      }

      // 4. UPDATE ARMORY INVENTORY STOCKS & AMMUNITION BALANCES
      const allFinalWeapons = Array.from(weaponsMap.values());
      const updatedInventory = [...existingInventory];

      // Tally weapons by model
      const weaponTypeCounts = new Map<string, { total: number; issued: number; inStore: number; maint: number }>();
      allFinalWeapons.forEach(w => {
        const type = w.weaponType || 'كلاش صيني';
        const current = weaponTypeCounts.get(type) || { total: 0, issued: 0, inStore: 0, maint: 0 };
        current.total++;
        if (w.status === 'منصرف للفرد') current.issued++;
        else if (w.status === 'في الصيانة') current.maint++;
        else current.inStore++;
        weaponTypeCounts.set(type, current);
      });

      // Update weapon inventory records
      weaponTypeCounts.forEach((counts, wType) => {
        const { caliber, category } = getCaliberAndAmmoForWeapon(wType);
        const idx = updatedInventory.findIndex(inv => inv.itemType === 'weapon' && inv.name.trim().toLowerCase() === wType.trim().toLowerCase());
        if (idx >= 0) {
          updatedInventory[idx].totalReceived = Math.max(updatedInventory[idx].totalReceived, counts.total);
          updatedInventory[idx].issuedQty = counts.issued;
          updatedInventory[idx].availableQty = Math.max(0, updatedInventory[idx].totalReceived - counts.issued - counts.maint);
          updatedInventory[idx].inMaintenanceQty = counts.maint;
          updatedInventory[idx].lastUpdated = new Date().toISOString().split('T')[0];
        } else {
          updatedInventory.push({
            id: `inv-w-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
            itemType: 'weapon',
            name: wType,
            category: category,
            caliber: caliber,
            totalReceived: counts.total + 5,
            availableQty: counts.inStore + 5,
            issuedQty: counts.issued,
            inMaintenanceQty: counts.maint,
            minThreshold: 10,
            storageLocation: 'مستودع التسليح الرئيسي',
            unit: 'اللواء الأول المدرع',
            lastUpdated: new Date().toISOString().split('T')[0]
          });
        }
      });

      // Tally ammunition by caliber/name
      const ammoByCaliber = new Map<string, number>();
      Array.from(personnelMap.values()).forEach(p => {
        if (p.logs?.armament && p.logs.armament.length > 0) {
          p.logs.armament.forEach(a => {
            if (!a.returnDate && a.ammoQty) {
              const { ammoName } = getCaliberAndAmmoForWeapon(a.weaponType);
              ammoByCaliber.set(ammoName, (ammoByCaliber.get(ammoName) || 0) + a.ammoQty);
            }
          });
        }
      });

      ammoByCaliber.forEach((totalIssued, ammoName) => {
        const idx = updatedInventory.findIndex(inv => inv.itemType === 'ammo' && inv.name.trim().toLowerCase() === ammoName.trim().toLowerCase());
        if (idx >= 0) {
          updatedInventory[idx].issuedQty = totalIssued;
          if (updatedInventory[idx].totalReceived < totalIssued + 1000) {
            updatedInventory[idx].totalReceived = totalIssued + 5000;
          }
          updatedInventory[idx].availableQty = Math.max(0, updatedInventory[idx].totalReceived - totalIssued);
          updatedInventory[idx].lastUpdated = new Date().toISOString().split('T')[0];
        } else {
          updatedInventory.push({
            id: `inv-a-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
            itemType: 'ammo',
            name: ammoName,
            category: 'ذخائر حية',
            caliber: 'قياسي',
            totalReceived: totalIssued + 10000,
            availableQty: 10000,
            issuedQty: totalIssued,
            inMaintenanceQty: 0,
            minThreshold: 1000,
            storageLocation: 'مستودع الذخائر المركزي',
            unit: 'اللواء الأول المدرع',
            lastUpdated: new Date().toISOString().split('T')[0]
          });
        }
      });

      // 5. SAVE ALL DATA WITH CLOUD SYNCHRONIZATION
      const updatedPersonnelList = Array.from(personnelMap.values());
      StorageService.savePersonnel(updatedPersonnelList);
      StorageService.saveArmoryWeapons(allFinalWeapons);
      StorageService.saveArmoryInventory(updatedInventory);
      StorageService.saveArmoryIssues(existingIssues);

      // Audit Log
      StorageService.logAction(
        'ضابط التسليح والعمليات',
        'إدارة التسليح',
        'استيراد كشف عهد وتسليح إكسل',
        'ARMAMENT-EXCEL-IMPORT',
        'فرع التسليح والمستودع',
        `تم استيراد كشف التسليح بنجاح: معالجة (${totalWeaponsProcessed}) قطعة سلاح، واحتساب (${totalAmmoImported}) طلقة ذخيرة، و (${totalMagazinesImported}) مخزن، وتحديث جاهزية (${updatedPersonnelCount}) فرد وإضافة (${addedPersonnelCount}) فرد.`
      );

      if (onArmamentImported) {
        onArmamentImported(newArmoryPiecesList);
      }
      if (onPersonnelImported) {
        onPersonnelImported(updatedPersonnelList);
      }

      setImportError(null);
      setImportSuccess(
        `✅ تم استيراد كشف التسليح والعهد بنجاح تام وبدون أي أخطاء!\n🔫 تم معالجة وتوثيق (${totalWeaponsProcessed}) قطعة سلاح.\n🎯 تم احتساب وإسناد (${totalAmmoImported}) طلقة ذخيرة حية و (${totalMagazinesImported}) مخزن.\n👥 تم تحديث جاهزية وبيانات (${updatedPersonnelCount}) فرد وإدراج (${addedPersonnelCount}) فرد جديد بمستودع وقاعدة التسليح المركزية. 🛡️`
      );

      setParsedData([]);
      setFileInfo(null);
    } catch (err: any) {
      console.error('Armament import error:', err);
      setImportError('حدث خطأ أثناء معالجة بيانات قطع التسليح والعهد.');
    }
  };

  // Execute Import
  const handleExecuteImport = () => {
    setIsLoading(true);
    setTimeout(() => {
      if (activeType === 'personnel') {
        processPersonnelImport();
      } else {
        processArmamentImport();
      }
      setIsLoading(false);
    }, 50);
  };

  // Download Sample Excel Template matching Canonical Columns 100%
  const downloadSampleTemplate = (type: 'personnel' | 'armament') => {
    let headers: string[] = [];
    let sampleRows: any[] = [];
    let filename = '';
    let colWidths: { wch: number }[] = [];

    if (type === 'personnel') {
      filename = `قالب_كشف_القوة_البشرية_المعتمد_${new Date().toISOString().split('T')[0]}.xlsx`;
      headers = CANONICAL_PERSONNEL_COLUMNS.map(c => c.header);
      colWidths = CANONICAL_PERSONNEL_COLUMNS.map(c => ({ wch: c.width }));

      sampleRows = [
        {
          'م': 1,
          'الرقم العسكري': 'MIL-102031',
          'الاسم الكامل': 'سالم بن أحمد الحداء',
          'الرتبة العسكرية': 'نقيب',
          'رقم الهوية الوطنية': '1098765432',
          'الوحدة / اللواء': 'اللواء الأول المدرع',
          'الكتيبة': 'الكتيبة الأولى دبابات',
          'السرية': 'السرية الأولى',
          'الفصيل': 'الفصيل الأول',
          'حالة الجاهزية الحالية': 'متواجد',
          'التخصص / المسمى الوظيفي': 'قائد سرية مدرعات',
          'رقم التواصل': '0501112233',
          'فصيلة الدم': 'O+',
          'المؤهل العلمي': 'بكالوريوس علوم عسكرية',
          'تاريخ التجنيد': '2018-05-15',
          'المحافظة / مكان الميلاد': 'صنعاء',
          'تاريخ الميلاد': '1992-04-10',
          'الحالة الاجتماعية': 'متزوج',
          'اسم الأم': 'فاطمة محمد',
          'اسم الضمين': 'أحمد علي الحداء',
          'اسم القريب (طوارئ)': 'محمد أحمد الحداء',
          'رقم هاتف القريب': '0509998877',
          'الوحدة المنتدب إليها': '-'
        },
        {
          'م': 2,
          'الرقم العسكري': 'MIL-102032',
          'الاسم الكامل': 'عبد الله بن سعيد الأهدل',
          'الرتبة العسكرية': 'رقيب أول',
          'رقم الهوية الوطنية': '1087654321',
          'الوحدة / اللواء': 'اللواء الأول المدرع',
          'الكتيبة': 'الكتيبة الأولى دبابات',
          'السرية': 'السرية الثانية',
          'الفصيل': 'الفصيل الثاني',
          'حالة الجاهزية الحالية': 'في الميدان',
          'التخصص / المسمى الوظيفي': 'فني دروع ومدرعات',
          'رقم التواصل': '0504445566',
          'فصيلة الدم': 'A+',
          'المؤهل العلمي': 'دبلوم تقني ميكانيكا',
          'تاريخ التجنيد': '2020-03-01',
          'المحافظة / مكان الميلاد': 'الحديدة',
          'تاريخ الميلاد': '1996-08-22',
          'الحالة الاجتماعية': 'أعزب',
          'اسم الأم': 'مريم عبد الله',
          'اسم الضمين': 'سعيد الأهدل',
          'اسم القريب (طوارئ)': 'خالد سعيد الأهدل',
          'رقم هاتف القريب': '0503332211',
          'الوحدة المنتدب إليها': '-'
        },
        {
          'م': 3,
          'الرقم العسكري': 'MIL-102033',
          'الاسم الكامل': 'طارق بن صالح القحطاني',
          'الرتبة العسكرية': 'عريف',
          'رقم الهوية الوطنية': '1076543210',
          'الوحدة / اللواء': 'اللواء الأول المدرع',
          'الكتيبة': 'كتيبة الاستطلاع',
          'السرية': 'سرية المشاة الآلية',
          'الفصيل': 'فصيل الرصد',
          'حالة الجاهزية الحالية': 'إجازة',
          'التخصص / المسمى الوظيفي': 'رامي مدفعية ورصد',
          'رقم التواصل': '0507778899',
          'فصيلة الدم': 'B+',
          'المؤهل العلمي': 'ثانوية عامة',
          'تاريخ التجنيد': '2021-09-10',
          'المحافظة / مكان الميلاد': 'مأرب',
          'تاريخ الميلاد': '1999-11-05',
          'الحالة الاجتماعية': 'أعزب',
          'اسم الأم': 'نورة صالح',
          'اسم الضمين': 'صالح القحطاني',
          'اسم القريب (طوارئ)': 'عبد الرحمن القحطاني',
          'رقم هاتف القريب': '0506665544',
          'الوحدة المنتدب إليها': '-'
        }
      ];
    } else {
      filename = `قالب_كشف_التسليح_والعهد_المعتمد_${new Date().toISOString().split('T')[0]}.xlsx`;
      headers = CANONICAL_ARMAMENT_COLUMNS.map(c => c.header);
      colWidths = CANONICAL_ARMAMENT_COLUMNS.map(c => ({ wch: c.width }));

      sampleRows = [
        {
          'م': 1,
          'الرقم الوظيفي': 'MIL-102031',
          'الاسم الكامل': 'سالم بن أحمد الحداء',
          'نوع السلاح العهدة': 'كلاش صيني',
          'رقم السلاح': 'WP-88201',
          'عدد المخازن': 6,
          'عدد الذخيرة المنصرفة': 180,
          'حالة السلاح': 'ممتازة',
          'تاريخ الصرف': '2024-01-15',
          'الحالة': 'متواجد'
        },
        {
          'م': 2,
          'الرقم الوظيفي': 'MIL-102032',
          'الاسم الكامل': 'عبد الله بن سعيد الأهدل',
          'نوع السلاح العهدة': 'قناصة دراغانوف',
          'رقم السلاح': 'WP-88202',
          'عدد المخازن': 5,
          'عدد الذخيرة المنصرفة': 100,
          'حالة السلاح': 'ممتازة',
          'تاريخ الصرف': '2024-02-10',
          'الحالة': 'مامورية'
        },
        {
          'م': 3,
          'الرقم الوظيفي': 'MIL-102033',
          'الاسم الكامل': 'طارق بن صالح القحطاني',
          'نوع السلاح العهدة': 'بندقية هجومية M4A1',
          'رقم السلاح': 'WP-88203',
          'عدد المخازن': 4,
          'عدد الذخيرة المنصرفة': 120,
          'حالة السلاح': 'جيدة',
          'تاريخ الصرف': '2024-03-05',
          'الحالة': 'فرار بالسلاح'
        },
        {
          'م': 4,
          'الرقم الوظيفي': 'MIL-102034',
          'الاسم الكامل': 'فهد بن ناصر العولقي',
          'نوع السلاح العهدة': 'كلاش صيني',
          'رقم السلاح': 'WP-88204',
          'عدد المخازن': 6,
          'عدد الذخيرة المنصرفة': 180,
          'حالة السلاح': 'تحتاج صيانة',
          'تاريخ الصرف': '2024-04-01',
          'الحالة': 'في مخازن التسليح'
        },
        {
          'م': 5,
          'الرقم الوظيفي': 'MIL-102035',
          'الاسم الكامل': 'يحيى بن علي المرادي',
          'نوع السلاح العهدة': 'معدل شيكي',
          'رقم السلاح': 'WP-88205',
          'عدد المخازن': 3,
          'عدد الذخيرة المنصرفة': 300,
          'حالة السلاح': 'ممتازة',
          'تاريخ الصرف': '2024-05-12',
          'الحالة': 'في الميدان'
        }
      ];
    }

    const ws = XLSX.utils.json_to_sheet(sampleRows, { header: headers });
    ws['!cols'] = colWidths;

    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, 'القالب المعتمد');
    exportExcelWorkbook(wb, filename);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/85 backdrop-blur-xs animate-in fade-in duration-200" dir="rtl">
      <div className="bg-slate-900 border border-slate-800 text-slate-100 rounded-3xl max-w-3xl w-full p-6 space-y-6 shadow-2xl relative overflow-hidden font-['Cairo',sans-serif]">
        
        {/* Header bar */}
        <div className="flex items-center justify-between border-b border-slate-800 pb-4">
          <div className="flex items-center space-x-3 space-x-reverse">
            <div className="p-3 bg-emerald-500/20 text-emerald-400 rounded-2xl border border-emerald-500/30">
              <FileSpreadsheet className="w-6 h-6" />
            </div>
            <div>
              <h2 className="text-lg font-extrabold text-white font-['Tajawal'] flex items-center space-x-2 space-x-reverse">
                <span>استيراد وتحديث كشوفات إكسل (Excel / CSV) 📊</span>
                <span className="text-[11px] bg-emerald-500/20 text-emerald-300 border border-emerald-500/40 px-2 py-0.5 rounded-md font-bold">
                  مطابق 100% لكشف التصدير
                </span>
              </h2>
              <p className="text-xs text-slate-400">
                استيراد موحد بنفس عدد وأسماء وترتيب أعمدة كشف التصدير لضمان دقة 100% وبدون أي أخطاء
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-2 text-slate-400 hover:text-white bg-slate-800 hover:bg-slate-700 rounded-full transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Type selector tabs */}
        <div className="flex items-center p-1 bg-slate-800/80 rounded-2xl border border-slate-700/80 text-xs font-bold">
          <button
            type="button"
            onClick={() => {
              setActiveType('personnel');
              setParsedData([]);
              setFileInfo(null);
              setImportError(null);
              setImportSuccess(null);
            }}
            className={`flex-1 py-2.5 rounded-xl transition-all flex items-center justify-center space-x-2 space-x-reverse cursor-pointer ${
              activeType === 'personnel'
                ? 'bg-emerald-600 text-white shadow-md font-extrabold'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <ShieldCheck className="w-4 h-4" />
            <span>كشف القوة البشرية والجاهزية (22 عمود مطابق للتصدير)</span>
          </button>

          <button
            type="button"
            onClick={() => {
              setActiveType('armament');
              setParsedData([]);
              setFileInfo(null);
              setImportError(null);
              setImportSuccess(null);
            }}
            className={`flex-1 py-2.5 rounded-xl transition-all flex items-center justify-center space-x-2 space-x-reverse cursor-pointer ${
              activeType === 'armament'
                ? 'bg-amber-600 text-white shadow-md font-extrabold'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <Database className="w-4 h-4" />
            <span>كشف عهد وتسليح الأفراد والجاهزية (10 أعمدة مطابقة)</span>
          </button>
        </div>

        {/* Template Download Prompt */}
        <div className="bg-slate-950 border border-slate-800 p-4 rounded-2xl flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 text-xs">
          <div className="space-y-1">
            <div className="flex items-center space-x-2 space-x-reverse">
              <h4 className="font-bold text-emerald-400 text-sm">
                {activeType === 'personnel'
                  ? 'تحميل قالب كشف القوة البشرية المعتمد (.XLSX)'
                  : 'تحميل قالب كشف التسليح والعهد المعتمد (.XLSX)'}
              </h4>
              <span className="bg-emerald-950 text-emerald-300 text-[10px] px-2 py-0.5 rounded border border-emerald-800 font-bold">
                جاهز ومطابق 100%
              </span>
            </div>
            <p className="text-[11px] text-slate-400 leading-relaxed">
              {activeType === 'personnel'
                ? 'يحتوي القالب على أعمدة: (الرقم العسكري، الاسم الكامل، الرتبة، الهوية، الوحدة، الكتيبة، السرية، الفصيل، الجاهزية، التخصص، الهاتف، فصيلة الدم، المؤهل، تاريخ التجنيد، المحافظة، تاريخ الميلاد، الحالة الاجتماعية، اسم الأم، اسم الضمين، القريب، هاتف القريب، الانتداب).'
                : 'يحتوي القالب على أعمدة كشف التسليح المعتمد: (الرقم الوظيفي، الاسم الكامل، نوع السلاح العهدة، رقم السلاح، عدد المخازن، عدد الذخيرة المنصرفة، حالة السلاح، تاريخ الصرف، الحالة [متواجد، فرار بالسلاح، مامورية، في مخازن التسليح]).'}
            </p>
          </div>
          <button
            type="button"
            onClick={() => downloadSampleTemplate(activeType)}
            className="px-4 py-2.5 bg-emerald-600 hover:bg-emerald-500 text-white rounded-xl font-black transition-all shrink-0 flex items-center space-x-1.5 space-x-reverse cursor-pointer shadow border border-emerald-500"
          >
            <Download className="w-4 h-4" />
            <span>تحميل القالب المعتمد</span>
          </button>
        </div>

        {/* Alerts */}
        {importError && (
          <div className="bg-rose-500/10 border border-rose-500/30 text-rose-300 p-3.5 rounded-2xl text-xs font-medium flex items-center space-x-2 space-x-reverse">
            <AlertTriangle className="w-5 h-5 text-rose-400 shrink-0" />
            <span className="whitespace-pre-line">{importError}</span>
          </div>
        )}

        {importSuccess && (
          <div className="bg-emerald-500/10 border border-emerald-500/30 text-emerald-300 p-3.5 rounded-2xl text-xs font-medium flex items-center space-x-2 space-x-reverse">
            <CheckCircle2 className="w-5 h-5 text-emerald-400 shrink-0" />
            <span>{importSuccess}</span>
          </div>
        )}

        {/* Drag & Drop File Upload Box */}
        {!fileInfo ? (
          <div
            onClick={() => fileInputRef.current?.click()}
            onDragOver={handleDragOver}
            onDragLeave={handleDragLeave}
            onDrop={handleDrop}
            className={`border-2 border-dashed p-8 rounded-3xl text-center space-y-3 cursor-pointer transition-all group ${
              isDragging
                ? 'border-emerald-400 bg-emerald-950/40 scale-[1.01]'
                : 'border-slate-700 hover:border-emerald-500/80 bg-slate-950/50 hover:bg-slate-950'
            }`}
          >
            <div className="w-14 h-14 mx-auto bg-emerald-500/10 group-hover:bg-emerald-500/20 text-emerald-400 rounded-2xl border border-emerald-500/20 flex items-center justify-center transition-colors">
              <Upload className="w-7 h-7 group-hover:scale-110 transition-transform" />
            </div>
            <div>
              <p className="font-extrabold text-slate-200 text-sm">
                {isDragging ? 'أفلت ملف الإكسل هنا الآن...' : 'اضغط هنا أو اسحب وأفلت ملف إكسل المصدر من جهازك'}
              </p>
              <p className="text-xs text-slate-400 mt-1">يدعم ملفات التصدير الرسمية وصيغ .xlsx, .xls, .csv بدون أي تعارض في الأعمدة</p>
            </div>
            <input
              type="file"
              ref={fileInputRef}
              accept=".xlsx, .xls, .csv"
              onChange={handleFileUpload}
              className="hidden"
            />
          </div>
        ) : (
          /* Parsed Data Preview & Options */
          <div className="space-y-4">
            {/* File Info Bar */}
            <div className="bg-slate-800 border border-slate-700 p-3.5 rounded-2xl flex flex-wrap items-center justify-between gap-3 text-xs">
              <div className="flex items-center space-x-2 space-x-reverse">
                <FileText className="w-5 h-5 text-emerald-400 shrink-0" />
                <div>
                  <span className="font-bold text-white block">{fileInfo.name}</span>
                  <div className="flex items-center space-x-2 space-x-reverse mt-0.5">
                    <span className="text-[11px] text-emerald-400 font-bold">
                      تم استخراج {fileInfo.rowsCount} صف بيانات
                    </span>
                    <span className="text-slate-500">•</span>
                    <span className="text-[11px] text-sky-400 font-bold">
                      تم التعرف على {fileInfo.matchedColumnsCount} عمود مطابق
                    </span>
                  </div>
                </div>
              </div>

              <div className="flex items-center space-x-2 space-x-reverse">
                <button
                  type="button"
                  onClick={() => setShowMappingDrawer(!showMappingDrawer)}
                  className="px-3 py-1.5 bg-slate-700 hover:bg-slate-600 text-slate-200 rounded-xl text-xs font-bold transition-all flex items-center space-x-1.5 space-x-reverse cursor-pointer border border-slate-600"
                >
                  <Sliders className="w-3.5 h-3.5 text-emerald-400" />
                  <span>تخصيص مطابقة الأعمدة</span>
                  {showMappingDrawer ? <ChevronUp className="w-3.5 h-3.5" /> : <ChevronDown className="w-3.5 h-3.5" />}
                </button>

                <button
                  type="button"
                  onClick={() => {
                    setParsedData([]);
                    setFileInfo(null);
                    setCustomMapping({});
                    setShowMappingDrawer(false);
                    setSheetsList([]);
                    setSelectedSheet('');
                  }}
                  className="text-xs text-rose-400 hover:text-rose-300 underline font-bold cursor-pointer px-2"
                >
                  تغيير الملف
                </button>
              </div>
            </div>

            {/* Multi-sheet Selector (if workbook has multiple sheets) */}
            {sheetsList.length > 1 && rawWorkbook && (
              <div className="bg-slate-950 p-3 rounded-2xl border border-slate-800 text-xs flex items-center justify-between">
                <span className="font-bold text-slate-300 flex items-center space-x-1.5 space-x-reverse">
                  <Layers className="w-4 h-4 text-emerald-400" />
                  <span>الملف يحتوي على عدة أوراق عمل. اختر الورقة المطلوبة:</span>
                </span>
                <div className="flex items-center space-x-1.5 space-x-reverse overflow-x-auto">
                  {sheetsList.map((sName) => (
                    <button
                      key={sName}
                      type="button"
                      onClick={() => parseSheetData(rawWorkbook, sName)}
                      className={`px-3 py-1 rounded-xl font-bold transition-all text-xs cursor-pointer ${
                        selectedSheet === sName
                          ? 'bg-emerald-600 text-white shadow'
                          : 'bg-slate-800 text-slate-400 hover:text-slate-200'
                      }`}
                    >
                      {sName}
                    </button>
                  ))}
                </div>
              </div>
            )}

            {/* Custom Column Mapping Drawer */}
            {showMappingDrawer && (
              <div className="bg-slate-950 p-4 rounded-2xl border border-emerald-500/30 text-xs space-y-3 animate-in fade-in">
                <div className="flex items-center justify-between border-b border-slate-800 pb-2">
                  <div className="flex items-center space-x-1.5 space-x-reverse font-bold text-emerald-400">
                    <Sparkles className="w-4 h-4" />
                    <span>تخصيص مطابقة حقول النظام مع أعمدة ملف الإكسل المرفوع</span>
                  </div>
                  <span className="text-[11px] text-slate-400">
                    إذا كان ملفك يحتوي على أسماء أعمدة مخصصة، يمكنك ربطها يدوياً هنا
                  </span>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 max-h-56 overflow-y-auto pr-1">
                  {(activeType === 'personnel' ? CANONICAL_PERSONNEL_COLUMNS : CANONICAL_ARMAMENT_COLUMNS)
                    .filter(col => col.key !== 'serial')
                    .map((col) => {
                      const autoResolved = buildColumnResolver(parsedData[0] || {}, customMapping)([col.header, col.key], col.key);
                      return (
                        <div key={col.key} className="bg-slate-900/80 p-2.5 rounded-xl border border-slate-800 flex items-center justify-between gap-2">
                          <span className="font-bold text-slate-300 shrink-0 text-[11px]">{col.header}:</span>
                          <select
                            value={customMapping[col.key] || autoResolved || ''}
                            onChange={(e) => {
                              const val = e.target.value;
                              const updated = { ...customMapping, [col.key]: val };
                              setCustomMapping(updated);
                            }}
                            className="bg-slate-950 text-emerald-300 border border-slate-700 rounded-lg px-2 py-1 text-xs w-full max-w-[180px] focus:outline-hidden focus:border-emerald-500"
                          >
                            <option value="">-- تخطي أو تلقائي --</option>
                            {detectedColumns.map((colName) => (
                              <option key={colName} value={colName}>
                                {colName}
                              </option>
                            ))}
                          </select>
                        </div>
                      );
                    })}
                </div>
              </div>
            )}

            {/* Column matching indicators */}
            <div className="bg-slate-950/70 p-3 rounded-2xl border border-slate-800 text-[11px] space-y-1.5">
              <div className="flex items-center justify-between font-bold text-slate-300">
                <span>فحص توافق الأعمدة مع كشف التصدير القياسي:</span>
                <span className="text-emerald-400 font-bold flex items-center space-x-1 space-x-reverse">
                  <Check className="w-3.5 h-3.5 text-emerald-400" />
                  <span>تطابق دقيق ومضمون</span>
                </span>
              </div>
              <div className="flex flex-wrap gap-1.5 pt-1">
                {(activeType === 'personnel' ? CANONICAL_PERSONNEL_COLUMNS : CANONICAL_ARMAMENT_COLUMNS).slice(1, 10).map((col, i) => (
                  <span key={i} className="px-2 py-0.5 bg-slate-800/80 border border-slate-700 text-slate-300 rounded text-[10px] flex items-center space-x-1 space-x-reverse">
                    <span className="w-1.5 h-1.5 rounded-full bg-emerald-400"></span>
                    <span>{col.header}</span>
                  </span>
                ))}
                <span className="px-2 py-0.5 bg-slate-800/50 text-slate-400 rounded text-[10px]">
                  + المزيد من الحقول
                </span>
              </div>
            </div>

            {/* Table Sample Preview */}
            <div className="max-h-48 overflow-x-auto overflow-y-auto border border-slate-800 rounded-2xl bg-slate-950 text-xs">
              <table className="w-full text-right text-[11px] min-w-[600px]">
                <thead className="bg-slate-900 text-slate-300 font-bold sticky top-0 border-b border-slate-800">
                  <tr>
                    {Object.keys(parsedData[0] || {}).slice(0, 8).map((key, i) => (
                      <th key={i} className="p-2.5 border-l border-slate-800 whitespace-nowrap">{key}</th>
                    ))}
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-800/60 text-slate-300 font-medium">
                  {parsedData.slice(0, 4).map((row, idx) => (
                    <tr key={idx} className="hover:bg-slate-900/50">
                      {Object.keys(parsedData[0] || {}).slice(0, 8).map((key, i) => (
                        <td key={i} className="p-2.5 border-l border-slate-800/60 whitespace-nowrap">
                          {String(row[key] || '-')}
                        </td>
                      ))}
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>

            {/* Submit Action */}
            <button
              type="button"
              disabled={isLoading}
              onClick={handleExecuteImport}
              className="w-full py-3.5 bg-emerald-600 hover:bg-emerald-500 active:scale-[0.99] text-white font-extrabold rounded-2xl text-sm transition-all shadow-lg flex items-center justify-center space-x-2 space-x-reverse cursor-pointer"
            >
              {isLoading ? (
                <>
                  <RefreshCw className="w-5 h-5 animate-spin" />
                  <span>جاري معالجة وتحديث السجلات بدقة...</span>
                </>
              ) : (
                <>
                  <CheckCircle2 className="w-5 h-5" />
                  <span>
                    {activeType === 'personnel'
                      ? `بدء الاستيراد واعتماد تحديث الجاهزية لـ (${fileInfo.rowsCount}) فرد ⚡`
                      : `بدء استيراد كشف التسليح وتحديث الجاهزية والعهد لـ (${fileInfo.rowsCount}) فرد وسلاح ⚡`}
                  </span>
                </>
              )}
            </button>
          </div>
        )}

        {/* Footer */}
        <div className="pt-2 border-t border-slate-800 flex items-center justify-between text-xs text-slate-400">
          <span className="text-[11px] text-slate-500">
            تحديث فوري لقاعدة البيانات المركزية ومزامنة سحابية 💾
          </span>
          <button
            onClick={onClose}
            className="text-slate-400 hover:text-white font-bold underline cursor-pointer"
          >
            إغلاق
          </button>
        </div>
      </div>
    </div>
  );
};

