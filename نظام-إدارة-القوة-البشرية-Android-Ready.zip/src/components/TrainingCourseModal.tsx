import React, { useState, useEffect } from 'react';
import { GraduationCap, X, Check, BookOpen, Globe2, School, FileText, Sparkles } from 'lucide-react';
import { PersonnelRecord, PersonnelStatus } from '../types';

interface TrainingCourseModalProps {
  isOpen: boolean;
  onClose: () => void;
  personnel: PersonnelRecord | null;
  defaultStatus?: 'دورة تدريبية داخلية' | 'دورة تدريبية خارجية';
  onConfirm: (
    militaryId: string,
    trainingCourseType: string,
    status: 'دورة تدريبية داخلية' | 'دورة تدريبية خارجية',
    reason?: string
  ) => void;
}

const COMMON_INTERNAL_COURSES = [
  'دورة قادة فصائل وسرايا',
  'دورة تأهيل ضباط صف',
  'دورة صاعقة ومظلات تأسيسية',
  'دورة رماية وقناصة ميدانية',
  'دورة هندسة ميدانية وإبطال متفجرات',
  'دورة إشارة واتصالات تكتيكية',
  'دورة تدريب مدربين عسكريين (TOT)',
  'دورة أمن وحماية منشآت وشخصيات',
  'دورة إسعافات وطب ميداني تكتيكي',
  'دورة صيانة أسلحة ومعدات قتالية',
  'دورة قيادة مدرعات وآليات ميدانية',
  'دورة دفاع جوي قصير المدى'
];

const COMMON_EXTERNAL_COURSES = [
  'دورة قيادة وأركان مشتركة (خارجية)',
  'دورة حرب إلكترونية واستخبارات متقدمة',
  'دورة صاعقة وقوات خاصة متقدمة',
  'دورة طيران مسير (درونز) واستطلاع جوي',
  'دورة إدارة عمليات حربية ودفاعية',
  'دورة تأهيل قيادات عسكرية استراتيجية',
  'دورة مكافحة إرهاب وتدخل سريع',
  'دورة لغات عسكرية وترجمة تكتيكية'
];

export const TrainingCourseModal: React.FC<TrainingCourseModalProps> = ({
  isOpen,
  onClose,
  personnel,
  defaultStatus = 'دورة تدريبية داخلية',
  onConfirm
}) => {
  const [selectedStatus, setSelectedStatus] = useState<'دورة تدريبية داخلية' | 'دورة تدريبية خارجية'>(defaultStatus);
  const [courseType, setCourseType] = useState('');
  const [reason, setReason] = useState('إلحاق بدورة تدريبية عسكرية بقرار القيادة');
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (isOpen && personnel) {
      const isExternal = personnel.currentStatus === 'دورة تدريبية خارجية';
      setSelectedStatus(isExternal ? 'دورة تدريبية خارجية' : defaultStatus);
      setCourseType(personnel.trainingCourseType || '');
      setReason(
        personnel.trainingCourseType
          ? `تحديث بيانات الدورة [${personnel.trainingCourseType}]`
          : 'إلحاق بدورة تدريبية عسكرية بقرار القيادة'
      );
      setError(null);
    }
  }, [isOpen, personnel, defaultStatus]);

  if (!isOpen || !personnel) return null;

  const activePresets = selectedStatus === 'دورة تدريبية خارجية' ? COMMON_EXTERNAL_COURSES : COMMON_INTERNAL_COURSES;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const trimmed = courseType.trim();
    if (!trimmed) {
      setError('يرجى كتابة أو اختيار مسمى ونوع الدورة التدريبية.');
      return;
    }

    onConfirm(personnel.militaryId, trimmed, selectedStatus, reason.trim() || undefined);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/70 backdrop-blur-xs font-['Cairo',sans-serif] select-none animate-fadeIn">
      <div className="bg-white border-2 border-indigo-500/40 rounded-3xl max-w-lg w-full shadow-2xl overflow-hidden text-right">
        
        {/* Header */}
        <div className="bg-gradient-to-r from-slate-900 via-indigo-950 to-slate-900 p-5 text-white flex items-center justify-between">
          <div className="flex items-center space-x-3 space-x-reverse">
            <div className="w-10 h-10 rounded-2xl bg-indigo-500/20 border border-indigo-400 flex items-center justify-center text-indigo-300">
              <GraduationCap className="w-6 h-6" />
            </div>
            <div>
              <h3 className="font-black text-lg text-indigo-200">
                تحديد نوع ومسمى الدورة التدريبية 🎓
              </h3>
              <p className="text-xs text-indigo-300">
                توثيق الدورة بالجاهزية العسكرية وسجل التدريب والتأهيل
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            type="button"
            className="p-1.5 rounded-xl bg-indigo-950/50 hover:bg-indigo-800 text-indigo-200 hover:text-white transition-colors border border-indigo-700/50 cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Form Body */}
        <form onSubmit={handleSubmit} className="p-6 space-y-5">
          
          {/* Target Personnel Badge */}
          <div className="bg-indigo-50/70 border border-indigo-200 rounded-2xl p-4 flex items-center space-x-3 space-x-reverse">
            <div className="w-12 h-12 rounded-xl bg-indigo-600 text-white flex items-center justify-center font-black text-sm shrink-0 shadow-xs">
              {personnel.rank}
            </div>
            <div className="space-y-1">
              <div className="font-black text-slate-800 text-sm">
                {personnel.rank} / {personnel.fullName}
              </div>
              <div className="text-xs text-slate-600 flex items-center space-x-2 space-x-reverse">
                <span className="font-mono bg-indigo-100 text-indigo-900 px-2 py-0.5 rounded font-bold">
                  {personnel.militaryId}
                </span>
                <span>•</span>
                <span className="text-slate-500">{personnel.unit || 'القوة العسكرية'}</span>
              </div>
            </div>
          </div>

          {/* Training Course Category Toggle (Internal vs External) */}
          <div className="space-y-1.5">
            <label className="text-xs font-black text-slate-700 block">
              نطاق ومكان الدورة التدريبية:
            </label>
            <div className="grid grid-cols-2 gap-2">
              <button
                type="button"
                onClick={() => setSelectedStatus('دورة تدريبية داخلية')}
                className={`py-2 px-3 rounded-xl text-xs font-black border flex items-center justify-center space-x-1.5 space-x-reverse transition-all cursor-pointer ${
                  selectedStatus === 'دورة تدريبية داخلية'
                    ? 'bg-indigo-600 text-white border-indigo-700 shadow-sm ring-2 ring-indigo-300'
                    : 'bg-slate-50 text-slate-700 border-slate-200 hover:bg-slate-100'
                }`}
              >
                <School className="w-4 h-4" />
                <span>دورة تدريبية داخلية 🏛️</span>
              </button>

              <button
                type="button"
                onClick={() => setSelectedStatus('دورة تدريبية خارجية')}
                className={`py-2 px-3 rounded-xl text-xs font-black border flex items-center justify-center space-x-1.5 space-x-reverse transition-all cursor-pointer ${
                  selectedStatus === 'دورة تدريبية خارجية'
                    ? 'bg-sky-600 text-white border-sky-700 shadow-sm ring-2 ring-sky-300'
                    : 'bg-slate-50 text-slate-700 border-slate-200 hover:bg-slate-100'
                }`}
              >
                <Globe2 className="w-4 h-4" />
                <span>دورة تدريبية خارجية ✈️</span>
              </button>
            </div>
          </div>

          {/* Quick Select Presets */}
          <div className="space-y-2">
            <label className="text-xs font-black text-slate-700 flex items-center space-x-1.5 space-x-reverse">
              <Sparkles className="w-3.5 h-3.5 text-indigo-600" />
              <span>اختيار سريع للدورات الشائعة ({selectedStatus === 'دورة تدريبية داخلية' ? 'داخلية' : 'خارجية'}):</span>
            </label>
            <div className="flex flex-wrap gap-1.5 max-h-32 overflow-y-auto p-1.5 bg-slate-50 border border-slate-200 rounded-xl">
              {activePresets.map((course) => (
                <button
                  key={course}
                  type="button"
                  onClick={() => {
                    setCourseType(course);
                    setError(null);
                  }}
                  className={`text-[11px] px-2.5 py-1 rounded-lg font-bold border transition-all cursor-pointer ${
                    courseType === course
                      ? 'bg-indigo-700 text-white border-indigo-800 shadow-xs'
                      : 'bg-white text-slate-700 border-slate-300 hover:border-indigo-400 hover:bg-indigo-50'
                  }`}
                >
                  {course}
                </button>
              ))}
            </div>
          </div>

          {/* Course Name / Type Input */}
          <div className="space-y-1.5">
            <label className="text-xs font-black text-indigo-900 flex items-center space-x-1.5 space-x-reverse">
              <BookOpen className="w-4 h-4 text-indigo-700" />
              <span>نوع ومسمى الدورة التدريبية *</span>
            </label>
            <input
              type="text"
              required
              value={courseType}
              onChange={(e) => {
                setCourseType(e.target.value);
                if (error) setError(null);
              }}
              placeholder="مثال: دورة قادة سرايا، دورة مكافحة إرهاب، دورة اتصالات حربية..."
              className="w-full px-3.5 py-2.5 bg-slate-50 border-2 border-slate-300 focus:border-indigo-600 focus:bg-white rounded-xl text-sm font-bold text-slate-800 outline-hidden transition-colors"
            />
            {error && (
              <p className="text-[11px] font-bold text-rose-600 mt-1">
                {error}
              </p>
            )}
          </div>

          {/* Administrative Reference / Order */}
          <div className="space-y-1.5">
            <label className="text-xs font-bold text-slate-600 flex items-center space-x-1.5 space-x-reverse">
              <FileText className="w-3.5 h-3.5 text-slate-500" />
              <span>رقم / أمر التكليف بالدورة (اختياري)</span>
            </label>
            <input
              type="text"
              value={reason}
              onChange={(e) => setReason(e.target.value)}
              placeholder="أمر إداري صادر من شعبة التدريب والتأهيل..."
              className="w-full px-3 py-2 bg-slate-50 border border-slate-300 focus:border-indigo-600 focus:bg-white rounded-xl text-xs text-slate-700 outline-hidden transition-colors"
            />
          </div>

          {/* Action Buttons */}
          <div className="pt-3 border-t border-slate-200 flex items-center justify-end gap-2">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2.5 bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-bold rounded-xl transition-colors cursor-pointer"
            >
              إلغاء
            </button>
            <button
              type="submit"
              className="px-5 py-2.5 bg-indigo-700 hover:bg-indigo-800 text-white text-xs font-black rounded-xl transition-all shadow-md hover:shadow-lg flex items-center space-x-1.5 space-x-reverse cursor-pointer"
            >
              <Check className="w-4 h-4 text-white" />
              <span>اعتماد الدورة التدريبية ⚡</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
