import React, { useState, useEffect } from 'react';
import {
  X,
  Cloud,
  Database,
  Wifi,
  WifiOff,
  RefreshCw,
  CheckCircle2,
  HardDrive,
  ShieldCheck,
  AlertCircle,
  Clock,
  Layers,
  CloudDownload,
  Upload,
  Download
} from 'lucide-react';
import { hybridSyncEngine, HybridSyncStatus } from '../lib/hybridSync';
import { StorageService } from '../lib/storage';

interface HybridSyncModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const HybridSyncModal: React.FC<HybridSyncModalProps> = ({ isOpen, onClose }) => {
  const [status, setStatus] = useState<HybridSyncStatus>(() => hybridSyncEngine.getStatus());
  const [isSyncingNow, setIsSyncingNow] = useState(false);
  const [feedbackMessage, setFeedbackMessage] = useState<{ type: 'success' | 'error' | 'info'; text: string } | null>(null);

  useEffect(() => {
    if (!isOpen) return;

    const unsub = hybridSyncEngine.subscribe((newStatus) => {
      setStatus(newStatus);
    });
    return () => unsub();
  }, [isOpen]);

  if (!isOpen) return null;

  const handleCloudSyncForce = async () => {
    setIsSyncingNow(true);
    setFeedbackMessage({ type: 'info', text: 'جاري استرجاع البيانات من قاعدة بيانات السحاب...' });
    try {
      const result = await StorageService.syncFromCloudForce();
      if (result.success) {
        setFeedbackMessage({
          type: 'success',
          text: result.message
        });
      } else {
        setFeedbackMessage({
          type: 'error',
          text: result.message
        });
      }
    } catch (err: any) {
      setFeedbackMessage({
        type: 'error',
        text: `حدث خطأ أثناء المزامنة: ${err.message || err}`
      });
    } finally {
      setIsSyncingNow(false);
    }
  };

  const handleExportBackup = () => {
    try {
      const backupData = StorageService.exportFullSystemBackup();
      const jsonStr = JSON.stringify(backupData, null, 2);
      const blob = new Blob([jsonStr], { type: 'application/json' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `backup_military_hq_${new Date().toISOString().slice(0, 10)}.json`;
      a.click();
      URL.revokeObjectURL(url);
      setFeedbackMessage({ type: 'success', text: 'تم تصدير النسخة الاحتياطية بنجاح 📂' });
    } catch (err: any) {
      setFeedbackMessage({ type: 'error', text: `فشل التصدير: ${err.message}` });
    }
  };

  const handleImportBackup = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (event) => {
      try {
        const json = JSON.parse(event.target?.result as string);
        const res = StorageService.restoreFullSystemBackup(json);
        if (res.success) {
          setFeedbackMessage({ type: 'success', text: `${res.message} ${res.restoredStats || ''}` });
        } else {
          setFeedbackMessage({ type: 'error', text: res.message });
        }
      } catch (err) {
        setFeedbackMessage({ type: 'error', text: 'تنسيق ملف النسخة الاحتياطية غير صالح!' });
      }
    };
    reader.readAsText(file);
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-950/70 backdrop-blur-xs flex items-center justify-center p-4 overflow-y-auto font-['Cairo',sans-serif] animate-in fade-in duration-200">
      <div className="bg-white rounded-3xl shadow-2xl max-w-lg w-full border border-slate-200 overflow-hidden dir-rtl">
        
        {/* Header */}
        <div className="bg-slate-900 text-white p-5 border-b border-slate-800 flex items-center justify-between">
          <div className="flex items-center space-x-3 space-x-reverse">
            <div className="p-2.5 bg-emerald-500/20 border border-emerald-500/40 rounded-2xl text-emerald-400">
              <Database className="w-6 h-6" />
            </div>
            <div>
              <h3 className="text-base font-extrabold text-white flex items-center gap-2">
                <span>مركز التخزين المحلي والنسخ الاحتياطي 💾</span>
              </h3>
              <p className="text-xs text-slate-400 font-medium mt-0.5">
                حفظ البيانات على هذا الجهاز واستعادة النسخ الاحتياطية عند الحاجة
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="text-slate-400 hover:text-white p-2 rounded-xl hover:bg-slate-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="p-6 space-y-5">
          
          {/* Status Card */}
          <div className="p-4 rounded-2xl border flex items-center justify-between bg-emerald-50 border-emerald-200 text-emerald-950">
            <div className="flex items-center space-x-3 space-x-reverse">
              <div className="p-3 rounded-2xl bg-emerald-600 text-white">
                <Cloud className="w-6 h-6" />
              </div>
              <div>
                <div className="text-xs font-black opacity-80">حالة قاعدة البيانات المحلية</div>
                <div className="text-sm font-extrabold flex items-center gap-1.5 mt-0.5">
                  <span>البيانات محفوظة محلياً على هذا الجهاز</span>
                </div>
              </div>
            </div>

            <span className="text-[11px] font-bold px-2.5 py-1 rounded-full border bg-emerald-200 text-emerald-800 border-emerald-300">
              محلي فقط
            </span>
          </div>

          {/* Quick Actions Grid */}
          <div className="bg-slate-50 border border-slate-200 rounded-2xl p-4 space-y-3">
            <div className="text-xs font-bold text-slate-800 flex items-center space-x-1.5 space-x-reverse">
              <CloudDownload className="w-4 h-4 text-emerald-600" />
              <span>استعادة البيانات من نسخة احتياطية محلية:</span>
            </div>
            <p className="text-[11px] text-slate-600 leading-relaxed">
              لا توجد مزامنة سحابية في هذا الإصدار. لاستعادة البيانات، اختر ملف النسخة الاحتياطية المحفوظ على جهازك:
            </p>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 pt-1">
              <div className="py-2.5 px-3 bg-slate-200 text-slate-600 font-bold rounded-xl text-xs flex items-center justify-center space-x-1.5 space-x-reverse">
                <HardDrive className="w-4 h-4" />
                <span>التخزين المحلي فقط</span>
              </div>

              <label className="py-2.5 px-3 bg-slate-800 hover:bg-slate-700 text-white font-bold rounded-xl text-xs transition-all flex items-center justify-center space-x-1.5 space-x-reverse shadow-md cursor-pointer">
                <Upload className="w-4 h-4 text-amber-400" />
                <span>استرجاع JSON 📂</span>
                <input type="file" accept=".json" onChange={handleImportBackup} className="hidden" />
              </label>
            </div>

            <button
              type="button"
              onClick={handleExportBackup}
              className="w-full mt-2 py-2 px-3 bg-slate-200 hover:bg-slate-300 text-slate-800 font-bold rounded-xl text-xs transition-all flex items-center justify-center space-x-1.5 space-x-reverse cursor-pointer"
            >
              <Download className="w-4 h-4 text-slate-700" />
              <span>تصدير نسخة احتياطية كاملة (JSON Backup)</span>
            </button>
          </div>

          {/* Feedback Message if any */}
          {feedbackMessage && (
            <div className={`p-3.5 rounded-2xl text-xs font-bold flex items-center space-x-2 space-x-reverse ${
              feedbackMessage.type === 'success'
                ? 'bg-emerald-100 text-emerald-900 border border-emerald-300'
                : feedbackMessage.type === 'error'
                ? 'bg-rose-100 text-rose-900 border border-rose-300'
                : 'bg-blue-100 text-blue-900 border border-blue-300'
            }`}>
              {feedbackMessage.type === 'success' ? (
                <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
              ) : (
                <AlertCircle className="w-4 h-4 text-rose-600 shrink-0" />
              )}
              <span>{feedbackMessage.text}</span>
            </div>
          )}

          {/* Actions */}
          <div className="pt-2 flex items-center justify-end space-x-3 space-x-reverse">
            <button
              type="button"
              onClick={onClose}
              className="px-5 py-2.5 rounded-xl bg-slate-900 hover:bg-slate-800 text-white text-xs font-bold transition-colors cursor-pointer"
            >
              إغلاق النافذة
            </button>
          </div>

        </div>

      </div>
    </div>
  );
};

