import React, { useState, useEffect } from 'react';
import { Calendar, Clock, X, Check, FileText, Sparkles, AlertCircle } from 'lucide-react';
import { PersonnelRecord, PersonnelStatus } from '../types';

interface LeavePermissionDateModalProps {
  isOpen: boolean;
  onClose: () => void;
  personnel: PersonnelRecord | null;
  defaultStatus?: 'إجازة' | 'إذن';
  onConfirm: (
    militaryId: string,
    status: 'إجازة' | 'إذن',
    details: {
      startDate: string;
      endDate: string;
      durationDays: number;
      leaveType?: string;
      reason?: string;
    }
  ) => void;
}

const COMMON_LEAVE_TYPES = [
  'إجازة اعتيادية دورية',
  'إجازة سنوية معتمدة',
  'إجازة ميدانية تعويضية',
  'إجازة مرضية بتقرير طبي',
  'إجازة زواج',
  'إجازة وفاة / عزاء',
  'إجازة طارئة'
];

const COMMON_PERMISSION_TYPES = [
  'إذن رسمي لساعات محددة',
  'إذن خروج مؤقت (يوم واحد)',
  'إذن مراجعة طبية ومستشفى',
  'إذن مراجعة دائرة حكومية',
  'إذن عائلي ظرف طارئ',
  'إذن 48 ساعة'
];

export const LeavePermissionDateModal: React.FC<LeavePermissionDateModalProps> = ({
  isOpen,
  onClose,
  personnel,
  defaultStatus = 'إجازة',
  onConfirm
}) => {
  const todayStr = new Date().toISOString().split('T')[0];

  const [status, setStatus] = useState<'إجازة' | 'إذن'>(defaultStatus);
  const [startDate, setStartDate] = useState<string>(todayStr);
  const [endDate, setEndDate] = useState<string>('');
  const [durationDays, setDurationDays] = useState<number>(defaultStatus === 'إذن' ? 1 : 7);
  const [leaveType, setLeaveType] = useState<string>('');
  const [reason, setReason] = useState<string>('');
  const [error, setError] = useState<string | null>(null);

  // Helper to compute end date given start date and duration days
  const computeEndDate = (start: string, days: number): string => {
    if (!start) return '';
    try {
      const d = new Date(start);
      if (isNaN(d.getTime())) return '';
      // Adding days: if 1 day, end date is the same day or next day depending on convention.
      // Usually for 1 day leave, start=end. For N days: end = start + (days - 1) days.
      d.setDate(d.getDate() + Math.max(0, days - 1));
      return d.toISOString().split('T')[0];
    } catch {
      return '';
    }
  };

  // Helper to compute duration given start and end date
  const computeDays = (start: string, end: string): number => {
    if (!start || !end) return 1;
    try {
      const s = new Date(start).getTime();
      const e = new Date(end).getTime();
      if (isNaN(s) || isNaN(e)) return 1;
      const diff = Math.ceil((e - s) / (1000 * 60 * 60 * 24)) + 1;
      return diff > 0 ? diff : 1;
    } catch {
      return 1;
    }
  };

  useEffect(() => {
    if (isOpen && personnel) {
      const initialStatus =
        personnel.currentStatus === 'إجازة' || personnel.currentStatus === 'إذن'
          ? (personnel.currentStatus as 'إجازة' | 'إذن')
          : defaultStatus;
      setStatus(initialStatus);

      // Latest attendance log for matching type
      const latestAtt = personnel.logs?.attendance?.find(
        (a) => a.type === initialStatus || a.type === 'إجازة' || a.type === 'إذن'
      );

      const initialStart = personnel.leaveStartDate || latestAtt?.startDate || personnel.lastStatusChangeDate || todayStr;
      const initialEnd =
        personnel.leaveEndDate ||
        latestAtt?.endDate ||
        computeEndDate(initialStart, initialStatus === 'إذن' ? 1 : 7);

      setStartDate(initialStart);
      setEndDate(initialEnd);
      setDurationDays(computeDays(initialStart, initialEnd));
      setLeaveType(
        personnel.leaveType ||
        latestAtt?.leaveType ||
        latestAtt?.permissionType ||
        (initialStatus === 'إجازة' ? 'إجازة اعتيادية دورية' : 'إذن رسمي لساعات محددة')
      );
      setReason(latestAtt?.reason || `منح ${initialStatus} رسمية بقرار القيادة المباشرة`);
      setError(null);
    }
  }, [isOpen, personnel, defaultStatus, todayStr]);

  if (!isOpen || !personnel) return null;

  const handleStartDateChange = (newStart: string) => {
    setStartDate(newStart);
    if (newStart && durationDays > 0) {
      setEndDate(computeEndDate(newStart, durationDays));
    }
    setError(null);
  };

  const handleEndDateChange = (newEnd: string) => {
    setEndDate(newEnd);
    if (startDate && newEnd) {
      const diff = computeDays(startDate, newEnd);
      setDurationDays(diff);
    }
    setError(null);
  };

  const handlePresetDays = (days: number) => {
    setDurationDays(days);
    if (startDate) {
      setEndDate(computeEndDate(startDate, days));
    }
    setError(null);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!startDate) {
      setError('يرجى تحديد تاريخ بدء الإجازة أو الإذن.');
      return;
    }
    if (!endDate) {
      setError('يرجى تحديد تاريخ انتهاء الإجازة أو الإذن.');
      return;
    }
    if (new Date(endDate).getTime() < new Date(startDate).getTime()) {
      setError('تاريخ الانتهاء لا يمكن أن يكون قبل تاريخ البدء.');
      return;
    }

    onConfirm(personnel.militaryId, status, {
      startDate,
      endDate,
      durationDays: durationDays > 0 ? durationDays : 1,
      leaveType: leaveType.trim() || (status === 'إجازة' ? 'إجازة رسمية' : 'إذن رسمي'),
      reason: reason.trim() || undefined
    });
    onClose();
  };

  const presetDayOptions = status === 'إجازة' ? [3, 5, 7, 10, 14, 21, 30] : [1, 2, 3];
  const commonTypes = status === 'إجازة' ? COMMON_LEAVE_TYPES : COMMON_PERMISSION_TYPES;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/70 backdrop-blur-xs font-['Cairo',sans-serif] select-none animate-fadeIn">
      <div className="bg-white border-2 border-emerald-500/40 rounded-3xl max-w-lg w-full shadow-2xl overflow-hidden text-right">
        
        {/* Header */}
        <div className="bg-gradient-to-r from-emerald-950 via-slate-900 to-teal-950 p-5 text-white flex items-center justify-between">
          <div className="flex items-center space-x-3 space-x-reverse">
            <div className="w-10 h-10 rounded-2xl bg-emerald-500/20 border border-emerald-400 flex items-center justify-center text-emerald-300">
              <Calendar className="w-6 h-6" />
            </div>
            <div>
              <h3 className="font-black text-lg text-emerald-200">
                توثيق فترة وتواريخ {status === 'إجازة' ? 'الإجازة' : 'الإذن'} 🗓️
              </h3>
              <p className="text-xs text-emerald-300">
                تحديد تاريخ البدء والانتهاء واحتساب المدة بسجل التمام والانضباط
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            type="button"
            className="p-1.5 rounded-xl bg-emerald-950/50 hover:bg-emerald-800 text-emerald-200 hover:text-white transition-colors border border-emerald-700/50 cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Form Body */}
        <form onSubmit={handleSubmit} className="p-6 space-y-5">
          
          {/* Target Personnel Badge */}
          <div className="bg-emerald-50/70 border border-emerald-200 rounded-2xl p-4 flex items-center space-x-3 space-x-reverse">
            <div className="w-12 h-12 rounded-xl bg-emerald-700 text-white flex items-center justify-center font-black text-sm shrink-0 shadow-xs">
              {personnel.rank}
            </div>
            <div className="space-y-1">
              <div className="font-black text-slate-800 text-sm">
                {personnel.rank} / {personnel.fullName}
              </div>
              <div className="text-xs text-slate-600 flex items-center space-x-2 space-x-reverse">
                <span className="font-mono bg-emerald-100 text-emerald-900 px-2 py-0.5 rounded font-bold">
                  {personnel.militaryId}
                </span>
                <span>•</span>
                <span className="text-slate-500">{personnel.unit || 'القوة العسكرية'}</span>
              </div>
            </div>
          </div>

          {/* Type Switcher (إجازة vs إذن) */}
          <div className="flex rounded-xl bg-slate-100 p-1 border border-slate-200">
            <button
              type="button"
              onClick={() => {
                setStatus('إجازة');
                setDurationDays(7);
                setEndDate(computeEndDate(startDate, 7));
                setLeaveType('إجازة اعتيادية دورية');
              }}
              className={`flex-1 py-2 text-xs font-black rounded-lg transition-all cursor-pointer flex items-center justify-center space-x-1.5 space-x-reverse ${
                status === 'إجازة'
                  ? 'bg-emerald-700 text-white shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              <Calendar className="w-3.5 h-3.5" />
              <span>إجازة رسمية</span>
            </button>
            <button
              type="button"
              onClick={() => {
                setStatus('إذن');
                setDurationDays(1);
                setEndDate(computeEndDate(startDate, 1));
                setLeaveType('إذن رسمي لساعات محددة');
              }}
              className={`flex-1 py-2 text-xs font-black rounded-lg transition-all cursor-pointer flex items-center justify-center space-x-1.5 space-x-reverse ${
                status === 'إذن'
                  ? 'bg-teal-700 text-white shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              <Clock className="w-3.5 h-3.5" />
              <span>إذن خروج / ساعي</span>
            </button>
          </div>

          {/* Dates Inputs: Start & End */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div className="space-y-1.5">
              <label className="text-xs font-black text-slate-800 flex items-center space-x-1.5 space-x-reverse">
                <Calendar className="w-3.5 h-3.5 text-emerald-600" />
                <span>تاريخ بدء {status === 'إجازة' ? 'الإجازة' : 'الإذن'} *</span>
              </label>
              <input
                type="date"
                required
                value={startDate}
                onChange={(e) => handleStartDateChange(e.target.value)}
                className="w-full px-3 py-2.5 bg-slate-50 border-2 border-slate-300 focus:border-emerald-600 focus:bg-white rounded-xl text-xs font-bold text-slate-800 outline-hidden transition-colors font-mono"
              />
            </div>

            <div className="space-y-1.5">
              <label className="text-xs font-black text-slate-800 flex items-center space-x-1.5 space-x-reverse">
                <Calendar className="w-3.5 h-3.5 text-emerald-600" />
                <span>تاريخ الانتهاء *</span>
              </label>
              <input
                type="date"
                required
                value={endDate}
                onChange={(e) => handleEndDateChange(e.target.value)}
                className="w-full px-3 py-2.5 bg-slate-50 border-2 border-slate-300 focus:border-emerald-600 focus:bg-white rounded-xl text-xs font-bold text-slate-800 outline-hidden transition-colors font-mono"
              />
            </div>
          </div>

          {/* Duration Summary & Quick Days Buttons */}
          <div className="space-y-2 bg-slate-50 border border-slate-200 p-3 rounded-2xl">
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold text-slate-700">المدة المحتسبة:</span>
              <span className="text-xs font-black font-mono text-emerald-800 bg-emerald-100 px-3 py-0.5 rounded-full border border-emerald-300">
                {durationDays} {durationDays === 1 ? 'يوم واحد' : durationDays === 2 ? 'يومان' : 'أيام'}
              </span>
            </div>
            <div className="flex flex-wrap items-center gap-1.5 pt-1">
              <span className="text-[11px] font-bold text-slate-500 ml-1">تحديد سريع:</span>
              {presetDayOptions.map((days) => (
                <button
                  key={days}
                  type="button"
                  onClick={() => handlePresetDays(days)}
                  className={`text-[11px] px-2.5 py-1 rounded-lg font-bold border transition-all cursor-pointer ${
                    durationDays === days
                      ? 'bg-emerald-700 text-white border-emerald-800 shadow-xs'
                      : 'bg-white text-slate-700 border-slate-300 hover:border-emerald-400 hover:bg-emerald-50'
                  }`}
                >
                  {days} {days === 1 ? 'يوم' : days === 2 ? 'يومان' : 'أيام'}
                </button>
              ))}
            </div>
          </div>

          {/* Leave Type Select / Input */}
          <div className="space-y-1.5">
            <label className="text-xs font-bold text-slate-700 flex items-center space-x-1.5 space-x-reverse">
              <Sparkles className="w-3.5 h-3.5 text-emerald-600" />
              <span>نوع {status === 'إجازة' ? 'الإجازة' : 'الإذن'}:</span>
            </label>
            <div className="flex flex-wrap gap-1.5 max-h-24 overflow-y-auto p-1 bg-slate-50 border border-slate-200 rounded-xl mb-1.5">
              {commonTypes.map((t) => (
                <button
                  key={t}
                  type="button"
                  onClick={() => setLeaveType(t)}
                  className={`text-[11px] px-2 py-0.5 rounded-lg font-bold border transition-all cursor-pointer ${
                    leaveType === t
                      ? 'bg-emerald-700 text-white border-emerald-800'
                      : 'bg-white text-slate-700 border-slate-200 hover:bg-emerald-50'
                  }`}
                >
                  {t}
                </button>
              ))}
            </div>
            <input
              type="text"
              value={leaveType}
              onChange={(e) => setLeaveType(e.target.value)}
              placeholder="مثال: إجازة اعتيادية دورية..."
              className="w-full px-3 py-2 bg-slate-50 border border-slate-300 focus:border-emerald-600 focus:bg-white rounded-xl text-xs font-bold text-slate-800 outline-hidden transition-colors"
            />
          </div>

          {/* Reason / Reference */}
          <div className="space-y-1.5">
            <label className="text-xs font-bold text-slate-600 flex items-center space-x-1.5 space-x-reverse">
              <FileText className="w-3.5 h-3.5 text-slate-500" />
              <span>ملاحظات / سبب الاعتماد (اختياري)</span>
            </label>
            <input
              type="text"
              value={reason}
              onChange={(e) => setReason(e.target.value)}
              placeholder="موافقة القيادة والضابط المسؤول..."
              className="w-full px-3 py-2 bg-slate-50 border border-slate-300 focus:border-emerald-600 focus:bg-white rounded-xl text-xs text-slate-700 outline-hidden transition-colors"
            />
          </div>

          {error && (
            <p className="text-[11px] font-bold text-rose-600 flex items-center space-x-1 space-x-reverse">
              <AlertCircle className="w-3.5 h-3.5 shrink-0" />
              <span>{error}</span>
            </p>
          )}

          {/* Action Buttons */}
          <div className="pt-3 border-t border-slate-200 flex items-center justify-end gap-2">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2.5 bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-bold rounded-xl transition-colors cursor-pointer"
            >
              إلغاء
            </button>
            <button
              type="submit"
              className="px-5 py-2.5 bg-emerald-700 hover:bg-emerald-800 text-white text-xs font-black rounded-xl transition-all shadow-md hover:shadow-lg flex items-center space-x-1.5 space-x-reverse cursor-pointer"
            >
              <Check className="w-4 h-4 text-white" />
              <span>تأكيد واعتماد تواريخ {status} ⚡</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
