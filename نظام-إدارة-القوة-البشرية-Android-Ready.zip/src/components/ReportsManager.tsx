import React, { useState, useMemo } from 'react';
import * as XLSX from 'xlsx';
import { exportExcelWorkbook, exportCSVContent } from '../lib/exportUtils';
import { getCurrentHeaderInfo } from '../lib/headerUtils';
import {
  FileText,
  Printer,
  Download,
  Filter,
  ShieldCheck,
  Activity,
  DollarSign,
  Lock,
  Crosshair,
  Award,
  Users,
  Calendar,
  ShieldAlert
} from 'lucide-react';
import { PersonnelRecord, MilitaryRank, PersonnelStatus } from '../types';

export const REPORT_TITLES_MAP: Record<string, string> = {
  security: 'تقرير فرع المخالفات الأمنية والمحاكمات العسكرية',
  medical: 'تقرير فرع الخدمات الطبية والمنومين والعيادات',
  armament: 'تقرير فرع عُهد التسليح الشخصي والذخائر والأسلحة',
  training: 'تقرير فرع التدريب والدورات العسكرية والتأهيل',
  absences: 'تقرير فرع الإجازات والأذونات والغياب والفرار',
  financial: 'تقرير فرع الإدارة المالية ومسيرات الرواتب والبدلات',
  readiness: 'تقرير الجاهزية القتالية والحالة الفنية للوحدات',
  daily: 'تقرير القوة اليومية وحصر التمام الميداني',
  comprehensive: 'التقرير الشامل والسجلات الإدارية لكافة الأفراد'
};

interface ReportsManagerProps {
  personnel: PersonnelRecord[];
  onPrintReport: (reportTitle: string, data: PersonnelRecord[], reportType?: string) => void;
  onOpenDailyReadinessReport?: () => void;
}

export const ReportsManager: React.FC<ReportsManagerProps> = ({
  personnel,
  onPrintReport,
  onOpenDailyReadinessReport
}) => {
  const [reportType, setReportType] = useState<
    | 'comprehensive'
    | 'readiness'
    | 'daily'
    | 'medical'
    | 'financial'
    | 'security'
    | 'armament'
    | 'training'
    | 'absences'
  >('readiness');

  const [unitFilter, setUnitFilter] = useState('الكل');
  const [rankFilter, setRankFilter] = useState('الكل');
  const [statusFilter, setStatusFilter] = useState('الكل');

  // Filtered dataset for reports
  const reportData = personnel.filter((p) => {
    const matchesUnit = unitFilter === 'الكل' || p.unit === unitFilter;
    const matchesRank = rankFilter === 'الكل' || p.rank === rankFilter;
    const matchesStatus = statusFilter === 'الكل' || p.currentStatus === statusFilter;

    // Report type specific condition
    if (reportType === 'medical') {
      return matchesUnit && matchesRank && matchesStatus && (p.logs?.medical?.length || 0) > 0;
    }
    if (reportType === 'security') {
      return matchesUnit && matchesRank && matchesStatus && (p.logs?.security?.length || 0) > 0;
    }
    if (reportType === 'armament') {
      const hasArmLog = (p.logs?.armament?.length || 0) > 0;
      const hasAssigned = !!(p.assignedWeapon && p.assignedWeapon.trim() !== '' && p.assignedWeapon !== 'غير مسند' && p.assignedWeapon !== '-');
      return matchesUnit && matchesRank && matchesStatus && (hasArmLog || hasAssigned);
    }
    if (reportType === 'training') {
      return matchesUnit && matchesRank && matchesStatus && (p.logs?.training?.length || 0) > 0;
    }
    if (reportType === 'financial') {
      return matchesUnit && matchesRank && matchesStatus && (p.logs?.financial?.length || 0) > 0;
    }
    if (reportType === 'absences') {
      return (
        matchesUnit &&
        matchesRank &&
        matchesStatus &&
        ['إجازة', 'إذن', 'غياب', 'فرار', 'موقوف'].includes(p.currentStatus)
      );
    }

    return matchesUnit && matchesRank && matchesStatus;
  });

  // Calculate accurate totals for armament report
  const armamentTotals = useMemo(() => {
    if (reportType !== 'armament') return { weapons: 0, mags: 0, ammo: 0, armedCount: 0 };
    let weapons = 0;
    let mags = 0;
    let ammo = 0;
    let armedCount = 0;

    reportData.forEach((p) => {
      const arm = p.logs?.armament?.find(a => !a.returnDate && a.status !== 'مورد' && a.weaponSerial && a.weaponSerial !== 'ذخيرة فقط') || p.logs?.armament?.[0];
      const direct = p.armament;
      const hasWpn = !!(
        (arm && arm.weaponSerial && arm.weaponSerial !== '-' && arm.weaponSerial !== 'ذخيرة فقط') ||
        (direct && direct.serialNumber && direct.serialNumber !== '-') ||
        (p.assignedWeapon && p.assignedWeapon !== 'غير مسند' && p.assignedWeapon !== '-')
      );
      if (hasWpn) {
        weapons += 1;
        armedCount += 1;
        mags += Number(arm?.firelinesCount) || Number(direct?.magazinesCount) || 0;
        ammo += Number(arm?.ammoQty) || Number(direct?.ammoQty) || Number(direct?.ammoCount) || 0;
      }
    });

    return { weapons, mags, ammo, armedCount };
  }, [reportData, reportType]);

  // Unique units list
  const uniqueUnits = Array.from(new Set(personnel.map((p) => p.unit)));

  // Current Arabic Report Title
  const currentTitle = REPORT_TITLES_MAP[reportType] || 'تقرير عسكري منظم';

  // Organized Export to Excel (.xlsx)
  const exportToExcel = () => {
    const dateStr = new Date().toISOString().split('T')[0];
    const fileName = `${currentTitle.replace(/\s+/g, '_')}_${dateStr}.xlsx`;

    let dataRows: any[] = [];

    if (reportType === 'security') {
      dataRows = reportData.flatMap((p, idx) => {
        const secLogs = p.logs?.security || [];
        if (secLogs.length === 0) {
          return [{
            'م': String(idx + 1),
            'الرقم العسكري': p.militaryId,
            'الاسم الكامل': p.fullName,
            'الرتبة': p.rank,
            'الوحدة والكتيبة': `${p.unit} / ${p.battalion}`,
            'نوع المخالفة': 'لا توجد مخالفة مقيدة',
            'درجة الخطورة': '-',
            'تفاصيل التحقيق': '-',
            'العقوبة المقررة': '-',
            'أمر التوقيف': '-',
            'جهة التحقيق': '-',
            'حالة المخالفة': '-',
            'التاريخ': '-'
          }];
        }
        return secLogs.map((sec, sIdx) => ({
          'م': `${idx + 1}.${sIdx + 1}`,
          'الرقم العسكري': p.militaryId,
          'الاسم الكامل': p.fullName,
          'الرتبة': p.rank,
          'الوحدة والكتيبة': `${p.unit} / ${p.battalion}`,
          'نوع المخالفة': sec.violation,
          'درجة الخطورة': sec.warningLevel,
          'تفاصيل التحقيق': sec.investigationDetails,
          'العقوبة المقررة': sec.penalty,
          'أمر التوقيف': sec.detentionOrder || 'لا يوجد',
          'جهة التحقيق': sec.authority,
          'حالة المخالفة': sec.status,
          'التاريخ': sec.date
        }));
      });
    } else if (reportType === 'armament') {
      dataRows = reportData.flatMap((p, idx) => {
        const armLogs = p.logs?.armament || [];
        if (armLogs.length === 0) {
          return [{
            'م': String(idx + 1),
            'الرقم العسكري': p.militaryId,
            'الاسم الكامل': p.fullName,
            'الرتبة': p.rank,
            'الوحدة': p.unit,
            'حالة الجاهزية': p.currentStatus,
            'السلاح المسند': 'غير مسند',
            'الرقم التسلسلي S/N': '-',
            'حالة السلاح': '-',
            'الحالة الفنية': '-',
            'عدد الخزائن / المخازن': 0,
            'كمية الذخيرة': 0,
            'تاريخ الصرف': '-'
          }];
        }
        return armLogs.map((weapon, wIdx) => ({
          'م': `${idx + 1}.${wIdx + 1}`,
          'الرقم العسكري': p.militaryId,
          'الاسم الكامل': p.fullName,
          'الرتبة': p.rank,
          'الوحدة': p.unit,
          'حالة الجاهزية': p.currentStatus,
          'السلاح المسند': weapon.weaponType,
          'الرقم التسلسلي S/N': weapon.weaponSerial,
          'حالة السلاح': weapon.status || 'بحوزته',
          'الحالة الفنية': weapon.condition,
          'عدد الخزائن / المخازن': Number(weapon.firelinesCount) || 0,
          'كمية الذخيرة': Number(weapon.ammoQty) || 0,
          'تاريخ الصرف': weapon.issueDate
        }));
      });
    } else if (reportType === 'medical') {
      dataRows = reportData.flatMap((p, idx) => {
        const medLogs = p.logs?.medical || [];
        if (medLogs.length === 0) {
          return [{
            'م': String(idx + 1),
            'الرقم العسكري': p.militaryId,
            'الاسم الكامل': p.fullName,
            'الرتبة': p.rank,
            'الوحدة': p.unit,
            'الحالة الحالية': p.currentStatus,
            'التشخيص الطبي': 'سليم معافى',
            'المستشفى': '-',
            'الطبيب المعالج': '-',
            'أيام الإجازة المرضية': 0,
            'الأدوية والتوصيات': 'جاهزية قتالية كاملة',
            'التاريخ': '-'
          }];
        }
        return medLogs.map((med, mIdx) => ({
          'م': `${idx + 1}.${mIdx + 1}`,
          'الرقم العسكري': p.militaryId,
          'الاسم الكامل': p.fullName,
          'الرتبة': p.rank,
          'الوحدة': p.unit,
          'الحالة الحالية': p.currentStatus,
          'التشخيص الطبي': med.diagnosis,
          'المستشفى': med.hospital || 'الخدمات الطبية العسكرية',
          'الطبيب المعالج': med.doctor || '-',
          'أيام الإجازة المرضية': med.sickLeaveDays || 0,
          'الأدوية والتوصيات': med.recommendations || med.notes || med.prescriptionDetails || '-',
          'التاريخ': med.date
        }));
      });
    } else if (reportType === 'training') {
      dataRows = reportData.flatMap((p, idx) => {
        const trnLogs = p.logs?.training || [];
        if (trnLogs.length === 0) {
          return [{
            'م': String(idx + 1),
            'الرقم العسكري': p.militaryId,
            'الاسم الكامل': p.fullName,
            'الرتبة': p.rank,
            'الوحدة': p.unit,
            'اسم الدورة': p.trainingCourseType || 'تدريب عام',
            'نوع الدورة': '-',
            'معهد / جهة التدريب': '-',
            'الفترة الزمنية': '-',
            'المدة بالأسابيع': '-',
            'التقدير': '-',
            'التقييم والشهادة': '-'
          }];
        }
        return trnLogs.map((trn, tIdx) => ({
          'م': `${idx + 1}.${tIdx + 1}`,
          'الرقم العسكري': p.militaryId,
          'الاسم الكامل': p.fullName,
          'الرتبة': p.rank,
          'الوحدة': p.unit,
          'اسم الدورة': trn.courseName,
          'نوع الدورة': String(trn.courseType),
          'معهد / جهة التدريب': trn.provider,
          'الفترة الزمنية': `${trn.startDate} إلى ${trn.endDate}`,
          'المدة بالأسابيع': String(trn.durationWeeks),
          'التقدير': trn.grade,
          'التقييم والشهادة': trn.evaluation || trn.certificates || '-'
        }));
      });
    } else if (reportType === 'financial') {
      dataRows = reportData.flatMap((p, idx) => {
        const finLogs = p.logs?.financial || [];
        if (finLogs.length === 0) {
          return [{
            'م': String(idx + 1),
            'الرقم العسكري': p.militaryId,
            'الاسم الكامل': p.fullName,
            'الرتبة': p.rank,
            'الوحدة': p.unit,
            'نوع المعاملة': 'راتب أساسي',
            'المبلغ (ريال)': 0,
            'السبب والغرض': 'لا توجد حركات مقيدة',
            'تاريخ المعاملة': '-',
            'الجهة المعتمدة': '-'
          }];
        }
        return finLogs.map((fin, fIdx) => ({
          'م': `${idx + 1}.${fIdx + 1}`,
          'الرقم العسكري': p.militaryId,
          'الاسم الكامل': p.fullName,
          'الرتبة': p.rank,
          'الوحدة': p.unit,
          'نوع المعاملة': String(fin.type),
          'المبلغ (ريال)': fin.amount,
          'السبب والغرض': fin.reason,
          'تاريخ المعاملة': fin.transactionDate || fin.date,
          'الجهة المعتمدة': fin.approvedBy || '-'
        }));
      });
    } else if (reportType === 'absences') {
      dataRows = reportData.map((p, idx) => {
        const att = p.logs?.attendance?.[0];
        return {
          'م': String(idx + 1),
          'الرقم العسكري': p.militaryId,
          'الاسم الكامل': p.fullName,
          'الرتبة': p.rank,
          'الوحدة والكتيبة': `${p.unit} / ${p.battalion}`,
          'الحالة الحالية': p.currentStatus,
          'نوع الحركة': att ? att.type : p.currentStatus,
          'تاريخ البدء': att?.startDate || '-',
          'تاريخ الانتهاء': att?.endDate || '-',
          'المدة بالأيام': att?.durationDays || '-',
          'الجهة المعتمدة': att?.approvedBy || '-',
          'ملاحظات وسبب الغياب/الإجازة': att?.reason || '-'
        };
      });
    } else if (reportType === 'readiness') {
      dataRows = reportData.map((p, idx) => ({
        'م': String(idx + 1),
        'الرقم العسكري': p.militaryId,
        'الاسم الكامل': p.fullName,
        'الرتبة': p.rank,
        'الوحدة والكتيبة': `${p.unit} / ${p.battalion}`,
        'الحالة الراهنة': p.currentStatus,
        'الجاهزية القتالية': p.combatReadiness || '100% جاهز للقتال',
        'فصيلة الدم': p.bloodType || 'غير مسجلة',
        'اللياقة الطبية': p.medicalFitness || 'لائق أ',
        'السلاح المسند': p.assignedWeapon || p.logs?.armament?.[0]?.weaponType || 'غير مسند',
        'الوظيفة العسكرية': p.jobTitle || 'غير محدد',
        'رقم الهاتف': p.phone || '-'
      }));
    } else if (reportType === 'daily') {
      dataRows = reportData.map((p, idx) => ({
        'م': String(idx + 1),
        'الرقم العسكري': p.militaryId,
        'الاسم الكامل': p.fullName,
        'الرتبة': p.rank,
        'الوحدة والكتيبة': `${p.unit} / ${p.battalion}`,
        'التمام اليومي': p.currentStatus,
        'الجهة المنتدب إليها': p.secondedUnit || '-',
        'نوع الدورة': p.trainingCourseType || '-',
        'آخر تحديث': p.lastStatusChangeDate || '-',
        'رقم الهاتف': p.phone || '-'
      }));
    } else {
      dataRows = reportData.map((p, idx) => ({
        'م': String(idx + 1),
        'الرقم العسكري': p.militaryId,
        'الاسم الكامل': p.fullName,
        'الرتبة': p.rank,
        'رقم الهوية': p.nationalId || '-',
        'الوحدة والكتيبة': `${p.unit} / ${p.battalion || '-'}`,
        'السرية': p.company || '-',
        'الوظيفة العسكرية': p.jobTitle || 'غير محدد',
        'الحالة الحالية': p.currentStatus,
        'رقم الهاتف': p.phone || '-'
      }));
    }

    const ws = XLSX.utils.json_to_sheet(dataRows);
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, currentTitle.slice(0, 31));
    exportExcelWorkbook(wb, fileName);
  };

  // Organized Export to CSV
  const exportToCSV = () => {
    const escapeField = (val: any) => {
      if (val === undefined || val === null) return '""';
      const str = String(val).replace(/"/g, '""');
      return `"${str}"`;
    };

    const generationDate = new Date().toLocaleString('ar-SA');
    const headerInfo = getCurrentHeaderInfo();

    // Header metadata lines for clean document organization
    const metadataHeader = [
      escapeField(`${headerInfo.forceName} - ${headerInfo.divisionName} - ${headerInfo.unitName}`),
      escapeField(`نوع التقرير: ${currentTitle}`),
      escapeField(`تاريخ ووقت التصدير: ${generationDate}`),
      escapeField(`إجمالي السجلات المسجلة: ${reportData.length} فرد`),
      escapeField(`درجة السرية: سري للغاية وللإستعمال الرسمـي فقط`),
      ''
    ].join('\n');

    let headers: string[] = [];
    let rows: string[][] = [];

    if (reportType === 'security') {
      headers = ['الرقم الوظيفي', 'الاسم الرباعي', 'الرتبة', 'الوحدة والكتيبة', 'نوع المخالفة', 'درجة الخطورة', 'تفاصيل التحقيق', 'العقوبة المقررة', 'أمر التوقيف', 'جهة التحقيق', 'حالة المخالفة', 'تاريخ المخالفة'];
      rows = reportData.flatMap((p) => {
        const secLogs = p.logs?.security || [];
        if (secLogs.length === 0) {
          return [[p.militaryId, p.fullName, p.rank, `${p.unit} / ${p.battalion}`, 'لا توجد مخالفة', '-', '-', '-', '-', '-', '-', '-']];
        }
        return secLogs.map((sec) => [
          p.militaryId,
          p.fullName,
          p.rank,
          `${p.unit} / ${p.battalion}`,
          sec.violation,
          sec.warningLevel,
          sec.investigationDetails,
          sec.penalty,
          sec.detentionOrder || 'لا يوجد',
          sec.authority,
          sec.status,
          sec.date
        ]);
      });
    } else if (reportType === 'armament') {
      headers = ['الرقم الوظيفي', 'الاسم الرباعي', 'الرتبة', 'الوحدة', 'الحالة', 'السلاح المسند', 'الرقم التسلسلي S/N', 'حالة السلاح', 'الحالة الفنية', 'عدد المخازن', 'كمية الذخيرة', 'تاريخ الصرف'];
      rows = reportData.flatMap((p) => {
        const weapons = p.logs?.armament || [];
        if (weapons.length === 0) {
          return [[p.militaryId, p.fullName, p.rank, p.unit, p.currentStatus, 'غير مسند', '-', '-', '-', '0', '0', '-']];
        }
        return weapons.map((w) => [
          p.militaryId,
          p.fullName,
          p.rank,
          p.unit,
          p.currentStatus,
          w.weaponType,
          w.weaponSerial,
          w.status || 'بحوزته',
          w.condition,
          String(Number(w.firelinesCount) || 0),
          String(Number(w.ammoQty) || 0),
          w.issueDate
        ]);
      });
    } else if (reportType === 'medical') {
      headers = ['الرقم الوظيفي', 'الاسم الرباعي', 'الرتبة', 'الوحدة', 'الحالة الحالية', 'التشخيص الطبي', 'المستشفى', 'الطبيب المعالج', 'أيام الإجازة المرضية', 'الأدوية والتوصيات', 'تاريخ الكشف'];
      rows = reportData.flatMap((p) => {
        const meds = p.logs?.medical || [];
        if (meds.length === 0) {
          return [[p.militaryId, p.fullName, p.rank, p.unit, p.currentStatus, 'سليم معافى', '-', '-', '0', 'جاهزية قتالية كاملة', '-']];
        }
        return meds.map((m) => [
          p.militaryId,
          p.fullName,
          p.rank,
          p.unit,
          p.currentStatus,
          m.diagnosis,
          m.hospital || 'الخدمات الطبية',
          m.doctor || '-',
          String(m.sickLeaveDays || 0),
          m.recommendations || m.notes || '-',
          m.date
        ]);
      });
    } else if (reportType === 'training') {
      headers = ['الرقم الوظيفي', 'الاسم الرباعي', 'الرتبة', 'الوحدة', 'اسم الدورة', 'نوع الدورة', 'جهة التدريب', 'الفترة الزمنية', 'المدة بالأسابيع', 'التقدير', 'التقييم والشهادة'];
      rows = reportData.flatMap((p) => {
        const trns = p.logs?.training || [];
        if (trns.length === 0) {
          return [[p.militaryId, p.fullName, p.rank, p.unit, p.trainingCourseType || 'تدريب عام', '-', '-', '-', '-', '-', '-']];
        }
        return trns.map((t) => [
          p.militaryId,
          p.fullName,
          p.rank,
          p.unit,
          t.courseName,
          t.courseType,
          t.provider,
          `${t.startDate} إلى ${t.endDate}`,
          String(t.durationWeeks),
          t.grade,
          t.evaluation || t.certificates || '-'
        ]);
      });
    } else if (reportType === 'financial') {
      headers = ['الرقم الوظيفي', 'الاسم الرباعي', 'الرتبة', 'الوحدة', 'نوع المعاملة', 'المبلغ (ريال)', 'السبب والغرض', 'تاريخ المعاملة', 'الجهة المعتمدة'];
      rows = reportData.flatMap((p) => {
        const fins = p.logs?.financial || [];
        if (fins.length === 0) {
          return [[p.militaryId, p.fullName, p.rank, p.unit, 'راتب أساسي', '0', '-', '-', '-']];
        }
        return fins.map((f) => [
          p.militaryId,
          p.fullName,
          p.rank,
          p.unit,
          f.type,
          String(f.amount),
          f.reason,
          f.transactionDate || f.date,
          f.approvedBy || '-'
        ]);
      });
    } else if (reportType === 'absences') {
      headers = ['الرقم الوظيفي', 'الاسم الرباعي', 'الرتبة', 'الوحدة والكتيبة', 'الحالة الحالية', 'نوع الحركة', 'تاريخ البدء', 'تاريخ الانتهاء', 'المدة بالأيام', 'الجهة المعتمدة', 'ملاحظات وتفاصيل'];
      rows = reportData.map((p) => {
        const att = p.logs?.attendance?.[0];
        return [
          p.militaryId,
          p.fullName,
          p.rank,
          `${p.unit} / ${p.battalion}`,
          p.currentStatus,
          att ? att.type : p.currentStatus,
          att?.startDate || '-',
          att?.endDate || '-',
          String(att?.durationDays || '-'),
          att?.approvedBy || '-',
          att?.reason || '-'
        ];
      });
    } else {
      headers = ['الرقم الوظيفي', 'الاسم الرباعي', 'الرتبة', 'الرقم الوطني', 'الوحدة والكتيبة', 'السرية', 'الوظيفة العسكرية', 'الحالة الحالية', 'رقم الهاتف'];
      rows = reportData.map((p) => [
        p.militaryId,
        p.fullName,
        p.rank,
        p.nationalId,
        `${p.unit} / ${p.battalion}`,
        p.company,
        p.jobTitle || 'غير محدد',
        p.currentStatus,
        p.phone
      ]);
    }

    const csvDataRows = [
      headers.map(escapeField).join(','),
      ...rows.map((row) => row.map(escapeField).join(','))
    ].join('\n');

    const fullCsvContent = metadataHeader + '\n' + csvDataRows;
    const fileName = `${currentTitle.replace(/\s+/g, '_')}_${new Date().toISOString().split('T')[0]}.csv`;
    exportCSVContent(fullCsvContent, fileName);
  };

  return (
    <div className="space-y-6 pb-12">
      
      {/* Header */}
      <div className="bg-white border border-slate-200 rounded-2xl p-6 shadow-sm flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center space-x-2 space-x-reverse">
            <span className="text-xl">📊</span>
            <h2 className="text-xl font-black text-slate-900 font-['Tajawal']">
              نظام التقارير الذكية والمستندات الرسمية
            </h2>
          </div>
          <p className="text-xs text-slate-500 mt-1 font-medium">
            استخراج وعرض وتصدير التقارير الإدارية والعملياتية والطبية والمالية مع إمكانية التصدير والطباعة المباشرة لكل فرع
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          {onOpenDailyReadinessReport && (
            <button
              onClick={onOpenDailyReadinessReport}
              className="flex items-center space-x-1.5 space-x-reverse bg-emerald-600 hover:bg-emerald-700 text-white border border-emerald-500/50 px-4 py-2 rounded-xl text-xs font-black transition-all shadow-md cursor-pointer"
            >
              <Activity className="w-4 h-4 text-emerald-200 animate-pulse" />
              <span>توليد تقرير الجاهزية اليومي التلقائي (PDF) 📄</span>
            </button>
          )}

          <button
            onClick={exportToExcel}
            className="flex items-center space-x-1.5 space-x-reverse bg-gradient-to-r from-emerald-700 to-teal-700 hover:from-emerald-600 hover:to-teal-600 text-white border border-emerald-500/40 px-4 py-2 rounded-xl text-xs font-black transition-all shadow-md cursor-pointer"
            title="تصدير التقرير الحالي بصيغة إكسل رسمية XLSX"
          >
            <Download className="w-4 h-4 text-emerald-200" />
            <span>تصدير Excel (.xlsx) 📊</span>
          </button>

          <button
            onClick={exportToCSV}
            className="flex items-center space-x-1 space-x-reverse bg-slate-100 hover:bg-slate-200 text-slate-700 border border-slate-300 px-3 py-2 rounded-xl text-xs font-bold transition-all cursor-pointer"
            title="تصدير صيغة CSV"
          >
            <span>CSV</span>
          </button>

          <button
            onClick={() => onPrintReport(currentTitle, reportData, reportType)}
            className="flex items-center space-x-1.5 space-x-reverse bg-slate-900 hover:bg-emerald-800 text-white px-4 py-2 rounded-xl text-xs font-extrabold transition-all shadow-md cursor-pointer border border-emerald-500/40"
            title={`طباعة ${currentTitle}`}
          >
            <Printer className="w-4 h-4 text-emerald-400" />
            <span>طباعة تقرير الفرع المحدد ({reportData.length}) 🖨️</span>
          </button>
        </div>
      </div>

      {/* Report Types Selector Grid */}
      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-3">
        
        <button
          onClick={() => setReportType('readiness')}
          className={`p-3 rounded-xl border text-right transition-all flex flex-col justify-between space-y-2 ${
            reportType === 'readiness'
              ? 'bg-emerald-700 border-emerald-800 text-white shadow-sm'
              : 'bg-white border-slate-200 text-slate-700 hover:bg-slate-50'
          }`}
        >
          <div className="flex items-center justify-between">
            <ShieldCheck className={`w-4 h-4 ${reportType === 'readiness' ? 'text-emerald-200' : 'text-emerald-700'}`} />
            <span className="text-[10px] opacity-75 font-mono">رقم 01</span>
          </div>
          <span className="text-xs font-bold">تقرير الجاهزية القتالية</span>
        </button>

        <button
          onClick={() => setReportType('daily')}
          className={`p-3 rounded-xl border text-right transition-all flex flex-col justify-between space-y-2 ${
            reportType === 'daily'
              ? 'bg-emerald-700 border-emerald-800 text-white shadow-sm'
              : 'bg-white border-slate-200 text-slate-700 hover:bg-slate-50'
          }`}
        >
          <div className="flex items-center justify-between">
            <Users className={`w-4 h-4 ${reportType === 'daily' ? 'text-blue-200' : 'text-blue-700'}`} />
            <span className="text-[10px] opacity-75 font-mono">رقم 02</span>
          </div>
          <span className="text-xs font-bold">تقرير القوة اليومية</span>
        </button>

        <button
          onClick={() => setReportType('comprehensive')}
          className={`p-3 rounded-xl border text-right transition-all flex flex-col justify-between space-y-2 ${
            reportType === 'comprehensive'
              ? 'bg-emerald-700 border-emerald-800 text-white shadow-sm'
              : 'bg-white border-slate-200 text-slate-700 hover:bg-slate-50'
          }`}
        >
          <div className="flex items-center justify-between">
            <FileText className={`w-4 h-4 ${reportType === 'comprehensive' ? 'text-purple-200' : 'text-purple-700'}`} />
            <span className="text-[10px] opacity-75 font-mono">رقم 03</span>
          </div>
          <span className="text-xs font-bold">التقرير الشامل للأفراد</span>
        </button>

        <button
          onClick={() => setReportType('medical')}
          className={`p-3 rounded-xl border text-right transition-all flex flex-col justify-between space-y-2 ${
            reportType === 'medical'
              ? 'bg-emerald-700 border-emerald-800 text-white shadow-sm'
              : 'bg-white border-slate-200 text-slate-700 hover:bg-slate-50'
          }`}
        >
          <div className="flex items-center justify-between">
            <Activity className={`w-4 h-4 ${reportType === 'medical' ? 'text-pink-200' : 'text-pink-700'}`} />
            <span className="text-[10px] opacity-75 font-mono">رقم 04</span>
          </div>
          <span className="text-xs font-bold">التقرير الطبي والمنومين</span>
        </button>

        <button
          onClick={() => setReportType('financial')}
          className={`p-3 rounded-xl border text-right transition-all flex flex-col justify-between space-y-2 ${
            reportType === 'financial'
              ? 'bg-emerald-700 border-emerald-800 text-white shadow-sm'
              : 'bg-white border-slate-200 text-slate-700 hover:bg-slate-50'
          }`}
        >
          <div className="flex items-center justify-between">
            <DollarSign className={`w-4 h-4 ${reportType === 'financial' ? 'text-teal-200' : 'text-teal-700'}`} />
            <span className="text-[10px] opacity-75 font-mono">رقم 05</span>
          </div>
          <span className="text-xs font-bold">التقرير المالي والإجمالي</span>
        </button>

        <button
          onClick={() => setReportType('security')}
          className={`p-3 rounded-xl border text-right transition-all flex flex-col justify-between space-y-2 ${
            reportType === 'security'
              ? 'bg-emerald-700 border-emerald-800 text-white shadow-sm'
              : 'bg-white border-slate-200 text-slate-700 hover:bg-slate-50'
          }`}
        >
          <div className="flex items-center justify-between">
            <Lock className={`w-4 h-4 ${reportType === 'security' ? 'text-rose-200' : 'text-rose-700'}`} />
            <span className="text-[10px] opacity-75 font-mono">رقم 06</span>
          </div>
          <span className="text-xs font-bold">التقرير الأمني والمخالفات</span>
        </button>

        <button
          onClick={() => setReportType('armament')}
          className={`p-3 rounded-xl border text-right transition-all flex flex-col justify-between space-y-2 ${
            reportType === 'armament'
              ? 'bg-emerald-700 border-emerald-800 text-white shadow-sm'
              : 'bg-white border-slate-200 text-slate-700 hover:bg-slate-50'
          }`}
        >
          <div className="flex items-center justify-between">
            <Crosshair className={`w-4 h-4 ${reportType === 'armament' ? 'text-amber-200' : 'text-amber-700'}`} />
            <span className="text-[10px] opacity-75 font-mono">رقم 07</span>
          </div>
          <span className="text-xs font-bold">تقرير التسليح والذخيرة</span>
        </button>

        <button
          onClick={() => setReportType('training')}
          className={`p-3 rounded-xl border text-right transition-all flex flex-col justify-between space-y-2 ${
            reportType === 'training'
              ? 'bg-emerald-700 border-emerald-800 text-white shadow-sm'
              : 'bg-white border-slate-200 text-slate-700 hover:bg-slate-50'
          }`}
        >
          <div className="flex items-center justify-between">
            <Award className={`w-4 h-4 ${reportType === 'training' ? 'text-purple-200' : 'text-purple-700'}`} />
            <span className="text-[10px] opacity-75 font-mono">رقم 08</span>
          </div>
          <span className="text-xs font-bold">تقرير التدريب والدورات</span>
        </button>

        <button
          onClick={() => setReportType('absences')}
          className={`p-3 rounded-xl border text-right transition-all flex flex-col justify-between space-y-2 col-span-2 sm:col-span-1 ${
            reportType === 'absences'
              ? 'bg-emerald-700 border-emerald-800 text-white shadow-sm'
              : 'bg-white border-slate-200 text-slate-700 hover:bg-slate-50'
          }`}
        >
          <div className="flex items-center justify-between">
            <Calendar className={`w-4 h-4 ${reportType === 'absences' ? 'text-orange-200' : 'text-orange-700'}`} />
            <span className="text-[10px] opacity-75 font-mono">رقم 09</span>
          </div>
          <span className="text-xs font-bold">تقرير الغياب والإجازات والفرار</span>
        </button>

      </div>

      {/* Report Filter Controls */}
      <div className="bg-white border border-slate-200 rounded-2xl p-4 shadow-sm grid grid-cols-1 sm:grid-cols-3 gap-3">
        <div>
          <label className="block text-[11px] font-bold text-slate-600 mb-1">فلترة حسب الوحدة:</label>
          <select
            value={unitFilter}
            onChange={(e) => setUnitFilter(e.target.value)}
            className="w-full bg-slate-50 border border-slate-300 rounded-xl px-3 py-1.5 text-xs text-slate-800 focus:outline-none focus:bg-white focus:border-emerald-600"
          >
            <option value="الكل">جميع الوحدات</option>
            {uniqueUnits.map((u) => (
              <option key={u} value={u}>
                {u}
              </option>
            ))}
          </select>
        </div>

        <div>
          <label className="block text-[11px] font-bold text-slate-600 mb-1">فلترة حسب الرتبة:</label>
          <select
            value={rankFilter}
            onChange={(e) => setRankFilter(e.target.value)}
            className="w-full bg-slate-50 border border-slate-300 rounded-xl px-3 py-1.5 text-xs text-slate-800 focus:outline-none focus:bg-white focus:border-emerald-600"
          >
            <option value="الكل">جميع الرتب</option>
            <option value="عقيد">عقيد</option>
            <option value="مقدم">مقدم</option>
            <option value="رائد">رائد</option>
            <option value="نقيب">نقيب</option>
            <option value="ملازم أول">ملازم أول</option>
            <option value="ملازم">ملازم</option>
            <option value="رئيس رقباء">رئيس رقباء</option>
            <option value="رقيب أول">رقيب أول</option>
            <option value="رقيب">رقيب</option>
            <option value="وكيل رقيب">وكيل رقيب</option>
            <option value="عريف">عريف</option>
            <option value="جندي أول">جندي أول</option>
            <option value="جندي">جندي</option>
          </select>
        </div>

        <div>
          <label className="block text-[11px] font-bold text-slate-600 mb-1">فلترة حسب الحالة الحالية:</label>
          <select
            value={statusFilter}
            onChange={(e) => setStatusFilter(e.target.value)}
            className="w-full bg-slate-50 border border-slate-300 rounded-xl px-3 py-1.5 text-xs text-slate-800 focus:outline-none focus:bg-white focus:border-emerald-600"
          >
            <option value="الكل">جميع الحالات</option>
            <option value="متواجد">متواجد</option>
            <option value="في الميدان">في الميدان</option>
            <option value="مأمورية">مأمورية</option>
            <option value="منتدب">منتدب (انتداب)</option>
            <option value="دورة تدريبية داخلية">دورة تدريبية داخلية 🎓</option>
            <option value="دورة تدريبية خارجية">دورة تدريبية خارجية ✈️</option>
            <option value="إجازة">إجازة</option>
            <option value="إذن">إذن</option>
            <option value="مستشفى">مستشفى</option>
            <option value="جريح">جريح 🩹</option>
            <option value="غياب">غياب</option>
            <option value="فرار">فرار</option>
            <option value="اسير">اسير ⛓️</option>
            <option value="شهيد">شهيد 🎖️</option>
            <option value="معاق">معاق ♿</option>
            <option value="مفقود">مفقود ❓</option>
            <option value="موقوف">موقوف</option>
            <option value="احتياط">احتياط</option>
          </select>
        </div>
      </div>

      {/* Generated Report View Container */}
      <div className="bg-white border border-slate-200 rounded-2xl shadow-sm p-6 space-y-4">
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between border-b border-slate-200 pb-3 gap-3">
          <div>
            <div className="flex items-center space-x-2 space-x-reverse">
              <span className="text-emerald-700 font-black text-sm">📋 {currentTitle}</span>
              <span className="bg-emerald-100 text-emerald-800 text-[11px] font-mono px-2 py-0.5 rounded-full font-bold">
                {reportData.length} فرد مسجل
              </span>
            </div>
            <p className="text-[11px] text-slate-500 mt-0.5">
              بيانات ومستندات الفرع المحدد المعتمدة وجاهزة للطباعة والتصدير الفوري
            </p>
          </div>

          <div className="flex items-center space-x-2 space-x-reverse flex-wrap gap-1.5">
            <span className="text-[11px] text-slate-500 font-mono font-bold hidden sm:inline">
              تاريخ الاستخراج: {new Date().toISOString().split('T')[0]}
            </span>
            <button
              type="button"
              onClick={() => onPrintReport(currentTitle, reportData, reportType)}
              className="bg-emerald-700 hover:bg-emerald-800 text-white font-black px-4 py-2 rounded-xl text-xs flex items-center space-x-1.5 space-x-reverse shadow-md transition-all cursor-pointer border border-emerald-600"
            >
              <Printer className="w-3.5 h-3.5 text-emerald-200" />
              <span>طباعة كشف هذا الفرع 🖨️</span>
            </button>
          </div>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-right text-xs">
            <thead className="bg-slate-100 text-slate-800 font-bold border-b border-slate-200">
              {reportType === 'security' ? (
                <tr>
                  <th className="px-3 py-2.5">#</th>
                  <th className="px-3 py-2.5">الرقم الوظيفي</th>
                  <th className="px-3 py-2.5">الاسم الرباعي</th>
                  <th className="px-3 py-2.5">الرتبة</th>
                  <th className="px-3 py-2.5">الوحدة والكتيبة</th>
                  <th className="px-3 py-2.5">نوع المخالفة</th>
                  <th className="px-3 py-2.5">درجة الخطورة</th>
                  <th className="px-3 py-2.5">ملخص التحقيق</th>
                  <th className="px-3 py-2.5">العقوبة المقررة</th>
                  <th className="px-3 py-2.5">أمر التوقيف</th>
                  <th className="px-3 py-2.5">جهة التحقيق</th>
                  <th className="px-3 py-2.5">الحالة</th>
                  <th className="px-3 py-2.5">تاريخ المخالفة</th>
                </tr>
              ) : reportType === 'medical' ? (
                <tr>
                  <th className="px-3 py-2.5">#</th>
                  <th className="px-3 py-2.5">الرقم الوظيفي</th>
                  <th className="px-3 py-2.5">الاسم الرباعي</th>
                  <th className="px-3 py-2.5">الرتبة</th>
                  <th className="px-3 py-2.5">الوحدة</th>
                  <th className="px-3 py-2.5">الحالة الحالية</th>
                  <th className="px-3 py-2.5">التشخيص الطبي</th>
                  <th className="px-3 py-2.5">المستشفى</th>
                  <th className="px-3 py-2.5">الطبيب المعالج</th>
                  <th className="px-3 py-2.5">أيام الإجازة</th>
                  <th className="px-3 py-2.5">التوصيات الطبية</th>
                  <th className="px-3 py-2.5">تاريخ الكشف</th>
                </tr>
              ) : reportType === 'armament' ? (
                <tr>
                  <th className="px-3 py-2.5">#</th>
                  <th className="px-3 py-2.5">الرقم الوظيفي</th>
                  <th className="px-3 py-2.5">الاسم الرباعي</th>
                  <th className="px-3 py-2.5">الرتبة</th>
                  <th className="px-3 py-2.5">الوحدة</th>
                  <th className="px-3 py-2.5">نوع السلاح</th>
                  <th className="px-3 py-2.5">الرقم التسلسلي S/N</th>
                  <th className="px-3 py-2.5">حالة العهدة</th>
                  <th className="px-3 py-2.5">الحالة الفنية</th>
                  <th className="px-3 py-2.5">عدد الخزائن</th>
                  <th className="px-3 py-2.5">كمية الذخيرة</th>
                  <th className="px-3 py-2.5">تاريخ الصرف</th>
                </tr>
              ) : reportType === 'training' ? (
                <tr>
                  <th className="px-3 py-2.5">#</th>
                  <th className="px-3 py-2.5">الرقم الوظيفي</th>
                  <th className="px-3 py-2.5">الاسم الرباعي</th>
                  <th className="px-3 py-2.5">الرتبة</th>
                  <th className="px-3 py-2.5">الوحدة</th>
                  <th className="px-3 py-2.5">اسم الدورة</th>
                  <th className="px-3 py-2.5">نوع الدورة</th>
                  <th className="px-3 py-2.5">جهة التدريب</th>
                  <th className="px-3 py-2.5">الفترة الزمنية</th>
                  <th className="px-3 py-2.5">المدة</th>
                  <th className="px-3 py-2.5">التقدير</th>
                  <th className="px-3 py-2.5">التقييم والشهادة</th>
                </tr>
              ) : reportType === 'financial' ? (
                <tr>
                  <th className="px-3 py-2.5">#</th>
                  <th className="px-3 py-2.5">الرقم الوظيفي</th>
                  <th className="px-3 py-2.5">الاسم الرباعي</th>
                  <th className="px-3 py-2.5">الرتبة</th>
                  <th className="px-3 py-2.5">الوحدة</th>
                  <th className="px-3 py-2.5">نوع المعاملة</th>
                  <th className="px-3 py-2.5">المبلغ (ريال)</th>
                  <th className="px-3 py-2.5">السبب والغرض</th>
                  <th className="px-3 py-2.5">تاريخ المعاملة</th>
                  <th className="px-3 py-2.5">الجهة المعتمدة</th>
                </tr>
              ) : reportType === 'absences' ? (
                <tr>
                  <th className="px-3 py-2.5">#</th>
                  <th className="px-3 py-2.5">الرقم الوظيفي</th>
                  <th className="px-3 py-2.5">الاسم الرباعي</th>
                  <th className="px-3 py-2.5">الرتبة</th>
                  <th className="px-3 py-2.5">الوحدة والكتيبة</th>
                  <th className="px-3 py-2.5">نوع الحالة</th>
                  <th className="px-3 py-2.5">سبب الغياب / الإجازة</th>
                  <th className="px-3 py-2.5">تاريخ البدء</th>
                  <th className="px-3 py-2.5">تاريخ الانتهاء</th>
                  <th className="px-3 py-2.5">المدة بالأيام</th>
                  <th className="px-3 py-2.5">جهة الاعتماد</th>
                </tr>
              ) : reportType === 'readiness' ? (
                <tr>
                  <th className="px-3 py-2.5">#</th>
                  <th className="px-3 py-2.5">الرقم الوظيفي</th>
                  <th className="px-3 py-2.5">الاسم الرباعي</th>
                  <th className="px-3 py-2.5">الرتبة</th>
                  <th className="px-3 py-2.5">الوحدة والكتيبة</th>
                  <th className="px-3 py-2.5">الحالة الراهنة</th>
                  <th className="px-3 py-2.5">الجاهزية القتالية</th>
                  <th className="px-3 py-2.5">فصيلة الدم</th>
                  <th className="px-3 py-2.5">اللياقة الطبية</th>
                  <th className="px-3 py-2.5">السلاح المسند</th>
                  <th className="px-3 py-2.5">الوظيفة</th>
                  <th className="px-3 py-2.5">رقم الهاتف</th>
                </tr>
              ) : reportType === 'daily' ? (
                <tr>
                  <th className="px-3 py-2.5">#</th>
                  <th className="px-3 py-2.5">الرقم الوظيفي</th>
                  <th className="px-3 py-2.5">الاسم الرباعي</th>
                  <th className="px-3 py-2.5">الرتبة</th>
                  <th className="px-3 py-2.5">الوحدة والكتيبة</th>
                  <th className="px-3 py-2.5">التمام اليومي</th>
                  <th className="px-3 py-2.5">جهة الانتداب / المأمورية</th>
                  <th className="px-3 py-2.5">الدورة التدريبية</th>
                  <th className="px-3 py-2.5">تاريخ آخر تحديث</th>
                  <th className="px-3 py-2.5">رقم الهاتف</th>
                </tr>
              ) : (
                <tr>
                  <th className="px-3 py-2.5">#</th>
                  <th className="px-3 py-2.5">الرقم الوظيفي</th>
                  <th className="px-3 py-2.5">الاسم الرباعي</th>
                  <th className="px-3 py-2.5">الرتبة</th>
                  <th className="px-3 py-2.5">الرقم الوطني</th>
                  <th className="px-3 py-2.5">الوحدة والكتيبة</th>
                  <th className="px-3 py-2.5">الوظيفة العسكرية</th>
                  <th className="px-3 py-2.5">تاريخ الالتحاق</th>
                  <th className="px-3 py-2.5">الحالة الحالية</th>
                  <th className="px-3 py-2.5">رقم الهاتف</th>
                </tr>
              )}
            </thead>
            <tbody className="divide-y divide-slate-100">
              {reportData.length === 0 ? (
                <tr>
                  <td colSpan={13} className="px-4 py-8 text-center text-slate-500 font-bold">
                    لا توجد سجلات مطابقة لهذا الفرع أو الفلاتر المحددة حالياً.
                  </td>
                </tr>
              ) : (
                reportData.map((p, idx) => {
                  if (reportType === 'security') {
                    const sec = p.logs?.security?.[0];
                    return (
                      <tr key={p.militaryId} className="hover:bg-slate-50">
                        <td className="px-3 py-2 font-mono text-slate-400">{idx + 1}</td>
                        <td className="px-3 py-2 font-mono text-emerald-800 font-bold">{p.militaryId}</td>
                        <td className="px-3 py-2 text-slate-900 font-bold">{p.fullName}</td>
                        <td className="px-3 py-2 font-extrabold text-slate-800">{p.rank}</td>
                        <td className="px-3 py-2 text-slate-700">{p.unit} ({p.battalion})</td>
                        <td className="px-3 py-2 text-rose-700 font-bold">{sec?.violation || 'لا توجد'}</td>
                        <td className="px-3 py-2">
                          <span className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                            sec?.warningLevel === 'حرج' || sec?.warningLevel === 'شديد الخطورة'
                              ? 'bg-rose-100 text-rose-800 border border-rose-300'
                              : 'bg-amber-100 text-amber-800 border border-amber-300'
                          }`}>
                            {sec?.warningLevel || '-'}
                          </span>
                        </td>
                        <td className="px-3 py-2 text-slate-600 max-w-xs truncate" title={sec?.investigationDetails}>
                          {sec?.investigationDetails || '-'}
                        </td>
                        <td className="px-3 py-2 font-bold text-slate-900">{sec?.penalty || '-'}</td>
                        <td className="px-3 py-2 font-mono text-rose-800">{sec?.detentionOrder || '-'}</td>
                        <td className="px-3 py-2 text-slate-700">{sec?.authority || '-'}</td>
                        <td className="px-3 py-2">
                          <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-slate-100 text-slate-800 border border-slate-300">
                            {sec?.status || '-'}
                          </span>
                        </td>
                        <td className="px-3 py-2 font-mono text-slate-500">{sec?.date || '-'}</td>
                      </tr>
                    );
                  }

                  if (reportType === 'medical') {
                    const med = p.logs?.medical?.[0];
                    return (
                      <tr key={p.militaryId} className="hover:bg-slate-50">
                        <td className="px-3 py-2 font-mono text-slate-400">{idx + 1}</td>
                        <td className="px-3 py-2 font-mono text-emerald-800 font-bold">{p.militaryId}</td>
                        <td className="px-3 py-2 text-slate-900 font-bold">{p.fullName}</td>
                        <td className="px-3 py-2 font-extrabold text-slate-800">{p.rank}</td>
                        <td className="px-3 py-2 text-slate-700">{p.unit}</td>
                        <td className="px-3 py-2">
                          <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-pink-100 text-pink-800 border border-pink-200">
                            {p.currentStatus}
                          </span>
                        </td>
                        <td className="px-3 py-2 text-slate-900 font-bold">{med?.diagnosis || 'سليم'}</td>
                        <td className="px-3 py-2 text-slate-700">{med?.hospital || '-'}</td>
                        <td className="px-3 py-2 text-slate-700">{med?.doctor || '-'}</td>
                        <td className="px-3 py-2 font-bold text-pink-800 font-mono">{med?.sickLeaveDays || 0} يوم</td>
                        <td className="px-3 py-2 text-slate-600 max-w-xs truncate" title={med?.recommendations || med?.notes}>
                          {med?.recommendations || med?.notes || '-'}
                        </td>
                        <td className="px-3 py-2 font-mono text-slate-500">{med?.date || '-'}</td>
                      </tr>
                    );
                  }

                  if (reportType === 'armament') {
                    const arm = p.logs?.armament?.find(a => !a.returnDate && a.status !== 'مورد' && a.weaponSerial && a.weaponSerial !== 'ذخيرة فقط') || p.logs?.armament?.[0];
                    const direct = p.armament;
                    const hasWpn = !!(
                      (arm && arm.weaponSerial && arm.weaponSerial !== '-' && arm.weaponSerial !== 'ذخيرة فقط') ||
                      (direct && direct.serialNumber && direct.serialNumber !== '-') ||
                      (p.assignedWeapon && p.assignedWeapon !== 'غير مسند' && p.assignedWeapon !== '-')
                    );
                    const weaponType = arm?.weaponType || direct?.weaponType || direct?.name || p.assignedWeapon || (hasWpn ? 'سلاح فردي' : 'غير مسند');
                    const weaponSerial = arm?.weaponSerial || direct?.serialNumber || direct?.weaponSerial || '-';
                    const status = arm?.status || (hasWpn ? 'بحوزته' : 'غير مسلّح');
                    const firelinesCount = hasWpn ? (Number(arm?.firelinesCount) || Number(direct?.magazinesCount) || 0) : 0;
                    const ammoQty = hasWpn ? (Number(arm?.ammoQty) || Number(direct?.ammoQty) || Number(direct?.ammoCount) || 0) : 0;
                    const issueDate = arm?.issueDate || '-';
                    return (
                      <tr key={p.militaryId} className="hover:bg-slate-50">
                        <td className="px-3 py-2 font-mono text-slate-400">{idx + 1}</td>
                        <td className="px-3 py-2 font-mono text-emerald-800 font-bold">{p.militaryId}</td>
                        <td className="px-3 py-2 text-slate-900 font-bold">{p.fullName}</td>
                        <td className="px-3 py-2 font-extrabold text-slate-800">{p.rank}</td>
                        <td className="px-3 py-2 text-slate-700">{p.unit}</td>
                        <td className="px-3 py-2 font-bold text-slate-900">{weaponType}</td>
                        <td className="px-3 py-2 font-mono text-amber-800 font-bold">{weaponSerial}</td>
                        <td className="px-3 py-2">
                          <span className={`px-2 py-0.5 rounded text-[10px] font-bold ${hasWpn ? 'bg-amber-100 text-amber-800 border border-amber-200' : 'bg-slate-100 text-slate-600 border border-slate-200'}`}>
                            {status}
                          </span>
                        </td>
                        <td className="px-3 py-2 font-mono text-center font-bold text-slate-800">{firelinesCount}</td>
                        <td className="px-3 py-2 font-mono text-emerald-800 font-bold">{ammoQty.toLocaleString()} طلقة</td>
                        <td className="px-3 py-2 font-mono text-slate-500">{issueDate}</td>
                      </tr>
                    );
                  }

                  if (reportType === 'training') {
                    const trn = p.logs?.training?.[0];
                    return (
                      <tr key={p.militaryId} className="hover:bg-slate-50">
                        <td className="px-3 py-2 font-mono text-slate-400">{idx + 1}</td>
                        <td className="px-3 py-2 font-mono text-emerald-800 font-bold">{p.militaryId}</td>
                        <td className="px-3 py-2 text-slate-900 font-bold">{p.fullName}</td>
                        <td className="px-3 py-2 font-extrabold text-slate-800">{p.rank}</td>
                        <td className="px-3 py-2 text-slate-700">{p.unit}</td>
                        <td className="px-3 py-2 font-bold text-purple-900">{trn?.courseName || p.trainingCourseType || 'تدريب عام'}</td>
                        <td className="px-3 py-2 text-slate-700">{trn?.courseType || '-'}</td>
                        <td className="px-3 py-2 text-slate-700">{trn?.provider || '-'}</td>
                        <td className="px-3 py-2 font-mono text-[11px] text-slate-600">{trn?.startDate ? `${trn.startDate} - ${trn.endDate}` : '-'}</td>
                        <td className="px-3 py-2 font-mono text-slate-800">{trn?.durationWeeks ? `${trn.durationWeeks} أسابيع` : '-'}</td>
                        <td className="px-3 py-2 font-bold text-emerald-800">{trn?.grade || '-'}</td>
                        <td className="px-3 py-2 text-slate-600 text-[11px]">{trn?.evaluation || trn?.certificates || '-'}</td>
                      </tr>
                    );
                  }

                  if (reportType === 'financial') {
                    const fin = p.logs?.financial?.[0];
                    const totalAmt = (p.logs?.financial || []).reduce((acc, f) => acc + (f.amount || 0), 0);
                    return (
                      <tr key={p.militaryId} className="hover:bg-slate-50">
                        <td className="px-3 py-2 font-mono text-slate-400">{idx + 1}</td>
                        <td className="px-3 py-2 font-mono text-emerald-800 font-bold">{p.militaryId}</td>
                        <td className="px-3 py-2 text-slate-900 font-bold">{p.fullName}</td>
                        <td className="px-3 py-2 font-extrabold text-slate-800">{p.rank}</td>
                        <td className="px-3 py-2 text-slate-700">{p.unit}</td>
                        <td className="px-3 py-2 font-bold text-teal-800">{fin?.type || 'راتب'}</td>
                        <td className="px-3 py-2 font-mono font-bold text-emerald-800">{totalAmt.toLocaleString()} ريال</td>
                        <td className="px-3 py-2 text-slate-700">{fin?.reason || '-'}</td>
                        <td className="px-3 py-2 font-mono text-slate-500">{fin?.transactionDate || fin?.date || '-'}</td>
                        <td className="px-3 py-2 text-slate-700">{fin?.approvedBy || '-'}</td>
                      </tr>
                    );
                  }

                  if (reportType === 'absences') {
                    const att = p.logs?.attendance?.[0];
                    return (
                      <tr key={p.militaryId} className="hover:bg-slate-50">
                        <td className="px-3 py-2 font-mono text-slate-400">{idx + 1}</td>
                        <td className="px-3 py-2 font-mono text-emerald-800 font-bold">{p.militaryId}</td>
                        <td className="px-3 py-2 text-slate-900 font-bold">{p.fullName}</td>
                        <td className="px-3 py-2 font-extrabold text-slate-800">{p.rank}</td>
                        <td className="px-3 py-2 text-slate-700">{p.unit} ({p.battalion})</td>
                        <td className="px-3 py-2">
                          <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-orange-100 text-orange-900 border border-orange-200">
                            {p.currentStatus}
                          </span>
                        </td>
                        <td className="px-3 py-2 text-slate-700">{att?.reason || '-'}</td>
                        <td className="px-3 py-2 font-mono text-slate-600">{att?.startDate || '-'}</td>
                        <td className="px-3 py-2 font-mono text-slate-600">{att?.endDate || '-'}</td>
                        <td className="px-3 py-2 font-mono font-bold text-orange-800">{att?.durationDays || '-'} يوم</td>
                        <td className="px-3 py-2 text-slate-700">{att?.approvedBy || '-'}</td>
                      </tr>
                    );
                  }

                  if (reportType === 'readiness') {
                    return (
                      <tr key={p.militaryId} className="hover:bg-slate-50">
                        <td className="px-3 py-2 font-mono text-slate-400">{idx + 1}</td>
                        <td className="px-3 py-2 font-mono text-emerald-800 font-bold">{p.militaryId}</td>
                        <td className="px-3 py-2 text-slate-900 font-bold">{p.fullName}</td>
                        <td className="px-3 py-2 font-extrabold text-slate-800">{p.rank}</td>
                        <td className="px-3 py-2 text-slate-700">{p.unit} ({p.battalion})</td>
                        <td className="px-3 py-2">
                          <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-emerald-100 text-emerald-800 border border-emerald-200">
                            {p.currentStatus}
                          </span>
                        </td>
                        <td className="px-3 py-2 font-bold text-emerald-800">{p.combatReadiness || '100% جاهز للقتال'}</td>
                        <td className="px-3 py-2 font-mono font-bold text-rose-700">{p.bloodType || 'غير مسجلة'}</td>
                        <td className="px-3 py-2 text-slate-700">{p.medicalFitness || 'لائق أ'}</td>
                        <td className="px-3 py-2 font-bold text-slate-800">{p.assignedWeapon || p.logs?.armament?.[0]?.weaponType || 'غير مسند'}</td>
                        <td className="px-3 py-2 text-slate-700">{p.jobTitle || 'غير محدد'}</td>
                        <td className="px-3 py-2 font-mono text-slate-600">{p.phone}</td>
                      </tr>
                    );
                  }

                  if (reportType === 'daily') {
                    return (
                      <tr key={p.militaryId} className="hover:bg-slate-50">
                        <td className="px-3 py-2 font-mono text-slate-400">{idx + 1}</td>
                        <td className="px-3 py-2 font-mono text-emerald-800 font-bold">{p.militaryId}</td>
                        <td className="px-3 py-2 text-slate-900 font-bold">{p.fullName}</td>
                        <td className="px-3 py-2 font-extrabold text-slate-800">{p.rank}</td>
                        <td className="px-3 py-2 text-slate-700">{p.unit} ({p.battalion})</td>
                        <td className="px-3 py-2">
                          <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-slate-100 text-slate-800 border border-slate-200">
                            {p.currentStatus}
                          </span>
                        </td>
                        <td className="px-3 py-2 text-purple-800 font-bold">{p.secondedUnit || '-'}</td>
                        <td className="px-3 py-2 text-indigo-800 font-bold">{p.trainingCourseType || '-'}</td>
                        <td className="px-3 py-2 font-mono text-slate-500">{p.lastStatusChangeDate || '-'}</td>
                        <td className="px-3 py-2 font-mono text-slate-600">{p.phone}</td>
                      </tr>
                    );
                  }

                  // Default comprehensive
                  return (
                    <tr key={p.militaryId} className="hover:bg-slate-50">
                      <td className="px-3 py-2 font-mono text-slate-400">{idx + 1}</td>
                      <td className="px-3 py-2 font-mono text-emerald-800 font-bold">{p.militaryId}</td>
                      <td className="px-3 py-2 text-slate-900 font-bold">{p.fullName}</td>
                      <td className="px-3 py-2 font-extrabold text-slate-800">{p.rank}</td>
                      <td className="px-3 py-2 font-mono text-slate-700">{p.nationalId}</td>
                      <td className="px-3 py-2 text-slate-700">{p.unit} ({p.battalion})</td>
                      <td className="px-3 py-2 text-slate-700">{p.jobTitle || 'غير محدد'}</td>
                      <td className="px-3 py-2 font-mono text-slate-500">{p.enlistmentDate || '-'}</td>
                      <td className="px-3 py-2">
                        <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-slate-100 text-slate-800 border border-slate-200">
                          {p.currentStatus}
                        </span>
                      </td>
                      <td className="px-3 py-2 font-mono text-slate-600">{p.phone}</td>
                    </tr>
                  );
                })
              )}
            </tbody>
            {reportType === 'armament' && (
              <tfoot className="bg-slate-100 font-bold text-slate-900 border-t-2 border-slate-300">
                <tr>
                  <td colSpan={5} className="px-3 py-2.5 text-right font-black">
                    المجموع الإجمالي لفرع التسليح:
                  </td>
                  <td colSpan={3} className="px-3 py-2.5 font-bold text-amber-900">
                    إجمالي الأسلحة المنصرفة: {armamentTotals.weapons} قطعة ({armamentTotals.armedCount} فرد مسلح)
                  </td>
                  <td className="px-3 py-2.5 text-center font-mono font-black text-slate-900">
                    {armamentTotals.mags}
                  </td>
                  <td className="px-3 py-2.5 font-mono font-black text-emerald-900">
                    {armamentTotals.ammo.toLocaleString()} طلقة
                  </td>
                  <td className="px-3 py-2.5 text-slate-500 font-mono text-[11px]">
                    مطابق للسجلات
                  </td>
                </tr>
              </tfoot>
            )}
          </table>
        </div>
      </div>

    </div>
  );
};
