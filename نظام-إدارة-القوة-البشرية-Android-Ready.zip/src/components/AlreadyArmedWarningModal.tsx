import React from 'react';
import { ShieldAlert, AlertTriangle, X, ArrowLeft, RotateCcw } from 'lucide-react';
import { PersonnelRecord, ArmamentLog } from '../types';

interface AlreadyArmedWarningModalProps {
  isOpen: boolean;
  onClose: () => void;
  personnel: PersonnelRecord | null;
  existingWeapon: ArmamentLog | null;
  onOpenTurnIn?: (personnel: PersonnelRecord) => void;
}

export const AlreadyArmedWarningModal: React.FC<AlreadyArmedWarningModalProps> = ({
  isOpen,
  onClose,
  personnel,
  existingWeapon,
  onOpenTurnIn
}) => {
  if (!isOpen || !personnel) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-xs font-['Cairo',sans-serif] select-none animate-fadeIn">
      <div className="bg-white border-2 border-rose-500 rounded-3xl max-w-lg w-full shadow-2xl overflow-hidden text-right">
        
        {/* Header */}
        <div className="bg-gradient-to-r from-rose-950 via-slate-900 to-rose-900 p-5 text-white flex items-center justify-between">
          <div className="flex items-center space-x-3 space-x-reverse">
            <div className="w-11 h-11 rounded-2xl bg-rose-500/20 border-2 border-rose-400 flex items-center justify-center text-rose-400 animate-pulse">
              <ShieldAlert className="w-6 h-6" />
            </div>
            <div>
              <h3 className="font-black text-lg text-rose-300 font-['Tajawal']">
                تحذير أمني: الفرد مسلّح بعهدة مسبقة! 🚫
              </h3>
              <p className="text-xs text-rose-200">
                منع ازدواجية تسليح الأفراد وصرف أكثر من قطعة عهدة
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            type="button"
            className="p-1.5 rounded-xl bg-rose-950/60 hover:bg-rose-800 text-rose-200 hover:text-white transition-colors border border-rose-700/50 cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content Body */}
        <div className="p-6 space-y-5">
          
          {/* Target Soldier Card */}
          <div className="bg-slate-50 border border-slate-200 rounded-2xl p-4 flex items-center space-x-3 space-x-reverse">
            <div className="w-12 h-12 rounded-xl bg-slate-800 text-white flex items-center justify-center font-black text-sm shrink-0">
              {personnel.rank}
            </div>
            <div className="space-y-0.5 flex-1 min-w-0">
              <div className="font-black text-slate-900 text-sm">
                {personnel.rank} / {personnel.fullName}
              </div>
              <div className="text-xs text-slate-500 flex items-center space-x-2 space-x-reverse">
                <span className="font-mono bg-slate-200 text-slate-800 px-2 py-0.5 rounded font-bold">
                  {personnel.militaryId}
                </span>
                <span>•</span>
                <span className="text-slate-600 font-bold">{personnel.unit}</span>
              </div>
            </div>
          </div>

          {/* Active Weapon in Custody Details */}
          <div className="bg-rose-50 border-2 border-rose-300 rounded-2xl p-4 space-y-2.5">
            <div className="flex items-center space-x-2 space-x-reverse text-rose-900 font-black text-xs">
              <AlertTriangle className="w-4 h-4 text-rose-600 shrink-0" />
              <span>بيانات السلاح العهدة المقيد بحوزة الفرد حالياً:</span>
            </div>

            <div className="grid grid-cols-2 gap-2 text-xs pt-1">
              <div className="bg-white/80 p-2.5 rounded-xl border border-rose-200">
                <span className="text-[10px] text-slate-500 font-bold block">نوع السلاح:</span>
                <span className="font-black text-slate-900 text-xs">{existingWeapon?.weaponType || 'سلاح عسكري مسند'}</span>
              </div>
              <div className="bg-white/80 p-2.5 rounded-xl border border-rose-200">
                <span className="text-[10px] text-slate-500 font-bold block">الرقم التسلسلي (S/N):</span>
                <span className="font-black font-mono text-rose-700 text-xs">{existingWeapon?.weaponSerial || '-'}</span>
              </div>
              <div className="bg-white/80 p-2.5 rounded-xl border border-rose-200">
                <span className="text-[10px] text-slate-500 font-bold block">تاريخ الصرف:</span>
                <span className="font-mono font-bold text-slate-800 text-xs">{existingWeapon?.issueDate || '-'}</span>
              </div>
              <div className="bg-white/80 p-2.5 rounded-xl border border-rose-200">
                <span className="text-[10px] text-slate-500 font-bold block">الذخيرة المسندة:</span>
                <span className="font-mono font-bold text-amber-700 text-xs">{existingWeapon?.ammoQty || 0} طلقة</span>
              </div>
            </div>
          </div>

          {/* Warning Policy Text */}
          <div className="p-3 bg-amber-50 border border-amber-300 rounded-xl text-xs text-amber-950 leading-relaxed font-bold">
            🚨 <strong>قواعد ولوائح التسليح العسكري:</strong>
            <p className="mt-1 font-medium text-amber-900 text-[11px]">
              لا يجوز صرف سلاح ناري جديد للفرد طالما أن لديه سلاح عهدة فعال بحوزته. إذا كان المطلوب استبدال السلاح أو تسليمه، يرجى أولاً إجراء عملية <strong>[توريد عهدة السلاح السابق إلى المخزن]</strong> لتسوية القيد وإخلاء العهدة.
            </p>
          </div>

          {/* Actions */}
          <div className="pt-3 border-t border-slate-200 flex flex-wrap items-center justify-end gap-2">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2.5 bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-bold rounded-xl transition-colors cursor-pointer"
            >
              إلغاء والتراجع
            </button>
            {onOpenTurnIn && (
              <button
                type="button"
                onClick={() => {
                  onClose();
                  onOpenTurnIn(personnel);
                }}
                className="px-5 py-2.5 bg-amber-600 hover:bg-amber-700 text-white text-xs font-black rounded-xl transition-all shadow-md flex items-center space-x-1.5 space-x-reverse cursor-pointer"
              >
                <RotateCcw className="w-4 h-4 text-white" />
                <span>الانتقال لتوريد السلاح السابق ↩️</span>
              </button>
            )}
          </div>

        </div>
      </div>
    </div>
  );
};
