import React, { useState } from 'react';
import { Printer, Share2, ArrowRight, CheckCircle2, Loader2, FileDown } from 'lucide-react';
import { executeUnifiedPrint, shareOrSavePrintableDocument } from '../lib/unifiedPrintService';

interface PrintHeaderToolbarProps {
  title: string;
  subtitle?: string;
  printableElementRef: React.RefObject<HTMLElement | null>;
  documentTitle: string;
  orientation?: 'portrait' | 'landscape';
  onClose: () => void;
  isReady?: boolean;
  onBeforePrint?: () => void;
  onAfterPrint?: () => void;
  extraActions?: React.ReactNode;
}

export const PrintHeaderToolbar: React.FC<PrintHeaderToolbarProps> = ({
  title,
  subtitle,
  printableElementRef,
  documentTitle,
  orientation = 'portrait',
  onClose,
  isReady = true,
  onBeforePrint,
  onAfterPrint,
  extraActions
}) => {
  const [isProcessing, setIsProcessing] = useState(false);
  const [statusMessage, setStatusMessage] = useState<string | null>(null);

  const handlePrint = async () => {
    if (isProcessing) return;
    setIsProcessing(true);
    setStatusMessage('جاري تجهيز الخطوط والصور للأمر الطباعي...');

    try {
      await executeUnifiedPrint({
        element: printableElementRef.current,
        documentTitle,
        orientation,
        onBeforePrint,
        onAfterPrint
      });
    } catch (err) {
      console.error('Print execution error:', err);
    } finally {
      setIsProcessing(false);
      setStatusMessage(null);
    }
  };

  const handleShareOrSave = async () => {
    if (isProcessing || !printableElementRef.current) return;
    setIsProcessing(true);
    setStatusMessage('جاري تجهيز وتوليد ملف المستند المستقل...');

    try {
      await shareOrSavePrintableDocument(
        printableElementRef.current,
        documentTitle,
        orientation
      );
    } catch (err) {
      console.error('Share or save error:', err);
    } finally {
      setIsProcessing(false);
      setStatusMessage(null);
    }
  };

  return (
    <div className="bg-slate-900 text-white px-4 py-3 sm:px-6 sm:py-3.5 border-b border-slate-700/80 shadow-md flex flex-wrap items-center justify-between gap-3 shrink-0 no-print print:hidden select-none font-['Cairo',sans-serif]">
      {/* Title & Readiness Badge */}
      <div className="flex items-center space-x-3 space-x-reverse min-w-0">
        <div className="p-2 bg-slate-800 rounded-xl border border-slate-700 text-amber-400">
          <Printer className="w-5 h-5" />
        </div>
        <div className="min-w-0">
          <div className="flex items-center gap-2 flex-wrap">
            <h2 className="text-sm sm:text-base font-black text-white truncate">{title}</h2>
            {isReady ? (
              <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-bold bg-emerald-950/80 text-emerald-400 border border-emerald-800/80">
                <CheckCircle2 className="w-3 h-3 text-emerald-400" />
                <span>جاهز للطباعة والتصدير</span>
              </span>
            ) : (
              <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-bold bg-amber-950/80 text-amber-300 border border-amber-800/80">
                <Loader2 className="w-3 h-3 animate-spin text-amber-400" />
                <span>جاري تحميل الصور والخطوط...</span>
              </span>
            )}
          </div>
          {subtitle && (
            <p className="text-[11px] text-slate-400 truncate mt-0.5">{subtitle}</p>
          )}
          {statusMessage && (
            <p className="text-[10px] text-amber-300 font-bold animate-pulse mt-0.5">
              ⏳ {statusMessage}
            </p>
          )}
        </div>
      </div>

      {/* Action Buttons */}
      <div className="flex items-center space-x-2 space-x-reverse flex-wrap gap-y-2">
        {extraActions}

        {/* Share / Save Standalone for Android & Windows */}
        <button
          type="button"
          onClick={handleShareOrSave}
          disabled={isProcessing}
          className="bg-slate-800 hover:bg-slate-700 active:scale-95 text-sky-300 hover:text-white border border-sky-500/40 font-bold px-3 py-1.5 sm:px-3.5 sm:py-2 rounded-xl text-xs transition-all shadow-sm flex items-center space-x-1.5 space-x-reverse cursor-pointer disabled:opacity-50"
          title="مشاركة أو حفظ المستند كملف مستقل (متوافق مع أندرويد وويندوز)"
        >
          {isProcessing ? (
            <Loader2 className="w-4 h-4 animate-spin text-sky-400" />
          ) : (
            <Share2 className="w-4 h-4 text-sky-400" />
          )}
          <span>مشاركة / حفظ PDF</span>
        </button>

        {/* Primary Direct Print */}
        <button
          type="button"
          onClick={handlePrint}
          disabled={isProcessing}
          className="bg-emerald-600 hover:bg-emerald-500 active:scale-95 text-white font-black px-4 py-1.5 sm:px-5 sm:py-2 rounded-xl text-xs transition-all shadow-lg flex items-center space-x-1.5 space-x-reverse cursor-pointer disabled:opacity-50"
          title="أمر الطباعة المباشرة من المتصفح أو بيئة النظام"
        >
          {isProcessing ? (
            <Loader2 className="w-4 h-4 animate-spin" />
          ) : (
            <Printer className="w-4 h-4" />
          )}
          <span>طباعة المستند 🖨️</span>
        </button>

        {/* Return Button */}
        <button
          type="button"
          onClick={onClose}
          className="bg-slate-800 hover:bg-slate-700 active:scale-95 text-amber-300 hover:text-white border border-amber-500/40 font-bold px-3 py-1.5 sm:px-3.5 sm:py-2 rounded-xl text-xs transition-all shadow-sm flex items-center space-x-1.5 space-x-reverse cursor-pointer"
          title="العودة للشاشة السابقة"
        >
          <ArrowRight className="w-4 h-4 text-amber-400" />
          <span>العودة ↩️</span>
        </button>
      </div>
    </div>
  );
};
