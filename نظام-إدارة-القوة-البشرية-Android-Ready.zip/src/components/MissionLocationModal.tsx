import React, { useState, useEffect } from 'react';
import { MapPin, X, Check, Compass, FileText, Sparkles, Calendar, Navigation } from 'lucide-react';
import { PersonnelRecord } from '../types';

interface MissionLocationModalProps {
  isOpen: boolean;
  onClose: () => void;
  personnel: PersonnelRecord | null;
  onConfirm: (
    militaryId: string,
    missionDestination: string,
    details?: { startDate?: string; endDate?: string; reason?: string }
  ) => void;
}

const COMMON_MISSION_LOCATIONS = [
  'غرفة العمليات المشتركة',
  'المحور العملياتي الأوسط',
  'منفذ الوديعة الحدودي',
  'محور المهرة والساحل',
  'المنطقة العسكرية الرابعة - عدن',
  'المنطقة العسكرية الأولى - سيئون',
  'حماية وتأمين المنشآت الحيوية',
  'مهمة استطلاع ميداني متقدم',
  'مأمورية إدارية بديوان القيادة العامة',
  'مأمورية أمنية ومسلكية خاصة',
  'المستشفى العسكري الميداني',
  'نقطة التفتيش والسيطرة المتقدمة'
];

export const MissionLocationModal: React.FC<MissionLocationModalProps> = ({
  isOpen,
  onClose,
  personnel,
  onConfirm
}) => {
  const todayStr = new Date().toISOString().split('T')[0];

  const [missionDestination, setMissionDestination] = useState('');
  const [startDate, setStartDate] = useState(todayStr);
  const [endDate, setEndDate] = useState('');
  const [reason, setReason] = useState('مأمورية رسمية بتكليف وتوجيهات القيادة العسكرية');
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (isOpen && personnel) {
      setMissionDestination(personnel.missionDestination || '');
      setStartDate(personnel.missionStartDate || personnel.lastStatusChangeDate || todayStr);
      setEndDate(personnel.missionEndDate || '');
      setReason(
        personnel.currentStatus === 'مأمورية' && personnel.missionDestination
          ? `تحديث موقع المأمورية إلى [${personnel.missionDestination}]`
          : 'مأمورية رسمية بتكليف وتوجيهات القيادة العسكرية'
      );
      setError(null);
    }
  }, [isOpen, personnel, todayStr]);

  if (!isOpen || !personnel) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const trimmedLoc = missionDestination.trim();
    if (!trimmedLoc) {
      setError('يرجى كتابة أو اختيار موقع ومقر المأمورية للفرد.');
      return;
    }

    onConfirm(personnel.militaryId, trimmedLoc, {
      startDate: startDate || todayStr,
      endDate: endDate || undefined,
      reason: reason.trim() || undefined
    });
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/70 backdrop-blur-xs font-['Cairo',sans-serif] select-none animate-fadeIn">
      <div className="bg-white border-2 border-amber-500/40 rounded-3xl max-w-lg w-full shadow-2xl overflow-hidden text-right">
        
        {/* Header */}
        <div className="bg-gradient-to-r from-amber-950 via-slate-900 to-amber-900 p-5 text-white flex items-center justify-between">
          <div className="flex items-center space-x-3 space-x-reverse">
            <div className="w-10 h-10 rounded-2xl bg-amber-500/20 border border-amber-400 flex items-center justify-center text-amber-300">
              <MapPin className="w-6 h-6" />
            </div>
            <div>
              <h3 className="font-black text-lg text-amber-200">
                تحديد موقع الفرد وجهة المأمورية 📍
              </h3>
              <p className="text-xs text-amber-300">
                توثيق مقر المأمورية الميدانية وتحديث تمام الجاهزية العسكرية
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            type="button"
            className="p-1.5 rounded-xl bg-amber-950/50 hover:bg-amber-800 text-amber-200 hover:text-white transition-colors border border-amber-700/50 cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Form Body */}
        <form onSubmit={handleSubmit} className="p-6 space-y-5">
          
          {/* Target Personnel Badge */}
          <div className="bg-amber-50/70 border border-amber-200 rounded-2xl p-4 flex items-center space-x-3 space-x-reverse">
            <div className="w-12 h-12 rounded-xl bg-amber-600 text-white flex items-center justify-center font-black text-sm shrink-0 shadow-xs">
              {personnel.rank}
            </div>
            <div className="space-y-1">
              <div className="font-black text-slate-800 text-sm">
                {personnel.rank} / {personnel.fullName}
              </div>
              <div className="text-xs text-slate-600 flex items-center space-x-2 space-x-reverse">
                <span className="font-mono bg-amber-100 text-amber-900 px-2 py-0.5 rounded font-bold">
                  {personnel.militaryId}
                </span>
                <span>•</span>
                <span className="text-slate-500">{personnel.unit || 'القوة العسكرية'}</span>
              </div>
            </div>
          </div>

          {/* Quick Select Presets */}
          <div className="space-y-2">
            <label className="text-xs font-black text-slate-700 flex items-center space-x-1.5 space-x-reverse">
              <Sparkles className="w-3.5 h-3.5 text-amber-600" />
              <span>اختيار سريع للمواقع والجهات الشائعة:</span>
            </label>
            <div className="flex flex-wrap gap-1.5 max-h-32 overflow-y-auto p-1 bg-slate-50 border border-slate-200 rounded-xl">
              {COMMON_MISSION_LOCATIONS.map((loc) => (
                <button
                  key={loc}
                  type="button"
                  onClick={() => {
                    setMissionDestination(loc);
                    setError(null);
                  }}
                  className={`text-[11px] px-2.5 py-1 rounded-lg font-bold border transition-all cursor-pointer ${
                    missionDestination === loc
                      ? 'bg-amber-700 text-white border-amber-800 shadow-xs'
                      : 'bg-white text-slate-700 border-slate-300 hover:border-amber-400 hover:bg-amber-50'
                  }`}
                >
                  {loc}
                </button>
              ))}
            </div>
          </div>

          {/* Mission Location Input */}
          <div className="space-y-1.5">
            <label className="text-xs font-black text-amber-900 flex items-center space-x-1.5 space-x-reverse">
              <Compass className="w-4 h-4 text-amber-700" />
              <span>موقع ومقر الفرد / جهة المأمورية *</span>
            </label>
            <input
              type="text"
              required
              value={missionDestination}
              onChange={(e) => {
                setMissionDestination(e.target.value);
                if (error) setError(null);
              }}
              placeholder="مثال: غرفة العمليات المشتركة - المحور العملياتي الشرقي..."
              className="w-full px-3.5 py-2.5 bg-slate-50 border-2 border-slate-300 focus:border-amber-600 focus:bg-white rounded-xl text-sm font-bold text-slate-800 outline-hidden transition-colors"
            />
            {error && (
              <p className="text-[11px] font-bold text-rose-600 mt-1">
                {error}
              </p>
            )}
          </div>

          {/* Dates (Start / End) */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div className="space-y-1.5">
              <label className="text-xs font-bold text-slate-700 flex items-center space-x-1.5 space-x-reverse">
                <Calendar className="w-3.5 h-3.5 text-slate-500" />
                <span>تاريخ بدء المأمورية</span>
              </label>
              <input
                type="date"
                value={startDate}
                onChange={(e) => setStartDate(e.target.value)}
                className="w-full px-3 py-2 bg-slate-50 border border-slate-300 focus:border-amber-600 focus:bg-white rounded-xl text-xs text-slate-800 outline-hidden transition-colors font-mono"
              />
            </div>

            <div className="space-y-1.5">
              <label className="text-xs font-bold text-slate-700 flex items-center space-x-1.5 space-x-reverse">
                <Calendar className="w-3.5 h-3.5 text-slate-500" />
                <span>تاريخ الانتهاء المتوقع (اختياري)</span>
              </label>
              <input
                type="date"
                value={endDate}
                onChange={(e) => setEndDate(e.target.value)}
                className="w-full px-3 py-2 bg-slate-50 border border-slate-300 focus:border-amber-600 focus:bg-white rounded-xl text-xs text-slate-800 outline-hidden transition-colors font-mono"
              />
            </div>
          </div>

          {/* Reason / Reference */}
          <div className="space-y-1.5">
            <label className="text-xs font-bold text-slate-600 flex items-center space-x-1.5 space-x-reverse">
              <FileText className="w-3.5 h-3.5 text-slate-500" />
              <span>ملاحظات وأمر التكليف بالمأمورية (اختياري)</span>
            </label>
            <input
              type="text"
              value={reason}
              onChange={(e) => setReason(e.target.value)}
              placeholder="أمر تكليف رسمي صادر من القيادة..."
              className="w-full px-3 py-2 bg-slate-50 border border-slate-300 focus:border-amber-600 focus:bg-white rounded-xl text-xs text-slate-700 outline-hidden transition-colors"
            />
          </div>

          {/* Action Buttons */}
          <div className="pt-3 border-t border-slate-200 flex items-center justify-end gap-2">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2.5 bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-bold rounded-xl transition-colors cursor-pointer"
            >
              إلغاء الأمر
            </button>
            <button
              type="submit"
              className="px-5 py-2.5 bg-amber-700 hover:bg-amber-800 text-white text-xs font-black rounded-xl transition-all shadow-md hover:shadow-lg flex items-center space-x-1.5 space-x-reverse cursor-pointer"
            >
              <Check className="w-4 h-4 text-white" />
              <span>تأكيد واعتماد موقع المأمورية ⚡</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
