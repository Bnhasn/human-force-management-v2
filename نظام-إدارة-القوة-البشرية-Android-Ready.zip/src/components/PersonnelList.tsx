import React, { useState, useMemo, useEffect } from 'react';
import * as XLSX from 'xlsx';
import { exportExcelWorkbook, exportCSVContent } from '../lib/exportUtils';
import {
  UserPlus,
  Search,
  Filter,
  FileText,
  Edit,
  Shield,
  Eye,
  CheckCircle,
  AlertTriangle,
  XCircle,
  Clock,
  ChevronLeft,
  ChevronRight,
  Download,
  Trash2,
  FileSpreadsheet,
  Calendar,
  Users,
  ArrowRightLeft,
  Building2,
  Copy,
  Layers,
  GraduationCap,
  MapPin
} from 'lucide-react';
import { PersonnelRecord, PersonnelStatus, DepartmentRole } from '../types';
import { GrantLeavePermissionTabs } from './GrantLeavePermissionTabs';
import { SecondedUnitModal } from './SecondedUnitModal';
import { TrainingCourseModal } from './TrainingCourseModal';
import { MissionLocationModal } from './MissionLocationModal';
import { LeavePermissionDateModal } from './LeavePermissionDateModal';
import { StatusDateModal } from './StatusDateModal';
import { PersonnelAvatar } from './PersonnelAvatar';
import { matchesPersonnelRecord, scorePersonnelMatch } from '../lib/searchUtils';

interface PersonnelListProps {
  personnel: PersonnelRecord[];
  onSelectPersonnel: (militaryId: string) => void;
  onEditPersonnel: (personnel: PersonnelRecord) => void;
  onDeletePersonnel?: (militaryId: string, name: string) => void;
  onAddNewPersonnel: () => void;
  onOpenExcelImport?: () => void;
  onQuickStatusChange: (
    militaryId: string,
    newStatus: PersonnelStatus,
    extraDetails?: {
      secondedUnit?: string;
      trainingCourseType?: string;
      missionDestination?: string;
      missionStartDate?: string;
      missionEndDate?: string;
      leaveStartDate?: string;
      leaveEndDate?: string;
      leaveType?: string;
      durationDays?: number;
      reason?: string;
      effectiveDate?: string;
    }
  ) => void;
  onOpenReplacementModal?: (preSelectedMilitaryId?: string) => void;
  onOpenDeduplicationTab?: () => void;
  currentRole: DepartmentRole;
  globalSearchTerm: string;
}

export const PersonnelList: React.FC<PersonnelListProps> = ({
  personnel,
  onSelectPersonnel,
  onEditPersonnel,
  onDeletePersonnel,
  onAddNewPersonnel,
  onOpenExcelImport,
  onQuickStatusChange,
  onOpenReplacementModal,
  onOpenDeduplicationTab,
  currentRole,
  globalSearchTerm
}) => {
  const [moduleView, setModuleView] = useState<'directory' | 'leaves_permissions'>('directory');
  const [filterRank, setFilterRank] = useState<string>('الكل');
  const [filterUnit, setFilterUnit] = useState<string>('الكل');
  const [filterStatus, setFilterStatus] = useState<string>('الكل');
  const [localSearch, setLocalSearch] = useState<string>('');

  // Seconded Unit Modal State
  const [secondedTarget, setSecondedTarget] = useState<PersonnelRecord | null>(null);
  const [isSecondedModalOpen, setIsSecondedModalOpen] = useState<boolean>(false);

  // Mission Location Modal State
  const [missionTarget, setMissionTarget] = useState<PersonnelRecord | null>(null);
  const [isMissionModalOpen, setIsMissionModalOpen] = useState<boolean>(false);

  // Leave & Permission Date Modal State
  const [leaveTarget, setLeaveTarget] = useState<PersonnelRecord | null>(null);
  const [leaveDefaultStatus, setLeaveDefaultStatus] = useState<'إجازة' | 'إذن'>('إجازة');
  const [isLeaveModalOpen, setIsLeaveModalOpen] = useState<boolean>(false);

  // Training Course Modal State
  const [trainingTarget, setTrainingTarget] = useState<PersonnelRecord | null>(null);
  const [trainingDefaultStatus, setTrainingDefaultStatus] = useState<'دورة تدريبية داخلية' | 'دورة تدريبية خارجية'>('دورة تدريبية داخلية');
  const [isTrainingModalOpen, setIsTrainingModalOpen] = useState<boolean>(false);

  // Status Date Modal State (for all other statuses)
  const [statusDateTarget, setStatusDateTarget] = useState<PersonnelRecord | null>(null);
  const [isStatusDateModalOpen, setIsStatusDateModalOpen] = useState<boolean>(false);

  // Pagination State
  const [currentPage, setCurrentPage] = useState<number>(1);
  const pageSize = 20;

  // Reset to page 1 on search or filter change
  useEffect(() => {
    setCurrentPage(1);
  }, [localSearch, globalSearchTerm, filterRank, filterUnit, filterStatus]);

  // Extract unique units for filter safely
  const uniqueUnits = useMemo(() => {
    const units = new Set<string>();
    (personnel || []).forEach((p) => {
      if (p && p.unit) units.add(String(p.unit).trim());
    });
    return ['الكل', ...Array.from(units)];
  }, [personnel]);

  // Extract unique ranks
  const uniqueRanks = [
    'الكل',
    'فريق أول',
    'فريق',
    'لواء',
    'عميد',
    'عقيد',
    'مقدم',
    'رائد',
    'نقيب',
    'ملازم أول',
    'ملازم',
    'رئيس رقباء',
    'رقيب أول',
    'رقيب',
    'وكيل رقيب',
    'عريف',
    'جندي أول',
    'جندي'
  ];

  // Filtered personnel list with smart Arabic search and relevance ranking
  const filteredPersonnel = useMemo(() => {
    try {
      const rawSearch = (localSearch || globalSearchTerm || '').trim();

      const matched = (personnel || []).filter((p) => {
        if (!p) return false;
        // 1. Rank filter
        if (filterRank !== 'الكل' && p.rank !== filterRank) return false;

        // 2. Unit filter
        if (filterUnit !== 'الكل' && p.unit !== filterUnit) return false;

        // 3. Status filter
        if (filterStatus !== 'الكل' && p.currentStatus !== filterStatus) return false;

        // 4. Smart multi-token Arabic search match
        if (!rawSearch) return true;

        return matchesPersonnelRecord(p, rawSearch);
      });

      if (!rawSearch) return matched;

      // Rank matching results by relevance (exact ID / name prefix / rank at top)
      return matched.slice().sort((a, b) => {
        const scoreA = scorePersonnelMatch(a, rawSearch);
        const scoreB = scorePersonnelMatch(b, rawSearch);
        return scoreB - scoreA;
      });
    } catch (err) {
      console.error('Error calculating filtered personnel:', err);
      return personnel || [];
    }
  }, [personnel, localSearch, globalSearchTerm, filterRank, filterUnit, filterStatus]);

  const totalPages = Math.ceil(filteredPersonnel.length / pageSize) || 1;
  const paginatedPersonnel = useMemo(() => {
    const start = (currentPage - 1) * pageSize;
    return filteredPersonnel.slice(start, start + pageSize);
  }, [filteredPersonnel, currentPage, pageSize]);

  // Export filtered personnel data to Excel (.xlsx) matching canonical import format
  const exportExcel = () => {
    const dataToExport = filteredPersonnel.map((p, idx) => ({
      'م': idx + 1,
      'الرقم العسكري': p.militaryId,
      'الاسم الكامل': p.fullName,
      'الرتبة العسكرية': p.rank,
      'رقم الهوية الوطنية': p.nationalId || '-',
      'الوحدة / اللواء': p.unit,
      'الكتيبة': p.battalion || '-',
      'السرية': p.company || '-',
      'الفصيل': p.platoon || '-',
      'حالة الجاهزية الحالية': p.currentStatus,
      'التخصص / المسمى الوظيفي': p.jobTitle || '-',
      'رقم التواصل': p.phone || 'غير مسجل',
      'فصيلة الدم': p.bloodType || '-',
      'المؤهل العلمي': p.education || '-',
      'تاريخ التجنيد': p.enlistmentDate || '-',
      'المحافظة / مكان الميلاد': p.pob || '-',
      'تاريخ الميلاد': p.dob || '-',
      'الحالة الاجتماعية': p.maritalStatus || '-',
      'اسم الأم': p.motherName || '-',
      'اسم الضمين': p.guarantorName || '-',
      'اسم القريب (طوارئ)': p.relativeName || '-',
      'رقم هاتف القريب': p.relativePhone || '-',
      'الوحدة المنتدب إليها': p.secondedUnit || '-',
      'نوع ومسمى الدورة التدريبية': p.trainingCourseType || '-'
    }));

    const ws = XLSX.utils.json_to_sheet(dataToExport);

    // Set auto column widths for beautiful Arabic Excel layout
    ws['!cols'] = [
      { wch: 6 },  // م
      { wch: 16 }, // الرقم العسكري
      { wch: 28 }, // الاسم الكامل
      { wch: 15 }, // الرتبة العسكرية
      { wch: 18 }, // رقم الهوية الوطنية
      { wch: 24 }, // الوحدة / اللواء
      { wch: 18 }, // الكتيبة
      { wch: 16 }, // السرية
      { wch: 14 }, // الفصيل
      { wch: 20 }, // حالة الجاهزية الحالية
      { wch: 24 }, // التخصص / المسمى الوظيفي
      { wch: 16 }, // رقم التواصل
      { wch: 12 }, // فصيلة الدم
      { wch: 16 }, // المؤهل العلمي
      { wch: 14 }, // تاريخ التجنيد
      { wch: 18 }, // مكان الميلاد
      { wch: 14 }, // تاريخ الميلاد
      { wch: 14 }, // الحالة الاجتماعية
      { wch: 20 }, // اسم الأم
      { wch: 20 }, // اسم الضمين
      { wch: 22 }, // اسم القريب
      { wch: 16 }, // رقم هاتف القريب
      { wch: 20 }, // الوحدة المنتدب إليها
      { wch: 24 }  // نوع ومسمى الدورة
    ];

    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, 'سجل القوة البشرية');

    const fileName = `سجل_القوة_البشرية_المعتمد_${new Date().toISOString().split('T')[0]}.xlsx`;
    exportExcelWorkbook(wb, fileName);
  };

  // Export filtered table to CSV matching canonical headers
  const exportCSV = () => {
    const headers = [
      'م',
      'الرقم العسكري',
      'الاسم الكامل',
      'الرتبة العسكرية',
      'رقم الهوية الوطنية',
      'الوحدة / اللواء',
      'الكتيبة',
      'السرية',
      'الفصيل',
      'حالة الجاهزية الحالية',
      'التخصص / المسمى الوظيفي',
      'رقم التواصل',
      'فصيلة الدم',
      'المؤهل العلمي',
      'تاريخ التجنيد',
      'المحافظة / مكان الميلاد',
      'تاريخ الميلاد',
      'الحالة الاجتماعية',
      'اسم الأم',
      'اسم الضمين',
      'اسم القريب (طوارئ)',
      'رقم هاتف القريب',
      'الوحدة المنتدب إليها',
      'نوع ومسمى الدورة التدريبية'
    ];
    const rows = filteredPersonnel.map((p, idx) => [
      idx + 1,
      `"${p.militaryId}"`,
      `"${p.fullName}"`,
      `"${p.rank}"`,
      `"${p.nationalId || ''}"`,
      `"${p.unit}"`,
      `"${p.battalion || ''}"`,
      `"${p.company || ''}"`,
      `"${p.platoon || ''}"`,
      `"${p.currentStatus}"`,
      `"${p.jobTitle || ''}"`,
      `"${p.phone || ''}"`,
      `"${p.bloodType || ''}"`,
      `"${p.education || ''}"`,
      `"${p.enlistmentDate || ''}"`,
      `"${p.pob || ''}"`,
      `"${p.dob || ''}"`,
      `"${p.maritalStatus || ''}"`,
      `"${p.motherName || ''}"`,
      `"${p.guarantorName || ''}"`,
      `"${p.relativeName || ''}"`,
      `"${p.relativePhone || ''}"`,
      `"${p.secondedUnit || ''}"`,
      `"${p.trainingCourseType || ''}"`
    ]);

    const csvContent = [headers.join(','), ...rows.map((e) => e.join(','))].join('\n');
    const fileName = `سجل_القوة_البشرية_${new Date().toISOString().split('T')[0]}.csv`;
    exportCSVContent(csvContent, fileName);
  };

  return (
    <div className="space-y-6 pb-12">
      
      {/* Module Sub-Navigation Switcher */}
      <div className="bg-slate-100 p-1.5 rounded-2xl border border-slate-200 flex items-center justify-between gap-2 overflow-x-auto">
        <div className="flex items-center space-x-2 space-x-reverse">
          <button
            onClick={() => setModuleView('directory')}
            className={`px-5 py-2.5 rounded-xl text-xs font-black transition-all flex items-center space-x-2 space-x-reverse cursor-pointer ${
              moduleView === 'directory'
                ? 'bg-emerald-700 text-white shadow-md'
                : 'text-slate-600 hover:text-slate-900 hover:bg-slate-200'
            }`}
          >
            <Users className="w-4 h-4" />
            <span>📋 سجل وسرد القوة البشرية ({personnel.length})</span>
          </button>

          <button
            onClick={() => setModuleView('leaves_permissions')}
            className={`px-5 py-2.5 rounded-xl text-xs font-black transition-all flex items-center space-x-2 space-x-reverse cursor-pointer ${
              moduleView === 'leaves_permissions'
                ? 'bg-amber-600 text-white shadow-md'
                : 'text-slate-600 hover:text-slate-900 hover:bg-slate-200'
            }`}
          >
            <Calendar className="w-4 h-4" />
            <span>🌴 إجازات وأذونات القوة والتأثير الجاهزي</span>
          </button>

          {onOpenDeduplicationTab && (
            <button
              onClick={onOpenDeduplicationTab}
              className="px-5 py-2.5 rounded-xl text-xs font-black transition-all flex items-center space-x-2 space-x-reverse cursor-pointer bg-purple-100 hover:bg-purple-200 text-purple-900 border border-purple-300 shadow-2xs"
              title="الانتقال لتبويب فرز الأسماء القيود المكررة وإدارتها"
            >
              <Copy className="w-4 h-4 text-purple-700" />
              <span>🔁 فرز وإظهار الأسماء المكررة</span>
            </button>
          )}
        </div>

        <div className="text-[11px] text-slate-500 font-bold hidden md:block px-3">
          تحديث آلي وتطبيق فوري للوائح العسكرية
        </div>
      </div>

      {moduleView === 'leaves_permissions' ? (
        <GrantLeavePermissionTabs
          personnel={personnel}
          onSelectPersonnel={onSelectPersonnel}
          currentRole={currentRole}
        />
      ) : (
        <>
          {/* Top Header & Actions Bar */}
          <div className="bg-white border border-slate-200 rounded-2xl p-5 shadow-sm space-y-4">
        
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 border-b border-slate-100 pb-4">
          <div>
            <h2 className="text-xl font-bold text-slate-900 flex items-center space-x-2 space-x-reverse font-['Tajawal']">
              <span>👥</span>
              <span>سجل القوة البشرية والملفات العسكرية الإلكترونية</span>
            </h2>
            <p className="text-xs text-slate-500 mt-1 font-medium">
              إدارة شاملة لبيانات {personnel.length} فرد عسكري مسجل بقاعدة البيانات المركزية
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-2">
            <button
              onClick={exportExcel}
              className="flex items-center space-x-1.5 space-x-reverse bg-gradient-to-r from-emerald-700 to-teal-700 hover:from-emerald-600 hover:to-teal-600 text-white px-3.5 py-2 rounded-xl text-xs font-black transition-all shadow-md cursor-pointer border border-emerald-500/30"
              title="تصدير كشف القوة البشرية المفصل إلى ملف إكسل XLSX"
            >
              <FileSpreadsheet className="w-4 h-4 text-emerald-200" />
              <span>تصدير كشف البشرية Excel 📊</span>
            </button>

            {onOpenExcelImport && (
              <button
                onClick={onOpenExcelImport}
                className="flex items-center space-x-1.5 space-x-reverse bg-slate-800 hover:bg-slate-700 text-slate-100 border border-slate-700 px-3 py-2 rounded-xl text-xs font-bold transition-all shadow-xs cursor-pointer"
              >
                <FileSpreadsheet className="w-4 h-4 text-emerald-400" />
                <span>استيراد كشف Excel</span>
              </button>
            )}

            <button
              onClick={exportCSV}
              className="flex items-center space-x-1.5 space-x-reverse bg-slate-100 hover:bg-slate-200 text-slate-800 border border-slate-300 px-3 py-2 rounded-xl text-xs font-bold transition-all shadow-xs cursor-pointer"
            >
              <Download className="w-4 h-4 text-emerald-700" />
              <span>CSV</span>
            </button>

            {onOpenReplacementModal && (
              <button
                onClick={() => onOpenReplacementModal()}
                className="flex items-center space-x-2 space-x-reverse bg-amber-600 hover:bg-amber-700 text-white px-3.5 py-2 rounded-xl text-xs font-extrabold transition-all shadow-md cursor-pointer"
              >
                <ArrowRightLeft className="w-4 h-4" />
                <span>استبدال فرد (فرار/متغيب)</span>
              </button>
            )}

            <button
              onClick={onAddNewPersonnel}
              className="flex items-center space-x-2 space-x-reverse bg-emerald-700 hover:bg-emerald-800 text-white px-4 py-2 rounded-xl text-xs font-extrabold transition-all shadow-md cursor-pointer"
            >
              <UserPlus className="w-4 h-4" />
              <span>إضافة فرد جديد</span>
            </button>
          </div>
        </div>

        {/* Filters and Instant Search Bar */}
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-3 pt-1">
          
          {/* Local Search Input */}
          <div className="relative">
            <Search className="w-4 h-4 absolute right-3 top-1/2 -translate-y-1/2 text-slate-400" />
            <input
              type="text"
              value={localSearch}
              onChange={(e) => setLocalSearch(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === 'Enter') {
                  e.preventDefault();
                }
              }}
              autoComplete="off"
              spellCheck="false"
              placeholder="البحث الذكي بالاسم/الرقم/السلاح/الوحدة..."
              className="w-full bg-slate-50 border border-slate-300 rounded-xl pr-9 pl-8 py-2 text-xs text-slate-800 placeholder-slate-400 focus:outline-none focus:bg-white focus:border-emerald-600 focus:ring-1 focus:ring-emerald-600 font-['Tajawal']"
            />
            {localSearch && (
              <button
                type="button"
                onClick={() => setLocalSearch('')}
                className="absolute left-2.5 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-700 text-xs p-1 cursor-pointer"
                title="مسح البحث"
              >
                ✕
              </button>
            )}
          </div>

          {/* Rank Filter */}
          <div>
            <select
              value={filterRank}
              onChange={(e) => setFilterRank(e.target.value)}
              className="w-full bg-slate-50 border border-slate-300 rounded-xl px-3 py-2 text-xs text-slate-800 focus:outline-none focus:bg-white focus:border-emerald-600"
            >
              <option value="الكل">كل الرتب العسكرية</option>
              {uniqueRanks.filter((r) => r !== 'الكل').map((r) => (
                <option key={r} value={r}>
                  {r}
                </option>
              ))}
            </select>
          </div>

          {/* Unit Filter */}
          <div>
            <select
              value={filterUnit}
              onChange={(e) => setFilterUnit(e.target.value)}
              className="w-full bg-slate-50 border border-slate-300 rounded-xl px-3 py-2 text-xs text-slate-800 focus:outline-none focus:bg-white focus:border-emerald-600"
            >
              <option value="الكل">جميع الوحدات والكتائب</option>
              {uniqueUnits.filter((u) => u !== 'الكل').map((u) => (
                <option key={u} value={u}>
                  {u}
                </option>
              ))}
            </select>
          </div>

          {/* Status Filter */}
          <div>
            <select
              value={filterStatus}
              onChange={(e) => setFilterStatus(e.target.value)}
              className="w-full bg-slate-50 border border-slate-300 rounded-xl px-3 py-2 text-xs text-slate-800 focus:outline-none focus:bg-white focus:border-emerald-600"
            >
              <option value="الكل">جميع الحالات العسكرية</option>
              <option value="متواجد">متواجد</option>
              <option value="في الميدان">في الميدان</option>
              <option value="مأمورية">مأمورية</option>
              <option value="منتدب">منتدب (انتداب)</option>
              <option value="دورة تدريبية داخلية">دورة تدريبية داخلية 🎓</option>
              <option value="دورة تدريبية خارجية">دورة تدريبية خارجية ✈️</option>
              <option value="إجازة">إجازة</option>
              <option value="إذن">إذن</option>
              <option value="مستشفى">مستشفى</option>
              <option value="جريح">جريح 🩹</option>
              <option value="غياب">غياب</option>
              <option value="فرار">فرار</option>
              <option value="اسير">اسير ⛓️</option>
              <option value="شهيد">شهيد 🎖️</option>
              <option value="معاق">معاق ♿</option>
              <option value="مفقود">مفقود ❓</option>
              <option value="موقوف">موقوف</option>
              <option value="احتياط">احتياط</option>
            </select>
          </div>

        </div>

      </div>

      {/* Main Personnel Table */}
      <div className="bg-white border border-slate-200 rounded-2xl shadow-sm overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-right text-xs">
            
            {/* Table Header */}
            <thead className="bg-slate-100 text-slate-700 font-bold border-b border-slate-200 uppercase tracking-wider">
              <tr>
                <th className="px-4 py-3.5">الفرد والرقم الوظيفي</th>
                <th className="px-4 py-3.5">الرتبة ووظيفته</th>
                <th className="px-4 py-3.5">الوحدة والكتيبة</th>
                <th className="px-4 py-3.5">السلاح العسكري المسند</th>
                <th className="px-4 py-3.5">الحالة الحالية</th>
                <th className="px-4 py-3.5 text-center">الملف والعمليات</th>
              </tr>
            </thead>

            {/* Table Body */}
            <tbody className="divide-y divide-slate-200">
              {filteredPersonnel.length === 0 ? (
                <tr>
                  <td colSpan={6} className="text-center py-12 text-slate-500 font-medium">
                    لا توجد نتائج مطابقة لشروط البحث والفلترة.
                  </td>
                </tr>
              ) : (
                paginatedPersonnel.map((person, pIndex) => {
                  if (!person) return null;
                  const assignedWeapon = person.logs?.armament?.[0];
                  const rowKey = person.militaryId ? String(person.militaryId) : `person-${pIndex}`;

                  return (
                    <tr
                      key={rowKey}
                      className="hover:bg-slate-50 transition-colors group"
                    >
                      {/* Name & Photo & Military ID */}
                      <td className="px-4 py-3">
                        <div className="flex items-center space-x-3 space-x-reverse">
                          <PersonnelAvatar
                            photoUrl={person.photoUrl}
                            fullName={person.fullName}
                            rank={person.rank}
                            militaryId={person.militaryId}
                            size="md"
                            shape="rounded"
                          />
                          <div>
                            <div
                              onClick={() => onSelectPersonnel(String(person.militaryId || ''))}
                              className="font-bold text-sm text-slate-900 hover:text-emerald-700 cursor-pointer transition-colors"
                            >
                              {person.fullName}
                            </div>
                            <div className="flex items-center space-x-2 space-x-reverse text-[11px] text-slate-500 mt-0.5">
                              <span className="font-mono bg-slate-100 text-emerald-800 px-1.5 py-0.5 rounded border border-slate-300 font-bold">
                                {person.militaryId}
                              </span>
                              <span>• هوية: {person.nationalId || '-'}</span>
                            </div>
                          </div>
                        </div>
                      </td>

                      {/* Rank & Job Title */}
                      <td className="px-4 py-3">
                        <div className="font-bold text-slate-900 text-xs">
                          {person.rank}
                        </div>
                        <div className="text-[11px] text-slate-500 mt-0.5">
                          {person.jobTitle || 'غير محدد'}
                        </div>
                      </td>

                      {/* Unit & Battalion */}
                      <td className="px-4 py-3">
                        <div className="font-semibold text-slate-800 text-xs">
                          {person.unit}
                        </div>
                        <div className="text-[11px] text-slate-500 mt-0.5">
                          {person.battalion} / {person.company}
                        </div>
                      </td>

                      {/* Assigned Weapon */}
                      <td className="px-4 py-3">
                        {assignedWeapon ? (
                          <div>
                            <div className="font-bold text-slate-800 text-[11px]">
                              {assignedWeapon.weaponType}
                            </div>
                            <div className="text-[10px] text-amber-700 font-mono font-bold">
                              S/N: {assignedWeapon.weaponSerial} ({assignedWeapon.ammoQty} طلقة)
                            </div>
                          </div>
                        ) : (
                          <span className="text-[11px] text-slate-400 italic">لا يوجد سلاح مسند</span>
                        )}
                      </td>

                      {/* Current Status Dropdown */}
                      <td className="px-4 py-3">
                        <select
                          value={person.currentStatus}
                          onChange={(e) => {
                            const val = e.target.value as PersonnelStatus;
                            if (val === 'منتدب') {
                              setSecondedTarget(person);
                              setIsSecondedModalOpen(true);
                            } else if (val === 'مأمورية') {
                              setMissionTarget(person);
                              setIsMissionModalOpen(true);
                            } else if (val === 'إجازة' || val === 'إذن') {
                              setLeaveTarget(person);
                              setLeaveDefaultStatus(val);
                              setIsLeaveModalOpen(true);
                            } else if (val === 'دورة تدريبية داخلية' || val === 'دورة تدريبية خارجية') {
                              setTrainingTarget(person);
                              setTrainingDefaultStatus(val);
                              setIsTrainingModalOpen(true);
                            } else {
                              onQuickStatusChange(person.militaryId, val);
                            }
                          }}
                          className={`text-xs font-bold px-2.5 py-1 rounded-lg border focus:outline-none transition-colors cursor-pointer ${
                            ['متواجد', 'في الميدان'].includes(person.currentStatus)
                              ? 'bg-emerald-50 text-emerald-800 border-emerald-300'
                              : ['إجازة', 'إذن', 'مأمورية'].includes(person.currentStatus)
                              ? 'bg-amber-50 text-amber-800 border-amber-300'
                              : person.currentStatus === 'منتدب'
                              ? 'bg-purple-50 text-purple-800 border-purple-300'
                              : person.currentStatus === 'دورة تدريبية داخلية' || person.currentStatus === 'دورة تدريبية خارجية'
                              ? 'bg-indigo-50 text-indigo-800 border-indigo-300'
                              : person.currentStatus === 'شهيد'
                              ? 'bg-emerald-950 text-emerald-100 border-emerald-800'
                              : person.currentStatus === 'فرار بالسلاح'
                              ? 'bg-rose-950 text-rose-100 border-rose-900 ring-1 ring-rose-500 font-black'
                              : person.currentStatus === 'اسير' || person.currentStatus === 'معاق'
                              ? 'bg-zinc-800 text-white border-zinc-900'
                              : person.currentStatus === 'جريح'
                              ? 'bg-rose-900 text-rose-100 border-rose-950'
                              : ['مستشفى'].includes(person.currentStatus)
                              ? 'bg-pink-50 text-pink-800 border-pink-300'
                              : 'bg-rose-50 text-rose-800 border-rose-300'
                          }`}
                        >
                          <option value="متواجد">متواجد</option>
                          <option value="في الميدان">في الميدان</option>
                          <option value="مأمورية">مأمورية</option>
                          <option value="منتدب">منتدب (انتداب)</option>
                          <option value="دورة تدريبية داخلية">دورة تدريبية داخلية 🎓</option>
                          <option value="دورة تدريبية خارجية">دورة تدريبية خارجية ✈️</option>
                          <option value="إجازة">إجازة</option>
                          <option value="إذن">إذن</option>
                          <option value="مستشفى">مستشفى</option>
                          <option value="جريح">جريح 🩹</option>
                          <option value="غياب">غياب</option>
                          <option value="فرار">فرار</option>
                          <option value="فرار بالسلاح">فرار بالسلاح ⚠️</option>
                          <option value="اسير">اسير ⛓️</option>
                          <option value="شهيد">شهيد 🎖️</option>
                          <option value="معاق">معاق ♿</option>
                          <option value="مفقود">مفقود ❓</option>
                          <option value="موقوف">موقوف</option>
                          <option value="احتياط">احتياط</option>
                        </select>
                        {person.currentStatus === 'منتدب' && (
                          <button
                            type="button"
                            onClick={() => {
                              setSecondedTarget(person);
                              setIsSecondedModalOpen(true);
                            }}
                            title="تعديل أو تحديد الوحدة المنتدب إليها"
                            className="text-[10px] text-purple-800 font-bold mt-1 bg-purple-50 hover:bg-purple-100 px-2 py-0.5 rounded border border-purple-200 flex items-center space-x-1 space-x-reverse transition-colors cursor-pointer w-fit"
                          >
                            <Building2 className="w-3 h-3 text-purple-600 shrink-0" />
                            <span>الجهة: {person.secondedUnit || 'اضغط للتحديد'}</span>
                          </button>
                        )}
                        {person.currentStatus === 'مأمورية' && (
                          <button
                            type="button"
                            onClick={() => {
                              setMissionTarget(person);
                              setIsMissionModalOpen(true);
                            }}
                            title="تعديل أو تحديد موقع ومقر المأمورية"
                            className="text-[10px] text-amber-900 font-bold mt-1 bg-amber-50 hover:bg-amber-100 px-2 py-0.5 rounded border border-amber-300 flex items-center space-x-1 space-x-reverse transition-colors cursor-pointer w-fit"
                          >
                            <MapPin className="w-3 h-3 text-amber-700 shrink-0" />
                            <span>الموقع: {person.missionDestination || 'اضغط لتحديد الموقع'}</span>
                          </button>
                        )}
                        {(person.currentStatus === 'إجازة' || person.currentStatus === 'إذن') && (
                          <button
                            type="button"
                            onClick={() => {
                              setLeaveTarget(person);
                              setLeaveDefaultStatus(person.currentStatus as 'إجازة' | 'إذن');
                              setIsLeaveModalOpen(true);
                            }}
                            title="تعديل أو تحديد تاريخ بدء وانتهاء الإجازة/الإذن"
                            className="text-[10px] text-emerald-800 font-bold mt-1 bg-emerald-50 hover:bg-emerald-100 px-2 py-0.5 rounded border border-emerald-300 flex items-center space-x-1 space-x-reverse transition-colors cursor-pointer w-fit"
                          >
                            <Calendar className="w-3 h-3 text-emerald-600 shrink-0" />
                            <span>
                              {person.leaveStartDate
                                ? `الفترة: ${person.leaveStartDate} ← ${person.leaveEndDate || 'مفتوح'}`
                                : (person.logs?.attendance?.find(a => a.type === person.currentStatus)?.startDate
                                    ? `الفترة: ${person.logs.attendance.find(a => a.type === person.currentStatus)?.startDate} ← ${person.logs.attendance.find(a => a.type === person.currentStatus)?.endDate || 'مفتوح'}`
                                    : 'اضغط لتحديد التواريخ')}
                            </span>
                          </button>
                        )}
                        {(person.currentStatus === 'دورة تدريبية داخلية' || person.currentStatus === 'دورة تدريبية خارجية') && (
                          <button
                            type="button"
                            onClick={() => {
                              setTrainingTarget(person);
                              setTrainingDefaultStatus(person.currentStatus as any);
                              setIsTrainingModalOpen(true);
                            }}
                            title="تعديل أو تحديد نوع ومسمى الدورة التدريبية"
                            className="text-[10px] text-indigo-800 font-bold mt-1 bg-indigo-50 hover:bg-indigo-100 px-2 py-0.5 rounded border border-indigo-200 flex items-center space-x-1 space-x-reverse transition-colors cursor-pointer w-fit"
                          >
                            <GraduationCap className="w-3 h-3 text-indigo-600 shrink-0" />
                            <span>الدورة: {person.trainingCourseType || 'اضغط للتحديد'}</span>
                          </button>
                        )}

                        {/* Small date sub-tab for all other statuses */}
                        {!['منتدب', 'مأمورية', 'إجازة', 'إذن', 'دورة تدريبية داخلية', 'دورة تدريبية خارجية'].includes(person.currentStatus) && (
                          <button
                            type="button"
                            onClick={() => {
                              setStatusDateTarget(person);
                              setIsStatusDateModalOpen(true);
                            }}
                            title="تحديد أو تعديل تاريخ سريان الحالة والملاحظات"
                            className="text-[10px] text-slate-700 font-bold mt-1 bg-slate-100 hover:bg-slate-200 px-2 py-0.5 rounded border border-slate-300 flex items-center space-x-1 space-x-reverse transition-colors cursor-pointer w-fit"
                          >
                            <Calendar className="w-3 h-3 text-slate-600 shrink-0" />
                            <span>
                              {person.lastStatusChangeDate ||
                                person.logs?.attendance?.find((a) => a.type === person.currentStatus)?.startDate ||
                                person.logs?.attendance?.find((a) => a.type === person.currentStatus)?.date ||
                                'تحديد التاريخ 📅'}
                            </span>
                          </button>
                        )}
                      </td>

                      {/* Actions Buttons */}
                      <td className="px-4 py-3 text-center">
                        <div className="flex items-center justify-center space-x-1.5 space-x-reverse">
                          <button
                            onClick={() => onSelectPersonnel(person.militaryId)}
                            className="flex items-center space-x-1 space-x-reverse bg-emerald-50 hover:bg-emerald-700 text-emerald-800 hover:text-white border border-emerald-300 px-2.5 py-1 rounded-lg text-[11px] font-bold transition-all"
                            title="عرض الملف الإلكتروني الكامل (8 سجلات)"
                          >
                            <Eye className="w-3.5 h-3.5" />
                            <span>الملف</span>
                          </button>

                          {['فرار', 'متغيب', 'غياب', 'منقطع', 'مفقود'].includes(person.currentStatus) && onOpenReplacementModal && (
                            <button
                              onClick={() => onOpenReplacementModal(person.militaryId)}
                              className="flex items-center space-x-1 space-x-reverse bg-amber-50 hover:bg-amber-600 text-amber-800 hover:text-white border border-amber-300 px-2.5 py-1 rounded-lg text-[11px] font-bold transition-all"
                              title="استبدال الفرد المتغيب/الفرار بفرد جديد"
                            >
                              <ArrowRightLeft className="w-3.5 h-3.5" />
                              <span>استبدال</span>
                            </button>
                          )}

                          <button
                            onClick={() => onEditPersonnel(person)}
                            className="p-1.5 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-lg transition-colors border border-slate-300"
                            title="تعديل البيانات الأساسية"
                          >
                            <Edit className="w-3.5 h-3.5" />
                          </button>

                          {onDeletePersonnel && (
                            <button
                              onClick={() => onDeletePersonnel(person.militaryId, person.fullName)}
                              className="p-1.5 bg-rose-50 hover:bg-rose-600 text-rose-700 hover:text-white rounded-lg transition-all border border-rose-200"
                              title="حذف ونقل لسلة المحذوفات (احتفاظ لمدة 30 يوم)"
                            >
                              <Trash2 className="w-3.5 h-3.5" />
                            </button>
                          )}
                        </div>
                      </td>

                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>

        {/* Footer Summary & Pagination Controls */}
        <div className="bg-slate-50 px-4 py-3 border-t border-slate-200 flex flex-col sm:flex-row items-center justify-between text-xs text-slate-600 gap-3">
          <div className="flex items-center space-x-2 space-x-reverse">
            <span>
              عرض {filteredPersonnel.length === 0 ? 0 : (currentPage - 1) * pageSize + 1} - {Math.min(currentPage * pageSize, filteredPersonnel.length)} من إجمالي <strong className="text-slate-900">{filteredPersonnel.length}</strong> نتيجة
            </span>
            {filteredPersonnel.length !== personnel.length && (
              <span className="text-slate-400"> (إجمالي القوة: {personnel.length})</span>
            )}
          </div>

          {/* Pagination Navigation */}
          {totalPages > 1 && (
            <div className="flex items-center space-x-1.5 space-x-reverse">
              <button
                onClick={() => setCurrentPage((p) => Math.max(1, p - 1))}
                disabled={currentPage === 1}
                className="px-2.5 py-1 rounded-lg border border-slate-300 bg-white text-slate-700 hover:bg-slate-100 disabled:opacity-40 disabled:cursor-not-allowed font-medium text-xs transition-colors"
              >
                السابق
              </button>

              <span className="px-3 py-1 font-bold text-slate-800 bg-emerald-50 text-emerald-800 rounded-lg border border-emerald-200">
                صفحة {currentPage} من {totalPages}
              </span>

              <button
                onClick={() => setCurrentPage((p) => Math.min(totalPages, p + 1))}
                disabled={currentPage === totalPages}
                className="px-2.5 py-1 rounded-lg border border-slate-300 bg-white text-slate-700 hover:bg-slate-100 disabled:opacity-40 disabled:cursor-not-allowed font-medium text-xs transition-colors"
              >
                التالي
              </button>
            </div>
          )}

          <span className="text-[11px] text-emerald-800 font-bold hidden md:inline">
            تحديث البيانات يتم تلقائياً وفورياً
          </span>
        </div>
      </div>
        </>
      )}

      {/* Seconded Unit Modal */}
      <SecondedUnitModal
        isOpen={isSecondedModalOpen}
        onClose={() => {
          setIsSecondedModalOpen(false);
          setSecondedTarget(null);
        }}
        personnel={secondedTarget}
        onConfirm={(militaryId, secondedUnit, reason) => {
          onQuickStatusChange(militaryId, 'منتدب', { secondedUnit, reason });
        }}
      />

      {/* Mission Location Modal */}
      <MissionLocationModal
        isOpen={isMissionModalOpen}
        onClose={() => {
          setIsMissionModalOpen(false);
          setMissionTarget(null);
        }}
        personnel={missionTarget}
        onConfirm={(militaryId, missionDestination, details) => {
          onQuickStatusChange(militaryId, 'مأمورية', {
            missionDestination,
            missionStartDate: details?.startDate,
            missionEndDate: details?.endDate,
            reason: details?.reason
          });
        }}
      />

      {/* Leave & Permission Date Modal */}
      <LeavePermissionDateModal
        isOpen={isLeaveModalOpen}
        onClose={() => {
          setIsLeaveModalOpen(false);
          setLeaveTarget(null);
        }}
        personnel={leaveTarget}
        defaultStatus={leaveDefaultStatus}
        onConfirm={(militaryId, status, details) => {
          onQuickStatusChange(militaryId, status, {
            leaveStartDate: details.startDate,
            leaveEndDate: details.endDate,
            durationDays: details.durationDays,
            leaveType: details.leaveType,
            reason: details.reason
          });
        }}
      />

      {/* Training Course Modal */}
      <TrainingCourseModal
        isOpen={isTrainingModalOpen}
        onClose={() => {
          setIsTrainingModalOpen(false);
          setTrainingTarget(null);
        }}
        personnel={trainingTarget}
        defaultStatus={trainingDefaultStatus}
        onConfirm={(militaryId, trainingCourseType, status, reason) => {
          onQuickStatusChange(militaryId, status, { trainingCourseType, reason });
        }}
      />

      {/* Generic Status Date Modal for all other statuses */}
      <StatusDateModal
        isOpen={isStatusDateModalOpen}
        onClose={() => {
          setIsStatusDateModalOpen(false);
          setStatusDateTarget(null);
        }}
        personnel={statusDateTarget}
        onConfirm={(militaryId, statusDate, notes) => {
          if (statusDateTarget) {
            onQuickStatusChange(militaryId, statusDateTarget.currentStatus, {
              effectiveDate: statusDate,
              reason: notes
            });
          }
        }}
      />
    </div>
  );
};
