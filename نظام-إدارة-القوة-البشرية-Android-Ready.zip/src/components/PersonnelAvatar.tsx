import React, { useState } from 'react';
import { Shield, User } from 'lucide-react';

interface PersonnelAvatarProps {
  photoUrl?: string | null;
  fullName?: string;
  rank?: string;
  militaryId?: string;
  size?: 'xs' | 'sm' | 'md' | 'lg' | 'xl' | '2xl';
  shape?: 'rounded' | 'circle' | 'square';
  className?: string;
  showBadge?: boolean;
}

export const PersonnelAvatar: React.FC<PersonnelAvatarProps> = ({
  photoUrl,
  fullName = '',
  rank = '',
  militaryId = '',
  size = 'md',
  shape = 'rounded',
  className = '',
  showBadge = false
}) => {
  const [hasError, setHasError] = useState(false);

  // Check if photo is a valid custom user upload (not empty, not stock/unsplash)
  const isValidCustomPhoto = Boolean(
    photoUrl &&
    photoUrl.trim().length > 0 &&
    !photoUrl.includes('images.unsplash.com') &&
    !photoUrl.includes('unsplash.com') &&
    !photoUrl.includes('placeholder') &&
    !hasError
  );

  // Size styles
  const sizeMap = {
    xs: 'w-6 h-6 text-[9px]',
    sm: 'w-8 h-8 text-[11px]',
    md: 'w-10 h-10 text-xs',
    lg: 'w-14 h-14 text-sm',
    xl: 'w-20 h-20 text-base',
    '2xl': 'w-24 h-24 md:w-28 md:h-28 text-lg'
  };

  const iconSizeMap = {
    xs: 'w-3 h-3',
    sm: 'w-4 h-4',
    md: 'w-5 h-5',
    lg: 'w-7 h-7',
    xl: 'w-9 h-9',
    '2xl': 'w-12 h-12'
  };

  const shapeMap = {
    rounded: 'rounded-xl',
    circle: 'rounded-full',
    square: 'rounded-lg'
  };

  // Get initials from Arabic name (first letter of first name and last name)
  const getInitials = () => {
    if (!fullName) return rank ? rank.slice(0, 2) : 'ع';
    const parts = fullName.trim().split(/\s+/);
    if (parts.length === 1) return parts[0].slice(0, 2);
    return `${parts[0][0] || ''}${parts[parts.length - 1][0] || ''}`;
  };

  const initials = getInitials();
  const currentSizeClass = sizeMap[size] || sizeMap.md;
  const currentShapeClass = shapeMap[shape] || shapeMap.rounded;
  const iconClass = iconSizeMap[size] || iconSizeMap.md;

  // Render Real Photo
  if (isValidCustomPhoto) {
    return (
      <div className={`relative inline-block shrink-0 ${className}`}>
        <img
          src={photoUrl!}
          alt={fullName || 'الصورة الشخصية'}
          onError={() => setHasError(true)}
          className={`${currentSizeClass} ${currentShapeClass} object-cover border border-slate-300 shadow-xs`}
        />
        {showBadge && (
          <div className="absolute -bottom-1 -right-1 bg-emerald-700 text-white p-0.5 rounded-full border border-white">
            <Shield className="w-2.5 h-2.5" />
          </div>
        )}
      </div>
    );
  }

  // Render Crisp Military Silhouette Placeholder
  return (
    <div
      className={`relative inline-flex items-center justify-center shrink-0 bg-gradient-to-br from-slate-800 via-slate-900 to-slate-950 text-emerald-300 font-black font-['Tajawal'] ${currentSizeClass} ${currentShapeClass} border border-slate-700 shadow-xs select-none ${className}`}
      title={fullName ? `${rank} / ${fullName} (${militaryId})` : 'فرد عسكري'}
    >
      {/* Background Military Crest Silhouette */}
      <div className="absolute inset-0 flex items-center justify-center opacity-15 pointer-events-none">
        <Shield className="w-full h-full p-1 text-emerald-400" />
      </div>

      {/* Initials or Icon */}
      {size === 'xs' || size === 'sm' ? (
        <User className={`${iconClass} text-slate-300`} />
      ) : (
        <div className="relative z-10 flex flex-col items-center justify-center leading-none text-center">
          <span className="font-extrabold tracking-tight text-white drop-shadow-xs">
            {initials}
          </span>
          {size === '2xl' && rank && (
            <span className="text-[10px] font-bold text-emerald-400 mt-1 bg-emerald-950/80 px-2 py-0.5 rounded-full border border-emerald-500/30">
              {rank}
            </span>
          )}
        </div>
      )}

      {showBadge && (
        <div className="absolute -bottom-1 -right-1 bg-slate-800 text-emerald-400 p-0.5 rounded-full border border-slate-600">
          <Shield className="w-2.5 h-2.5" />
        </div>
      )}
    </div>
  );
};
