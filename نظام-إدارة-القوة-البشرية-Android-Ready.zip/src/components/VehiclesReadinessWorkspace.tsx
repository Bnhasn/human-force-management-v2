import React, { useState, useEffect } from 'react';
import { createPortal } from 'react-dom';
import { getCurrentHeaderInfo } from '../lib/headerUtils';
import {
  Truck,
  Wrench,
  Plus,
  Search,
  Filter,
  CheckCircle2,
  AlertOctagon,
  Clock,
  Shield,
  Activity,
  FileText,
  Printer,
  Gauge,
  Fuel,
  User,
  MapPin,
  AlertTriangle,
  X,
  RefreshCw,
  Edit,
  Trash2,
  ClipboardList,
  Layers,
  Boxes,
  Package,
  Zap,
  Laptop,
  Sun,
  Battery,
  Radio,
  AlertCircle,
  PlusCircle,
  BarChart2,
  Coins,
  ArrowLeftRight,
  Sparkles,
  Check,
  UserCheck,
  Share2
} from 'lucide-react';
import {
  preparePrintableDocument,
  executeUnifiedPrint,
  shareOrSavePrintableDocument
} from '../lib/unifiedPrintService';
import {
  VehicleItem,
  VehicleReadinessStatus,
  VehicleMaintenanceLog,
  SparePartItem,
  VehicleDispenseOrder,
  VehicleReturnClearanceOrder,
  PersonnelRecord
} from '../types';
import { StorageService } from '../lib/storage';
import { VehicleEditModal } from './VehicleEditModal';
import { VehicleReturnClearanceModal } from './VehicleReturnClearanceModal';
import { VehicleReturnVoucherModal } from './VehicleReturnVoucherModal';
import { PersonnelAvatar } from './PersonnelAvatar';
import { matchesPersonnelRecord, scorePersonnelMatch } from '../lib/searchUtils';

interface VehiclesReadinessWorkspaceProps {
  currentAccountName?: string;
  isMainCommand?: boolean;
}

export const VehiclesReadinessWorkspace: React.FC<VehiclesReadinessWorkspaceProps> = ({
  currentAccountName = 'جاهزية العربات والآليات',
  isMainCommand = false
}) => {
  // Main Navigation Tabs
  const [activeTab, setActiveTab] = useState<'vehicles' | 'dispense_orders' | 'returned_to_central' | 'spare_parts' | 'maintenance'>('vehicles');

  // Edit Vehicle Modal State
  const [editingVehicle, setEditingVehicle] = useState<VehicleItem | null>(null);
  const [isEditVehicleOpen, setIsEditVehicleOpen] = useState(false);

  // Returned Vehicles (المرجعة للفنية والحركة المركزية)
  const [returnOrders, setReturnOrders] = useState<VehicleReturnClearanceOrder[]>([]);
  const [returnSearchQuery, setReturnSearchQuery] = useState('');
  const [returnConditionFilter, setReturnConditionFilter] = useState<string>('الكل');
  const [isAddReturnOpen, setIsAddReturnOpen] = useState(false);
  const [editingReturnOrder, setEditingReturnOrder] = useState<VehicleReturnClearanceOrder | null>(null);
  const [selectedReturnForVoucher, setSelectedReturnForVoucher] = useState<VehicleReturnClearanceOrder | null>(null);
  const [returnPreselectedVehicle, setReturnPreselectedVehicle] = useState<VehicleItem | null>(null);

  // Vehicles Data & Filters
  const [vehicles, setVehicles] = useState<VehicleItem[]>([]);
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedStatusFilter, setSelectedStatusFilter] = useState<string>('الكل');
  const [selectedCategoryFilter, setSelectedCategoryFilter] = useState<string>('الكل');
  const [selectedUnitFilter, setSelectedUnitFilter] = useState<string>('الكل');

  // Dispense Orders Data & Filters
  const [dispenseOrders, setDispenseOrders] = useState<VehicleDispenseOrder[]>([]);
  const [dispenseSearchQuery, setDispenseSearchQuery] = useState('');
  const [dispenseTypeFilter, setDispenseTypeFilter] = useState<string>('الكل');
  const [personnelList, setPersonnelList] = useState<PersonnelRecord[]>([]);

  // Dispense Order Modals & Selection
  const [isAddDispenseOpen, setIsAddDispenseOpen] = useState(false);
  const [selectedOrderForVoucher, setSelectedOrderForVoucher] = useState<VehicleDispenseOrder | null>(null);

  // Spare Parts Data & Filters
  const [spareParts, setSpareParts] = useState<SparePartItem[]>([]);
  const [sparePartsSearch, setSparePartsSearch] = useState('');
  const [sparePartsCategoryFilter, setSparePartsCategoryFilter] = useState<string>('الكل');

  // Print Officer Signature States
  const [vehOfficer1Name, setVehOfficer1Name] = useState('');
  const [vehOfficer1Title, setVehOfficer1Title] = useState('');
  const [vehOfficer2Name, setVehOfficer2Name] = useState('');
  const [vehOfficer2Title, setVehOfficer2Title] = useState('');
  const [vehOfficer3Name, setVehOfficer3Name] = useState('');
  const [vehOfficer3Title, setVehOfficer3Title] = useState('');

  // Modal States
  const [isAddVehicleOpen, setIsAddVehicleOpen] = useState(false);
  const [customCategoryInput, setCustomCategoryInput] = useState('');
  const [isCustomCategorySelected, setIsCustomCategorySelected] = useState(false);

  const [selectedVehicleForCard, setSelectedVehicleForCard] = useState<VehicleItem | null>(null);
  const [isAddMaintenanceOpen, setIsAddMaintenanceOpen] = useState(false);
  const [isPrintReportOpen, setIsPrintReportOpen] = useState(false);

  const readinessPrintRef = React.useRef<HTMLDivElement>(null);
  const voucherPrintRef = React.useRef<HTMLDivElement>(null);

  const handlePrintReadinessReport = async () => {
    await executeUnifiedPrint(readinessPrintRef.current, {
      documentTitle: `تقرير_جاهزية_العربات_${new Date().toISOString().slice(0, 10)}`,
      orientation: 'landscape'
    });
  };

  const handleShareReadinessReport = async () => {
    await shareOrSavePrintableDocument(readinessPrintRef.current, {
      title: 'تقرير جاهزية العربات والآليات العسكرية',
      filename: `جاهزية_العربات_${new Date().toISOString().slice(0, 10)}.html`,
      orientation: 'landscape'
    });
  };

  const handlePrintDispenseVoucher = async () => {
    if (!selectedOrderForVoucher) return;
    await executeUnifiedPrint(voucherPrintRef.current, {
      documentTitle: `سند_صرف_عهدة_${selectedOrderForVoucher.orderNumber}`,
      orientation: 'portrait'
    });
  };

  const handleShareDispenseVoucher = async () => {
    if (!selectedOrderForVoucher) return;
    await shareOrSavePrintableDocument(voucherPrintRef.current, {
      title: `سند صرف عهدة عربات - ${selectedOrderForVoucher.orderNumber}`,
      filename: `سند_صرف_${selectedOrderForVoucher.orderNumber}.html`,
      orientation: 'portrait'
    });
  };

  // Spare Parts Modals
  const [isAddSparePartOpen, setIsAddSparePartOpen] = useState(false);
  const [editingSparePart, setEditingSparePart] = useState<SparePartItem | null>(null);

  // New Vehicle / Equipment Form State
  const [newVehicle, setNewVehicle] = useState<{
    name: string;
    category: string;
    plateNumber: string;
    engineSerial: string;
    status: VehicleReadinessStatus;
    readinessPercentage: number;
    assignedUnit: string;
    assignedDriverName: string;
    assignedDriverMilitaryId: string;
    fuelLevel: VehicleItem['fuelLevel'];
    location: string;
    lastMaintenanceDate: string;
    yearOfModel: string;
    mileageKm: number;
    notes: string;
  }>({
    name: '',
    category: 'طقم قتالي',
    plateNumber: '',
    engineSerial: '',
    status: 'جاهزة',
    readinessPercentage: 95,
    assignedUnit: 'اللواء الأول',
    assignedDriverName: '',
    assignedDriverMilitaryId: '',
    fuelLevel: 'ممتاز (ممتلئ)',
    location: 'المقر الرئيسي للجاهزية',
    lastMaintenanceDate: new Date().toISOString().split('T')[0],
    yearOfModel: '2024',
    mileageKm: 12000,
    notes: ''
  });

  // New Maintenance Log Form State (with spare part deduction)
  const [newLog, setNewLog] = useState<{
    type: VehicleMaintenanceLog['type'];
    date: string;
    description: string;
    partsReplaced: string;
    workshopOrTechnician: string;
    cost: number;
    status: VehicleMaintenanceLog['status'];
    notes: string;
    useWarehousePart: boolean;
    sparePartIdUsed: string;
    sparePartQtyUsed: number;
  }>({
    type: 'صيانة دورية',
    date: new Date().toISOString().split('T')[0],
    description: '',
    partsReplaced: '',
    workshopOrTechnician: 'ورشة الصيانة الفنية المركزية',
    cost: 350,
    status: 'مكتملة',
    notes: '',
    useWarehousePart: false,
    sparePartIdUsed: '',
    sparePartQtyUsed: 1
  });

  // New / Edit Spare Part Form State
  const [sparePartForm, setSparePartForm] = useState<Omit<SparePartItem, 'id'>>({
    code: '',
    name: '',
    category: 'زيوت وفلاتر',
    compatibleModels: '',
    quantity: 10,
    minThreshold: 5,
    unitPrice: 50,
    location: 'المخزن الرئيسي - رف A1',
    unitOfMeasure: 'قطعة',
    notes: '',
    lastRestockedDate: new Date().toISOString().split('T')[0]
  });

  // New Dispense Order Form State
  const [newDispenseForm, setNewDispenseForm] = useState<{
    itemType: 'آلية عسكرية' | 'أجهزة ومعدات أخرى';
    selectedVehicleId: string;
    itemName: string;
    itemCategory: string;
    itemSerialOrPlate: string;
    engineOrChassisSerial: string;
    itemCondition: string;
    quantity: number;

    recipientSearch: string;
    recipientName: string;
    recipientMilitaryId: string;
    recipientRank: string;
    recipientUnit: string;
    recipientBattalion: string;
    recipientJobTitle: string;
    recipientPhone: string;
    recipientNationalId: string;

    guarantorSearch: string;
    guarantorName: string;
    guarantorMilitaryId: string;
    guarantorRank: string;
    guarantorUnit: string;
    guarantorPhone: string;
    guarantorNationalId: string;

    orderNumber: string;
    orderDate: string;
    orderSource: string;
    dispenseReason: string;
    locationOrDestination: string;
    notes: string;
  }>({
    itemType: 'آلية عسكرية',
    selectedVehicleId: '',
    itemName: '',
    itemCategory: 'طقم قتالي',
    itemSerialOrPlate: '',
    engineOrChassisSerial: '',
    itemCondition: 'جاهزة ومتاحة',
    quantity: 1,

    recipientSearch: '',
    recipientName: '',
    recipientMilitaryId: '',
    recipientRank: 'رقيب',
    recipientUnit: 'اللواء الأول',
    recipientBattalion: '',
    recipientJobTitle: '',
    recipientPhone: '',
    recipientNationalId: '',

    guarantorSearch: '',
    guarantorName: '',
    guarantorMilitaryId: '',
    guarantorRank: 'مساعد',
    guarantorUnit: 'قيادة اللواء',
    guarantorPhone: '',
    guarantorNationalId: '',

    orderNumber: `ORD-${Math.floor(1000 + Math.random() * 9000)}/عربات`,
    orderDate: new Date().toISOString().split('T')[0],
    orderSource: 'قرار وتوجيهات قيادة اللواء',
    dispenseReason: 'صرف عهدة لمهمة تنفيذية وميدانية',
    locationOrDestination: 'الموقع الميداني المتقدم',
    notes: 'تسليم العهدة بشرط الحفاظ التام والتعهد بالصيانة الدوريات.'
  });

  // Live Search & Import State for Recipient & Guarantor in Dispense Modal
  const [recipientSearchQuery, setRecipientSearchQuery] = useState('');
  const [isRecipientDropdownOpen, setIsRecipientDropdownOpen] = useState(false);
  const [detectedGuarantorFromRecipient, setDetectedGuarantorFromRecipient] = useState<string>('');

  const [guarantorSearchQuery, setGuarantorSearchQuery] = useState('');
  const [isGuarantorDropdownOpen, setIsGuarantorDropdownOpen] = useState(false);
  const [guarantorEntryMode, setGuarantorEntryMode] = useState<'import' | 'manual'>('manual');

  // Filtered personnel lists for live search by name or military ID
  const filteredRecipientPersonnel = React.useMemo(() => {
    if (!recipientSearchQuery.trim()) {
      return personnelList.slice(0, 15);
    }
    const q = recipientSearchQuery.trim();
    return personnelList
      .filter((p) => matchesPersonnelRecord(p, q))
      .sort((a, b) => scorePersonnelMatch(b, q) - scorePersonnelMatch(a, q))
      .slice(0, 25);
  }, [personnelList, recipientSearchQuery]);

  const filteredGuarantorPersonnel = React.useMemo(() => {
    if (!guarantorSearchQuery.trim()) {
      return personnelList.slice(0, 15);
    }
    const q = guarantorSearchQuery.trim();
    return personnelList
      .filter((p) => matchesPersonnelRecord(p, q))
      .sort((a, b) => scorePersonnelMatch(b, q) - scorePersonnelMatch(a, q))
      .slice(0, 25);
  }, [personnelList, guarantorSearchQuery]);

  // Handler: Select Recipient from live search
  const handleSelectRecipient = (p: PersonnelRecord) => {
    setNewDispenseForm((prev) => ({
      ...prev,
      recipientName: p.fullName,
      recipientMilitaryId: p.militaryId,
      recipientRank: p.rank,
      recipientUnit: p.unit,
      recipientBattalion: p.battalion || '',
      recipientJobTitle: p.jobTitle || 'عضو طاقم',
      recipientPhone: p.phone || '',
      recipientNationalId: p.nationalId || ''
    }));
    setRecipientSearchQuery(`${p.rank} / ${p.fullName} (${p.militaryId})`);
    setIsRecipientDropdownOpen(false);

    if (p.guarantorName && p.guarantorName.trim()) {
      setDetectedGuarantorFromRecipient(p.guarantorName.trim());
    } else {
      setDetectedGuarantorFromRecipient('');
    }
  };

  // Handler: Select Guarantor from live search
  const handleSelectGuarantor = (p: PersonnelRecord) => {
    setNewDispenseForm((prev) => ({
      ...prev,
      guarantorName: p.fullName,
      guarantorMilitaryId: p.militaryId,
      guarantorRank: p.rank,
      guarantorUnit: p.unit,
      guarantorPhone: p.phone || '',
      guarantorNationalId: p.nationalId || ''
    }));
    setGuarantorSearchQuery(`${p.rank} / ${p.fullName} (${p.militaryId})`);
    setIsGuarantorDropdownOpen(false);
  };

  // Handler: Apply detected guarantor from recipient's personnel profile
  const handleApplyDetectedGuarantor = () => {
    if (!detectedGuarantorFromRecipient) return;
    const found = personnelList.find(
      (p) => p.fullName?.trim().toLowerCase() === detectedGuarantorFromRecipient.trim().toLowerCase()
    );
    if (found) {
      handleSelectGuarantor(found);
    } else {
      setNewDispenseForm((prev) => ({
        ...prev,
        guarantorName: detectedGuarantorFromRecipient,
        guarantorMilitaryId: 'مدني',
        guarantorRank: 'كفيل وضامن',
        guarantorUnit: 'خارج التشكيل / جهة مدنية'
      }));
      setGuarantorSearchQuery(detectedGuarantorFromRecipient);
    }
  };

  const handleOpenNewDispenseOrder = () => {
    setRecipientSearchQuery('');
    setGuarantorSearchQuery('');
    setDetectedGuarantorFromRecipient('');
    setIsRecipientDropdownOpen(false);
    setIsGuarantorDropdownOpen(false);
    setGuarantorEntryMode('manual');
    setIsAddDispenseOpen(true);
  };

  // Reload All Data
  const reloadData = () => {
    const list = StorageService.getVehicles();
    setVehicles(list);
    const parts = StorageService.getSpareParts();
    setSpareParts(parts);
    const disp = StorageService.getVehicleDispenseOrders();
    setDispenseOrders(disp);
    const pers = StorageService.getPersonnel();
    setPersonnelList(pers);
    const rets = StorageService.getVehicleReturnOrders();
    setReturnOrders(rets);

    if (selectedVehicleForCard) {
      const updated = list.find((v) => v.id === selectedVehicleForCard.id);
      if (updated) setSelectedVehicleForCard(updated);
    }
  };

  const handleOpenEditVehicle = (veh: VehicleItem) => {
    setEditingVehicle(veh);
    setIsEditVehicleOpen(true);
  };

  const handleOpenReturnForVehicle = (veh: VehicleItem) => {
    setReturnPreselectedVehicle(veh);
    setEditingReturnOrder(null);
    setIsAddReturnOpen(true);
  };

  const handleDeleteReturnOrder = (orderId: string, restoreVehicle = true) => {
    if (window.confirm('هل أنت متأكد من رغبتك في إلغاء أو حذف سند إخلاء العهدة؟\n(سيتم استعادة الآلية تلقائياً للأسطول النشط بحالة "جاهزة")')) {
      StorageService.deleteVehicleReturnOrder(orderId, restoreVehicle, currentAccountName);
      reloadData();
    }
  };

  useEffect(() => {
    reloadData();
    window.addEventListener('military_data_changed', reloadData);
    return () => window.removeEventListener('military_data_changed', reloadData);
  }, []);

  // Submit Handler for Add Dispense Order
  const handleAddDispenseSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newDispenseForm.itemName || !newDispenseForm.recipientName || !newDispenseForm.guarantorName) {
      alert('يرجى تعبئة كافة الحقول الأساسية (اسم الآلية/المعدة، اسم المستلم، اسم الضمين)');
      return;
    }

    const finalGuarantorMilitaryId = newDispenseForm.guarantorMilitaryId?.trim() || 'مدني';

    const created = StorageService.addVehicleDispenseOrder(
      {
        orderNumber: newDispenseForm.orderNumber,
        orderDate: newDispenseForm.orderDate,
        itemType: newDispenseForm.itemType,
        itemId: newDispenseForm.selectedVehicleId || undefined,
        itemName: newDispenseForm.itemName,
        itemCategory: newDispenseForm.itemCategory,
        itemSerialOrPlate: newDispenseForm.itemSerialOrPlate,
        engineOrChassisSerial: newDispenseForm.engineOrChassisSerial,
        itemCondition: newDispenseForm.itemCondition,
        quantity: Number(newDispenseForm.quantity) || 1,

        recipientName: newDispenseForm.recipientName,
        recipientMilitaryId: newDispenseForm.recipientMilitaryId || 'غير مسجل',
        recipientRank: newDispenseForm.recipientRank,
        recipientUnit: newDispenseForm.recipientUnit,
        recipientBattalion: newDispenseForm.recipientBattalion,
        recipientJobTitle: newDispenseForm.recipientJobTitle,
        recipientPhone: newDispenseForm.recipientPhone,
        recipientNationalId: newDispenseForm.recipientNationalId,

        guarantorName: newDispenseForm.guarantorName,
        guarantorMilitaryId: finalGuarantorMilitaryId,
        guarantorRank: newDispenseForm.guarantorRank || 'كفيل وضامن',
        guarantorUnit: newDispenseForm.guarantorUnit || 'جهة مدنية / خارجية',
        guarantorPhone: newDispenseForm.guarantorPhone,
        guarantorNationalId: newDispenseForm.guarantorNationalId,

        dispenseReason: newDispenseForm.dispenseReason,
        orderSource: newDispenseForm.orderSource,
        locationOrDestination: newDispenseForm.locationOrDestination,
        notes: newDispenseForm.notes,
        createdByName: currentAccountName
      },
      currentAccountName
    );

    reloadData();
    setIsAddDispenseOpen(false);
    setSelectedOrderForVoucher(created);

    // Reset Form
    setRecipientSearchQuery('');
    setGuarantorSearchQuery('');
    setDetectedGuarantorFromRecipient('');
    setGuarantorEntryMode('manual');
    setNewDispenseForm({
      itemType: 'آلية عسكرية',
      selectedVehicleId: '',
      itemName: '',
      itemCategory: 'طقم قتالي',
      itemSerialOrPlate: '',
      engineOrChassisSerial: '',
      itemCondition: 'جاهزة ومتاحة',
      quantity: 1,

      recipientSearch: '',
      recipientName: '',
      recipientMilitaryId: '',
      recipientRank: 'رقيب',
      recipientUnit: 'اللواء الأول',
      recipientBattalion: '',
      recipientJobTitle: '',
      recipientPhone: '',
      recipientNationalId: '',

      guarantorSearch: '',
      guarantorName: '',
      guarantorMilitaryId: '',
      guarantorRank: 'مساعد',
      guarantorUnit: 'قيادة اللواء',
      guarantorPhone: '',
      guarantorNationalId: '',

      orderNumber: `ORD-${Math.floor(1000 + Math.random() * 9000)}/عربات`,
      orderDate: new Date().toISOString().split('T')[0],
      orderSource: 'قرار وتوجيهات قيادة اللواء',
      dispenseReason: 'صرف عهدة لمهمة تنفيذية وميدانية',
      locationOrDestination: 'الموقع الميداني المتقدم',
      notes: 'تسليم العهدة بشرط الحفاظ التام والتعهد بالصيانة الدوريات.'
    });
  };

  const handleDeleteDispenseOrder = (orderId: string) => {
    if (window.confirm('هل أنت متأكد من إلغاء وحذف سند الصرف هذا؟')) {
      StorageService.deleteVehicleDispenseOrder(orderId, currentAccountName);
      reloadData();
    }
  };

  // Filtered Vehicles & Equipment
  const filteredVehicles = vehicles.filter((v) => {
    const matchesSearch =
      v.name.includes(searchQuery) ||
      v.plateNumber.includes(searchQuery) ||
      (v.assignedDriverName && v.assignedDriverName.includes(searchQuery)) ||
      (v.assignedDriverMilitaryId && v.assignedDriverMilitaryId.includes(searchQuery)) ||
      v.assignedUnit.includes(searchQuery) ||
      v.location.includes(searchQuery);

    const matchesStatus =
      selectedStatusFilter === 'الكل' || v.status === selectedStatusFilter;

    const matchesCategory =
      selectedCategoryFilter === 'الكل' || v.category === selectedCategoryFilter;

    const matchesUnit =
      selectedUnitFilter === 'الكل' || v.assignedUnit.includes(selectedUnitFilter);

    return matchesSearch && matchesStatus && matchesCategory && matchesUnit;
  });

  // Filtered Spare Parts
  const filteredSpareParts = spareParts.filter((p) => {
    const matchesSearch =
      p.name.includes(sparePartsSearch) ||
      p.code.includes(sparePartsSearch) ||
      p.compatibleModels.includes(sparePartsSearch) ||
      p.location.includes(sparePartsSearch);

    const matchesCategory =
      sparePartsCategoryFilter === 'الكل' || p.category === sparePartsCategoryFilter;

    return matchesSearch && matchesCategory;
  });

  // Filtered Dispense Orders
  const filteredDispenseOrders = dispenseOrders.filter((order) => {
    const matchesSearch =
      order.orderNumber.includes(dispenseSearchQuery) ||
      order.itemName.includes(dispenseSearchQuery) ||
      order.itemSerialOrPlate.includes(dispenseSearchQuery) ||
      order.recipientName.includes(dispenseSearchQuery) ||
      order.recipientMilitaryId.includes(dispenseSearchQuery) ||
      order.guarantorName.includes(dispenseSearchQuery) ||
      order.orderSource.includes(dispenseSearchQuery);

    const matchesType =
      dispenseTypeFilter === 'الكل' || order.itemType === dispenseTypeFilter;

    return matchesSearch && matchesType;
  });

  // Key KPI Counts for Vehicles & Equipment
  const totalCount = vehicles.length;
  const readyCount = vehicles.filter((v) => v.status === 'جاهزة').length;
  const issuedCount = vehicles.filter((v) => v.status === 'منصرف').length;
  const unissuedCount = vehicles.filter((v) => v.status === 'لم يتم صرفها').length;
  const outOfServiceCount = vehicles.filter(
    (v) => v.status === 'خارج الجاهزية' || v.status === 'تحت الصيانة'
  ).length;

  const avgReadiness =
    totalCount > 0
      ? Math.round(vehicles.reduce((acc, curr) => acc + curr.readinessPercentage, 0) / totalCount)
      : 100;

  // Key KPI Counts for Spare Parts
  const totalSparePartsTypes = spareParts.length;
  const totalSparePartsQuantity = spareParts.reduce((acc, curr) => acc + curr.quantity, 0);
  const lowStockPartsCount = spareParts.filter((p) => p.quantity <= p.minThreshold).length;
  const totalSparePartsValuation = spareParts.reduce(
    (acc, curr) => acc + curr.quantity * (curr.unitPrice || 0),
    0
  );

  // All Maintenance Logs Combined
  const allMaintenanceLogs = vehicles.flatMap((v) =>
    (v.maintenanceLogs || []).map((log) => ({
      ...log,
      vehicleName: v.name,
      vehiclePlate: v.plateNumber,
      vehicleCategory: v.category
    }))
  ).sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());

  // Submit Handler: Add Vehicle / Equipment
  const handleAddVehicleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newVehicle.name || !newVehicle.plateNumber) return;

    const finalCategory = isCustomCategorySelected && customCategoryInput.trim()
      ? customCategoryInput.trim()
      : newVehicle.category;

    StorageService.addVehicle({
      ...newVehicle,
      category: finalCategory as any,
      nextMaintenanceDate: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString().split('T')[0]
    });

    setIsAddVehicleOpen(false);
    setIsCustomCategorySelected(false);
    setCustomCategoryInput('');
    setNewVehicle({
      name: '',
      category: 'طقم قتالي',
      plateNumber: '',
      engineSerial: '',
      status: 'جاهزة',
      readinessPercentage: 95,
      assignedUnit: 'اللواء الأول',
      assignedDriverName: '',
      assignedDriverMilitaryId: '',
      fuelLevel: 'ممتاز (ممتلئ)',
      location: 'المقر الرئيسي للجاهزية',
      lastMaintenanceDate: new Date().toISOString().split('T')[0],
      yearOfModel: '2024',
      mileageKm: 12000,
      notes: ''
    });
    reloadData();
  };

  // Submit Handler: Add Maintenance Log (with optional spare part deduction)
  const handleAddMaintenanceSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedVehicleForCard || !newLog.description) return;

    let selectedPartName = '';
    if (newLog.useWarehousePart && newLog.sparePartIdUsed) {
      const partObj = spareParts.find((sp) => sp.id === newLog.sparePartIdUsed);
      if (partObj) {
        selectedPartName = `${partObj.name} (${newLog.sparePartQtyUsed} ${partObj.unitOfMeasure || 'قطعة'})`;
      }
    }

    StorageService.addMaintenanceLogToVehicle(selectedVehicleForCard.id, {
      type: newLog.type,
      date: newLog.date,
      description: newLog.description,
      partsReplaced: selectedPartName || newLog.partsReplaced || 'صيانة عامة',
      workshopOrTechnician: newLog.workshopOrTechnician,
      cost: newLog.cost,
      status: newLog.status,
      notes: newLog.notes,
      sparePartIdUsed: newLog.useWarehousePart ? newLog.sparePartIdUsed : undefined,
      sparePartQtyUsed: newLog.useWarehousePart ? newLog.sparePartQtyUsed : undefined,
      sparePartNameUsed: selectedPartName
    });

    setIsAddMaintenanceOpen(false);
    setNewLog({
      type: 'صيانة دورية',
      date: new Date().toISOString().split('T')[0],
      description: '',
      partsReplaced: '',
      workshopOrTechnician: 'ورشة الصيانة الفنية المركزية',
      cost: 350,
      status: 'مكتملة',
      notes: '',
      useWarehousePart: false,
      sparePartIdUsed: '',
      sparePartQtyUsed: 1
    });
    reloadData();
  };

  // Submit Handler: Add / Edit Spare Part
  const handleSparePartSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!sparePartForm.name || !sparePartForm.code) return;

    if (editingSparePart) {
      StorageService.updateSparePart(editingSparePart.id, sparePartForm);
      setEditingSparePart(null);
    } else {
      StorageService.addSparePart(sparePartForm);
    }

    setIsAddSparePartOpen(false);
    setSparePartForm({
      code: '',
      name: '',
      category: 'زيوت وفلاتر',
      compatibleModels: '',
      quantity: 10,
      minThreshold: 5,
      unitPrice: 50,
      location: 'المخزن الرئيسي - رف A1',
      unitOfMeasure: 'قطعة',
      notes: '',
      lastRestockedDate: new Date().toISOString().split('T')[0]
    });
    reloadData();
  };

  // Delete Spare Part
  const handleDeleteSparePart = (id: string, name: string) => {
    if (window.confirm(`هل أنت متأكد من حذف صنف قطعة الغيار (${name}) من المخزن؟`)) {
      StorageService.deleteSparePart(id);
      reloadData();
    }
  };

  // Quick Status Update for Vehicle
  const handleUpdateStatus = (vehicleId: string, newStatus: VehicleReadinessStatus) => {
    let readinessScore = 95;
    if (newStatus === 'خارج الجاهزية') readinessScore = 30;
    if (newStatus === 'تحت الصيانة') readinessScore = 55;
    if (newStatus === 'جاهزة' || newStatus === 'لم يتم صرفها') readinessScore = 98;

    StorageService.updateVehicle(vehicleId, {
      status: newStatus,
      readinessPercentage: readinessScore
    });
    reloadData();
  };

  // Delete Vehicle
  const handleDeleteVehicle = (vehicleId: string, vehicleName: string) => {
    if (window.confirm(`هل أنت متأكد من حذف الآلية / المعدة (${vehicleName}) نهائياً؟`)) {
      StorageService.deleteVehicle(vehicleId);
      if (selectedVehicleForCard?.id === vehicleId) {
        setSelectedVehicleForCard(null);
      }
      reloadData();
    }
  };

  // Status Badge Config
  const getStatusBadge = (status: VehicleReadinessStatus) => {
    switch (status) {
      case 'جاهزة':
        return {
          label: 'جاهزة',
          bg: 'bg-emerald-500/20 text-emerald-300 border-emerald-500/40',
          dot: 'bg-emerald-400',
          icon: CheckCircle2
        };
      case 'منصرف':
        return {
          label: 'منصرف',
          bg: 'bg-sky-500/20 text-sky-300 border-sky-500/40',
          dot: 'bg-sky-400',
          icon: Truck
        };
      case 'لم يتم صرفها':
        return {
          label: 'لم يتم صرفها',
          bg: 'bg-amber-500/20 text-amber-300 border-amber-500/40',
          dot: 'bg-amber-400',
          icon: Clock
        };
      case 'خارج الجاهزية':
        return {
          label: 'خارج الجاهزية',
          bg: 'bg-rose-500/20 text-rose-300 border-rose-500/40',
          dot: 'bg-rose-400',
          icon: AlertOctagon
        };
      case 'تحت الصيانة':
        return {
          label: 'تحت الصيانة',
          bg: 'bg-purple-500/20 text-purple-300 border-purple-500/40',
          dot: 'bg-purple-400',
          icon: Wrench
        };
      case 'مرجعة للفنية والحركة المركزية':
        return {
          label: 'مرجعة للفنية والحركة المركزية',
          bg: 'bg-indigo-500/20 text-indigo-300 border-indigo-500/40',
          dot: 'bg-indigo-400',
          icon: ArrowLeftRight
        };
      default:
        return {
          label: status,
          bg: 'bg-slate-700 text-slate-200 border-slate-600',
          dot: 'bg-slate-400',
          icon: Activity
        };
    }
  };

  // Filtered Return Orders for Central Technical Branch
  const filteredReturnOrders = returnOrders.filter((order) => {
    const query = returnSearchQuery.trim().toLowerCase();
    const matchSearch =
      !query ||
      order.vehicleName.toLowerCase().includes(query) ||
      order.plateNumber.toLowerCase().includes(query) ||
      order.returnNumber.toLowerCase().includes(query) ||
      order.handoverPersonName.toLowerCase().includes(query) ||
      order.handoverPersonMilitaryId.toLowerCase().includes(query) ||
      order.receivingOfficerName.toLowerCase().includes(query);

    const matchCondition =
      returnConditionFilter === 'الكل' || order.conditionAtHandover === returnConditionFilter;

    return matchSearch && matchCondition;
  });

  return (
    <div className="space-y-6 pb-12 font-['Tajawal'] text-right" dir="rtl">
      {/* Workspace Header Banner */}
      <div className="relative overflow-hidden rounded-3xl bg-gradient-to-l from-amber-950 via-slate-900 to-slate-950 border border-amber-600/30 p-6 md:p-8 shadow-2xl">
        <div className="absolute top-0 left-0 w-96 h-96 bg-amber-500/10 rounded-full filter blur-3xl pointer-events-none"></div>

        <div className="relative z-10 flex flex-col lg:flex-row items-start lg:items-center justify-between gap-6">
          <div className="space-y-3 max-w-2xl">
            <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-amber-500/20 border border-amber-400/40 text-amber-300 font-bold text-xs shadow-inner">
              <Truck className="w-4 h-4 text-amber-400" />
              <span>فرع الجاهزية الفنية: العربات، المعدات، ومخزن قطع الغيار</span>
            </div>
            <h1 className="text-2xl md:text-3xl font-black text-white tracking-wide">
              منظومة تتبع وتجهيز العربات والمعدات والمخزون
            </h1>
            <p className="text-xs md:text-sm text-slate-300 leading-relaxed font-semibold">
              لوحة متكاملة لمتابعة جاهزية الأسطول (عربات، دبابات، مولدات، لابتوبات، طابعات، ألواح شمسية، بطاريات، منظومات اتصالات) مع مخزن قطع الغيار والخصم المباشر للصيانة.
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-3 shrink-0">
            <button
              onClick={() => {
                setIsCustomCategorySelected(false);
                setIsAddVehicleOpen(true);
              }}
              className="px-5 py-3 bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-600 hover:to-amber-700 text-white font-black rounded-2xl shadow-lg hover:shadow-amber-500/25 flex items-center gap-2 text-xs md:text-sm transition-all cursor-pointer border border-amber-400/30"
            >
              <Plus className="w-5 h-5" />
              إضافة عربة / معدة جديدة
            </button>

            <button
              onClick={handleOpenNewDispenseOrder}
              className="px-5 py-3 bg-gradient-to-r from-emerald-600 to-teal-700 hover:from-emerald-700 hover:to-teal-800 text-white font-black rounded-2xl shadow-lg hover:shadow-emerald-500/25 flex items-center gap-2 text-xs md:text-sm transition-all cursor-pointer border border-emerald-500/30"
            >
              <FileText className="w-5 h-5 text-emerald-300" />
              إصدار أمر صرف جديد 📋
            </button>

            <button
              onClick={() => {
                setEditingSparePart(null);
                setSparePartForm({
                  code: `SP-${Date.now().toString().slice(-5)}`,
                  name: '',
                  category: 'زيوت وفلاتر',
                  compatibleModels: '',
                  quantity: 10,
                  minThreshold: 5,
                  unitPrice: 50,
                  location: 'المخزن الرئيسي - رف A1',
                  unitOfMeasure: 'قطعة',
                  notes: '',
                  lastRestockedDate: new Date().toISOString().split('T')[0]
                });
                setIsAddSparePartOpen(true);
              }}
              className="px-4 py-3 bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 font-bold rounded-2xl text-xs md:text-sm flex items-center gap-2 transition-all cursor-pointer shadow"
            >
              <Boxes className="w-5 h-5 text-emerald-400" />
              تسجيل وارد قطع غيار
            </button>

            <button
              onClick={() => setIsPrintReportOpen(true)}
              className="px-4 py-3 bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 font-bold rounded-2xl text-xs md:text-sm flex items-center gap-2 transition-all cursor-pointer shadow"
            >
              <Printer className="w-4 h-4 text-amber-400" />
              طباعة التقرير الشامل
            </button>
          </div>
        </div>

        {/* Tab Switcher Navigation */}
        <div className="mt-8 pt-4 border-t border-slate-800/80 flex items-center gap-2 overflow-x-auto scrollbar-none">
          <button
            onClick={() => setActiveTab('vehicles')}
            className={`px-5 py-2.5 rounded-2xl text-xs font-black flex items-center gap-2 transition-all cursor-pointer ${
              activeTab === 'vehicles'
                ? 'bg-amber-500 text-slate-950 shadow-lg shadow-amber-500/20 scale-105'
                : 'bg-slate-900/80 hover:bg-slate-800 text-slate-300 border border-slate-800'
            }`}
          >
            <Truck className="w-4 h-4" />
            <span>الأسطول والمعدات التكتيكية ({totalCount})</span>
          </button>

          <button
            onClick={() => setActiveTab('dispense_orders')}
            className={`px-5 py-2.5 rounded-2xl text-xs font-black flex items-center gap-2 transition-all cursor-pointer ${
              activeTab === 'dispense_orders'
                ? 'bg-amber-500 text-slate-950 shadow-lg shadow-amber-500/20 scale-105'
                : 'bg-slate-900/80 hover:bg-slate-800 text-slate-300 border border-slate-800'
            }`}
          >
            <FileText className="w-4 h-4" />
            <span>أوامر وسندات الصرف ({dispenseOrders.length})</span>
          </button>

          <button
            onClick={() => setActiveTab('returned_to_central')}
            className={`px-5 py-2.5 rounded-2xl text-xs font-black flex items-center gap-2 transition-all cursor-pointer ${
              activeTab === 'returned_to_central'
                ? 'bg-indigo-600 text-white shadow-lg shadow-indigo-600/30 scale-105'
                : 'bg-slate-900/80 hover:bg-slate-800 text-slate-300 border border-slate-800'
            }`}
          >
            <ArrowLeftRight className="w-4 h-4" />
            <span>العربات والآليات المرجعة للفنية والحركة ({returnOrders.length})</span>
          </button>

          <button
            onClick={() => setActiveTab('spare_parts')}
            className={`px-5 py-2.5 rounded-2xl text-xs font-black flex items-center gap-2 transition-all cursor-pointer ${
              activeTab === 'spare_parts'
                ? 'bg-amber-500 text-slate-950 shadow-lg shadow-amber-500/20 scale-105'
                : 'bg-slate-900/80 hover:bg-slate-800 text-slate-300 border border-slate-800'
            }`}
          >
            <Boxes className="w-4 h-4" />
            <span>مخزن قطع الغيار والمستلزمات ({totalSparePartsTypes})</span>
            {lowStockPartsCount > 0 && (
              <span className="px-2 py-0.5 rounded-full bg-rose-500 text-white text-[10px] animate-pulse">
                {lowStockPartsCount} تنبيه
              </span>
            )}
          </button>

          <button
            onClick={() => setActiveTab('maintenance')}
            className={`px-5 py-2.5 rounded-2xl text-xs font-black flex items-center gap-2 transition-all cursor-pointer ${
              activeTab === 'maintenance'
                ? 'bg-amber-500 text-slate-950 shadow-lg shadow-amber-500/20 scale-105'
                : 'bg-slate-900/80 hover:bg-slate-800 text-slate-300 border border-slate-800'
            }`}
          >
            <Wrench className="w-4 h-4" />
            <span>محاضر وأعمال الصيانة الميدانية ({allMaintenanceLogs.length})</span>
          </button>
        </div>
      </div>

      {/* TAB 1: VEHICLES & EQUIPMENT READINESS */}
      {activeTab === 'vehicles' && (
        <div className="space-y-6">
          {/* KPI Stats Cards - Readiness Board */}
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-3 md:gap-4">
            {/* Total Vehicles */}
            <div className="bg-slate-900/90 border border-slate-800 p-4 rounded-2xl shadow-lg relative overflow-hidden group hover:border-amber-500/50 transition-all">
              <div className="flex items-center justify-between text-slate-400 mb-2">
                <span className="text-xs font-bold">إجمالي الآليات والمعدات</span>
                <Truck className="w-5 h-5 text-amber-400" />
              </div>
              <div className="text-2xl font-black text-white">{totalCount}</div>
              <p className="text-[10px] text-slate-400 font-bold mt-1">كافة الفئات الميدانية</p>
            </div>

            {/* Ready Stat */}
            <div className="bg-emerald-950/40 border border-emerald-500/30 p-4 rounded-2xl shadow-lg relative overflow-hidden group hover:border-emerald-500 transition-all">
              <div className="flex items-center justify-between text-emerald-400 mb-2">
                <span className="text-xs font-bold">جاهزة</span>
                <CheckCircle2 className="w-5 h-5 text-emerald-400" />
              </div>
              <div className="text-2xl font-black text-emerald-300">{readyCount}</div>
              <p className="text-[10px] text-emerald-400/80 font-bold mt-1">
                {totalCount > 0 ? Math.round((readyCount / totalCount) * 100) : 0}% من الإجمالي
              </p>
            </div>

            {/* Issued Stat */}
            <div className="bg-sky-950/40 border border-sky-500/30 p-4 rounded-2xl shadow-lg relative overflow-hidden group hover:border-sky-500 transition-all">
              <div className="flex items-center justify-between text-sky-400 mb-2">
                <span className="text-xs font-bold">منصرف</span>
                <Truck className="w-5 h-5 text-sky-400" />
              </div>
              <div className="text-2xl font-black text-sky-300">{issuedCount}</div>
              <p className="text-[10px] text-sky-400/80 font-bold mt-1">في المهام الميدانية</p>
            </div>

            {/* Unissued Stat */}
            <div className="bg-amber-950/40 border border-amber-500/30 p-4 rounded-2xl shadow-lg relative overflow-hidden group hover:border-amber-500 transition-all">
              <div className="flex items-center justify-between text-amber-400 mb-2">
                <span className="text-xs font-bold">لم يتم صرفها</span>
                <Clock className="w-5 h-5 text-amber-400" />
              </div>
              <div className="text-2xl font-black text-amber-300">{unissuedCount}</div>
              <p className="text-[10px] text-amber-400/80 font-bold mt-1">احتياطي بالمخازن</p>
            </div>

            {/* Out of Service / Maintenance Stat */}
            <div className="bg-rose-950/40 border border-rose-500/30 p-4 rounded-2xl shadow-lg relative overflow-hidden group hover:border-rose-500 transition-all">
              <div className="flex items-center justify-between text-rose-400 mb-2">
                <span className="text-xs font-bold">خارج الجاهزية</span>
                <AlertOctagon className="w-5 h-5 text-rose-400" />
              </div>
              <div className="text-2xl font-black text-rose-300">{outOfServiceCount}</div>
              <p className="text-[10px] text-rose-400/80 font-bold mt-1">تحت الصيانة والإصلاح</p>
            </div>

            {/* Overall Readiness Meter */}
            <div className="bg-slate-900/90 border border-slate-800 p-4 rounded-2xl shadow-lg relative overflow-hidden">
              <div className="flex items-center justify-between text-slate-400 mb-2">
                <span className="text-xs font-bold">مؤشر الجاهزية العامة</span>
                <Gauge className="w-5 h-5 text-amber-400" />
              </div>
              <div className="text-2xl font-black text-amber-400">{avgReadiness}%</div>
              <div className="w-full bg-slate-800 h-2 rounded-full overflow-hidden mt-1.5">
                <div
                  className={`h-full transition-all duration-500 ${
                    avgReadiness >= 80 ? 'bg-emerald-500' : avgReadiness >= 60 ? 'bg-amber-500' : 'bg-rose-500'
                  }`}
                  style={{ width: `${avgReadiness}%` }}
                ></div>
              </div>
            </div>
          </div>

          {/* Vehicle & Equipment Category Quick Filter Tabs */}
          <div className="space-y-2">
            <div className="text-xs font-bold text-slate-400 flex items-center gap-1.5">
              <Layers className="w-4 h-4 text-amber-400" />
              <span>فئات العربات والآليات والمعدات التكتيكية:</span>
            </div>

            <div className="flex items-center space-x-2 space-x-reverse overflow-x-auto pb-2 scrollbar-none">
              {[
                'الكل',
                'طقم قتالي',
                'هايلكس',
                'دبابة',
                'مدرعة وحش',
                'مدرعة كاجو',
                'طقم مصفح',
                'طقم مدرع',
                'باصات نقل',
                'آلية ثقيلة',
                'مولدات كهرباء',
                'أجهزة لابتوب وكمبيوتر',
                'طابعات وتجهيزات مكتبية',
                'ألواح شمسية',
                'بطاريات ومخزنات',
                'منظومات واتصالات'
              ].map((cat) => {
                const isActive = selectedCategoryFilter === cat;
                return (
                  <button
                    key={cat}
                    onClick={() => setSelectedCategoryFilter(cat)}
                    className={`px-4 py-2 rounded-xl text-xs font-bold whitespace-nowrap transition-all cursor-pointer flex items-center gap-1.5 ${
                      isActive
                        ? 'bg-amber-600 text-white shadow-md shadow-amber-600/30 scale-105'
                        : 'bg-slate-900/80 hover:bg-slate-800 text-slate-300 border border-slate-800'
                    }`}
                  >
                    {cat === 'مولدات كهرباء' && <Zap className="w-3.5 h-3.5 text-amber-400" />}
                    {cat === 'أجهزة لابتوب وكمبيوتر' && <Laptop className="w-3.5 h-3.5 text-amber-400" />}
                    {cat === 'طابعات وتجهيزات مكتبية' && <Printer className="w-3.5 h-3.5 text-amber-400" />}
                    {cat === 'ألواح شمسية' && <Sun className="w-3.5 h-3.5 text-amber-400" />}
                    {cat === 'بطاريات ومخزنات' && <Battery className="w-3.5 h-3.5 text-amber-400" />}
                    {cat === 'منظومات واتصالات' && <Radio className="w-3.5 h-3.5 text-amber-400" />}
                    <span>{cat === 'الكل' ? '🚀 جميع الفئات' : cat}</span>
                  </button>
                );
              })}
            </div>
          </div>

          {/* Filter and Search Bar */}
          <div className="bg-slate-900/90 border border-slate-800 p-4 rounded-2xl shadow-xl flex flex-col lg:flex-row items-center justify-between gap-4">
            {/* Search Input */}
            <div className="relative w-full lg:w-1/3">
              <Search className="w-4 h-4 text-slate-400 absolute right-3.5 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                placeholder="بحث باسم الآلية، رقم اللوحة، الرقم التسلسلي، السائق..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full bg-slate-950 border border-slate-800 rounded-xl pr-10 pl-4 py-2.5 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-amber-500 transition-all"
              />
              {searchQuery && (
                <button
                  onClick={() => setSearchQuery('')}
                  className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-white"
                >
                  <X className="w-4 h-4" />
                </button>
              )}
            </div>

            {/* Status & Unit Dropdowns */}
            <div className="flex flex-wrap items-center gap-3 w-full lg:w-auto">
              <div className="flex items-center space-x-2 space-x-reverse text-xs font-bold text-slate-400">
                <Filter className="w-4 h-4 text-amber-400" />
                <span>الحالة:</span>
              </div>
              <select
                value={selectedStatusFilter}
                onChange={(e) => setSelectedStatusFilter(e.target.value)}
                className="bg-slate-950 border border-slate-800 text-white text-xs font-bold rounded-xl px-3 py-2 focus:outline-none focus:border-amber-500"
              >
                <option value="الكل">جميع الحالات</option>
                <option value="جاهزة">جاهزة</option>
                <option value="منصرف">منصرف</option>
                <option value="لم يتم صرفها">لم يتم صرفها</option>
                <option value="خارج الجاهزية">خارج الجاهزية</option>
                <option value="تحت الصيانة">تحت الصيانة</option>
              </select>

              {/* Unit Filter */}
              <select
                value={selectedUnitFilter}
                onChange={(e) => setSelectedUnitFilter(e.target.value)}
                className="bg-slate-950 border border-slate-800 text-white text-xs font-bold rounded-xl px-3 py-2 focus:outline-none focus:border-amber-500"
              >
                <option value="الكل">جميع الألوية والكتائب</option>
                <option value="اللواء الأول">اللواء الأول</option>
                <option value="اللواء الثاني">اللواء الثاني</option>
                <option value="اللواء الثالث">اللواء الثالث</option>
                <option value="اللواء الرابع">اللواء الرابع</option>
                <option value="اللواء الخامس">اللواء الخامس</option>
                <option value="قيادة الفرقة">قيادة الفرقة</option>
                <option value="مخازن">مخازن الجاهزية المركزية</option>
              </select>

              <span className="text-xs text-slate-400 font-bold border-r border-slate-800 pr-3">
                المعروض: <strong className="text-amber-400">{filteredVehicles.length}</strong> عنصر
              </span>
            </div>
          </div>

          {/* Vehicle Cards Grid */}
          {filteredVehicles.length === 0 ? (
            <div className="bg-slate-900/50 border border-slate-800 rounded-3xl p-12 text-center space-y-4">
              <Truck className="w-16 h-16 text-slate-600 mx-auto animate-bounce" />
              <h3 className="text-lg font-bold text-slate-300">لم يتم العثور على أي آلية أو معدة تطابق نتائج البحث!</h3>
              <p className="text-xs text-slate-500">جرب ضبط البحث بكلمات أخرى أو قم بإضافة عنصر جديد بالضغط على الزر بالعلية.</p>
              <button
                onClick={() => {
                  setSearchQuery('');
                  setSelectedStatusFilter('الكل');
                  setSelectedCategoryFilter('الكل');
                  setSelectedUnitFilter('الكل');
                }}
                className="px-4 py-2 bg-amber-600 hover:bg-amber-500 text-white font-bold rounded-xl text-xs transition-all cursor-pointer"
              >
                إعادة ضبط خيارات الفلترة
              </button>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
              {filteredVehicles.map((vehicle) => {
                const statusConfig = getStatusBadge(vehicle.status);
                const logCount = vehicle.maintenanceLogs?.length || 0;

                return (
                  <div
                    key={vehicle.id}
                    className="bg-slate-900/90 border border-slate-800 hover:border-amber-500/50 rounded-2xl p-5 shadow-xl transition-all duration-300 hover:shadow-2xl hover:shadow-amber-950/30 flex flex-col justify-between group relative overflow-hidden"
                  >
                    <div>
                      {/* Category Icon & Badge */}
                      <div className="flex items-start justify-between gap-2 mb-3">
                        <div className="w-11 h-11 rounded-2xl bg-amber-500/10 border border-amber-500/20 flex items-center justify-center text-amber-400 shrink-0 group-hover:scale-110 transition-transform">
                          {vehicle.category === 'مولدات كهرباء' && <Zap className="w-6 h-6 text-amber-400" />}
                          {vehicle.category === 'أجهزة لابتوب وكمبيوتر' && <Laptop className="w-6 h-6 text-amber-400" />}
                          {vehicle.category === 'طابعات وتجهيزات مكتبية' && <Printer className="w-6 h-6 text-amber-400" />}
                          {vehicle.category === 'ألواح شمسية' && <Sun className="w-6 h-6 text-amber-400" />}
                          {vehicle.category === 'بطاريات ومخزنات' && <Battery className="w-6 h-6 text-amber-400" />}
                          {vehicle.category === 'منظومات واتصالات' && <Radio className="w-6 h-6 text-amber-400" />}
                          {!['مولدات كهرباء', 'أجهزة لابتوب وكمبيوتر', 'طابعات وتجهيزات مكتبية', 'ألواح شمسية', 'بطاريات ومخزنات', 'منظومات واتصالات'].includes(vehicle.category) && (
                            <Truck className="w-6 h-6 text-amber-400" />
                          )}
                        </div>

                        <div className={`px-3 py-1 rounded-full border text-[11px] font-black flex items-center gap-1.5 ${statusConfig.bg}`}>
                          <span className={`w-2 h-2 rounded-full ${statusConfig.dot} animate-pulse`}></span>
                          <span>{statusConfig.label}</span>
                        </div>
                      </div>

                      {/* Name & Plate */}
                      <h3 className="text-sm font-black text-white group-hover:text-amber-300 transition-colors line-clamp-2 leading-snug">
                        {vehicle.name}
                      </h3>

                      <div className="mt-2 flex items-center justify-between text-xs font-bold text-slate-400 border-b border-slate-800 pb-2.5">
                        <span className="text-amber-400 font-mono bg-amber-950/60 border border-amber-800/40 px-2 py-0.5 rounded-lg">
                          {vehicle.plateNumber}
                        </span>
                        <span className="text-[11px] text-slate-400">{vehicle.category}</span>
                      </div>

                      {/* Attributes */}
                      <div className="mt-3 space-y-2 text-xs font-semibold text-slate-300">
                        <div className="flex items-center justify-between text-[11px]">
                          <span className="text-slate-400 flex items-center gap-1">
                            <MapPin className="w-3.5 h-3.5 text-amber-400" />
                            الوحدة:
                          </span>
                          <span className="font-bold text-slate-200 truncate max-w-[140px]">{vehicle.assignedUnit}</span>
                        </div>

                        <div className="flex items-center justify-between text-[11px]">
                          <span className="text-slate-400 flex items-center gap-1">
                            <User className="w-3.5 h-3.5 text-amber-400" />
                            المسؤول / العهدة:
                          </span>
                          <span className="font-bold text-slate-200 truncate max-w-[140px]">
                            {vehicle.assignedDriverName || 'غير معين'}
                          </span>
                        </div>

                        <div className="flex items-center justify-between text-[11px]">
                          <span className="text-slate-400 flex items-center gap-1">
                            <Fuel className="w-3.5 h-3.5 text-amber-400" />
                            الوقود / الطاقة:
                          </span>
                          <span className="font-bold text-slate-200">{vehicle.fuelLevel}</span>
                        </div>

                        {/* Readiness Bar */}
                        <div className="pt-1">
                          <div className="flex justify-between text-[10px] font-bold mb-1">
                            <span className="text-slate-400">الكفاءة الفنية:</span>
                            <span className={vehicle.readinessPercentage >= 80 ? 'text-emerald-400' : 'text-amber-400'}>
                              {vehicle.readinessPercentage}%
                            </span>
                          </div>
                          <div className="w-full bg-slate-950 h-1.5 rounded-full overflow-hidden border border-slate-800">
                            <div
                              className={`h-full transition-all ${
                                vehicle.readinessPercentage >= 80
                                  ? 'bg-emerald-500'
                                  : vehicle.readinessPercentage >= 50
                                  ? 'bg-amber-500'
                                  : 'bg-rose-500'
                              }`}
                              style={{ width: `${vehicle.readinessPercentage}%` }}
                            ></div>
                          </div>
                        </div>
                      </div>
                    </div>

                    {/* Footer Buttons */}
                    <div className="mt-4 pt-3 border-t border-slate-800 flex items-center justify-between gap-2 flex-wrap">
                      <div className="text-[10px] text-slate-400 flex items-center gap-1 font-bold">
                        <Wrench className="w-3 h-3 text-amber-400" />
                        <span>الصيانة: <strong className="text-white">{logCount}</strong></span>
                      </div>

                      <div className="flex items-center gap-1.5 flex-wrap">
                        <button
                          onClick={() => handleOpenEditVehicle(vehicle)}
                          className="px-2.5 py-1.5 bg-slate-800 hover:bg-slate-700 text-amber-300 hover:text-white border border-slate-700 rounded-xl text-xs font-bold transition-all flex items-center gap-1 cursor-pointer"
                          title="تعديل بيانات العربة أو المعدة"
                        >
                          <Edit className="w-3.5 h-3.5 text-amber-400" />
                          تعديل
                        </button>

                        {vehicle.status !== 'مرجعة للفنية والحركة المركزية' && (
                          <button
                            onClick={() => handleOpenReturnForVehicle(vehicle)}
                            className="px-2.5 py-1.5 bg-indigo-950/70 hover:bg-indigo-900 text-indigo-300 hover:text-white border border-indigo-700/60 rounded-xl text-xs font-bold transition-all flex items-center gap-1 cursor-pointer"
                            title="إرجاع الآلية وإخلاء العهدة لفرع الفنية والحركة الرئيسي"
                          >
                            <ArrowLeftRight className="w-3.5 h-3.5 text-indigo-400" />
                            إرجاع للفنية
                          </button>
                        )}

                        <button
                          onClick={() => setSelectedVehicleForCard(vehicle)}
                          className="px-3 py-1.5 bg-amber-600/20 hover:bg-amber-600 text-amber-300 hover:text-white border border-amber-500/40 rounded-xl text-xs font-bold transition-all flex items-center gap-1 cursor-pointer"
                        >
                          <ClipboardList className="w-3.5 h-3.5" />
                          عرض الكرت
                        </button>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      )}

      {/* TAB: DISPENSE ORDERS (أمر وسند الصرف) */}
      {activeTab === 'dispense_orders' && (
        <div className="space-y-6">
          {/* Top KPI Cards for Dispense Orders */}
          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-4">
            <div className="bg-slate-900/90 border border-slate-800 p-5 rounded-2xl shadow-lg relative overflow-hidden group hover:border-amber-500/50 transition-all">
              <div className="flex items-center justify-between text-slate-400 mb-2">
                <span className="text-xs font-bold">إجمالي سندات الصرف</span>
                <ClipboardList className="w-5 h-5 text-amber-400" />
              </div>
              <div className="text-2xl font-black text-white">{dispenseOrders.length} <span className="text-xs text-slate-400 font-normal">سند</span></div>
              <p className="text-[10px] text-slate-400 mt-1">سندات صرف الآليات والأجهزة والمعدات</p>
            </div>

            <div className="bg-slate-900/90 border border-slate-800 p-5 rounded-2xl shadow-lg relative overflow-hidden group hover:border-emerald-500/50 transition-all">
              <div className="flex items-center justify-between text-slate-400 mb-2">
                <span className="text-xs font-bold">آليات عسكرية منصرفة</span>
                <Truck className="w-5 h-5 text-emerald-400" />
              </div>
              <div className="text-2xl font-black text-emerald-400">
                {dispenseOrders.filter(d => d.itemType === 'آلية عسكرية').length} <span className="text-xs text-slate-400 font-normal">آلية</span>
              </div>
              <p className="text-[10px] text-slate-400 mt-1">أطقم وهائلُكسات ودبابات ومدرعات</p>
            </div>

            <div className="bg-slate-900/90 border border-slate-800 p-5 rounded-2xl shadow-lg relative overflow-hidden group hover:border-sky-500/50 transition-all">
              <div className="flex items-center justify-between text-slate-400 mb-2">
                <span className="text-xs font-bold">أجهزة ومعدات أخرى منصرفة</span>
                <Laptop className="w-5 h-5 text-sky-400" />
              </div>
              <div className="text-2xl font-black text-sky-400">
                {dispenseOrders.filter(d => d.itemType === 'أجهزة ومعدات أخرى').length} <span className="text-xs text-slate-400 font-normal">جهاز/معدة</span>
              </div>
              <p className="text-[10px] text-slate-400 mt-1">مولدات، أجهزة اتصالات، لابتوبات، طاقة</p>
            </div>

            <div className="bg-slate-900/90 border border-slate-800 p-5 rounded-2xl shadow-lg relative overflow-hidden group hover:border-purple-500/50 transition-all">
              <div className="flex items-center justify-between text-slate-400 mb-2">
                <span className="text-xs font-bold">أحدث سند صرف</span>
                <Clock className="w-5 h-5 text-purple-400" />
              </div>
              <div className="text-sm font-black text-white truncate">
                {dispenseOrders.length > 0 ? dispenseOrders[0].orderNumber : 'لا يوجد'}
              </div>
              <p className="text-[10px] text-purple-300 mt-1 truncate">
                {dispenseOrders.length > 0 ? `${dispenseOrders[0].itemName} - ${dispenseOrders[0].recipientName}` : 'لم يتم تسجيل أمر صرف بعد'}
              </p>
            </div>
          </div>

          {/* Action & Filter Bar */}
          <div className="bg-slate-900/90 border border-slate-800 p-4 rounded-2xl flex flex-wrap items-center justify-between gap-3 shadow-lg">
            <div className="flex flex-wrap items-center gap-3 flex-1 min-w-[280px]">
              <div className="relative flex-1 min-w-[200px]">
                <Search className="w-4 h-4 text-slate-400 absolute right-3 top-1/2 -translate-y-1/2" />
                <input
                  type="text"
                  placeholder="ابحث برقم السند، اسم الآلية/الجهاز، اسم المستلم، الرقم العسكري، أو الضمين..."
                  value={dispenseSearchQuery}
                  onChange={(e) => setDispenseSearchQuery(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl pr-9 pl-3 py-2 text-xs text-white focus:outline-none focus:border-amber-500"
                />
              </div>

              <select
                value={dispenseTypeFilter}
                onChange={(e) => setDispenseTypeFilter(e.target.value)}
                className="bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-amber-500 font-bold"
              >
                <option value="الكل">جميع أنواع المصروفات</option>
                <option value="آلية عسكرية">آلية عسكرية</option>
                <option value="أجهزة ومعدات أخرى">أجهزة ومعدات أخرى</option>
              </select>
            </div>

            <div className="flex items-center gap-2">
              <button
                onClick={handleOpenNewDispenseOrder}
                className="px-4 py-2.5 bg-gradient-to-r from-emerald-600 to-teal-700 hover:from-emerald-700 hover:to-teal-800 text-white font-bold rounded-xl text-xs flex items-center gap-2 transition-all cursor-pointer shadow-lg shadow-emerald-900/30 border border-emerald-500/30"
              >
                <PlusCircle className="w-4 h-4" />
                إصدار أمر صرف جديد
              </button>

              <button
                onClick={() => setIsPrintReportOpen(true)}
                className="px-4 py-2.5 bg-slate-800 hover:bg-slate-700 text-amber-400 border border-amber-500/30 font-bold rounded-xl text-xs flex items-center gap-2 transition-all cursor-pointer shadow"
              >
                <Printer className="w-4 h-4" />
                توليد تقرير الجاهزية الشامل
              </button>
            </div>
          </div>

          {/* List of Dispense Orders */}
          {filteredDispenseOrders.length === 0 ? (
            <div className="bg-slate-900/60 border border-slate-800 rounded-2xl p-12 text-center text-slate-400 space-y-3">
              <FileText className="w-12 h-12 text-slate-600 mx-auto" />
              <p className="text-sm font-bold">لا توجد أوامر أو سندات صرف مطابقة للبحث</p>
              <button
                onClick={handleOpenNewDispenseOrder}
                className="px-4 py-2 bg-amber-500 hover:bg-amber-600 text-slate-950 font-bold rounded-xl text-xs inline-flex items-center gap-1.5 cursor-pointer"
              >
                <PlusCircle className="w-4 h-4" />
                إصدار أمر صرف جديد الآن
              </button>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {filteredDispenseOrders.map((order) => (
                <div
                  key={order.id}
                  className="bg-slate-900/90 border border-slate-800 hover:border-amber-500/40 rounded-2xl p-4 shadow-xl space-y-4 transition-all relative overflow-hidden group"
                >
                  {/* Card Top Banner */}
                  <div className="flex items-center justify-between pb-3 border-b border-slate-800">
                    <div className="flex items-center gap-2">
                      <span className="px-2.5 py-1 rounded-lg bg-amber-500/10 border border-amber-500/30 text-amber-400 font-mono font-black text-xs">
                        {order.orderNumber}
                      </span>
                      <span className={`px-2 py-0.5 rounded-md text-[10px] font-bold ${
                        order.itemType === 'آلية عسكرية'
                          ? 'bg-emerald-500/10 border border-emerald-500/30 text-emerald-400'
                          : 'bg-sky-500/10 border border-sky-500/30 text-sky-400'
                      }`}>
                        {order.itemType}
                      </span>
                    </div>

                    <span className="text-[10px] text-slate-400 font-mono">{order.orderDate}</span>
                  </div>

                  {/* Item Info */}
                  <div className="space-y-1 bg-slate-950/80 p-3 rounded-xl border border-slate-800">
                    <div className="text-xs font-black text-white flex items-center justify-between">
                      <span className="truncate">{order.itemName}</span>
                      <span className="text-[10px] text-amber-300 bg-amber-950 px-1.5 py-0.5 rounded border border-amber-800/60 shrink-0">
                        {order.itemCategory}
                      </span>
                    </div>
                    <div className="text-[11px] text-slate-400 font-mono flex items-center justify-between">
                      <span>اللوحة/السيريال: {order.itemSerialOrPlate}</span>
                      {order.engineOrChassisSerial && (
                        <span>الشاسي: {order.engineOrChassisSerial}</span>
                      )}
                    </div>
                  </div>

                  {/* Recipient & Guarantor Info */}
                  <div className="grid grid-cols-2 gap-2 text-xs">
                    {/* Recipient */}
                    <div className="bg-slate-950/50 p-2.5 rounded-xl border border-slate-800/80 space-y-1">
                      <span className="text-[10px] text-emerald-400 font-bold block border-b border-slate-800 pb-1">
                        👤 المستلم المسؤول:
                      </span>
                      <p className="font-bold text-white truncate text-[11px]">{order.recipientName}</p>
                      <p className="text-[10px] text-slate-400">{order.recipientRank} • {order.recipientMilitaryId}</p>
                      <p className="text-[10px] text-slate-500 truncate">{order.recipientUnit}</p>
                    </div>

                    {/* Guarantor */}
                    <div className="bg-slate-950/50 p-2.5 rounded-xl border border-slate-800/80 space-y-1">
                      <span className="text-[10px] text-purple-400 font-bold block border-b border-slate-800 pb-1">
                        🛡️ الضمين العسكري:
                      </span>
                      <p className="font-bold text-white truncate text-[11px]">{order.guarantorName}</p>
                      <p className="text-[10px] text-slate-400">{order.guarantorRank} • {order.guarantorMilitaryId}</p>
                      <p className="text-[10px] text-slate-500 truncate">{order.guarantorUnit}</p>
                    </div>
                  </div>

                  {/* Order Source & Reason */}
                  <div className="text-[11px] text-slate-300 space-y-1 pt-1">
                    <p className="truncate"><strong className="text-amber-400">مصدر الأمر:</strong> {order.orderSource}</p>
                    <p className="line-clamp-2 text-slate-400 text-[10px] bg-slate-950 p-2 rounded-lg border border-slate-800">
                      <strong>سبب الصرف:</strong> {order.dispenseReason}
                    </p>
                  </div>

                  {/* Card Bottom Actions */}
                  <div className="pt-3 border-t border-slate-800 flex items-center justify-between gap-2">
                    <button
                      onClick={() => setSelectedOrderForVoucher(order)}
                      className="flex-1 py-2 bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-600 hover:to-amber-700 text-slate-950 font-black rounded-xl text-xs flex items-center justify-center gap-1.5 shadow-lg shadow-amber-500/10 cursor-pointer transition-all"
                    >
                      <Printer className="w-3.5 h-3.5" />
                      طباعة سند الصرف 🖨️
                    </button>

                    <button
                      onClick={() => handleDeleteDispenseOrder(order.id)}
                      className="p-2 text-slate-400 hover:text-rose-400 hover:bg-rose-500/10 rounded-xl border border-transparent hover:border-rose-500/30 transition-all cursor-pointer"
                      title="حذف/إلغاء سند الصرف"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {/* TAB: RETURNED TO CENTRAL TECHNICAL AND MOVEMENT BRANCH (العربات والآليات المرجعة للفنية والحركة المركزية) */}
      {activeTab === 'returned_to_central' && (
        <div className="space-y-6">
          {/* Top KPI Cards */}
          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-4">
            <div className="bg-slate-900/90 border border-slate-800 p-5 rounded-2xl shadow-lg relative overflow-hidden group hover:border-indigo-500/50 transition-all">
              <div className="flex items-center justify-between text-slate-400 mb-2">
                <span className="text-xs font-bold">إجمالي الآليات المرجعة</span>
                <ArrowLeftRight className="w-5 h-5 text-indigo-400" />
              </div>
              <div className="text-3xl font-black text-white">{returnOrders.length}</div>
              <p className="text-[10px] text-indigo-300 font-bold mt-1">مسلمة لفرع الفنية والحركة المركزي الرئيسي</p>
            </div>

            <div className="bg-slate-900/90 border border-slate-800 p-5 rounded-2xl shadow-lg relative overflow-hidden group hover:border-emerald-500/50 transition-all">
              <div className="flex items-center justify-between text-slate-400 mb-2">
                <span className="text-xs font-bold">صالحة وجاهزة عند التسليم</span>
                <CheckCircle2 className="w-5 h-5 text-emerald-400" />
              </div>
              <div className="text-3xl font-black text-emerald-400">
                {returnOrders.filter((o) => o.conditionAtHandover === 'صالحة وجاهزة للخدمة' || o.conditionAtHandover === 'مستعملة بحالة متوسطة').length}
              </div>
              <p className="text-[10px] text-slate-400 font-bold mt-1">كفاءة فنية عالية وقت الإخلاء</p>
            </div>

            <div className="bg-slate-900/90 border border-slate-800 p-5 rounded-2xl shadow-lg relative overflow-hidden group hover:border-amber-500/50 transition-all">
              <div className="flex items-center justify-between text-slate-400 mb-2">
                <span className="text-xs font-bold">بحاجة لصيانة وعمرة</span>
                <Wrench className="w-5 h-5 text-amber-400" />
              </div>
              <div className="text-3xl font-black text-amber-400">
                {returnOrders.filter((o) => o.conditionAtHandover === 'معطلة بحاجة لإصلاح' || o.conditionAtHandover === 'بحاجة لعمرة شاملة').length}
              </div>
              <p className="text-[10px] text-slate-400 font-bold mt-1">أحيلت لورش الصيانة المركزية</p>
            </div>

            <div className="bg-slate-900/90 border border-slate-800 p-5 rounded-2xl shadow-lg relative overflow-hidden group hover:border-rose-500/50 transition-all">
              <div className="flex items-center justify-between text-slate-400 mb-2">
                <span className="text-xs font-bold">خارج الجاهزية / تالفة</span>
                <AlertOctagon className="w-5 h-5 text-rose-400" />
              </div>
              <div className="text-3xl font-black text-rose-400">
                {returnOrders.filter((o) => o.conditionAtHandover === 'خارجة عن الجاهزية / تالفة').length}
              </div>
              <p className="text-[10px] text-slate-400 font-bold mt-1">أعطال جسيمة أو إتلاف ميداني</p>
            </div>
          </div>

          {/* Action Header & Search */}
          <div className="bg-slate-900/90 border border-slate-800 p-5 rounded-2xl shadow-lg flex flex-col md:flex-row items-center justify-between gap-4">
            <div className="flex-1 w-full flex flex-col sm:flex-row items-center gap-3">
              <div className="relative w-full sm:w-80">
                <Search className="w-4 h-4 text-slate-400 absolute right-3.5 top-3" />
                <input
                  type="text"
                  value={returnSearchQuery}
                  onChange={(e) => setReturnSearchQuery(e.target.value)}
                  placeholder="بحث باسم الآلية، اللوحة، رقم السند، أو المستلم..."
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl pr-10 pl-4 py-2 text-xs text-white placeholder-slate-500 focus:border-indigo-500 outline-none"
                />
              </div>

              <div className="flex items-center gap-2 w-full sm:w-auto">
                <Filter className="w-4 h-4 text-slate-400" />
                <select
                  value={returnConditionFilter}
                  onChange={(e) => setReturnConditionFilter(e.target.value)}
                  className="bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs text-slate-300 focus:border-indigo-500 outline-none cursor-pointer"
                >
                  <option value="الكل">كل حالات الآليات</option>
                  <option value="صالحة وجاهزة للخدمة">صالحة وجاهزة للخدمة</option>
                  <option value="مستعملة بحالة متوسطة">مستعملة بحالة متوسطة</option>
                  <option value="معطلة بحاجة لإصلاح">معطلة بحاجة لإصلاح</option>
                  <option value="بحاجة لعمرة شاملة">بحاجة لعمرة شاملة</option>
                  <option value="خارجة عن الجاهزية / تالفة">خارجة عن الجاهزية / تالفة</option>
                </select>
              </div>
            </div>

            <button
              onClick={() => {
                setEditingReturnOrder(null);
                setReturnPreselectedVehicle(null);
                setIsAddReturnOpen(true);
              }}
              className="w-full md:w-auto px-5 py-2.5 bg-gradient-to-r from-indigo-500 to-indigo-600 hover:from-indigo-600 hover:to-indigo-700 text-white font-black text-xs rounded-2xl shadow-lg shadow-indigo-500/25 flex items-center justify-center gap-2 transition-all cursor-pointer"
            >
              <PlusCircle className="w-4 h-4" />
              تسجيل إرجاع آلية وسند إخلاء عهدة جديد
            </button>
          </div>

          {/* Cards Grid */}
          {filteredReturnOrders.length === 0 ? (
            <div className="bg-slate-900/60 border border-slate-800 rounded-3xl p-12 text-center text-slate-400 space-y-3">
              <ArrowLeftRight className="w-12 h-12 text-slate-600 mx-auto" />
              <p className="text-base font-bold text-white">لا توجد عربات مرجعة مسجلة حالياً</p>
              <p className="text-xs text-slate-500 max-w-md mx-auto">
                يمكنك تسجيل إرجاع أي آلية من الأسطول إلى فرع الفنية والحركة المركزي مع إصدار سند إخلاء عهدة رسمي وإثبات ملاحظة حالة العربة وقت تسليمها.
              </p>
              <button
                onClick={() => {
                  setEditingReturnOrder(null);
                  setReturnPreselectedVehicle(null);
                  setIsAddReturnOpen(true);
                }}
                className="mt-2 px-5 py-2 bg-indigo-600 hover:bg-indigo-500 text-white font-bold text-xs rounded-xl inline-flex items-center gap-2 cursor-pointer"
              >
                <Plus className="w-4 h-4" />
                تسجيل أول سند إرجاع الآن
              </button>
            </div>
          ) : (
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-5">
              {filteredReturnOrders.map((order) => (
                <div
                  key={order.id}
                  className="bg-slate-900/90 border border-indigo-500/30 hover:border-indigo-500/60 rounded-3xl p-5 shadow-xl transition-all space-y-4 relative overflow-hidden"
                >
                  {/* Top Bar */}
                  <div className="flex items-start justify-between gap-3 border-b border-slate-800 pb-3">
                    <div>
                      <div className="flex items-center gap-2 flex-wrap">
                        <h3 className="text-base font-black text-white">{order.vehicleName}</h3>
                        <span className="px-2 py-0.5 rounded-full bg-slate-800 border border-slate-700 text-slate-300 text-[11px] font-bold">
                          {order.vehicleCategory}
                        </span>
                        <span className="px-2.5 py-0.5 rounded-lg bg-amber-500/10 border border-amber-500/30 text-amber-400 font-mono text-xs font-black">
                          {order.plateNumber}
                        </span>
                      </div>
                      <p className="text-xs text-slate-400 mt-1 flex items-center gap-2 flex-wrap">
                        <span>الجهة الآمرة: <strong className="text-slate-300">{order.returnAuthority || 'قيادة اللواء وركن الفنية'}</strong></span>
                        <span>•</span>
                        <span>السبب: <span className="text-slate-300">{order.returnReason}</span></span>
                      </p>
                    </div>

                    <div className="text-left flex-shrink-0">
                      <div className="px-3 py-1 rounded-xl bg-indigo-950/80 border border-indigo-500/40 text-indigo-300 text-xs font-mono font-bold">
                        {order.returnNumber}
                      </div>
                      <span className="text-[10px] text-slate-500 block mt-1">
                        {order.returnDate} {order.returnTime ? `- ${order.returnTime}` : ''}
                      </span>
                    </div>
                  </div>

                  {/* Parties Row: Handover Person & Receiving Team */}
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs bg-slate-950/70 p-3.5 rounded-2xl border border-slate-800/80">
                    <div className="space-y-1">
                      <span className="text-[10px] font-black text-amber-400 flex items-center gap-1">
                        <User className="w-3.5 h-3.5" />
                        المسلّم (مخلِي العهدة):
                      </span>
                      <strong className="text-white block">{order.handoverPersonName}</strong>
                      <div className="text-[11px] text-slate-400">
                        {order.handoverPersonRank} • عسكري: <span className="font-mono text-slate-300">{order.handoverPersonMilitaryId}</span>
                      </div>
                      <div className="text-[10px] text-slate-500">{order.handoverPersonUnit}</div>
                    </div>

                    <div className="space-y-1 sm:border-r sm:border-slate-800 sm:pr-3">
                      <span className="text-[10px] font-black text-indigo-400 flex items-center gap-1">
                        <Shield className="w-3.5 h-3.5" />
                        المستلم بالفنية والحركة الرئيسي:
                      </span>
                      <strong className="text-white block">{order.receivingOfficerName}</strong>
                      <div className="text-[11px] text-slate-400">
                        {order.receivingOfficerRank} {order.receivingTechnicianName ? `• فاحص: ${order.receivingTechnicianName}` : ''}
                      </div>
                      <div className="text-[10px] text-indigo-300/80">{order.recipientBranch || 'فرع الفنية والحركة المركزي الرئيسي'}</div>
                    </div>
                  </div>

                  {/* HIGHLIGHTED TECHNICAL CONDITION & NOTES BOX AT HANDOVER (USER REQUIREMENT) */}
                  <div className="bg-gradient-to-br from-indigo-950/50 to-slate-950 border border-indigo-500/40 p-3.5 rounded-2xl space-y-2.5">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-1.5 text-xs font-black text-indigo-300">
                        <Wrench className="w-3.5 h-3.5 text-amber-400" />
                        <span>حالة العربة وقت تسليمها إلى فرع الفنية والحركة الرئيسي:</span>
                      </div>
                      <span className={`px-2.5 py-0.5 rounded-full text-[11px] font-black border ${
                        order.conditionAtHandover.includes('صالحة')
                          ? 'bg-emerald-500/20 text-emerald-300 border-emerald-500/40'
                          : order.conditionAtHandover.includes('معطلة')
                          ? 'bg-amber-500/20 text-amber-300 border-amber-500/40'
                          : order.conditionAtHandover.includes('عمرة')
                          ? 'bg-orange-500/20 text-orange-300 border-orange-500/40'
                          : order.conditionAtHandover.includes('تالفة')
                          ? 'bg-rose-500/20 text-rose-300 border-rose-500/40'
                          : 'bg-sky-500/20 text-sky-300 border-sky-500/40'
                      }`}>
                        {order.conditionAtHandover}
                      </span>
                    </div>

                    {/* Condition Note Text */}
                    <div className="bg-slate-900/90 border border-indigo-500/20 p-3 rounded-xl text-xs text-slate-100 leading-relaxed font-medium">
                      <strong className="text-amber-300 block mb-1 text-[11px]">نص الملاحظة الفنية المسجلة عند التسليم:</strong>
                      <p className="whitespace-pre-wrap">{order.handoverConditionNotes}</p>
                    </div>

                    {/* Defects & Accessories info */}
                    <div className="grid grid-cols-2 gap-2 text-[11px] pt-1">
                      <div>
                        <span className="text-slate-400">العداد: </span>
                        <strong className="text-white font-mono">{order.mileageKmAtReturn ? `${order.mileageKmAtReturn.toLocaleString()} كم` : '---'}</strong>
                      </div>
                      <div>
                        <span className="text-slate-400">الوقود: </span>
                        <strong className="text-white">{order.fuelLevelAtReturn || 'متوسط'}</strong>
                      </div>
                    </div>

                    {order.technicalDefects && (
                      <div className="text-[11px] text-rose-300 bg-rose-950/40 border border-rose-800/60 px-2.5 py-1.5 rounded-lg">
                        <strong>نواقص / أعطال مرصودة:</strong> {order.technicalDefects}
                      </div>
                    )}
                  </div>

                  {/* Footer & Action Buttons */}
                  <div className="pt-2 border-t border-slate-800 flex items-center justify-between gap-2 flex-wrap">
                    <span className="px-2.5 py-1 rounded-full bg-emerald-500/10 border border-emerald-500/30 text-emerald-300 text-[11px] font-bold flex items-center gap-1">
                      <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
                      {order.clearanceStatus}
                    </span>

                    <div className="flex items-center gap-2">
                      <button
                        onClick={() => {
                          setEditingReturnOrder(order);
                          setReturnPreselectedVehicle(null);
                          setIsAddReturnOpen(true);
                        }}
                        className="p-2 bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white rounded-xl border border-slate-700 text-xs transition-all cursor-pointer"
                        title="تعديل بيانات السند والملاحظة الفنية"
                      >
                        <Edit className="w-3.5 h-3.5" />
                      </button>

                      <button
                        onClick={() => handleDeleteReturnOrder(order.id, true)}
                        className="p-2 bg-rose-950/50 hover:bg-rose-900 text-rose-300 rounded-xl border border-rose-800/60 text-xs transition-all cursor-pointer"
                        title="إلغاء السند واستعادة الآلية للأسطول النشط"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>

                      <button
                        onClick={() => setSelectedReturnForVoucher(order)}
                        className="px-3.5 py-1.5 bg-gradient-to-r from-indigo-500 to-indigo-600 hover:from-indigo-600 text-white font-bold text-xs rounded-xl shadow flex items-center gap-1.5 cursor-pointer transition-all"
                      >
                        <FileText className="w-3.5 h-3.5" />
                        سند إخلاء العهدة 🖨️
                      </button>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {/* TAB 2: SPARE PARTS WAREHOUSE */}
      {activeTab === 'spare_parts' && (
        <div className="space-y-6">
          {/* Spare Parts KPI Board */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            <div className="bg-slate-900/90 border border-slate-800 p-5 rounded-2xl shadow-lg">
              <div className="flex items-center justify-between text-slate-400 mb-2">
                <span className="text-xs font-bold">عدد أصناف قطع الغيار</span>
                <Boxes className="w-5 h-5 text-emerald-400" />
              </div>
              <div className="text-2xl font-black text-white">{totalSparePartsTypes} صنف</div>
              <p className="text-[10px] text-slate-400 font-bold mt-1">مسجلة بمستودع قطع الغيار</p>
            </div>

            <div className="bg-slate-900/90 border border-slate-800 p-5 rounded-2xl shadow-lg">
              <div className="flex items-center justify-between text-slate-400 mb-2">
                <span className="text-xs font-bold">إجمالي القطع المخزنة</span>
                <Package className="w-5 h-5 text-amber-400" />
              </div>
              <div className="text-2xl font-black text-amber-300">{totalSparePartsQuantity} قطعة</div>
              <p className="text-[10px] text-slate-400 font-bold mt-1">متوفرة للاستخدام والخصم</p>
            </div>

            <div className={`p-5 rounded-2xl shadow-lg border ${lowStockPartsCount > 0 ? 'bg-rose-950/40 border-rose-500/50' : 'bg-slate-900/90 border-slate-800'}`}>
              <div className="flex items-center justify-between text-slate-400 mb-2">
                <span className="text-xs font-bold">تنبيهات نقص المخزون</span>
                <AlertTriangle className={`w-5 h-5 ${lowStockPartsCount > 0 ? 'text-rose-400 animate-bounce' : 'text-slate-500'}`} />
              </div>
              <div className={`text-2xl font-black ${lowStockPartsCount > 0 ? 'text-rose-300' : 'text-emerald-400'}`}>
                {lowStockPartsCount} أصناف
              </div>
              <p className="text-[10px] text-slate-400 font-bold mt-1">وصلت لحد الأمان الأدنى</p>
            </div>

            <div className="bg-slate-900/90 border border-slate-800 p-5 rounded-2xl shadow-lg">
              <div className="flex items-center justify-between text-slate-400 mb-2">
                <span className="text-xs font-bold">القيمة التقديرية للمخزون</span>
                <Coins className="w-5 h-5 text-sky-400" />
              </div>
              <div className="text-2xl font-black text-sky-300">{totalSparePartsValuation.toLocaleString()} ريال</div>
              <p className="text-[10px] text-slate-400 font-bold mt-1">مباشرة بالمستودع الرئيسي</p>
            </div>
          </div>

          {/* Spare Parts Search & Filter */}
          <div className="bg-slate-900/90 border border-slate-800 p-4 rounded-2xl shadow-xl flex flex-col md:flex-row items-center justify-between gap-4">
            <div className="relative w-full md:w-1/2">
              <Search className="w-4 h-4 text-slate-400 absolute right-3.5 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                placeholder="بحث باسم قطعة الغيار، كود الصنف، الطرازات المتوافقة، الرف..."
                value={sparePartsSearch}
                onChange={(e) => setSparePartsSearch(e.target.value)}
                className="w-full bg-slate-950 border border-slate-800 rounded-xl pr-10 pl-4 py-2.5 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-amber-500 transition-all"
              />
            </div>

            <div className="flex items-center gap-3 w-full md:w-auto">
              <span className="text-xs font-bold text-slate-400">التصنيف:</span>
              <select
                value={sparePartsCategoryFilter}
                onChange={(e) => setSparePartsCategoryFilter(e.target.value)}
                className="bg-slate-950 border border-slate-800 text-white text-xs font-bold rounded-xl px-3 py-2 focus:outline-none focus:border-amber-500"
              >
                <option value="الكل">جميع الأقسام</option>
                <option value="زيوت وفلاتر">زيوت وفلاتر</option>
                <option value="إطارات وبنشرات">إطارات وبنشرات</option>
                <option value="قطع محركات">قطع محركات</option>
                <option value="كهرباء وبطاريات">كهرباء وبطاريات</option>
                <option value="مولدات وطاقة">مولدات وطاقة</option>
                <option value="ألواح وانفرترات">ألواح وانفرترات</option>
                <option value="أجهزة وطابعات">أجهزة وطابعات</option>
                <option value="منظومات وإلكترونيات">منظومات وإلكترونيات</option>
                <option value="أخرى">أخرى</option>
              </select>

              <button
                onClick={() => {
                  setEditingSparePart(null);
                  setSparePartForm({
                    code: `SP-${Date.now().toString().slice(-5)}`,
                    name: '',
                    category: 'زيوت وفلاتر',
                    compatibleModels: '',
                    quantity: 10,
                    minThreshold: 5,
                    unitPrice: 50,
                    location: 'المخزن الرئيسي - رف A1',
                    unitOfMeasure: 'قطعة',
                    notes: '',
                    lastRestockedDate: new Date().toISOString().split('T')[0]
                  });
                  setIsAddSparePartOpen(true);
                }}
                className="px-4 py-2 bg-amber-600 hover:bg-amber-500 text-white font-bold rounded-xl text-xs flex items-center gap-1.5 shadow cursor-pointer whitespace-nowrap"
              >
                <Plus className="w-4 h-4" />
                وارد جديد +
              </button>
            </div>
          </div>

          {/* Spare Parts Inventory Table */}
          <div className="bg-slate-900 border border-slate-800 rounded-2xl overflow-hidden shadow-xl">
            <div className="overflow-x-auto">
              <table className="w-full text-xs text-right border-collapse">
                <thead>
                  <tr className="bg-slate-950/80 border-b border-slate-800 text-slate-300 font-black">
                    <th className="p-3.5 border-l border-slate-800">كود الصنف</th>
                    <th className="p-3.5 border-l border-slate-800">اسم قطعة الغيار / المكون</th>
                    <th className="p-3.5 border-l border-slate-800">القسم</th>
                    <th className="p-3.5 border-l border-slate-800">التوافق والأجهزة</th>
                    <th className="p-3.5 border-l border-slate-800 text-center">الكمية المتوفرة</th>
                    <th className="p-3.5 border-l border-slate-800 text-center">سعر القطعة</th>
                    <th className="p-3.5 border-l border-slate-800">الموقع والرف</th>
                    <th className="p-3.5 text-center">الإجراءات</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-800/60 text-slate-200 font-semibold">
                  {filteredSpareParts.length === 0 ? (
                    <tr>
                      <td colSpan={8} className="p-8 text-center text-slate-500 text-xs font-bold">
                        لا توجد أصناف قطعة غيار مسجلة تطابق فلترة البحث حالياً.
                      </td>
                    </tr>
                  ) : (
                    filteredSpareParts.map((item) => {
                      const isLowStock = item.quantity <= item.minThreshold;
                      return (
                        <tr key={item.id} className="hover:bg-slate-850/50 transition-colors">
                          <td className="p-3.5 border-l border-slate-800 font-mono text-amber-400 font-bold">
                            {item.code}
                          </td>
                          <td className="p-3.5 border-l border-slate-800 font-bold text-white">
                            <div>{item.name}</div>
                            {item.notes && <div className="text-[10px] text-slate-400 mt-0.5">{item.notes}</div>}
                          </td>
                          <td className="p-3.5 border-l border-slate-800">
                            <span className="px-2.5 py-1 rounded-lg bg-slate-800 border border-slate-700 text-[11px] font-bold text-slate-300">
                              {item.category}
                            </span>
                          </td>
                          <td className="p-3.5 border-l border-slate-800 text-slate-300 text-[11px]">
                            {item.compatibleModels || 'عام'}
                          </td>
                          <td className="p-3.5 border-l border-slate-800 text-center">
                            <div className="flex items-center justify-center gap-1.5 font-bold">
                              <span className={`text-sm ${isLowStock ? 'text-rose-400 font-black' : 'text-emerald-300'}`}>
                                {item.quantity}
                              </span>
                              <span className="text-[10px] text-slate-400">{item.unitOfMeasure || 'قطعة'}</span>
                            </div>
                            {isLowStock && (
                              <span className="inline-block mt-1 px-2 py-0.5 rounded bg-rose-950 text-rose-300 text-[9px] font-bold border border-rose-800">
                                منخفض (حد الأمان: {item.minThreshold})
                              </span>
                            )}
                          </td>
                          <td className="p-3.5 border-l border-slate-800 text-center font-mono text-amber-300">
                            {item.unitPrice} ريال
                          </td>
                          <td className="p-3.5 border-l border-slate-800 text-slate-300 text-[11px]">
                            {item.location}
                          </td>
                          <td className="p-3.5 text-center">
                            <div className="flex items-center justify-center gap-2">
                              <button
                                onClick={() => {
                                  setEditingSparePart(item);
                                  setSparePartForm({
                                    code: item.code,
                                    name: item.name,
                                    category: item.category,
                                    compatibleModels: item.compatibleModels,
                                    quantity: item.quantity,
                                    minThreshold: item.minThreshold,
                                    unitPrice: item.unitPrice,
                                    location: item.location,
                                    unitOfMeasure: item.unitOfMeasure || 'قطعة',
                                    notes: item.notes || '',
                                    lastRestockedDate: item.lastRestockedDate || new Date().toISOString().split('T')[0]
                                  });
                                  setIsAddSparePartOpen(true);
                                }}
                                className="p-1.5 bg-slate-800 hover:bg-slate-700 text-amber-300 rounded-lg border border-slate-700 transition-all cursor-pointer"
                                title="تعديل الكمية أو الأصناف"
                              >
                                <Edit className="w-3.5 h-3.5" />
                              </button>
                              <button
                                onClick={() => handleDeleteSparePart(item.id, item.name)}
                                className="p-1.5 bg-rose-950/60 hover:bg-rose-900 text-rose-300 rounded-lg border border-rose-800 transition-all cursor-pointer"
                                title="حذف الصنف"
                              >
                                <Trash2 className="w-3.5 h-3.5" />
                              </button>
                            </div>
                          </td>
                        </tr>
                      );
                    })
                  )}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* TAB 3: MAINTENANCE LOGS AUDIT */}
      {activeTab === 'maintenance' && (
        <div className="space-y-6">
          <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 shadow-xl space-y-4">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <div className="flex items-center gap-2 text-amber-400 font-black text-base">
                <Wrench className="w-5 h-5" />
                <span>السجل التاريخي الشامل لجميع أعمال الصيانة وخصم قطع الغيار</span>
              </div>
              <span className="text-xs text-slate-400 font-bold">
                إجمالي المحاضر: <strong className="text-white">{allMaintenanceLogs.length}</strong>
              </span>
            </div>

            <div className="space-y-3">
              {allMaintenanceLogs.length === 0 ? (
                <div className="p-12 text-center text-slate-500 text-xs font-bold">
                  لا توجد أي محاضر صيانة مسجلة في المنظومة حتى الآن.
                </div>
              ) : (
                allMaintenanceLogs.map((log) => (
                  <div
                    key={log.id}
                    className="bg-slate-950 border border-slate-800 p-4 rounded-2xl space-y-2 hover:border-amber-500/40 transition-all"
                  >
                    <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-2 border-b border-slate-900 pb-2">
                      <div className="flex items-center gap-2">
                        <span className="font-black text-white text-sm">{log.vehicleName}</span>
                        <span className="text-amber-400 font-mono text-xs bg-amber-950/80 px-2 py-0.5 rounded border border-amber-800/50">
                          {log.vehiclePlate}
                        </span>
                        <span className="text-[11px] text-slate-400">({log.vehicleCategory})</span>
                      </div>

                      <div className="flex items-center gap-3 text-xs font-bold">
                        <span className="text-slate-400 font-mono text-[11px]">{log.date}</span>
                        <span className="px-2.5 py-0.5 rounded-lg bg-amber-500/20 text-amber-300 border border-amber-500/30 text-[11px]">
                          {log.type}
                        </span>
                        <span className="text-emerald-400 font-mono">
                          {log.cost > 0 ? `${log.cost} ريال` : 'بدون تكلفة'}
                        </span>
                      </div>
                    </div>

                    <p className="text-xs text-slate-200 font-semibold leading-relaxed">
                      {log.description}
                    </p>

                    <div className="grid grid-cols-1 md:grid-cols-2 gap-2 text-[11px] font-semibold text-slate-400 pt-1 border-t border-slate-900">
                      <div>
                        قطع الغيار المستخدمة: <strong className="text-slate-200">{log.sparePartNameUsed || log.partsReplaced || 'لم تستبدل'}</strong>
                      </div>
                      <div>
                        الورشة / الفني: <strong className="text-slate-200">{log.workshopOrTechnician}</strong>
                      </div>
                    </div>
                  </div>
                ))
              )}
            </div>
          </div>
        </div>
      )}

      {/* Modal 1: Add New Vehicle / Equipment */}
      {isAddVehicleOpen && (
        <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-md flex items-center justify-center p-4 overflow-y-auto">
          <div className="bg-slate-900 border border-amber-500/30 rounded-3xl w-full max-w-2xl overflow-hidden shadow-2xl animate-fadeIn my-8">
            <div className="bg-gradient-to-l from-amber-950 to-slate-900 border-b border-amber-500/30 p-5 flex items-center justify-between">
              <div className="flex items-center space-x-3 space-x-reverse text-amber-400 font-black text-lg">
                <Truck className="w-6 h-6 text-amber-400" />
                <span>إضافة عربة / آلية / معدة تكتيكية جديدة</span>
              </div>
              <button
                onClick={() => setIsAddVehicleOpen(false)}
                className="text-slate-400 hover:text-white p-1 rounded-xl bg-slate-800"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleAddVehicleSubmit} className="p-6 space-y-4 text-xs font-bold text-slate-200">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="block mb-1.5 text-slate-300">اسم / طراز الآلية أو المعدة <span className="text-rose-500">*</span></label>
                  <input
                    type="text"
                    required
                    placeholder="مثال: مولد كاتربيلر 150KVA / طقم تويوتا 2024 / لابتوب تكتيكي"
                    value={newVehicle.name}
                    onChange={(e) => setNewVehicle({ ...newVehicle, name: e.target.value })}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-white focus:outline-none focus:border-amber-500"
                  />
                </div>

                <div>
                  <label className="block mb-1.5 text-slate-300">الفئة التكتيكية <span className="text-rose-500">*</span></label>
                  <select
                    value={isCustomCategorySelected ? 'custom' : newVehicle.category}
                    onChange={(e) => {
                      if (e.target.value === 'custom') {
                        setIsCustomCategorySelected(true);
                      } else {
                        setIsCustomCategorySelected(false);
                        setNewVehicle({ ...newVehicle, category: e.target.value });
                      }
                    }}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-white focus:outline-none focus:border-amber-500"
                  >
                    <option value="طقم قتالي">طقم قتالي</option>
                    <option value="هايلكس">هايلكس</option>
                    <option value="دبابة">دبابة</option>
                    <option value="مدرعة وحش">مدرعة وحش</option>
                    <option value="مدرعة كاجو">مدرعة كاجو</option>
                    <option value="طقم مصفح">طقم مصفح</option>
                    <option value="طقم مدرع">طقم مدرع</option>
                    <option value="باصات نقل">باصات نقل</option>
                    <option value="آلية ثقيلة">آلية ثقيلة</option>
                    <option value="مولدات كهرباء">مولدات كهرباء</option>
                    <option value="أجهزة لابتوب وكمبيوتر">أجهزة لابتوب وكمبيوتر</option>
                    <option value="طابعات وتجهيزات مكتبية">طابعات وتجهيزات مكتبية</option>
                    <option value="ألواح شمسية">ألواح شمسية</option>
                    <option value="بطاريات ومخزنات">بطاريات ومخزنات</option>
                    <option value="منظومات واتصالات">منظومات واتصالات</option>
                    <option value="custom">➕ إضافة فئة/منظومة جديدة مخصصة...</option>
                  </select>

                  {isCustomCategorySelected && (
                    <input
                      type="text"
                      required
                      placeholder="أدخل اسم الفئة التكتيكية الجديدة..."
                      value={customCategoryInput}
                      onChange={(e) => setCustomCategoryInput(e.target.value)}
                      className="w-full mt-2 bg-slate-950 border border-amber-500/50 rounded-xl px-3 py-2 text-white focus:outline-none"
                    />
                  )}
                </div>

                <div>
                  <label className="block mb-1.5 text-slate-300">رقم اللوحة / الرقم التسلسلي / S/N <span className="text-rose-500">*</span></label>
                  <input
                    type="text"
                    required
                    placeholder="مثال: GEN-CAT-150 / طقم-4012"
                    value={newVehicle.plateNumber}
                    onChange={(e) => setNewVehicle({ ...newVehicle, plateNumber: e.target.value })}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-white focus:outline-none focus:border-amber-500 font-mono"
                  />
                </div>

                <div>
                  <label className="block mb-1.5 text-slate-300">رقم المحرك / الشاسي / سيريال الصنع</label>
                  <input
                    type="text"
                    placeholder="SN-99821-X"
                    value={newVehicle.engineSerial}
                    onChange={(e) => setNewVehicle({ ...newVehicle, engineSerial: e.target.value })}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-white focus:outline-none focus:border-amber-500 font-mono"
                  />
                </div>

                <div>
                  <label className="block mb-1.5 text-slate-300">حالة الجاهزية الأولية <span className="text-rose-500">*</span></label>
                  <select
                    value={newVehicle.status}
                    onChange={(e) => setNewVehicle({ ...newVehicle, status: e.target.value as VehicleReadinessStatus })}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-white focus:outline-none focus:border-amber-500"
                  >
                    <option value="جاهزة">جاهزة</option>
                    <option value="منصرف">منصرف</option>
                    <option value="لم يتم صرفها">لم يتم صرفها</option>
                    <option value="خارج الجاهزية">خارج الجاهزية</option>
                    <option value="تحت الصيانة">تحت الصيانة</option>
                  </select>
                </div>

                <div>
                  <label className="block mb-1.5 text-slate-300">الوحدة / اللواء / القسم المخصص له</label>
                  <input
                    type="text"
                    placeholder="مثال: اللواء الأول - غرفة العمليات"
                    value={newVehicle.assignedUnit}
                    onChange={(e) => setNewVehicle({ ...newVehicle, assignedUnit: e.target.value })}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-white focus:outline-none focus:border-amber-500"
                  />
                </div>

                <div>
                  <label className="block mb-1.5 text-slate-300">اسم السائق / المسؤول المباشر</label>
                  <input
                    type="text"
                    placeholder="اسم المسلم له العهدة"
                    value={newVehicle.assignedDriverName}
                    onChange={(e) => setNewVehicle({ ...newVehicle, assignedDriverName: e.target.value })}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-white focus:outline-none focus:border-amber-500"
                  />
                </div>

                <div>
                  <label className="block mb-1.5 text-slate-300">الرقم العسكري للمستلم</label>
                  <input
                    type="text"
                    placeholder="109281"
                    value={newVehicle.assignedDriverMilitaryId}
                    onChange={(e) => setNewVehicle({ ...newVehicle, assignedDriverMilitaryId: e.target.value })}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-white focus:outline-none focus:border-amber-500"
                  />
                </div>

                <div>
                  <label className="block mb-1.5 text-slate-300">مستوى الوقود / مصدر الطاقة</label>
                  <select
                    value={newVehicle.fuelLevel}
                    onChange={(e) => setNewVehicle({ ...newVehicle, fuelLevel: e.target.value as any })}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-white focus:outline-none focus:border-amber-500"
                  >
                    <option value="ممتاز (ممتلئ)">ممتاز (ممتلئ)</option>
                    <option value="جيد (3/4)">جيد (3/4)</option>
                    <option value="متوسط (1/2)">متوسط (1/2)</option>
                    <option value="منخفض (1/4)">منخفض (1/4)</option>
                    <option value="حرج (خالي)">حرج (خالي)</option>
                    <option value="طاقة شمسية/كهرباء">طاقة شمسية/كهرباء</option>
                    <option value="غير مطبق">غير مطبق</option>
                  </select>
                </div>

                <div>
                  <label className="block mb-1.5 text-slate-300">نسبة الكفاءة الفنية (%)</label>
                  <input
                    type="number"
                    min="0"
                    max="100"
                    value={newVehicle.readinessPercentage}
                    onChange={(e) => setNewVehicle({ ...newVehicle, readinessPercentage: Number(e.target.value) })}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-white focus:outline-none focus:border-amber-500"
                  />
                </div>
              </div>

              <div>
                <label className="block mb-1.5 text-slate-300">الموقع الميداني / المتواجد فيه</label>
                <input
                  type="text"
                  placeholder="مثال: حوش الجاهزية - مبنى العمليات"
                  value={newVehicle.location}
                  onChange={(e) => setNewVehicle({ ...newVehicle, location: e.target.value })}
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-white focus:outline-none focus:border-amber-500"
                />
              </div>

              <div>
                <label className="block mb-1.5 text-slate-300">ملاحظات فنية أو مواصفات خاصة</label>
                <textarea
                  rows={2}
                  placeholder="أدخل أي ملاحظات بخصوص الآلية أو المعدة التكتيكية..."
                  value={newVehicle.notes}
                  onChange={(e) => setNewVehicle({ ...newVehicle, notes: e.target.value })}
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl p-3 text-white focus:outline-none focus:border-amber-500"
                ></textarea>
              </div>

              <div className="pt-3 border-t border-slate-800 flex justify-end gap-3">
                <button
                  type="button"
                  onClick={() => setIsAddVehicleOpen(false)}
                  className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-xl cursor-pointer"
                >
                  إلغاء
                </button>
                <button
                  type="submit"
                  className="px-6 py-2 bg-amber-600 hover:bg-amber-500 text-white font-bold rounded-xl shadow-lg cursor-pointer"
                >
                  حفظ الآلية / المعدة 💾
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Modal 2: Vehicle Card & Maintenance History */}
      {selectedVehicleForCard && (
        <div className="fixed inset-0 z-50 bg-slate-950/85 backdrop-blur-md flex items-center justify-center p-4 overflow-y-auto">
          <div className="bg-slate-900 border border-amber-500/40 rounded-3xl w-full max-w-4xl overflow-hidden shadow-2xl animate-fadeIn my-6">
            {/* Header */}
            <div className="bg-gradient-to-l from-amber-950 via-slate-900 to-amber-900 border-b border-amber-500/30 p-6 flex items-start justify-between">
              <div className="space-y-1">
                <div className="flex items-center gap-2">
                  <span className="px-3 py-1 rounded-full bg-amber-500/20 text-amber-300 border border-amber-500/40 font-bold text-xs">
                    {selectedVehicleForCard.category}
                  </span>
                  <span className="text-amber-400 font-mono text-xs font-bold bg-slate-950 px-2 py-0.5 rounded border border-slate-800">
                    {selectedVehicleForCard.plateNumber}
                  </span>
                </div>
                <h2 className="text-xl font-black text-white">{selectedVehicleForCard.name}</h2>
                <p className="text-xs text-slate-400 font-semibold">
                  التابعة لـ: <strong className="text-slate-200">{selectedVehicleForCard.assignedUnit}</strong>
                </p>
              </div>

              <button
                onClick={() => setSelectedVehicleForCard(null)}
                className="text-slate-400 hover:text-white p-2 rounded-2xl bg-slate-800/80 border border-slate-700 cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="p-6 space-y-6 max-h-[80vh] overflow-y-auto">
              {/* Quick Status Bar & Actions */}
              <div className="bg-slate-950 border border-slate-800 rounded-2xl p-4 flex flex-col md:flex-row items-center justify-between gap-4">
                <div className="flex items-center gap-3">
                  <div className="text-xs text-slate-400 font-bold">تغيير حالة الجاهزية السريع:</div>
                  <div className="flex flex-wrap gap-1.5">
                    {(['جاهزة', 'منصرف', 'لم يتم صرفها', 'خارج الجاهزية', 'تحت الصيانة'] as VehicleReadinessStatus[]).map((st) => (
                      <button
                        key={st}
                        onClick={() => handleUpdateStatus(selectedVehicleForCard.id, st)}
                        className={`px-3 py-1 rounded-xl text-[11px] font-black transition-all cursor-pointer ${
                          selectedVehicleForCard.status === st
                            ? 'bg-amber-500 text-white shadow-md'
                            : 'bg-slate-900 text-slate-400 hover:text-white border border-slate-800'
                        }`}
                      >
                        {st}
                      </button>
                    ))}
                  </div>
                </div>

                <div className="flex items-center gap-2 flex-wrap">
                  <button
                    onClick={() => {
                      handleOpenEditVehicle(selectedVehicleForCard);
                    }}
                    className="px-3.5 py-2 bg-slate-800 hover:bg-slate-700 text-amber-300 hover:text-white border border-slate-700 font-bold rounded-xl text-xs flex items-center gap-1.5 shadow cursor-pointer transition-all"
                  >
                    <Edit className="w-4 h-4 text-amber-400" />
                    تعديل البيانات
                  </button>

                  {selectedVehicleForCard.status !== 'مرجعة للفنية والحركة المركزية' && (
                    <button
                      onClick={() => {
                        handleOpenReturnForVehicle(selectedVehicleForCard);
                      }}
                      className="px-3.5 py-2 bg-indigo-950/80 hover:bg-indigo-900 text-indigo-300 hover:text-white border border-indigo-700/60 font-bold rounded-xl text-xs flex items-center gap-1.5 shadow cursor-pointer transition-all"
                    >
                      <ArrowLeftRight className="w-4 h-4 text-indigo-400" />
                      إرجاع للفنية والحركة
                    </button>
                  )}

                  <button
                    onClick={() => {
                      setNewLog({
                        type: 'صيانة دورية',
                        date: new Date().toISOString().split('T')[0],
                        description: '',
                        partsReplaced: '',
                        workshopOrTechnician: 'ورشة الصيانة الفنية المركزية',
                        cost: 350,
                        status: 'مكتملة',
                        notes: '',
                        useWarehousePart: false,
                        sparePartIdUsed: '',
                        sparePartQtyUsed: 1
                      });
                      setIsAddMaintenanceOpen(true);
                    }}
                    className="px-4 py-2 bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-600 text-white font-bold rounded-xl text-xs flex items-center gap-1.5 shadow cursor-pointer"
                  >
                    <Wrench className="w-4 h-4" />
                    تسجيل عمل صيانة جديد
                  </button>

                  <button
                    onClick={() => handleDeleteVehicle(selectedVehicleForCard.id, selectedVehicleForCard.name)}
                    className="p-2 bg-rose-950/60 hover:bg-rose-900 text-rose-300 rounded-xl border border-rose-800 text-xs transition-all cursor-pointer"
                    title="حذف العنصر"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              </div>

              {/* Return Clearance Order Banner if Returned */}
              {selectedVehicleForCard.status === 'مرجعة للفنية والحركة المركزية' && (
                <div className="bg-indigo-950/70 border-2 border-indigo-500/60 rounded-2xl p-4 space-y-2">
                  <div className="flex items-center justify-between flex-wrap gap-2">
                    <span className="text-xs font-black text-indigo-300 flex items-center gap-2">
                      <ArrowLeftRight className="w-4 h-4 text-amber-400" />
                      مرجعة رسمياً إلى فرع الفنية والحركة المركزي الرئيسي
                    </span>
                    {selectedVehicleForCard.returnDetails?.returnNumber && (
                      <span className="px-2.5 py-0.5 rounded-lg bg-indigo-900 text-white font-mono font-bold text-xs">
                        سند إخلاء: {selectedVehicleForCard.returnDetails.returnNumber}
                      </span>
                    )}
                  </div>
                  {selectedVehicleForCard.returnDetails?.handoverConditionNotes && (
                    <div className="bg-slate-900/90 border border-indigo-500/30 p-3 rounded-xl text-xs text-slate-200">
                      <strong className="text-amber-300 block mb-1">ملاحظة حالة العربة وقت التسليم:</strong>
                      <p>{selectedVehicleForCard.returnDetails.handoverConditionNotes}</p>
                    </div>
                  )}
                </div>
              )}

              {/* Specs Grid */}
              <div className="grid grid-cols-2 md:grid-cols-4 gap-3 bg-slate-950/60 p-4 rounded-2xl border border-slate-800 text-xs font-semibold">
                <div>
                  <span className="text-slate-400 block text-[11px]">المسؤول / العهدة:</span>
                  <strong className="text-white block mt-0.5">{selectedVehicleForCard.assignedDriverName || 'غير محدد'}</strong>
                  <span className="text-[10px] text-slate-500">مباين: {selectedVehicleForCard.assignedDriverMilitaryId || '---'}</span>
                </div>

                <div>
                  <span className="text-slate-400 block text-[11px]">رقم المحرك / السيريال:</span>
                  <strong className="text-amber-300 font-mono block mt-0.5">{selectedVehicleForCard.engineSerial || 'غير مسجل'}</strong>
                </div>

                <div>
                  <span className="text-slate-400 block text-[11px]">الوقود / الطاقة:</span>
                  <strong className="text-sky-300 block mt-0.5">{selectedVehicleForCard.fuelLevel}</strong>
                </div>

                <div>
                  <span className="text-slate-400 block text-[11px]">الموقع الميداني:</span>
                  <strong className="text-slate-200 block mt-0.5">{selectedVehicleForCard.location}</strong>
                </div>
              </div>

              {/* Maintenance History */}
              <div className="space-y-3">
                <div className="flex items-center justify-between border-b border-slate-800 pb-2">
                  <div className="flex items-center space-x-2 space-x-reverse font-black text-sm text-amber-400">
                    <Wrench className="w-5 h-5 text-amber-400" />
                    <span>سجل ومحضر أعمال الصيانة المسجلة لهذا العنصر</span>
                  </div>
                  <span className="text-xs text-slate-400 font-bold">
                    إجمالي الأعمال: <strong className="text-white">{selectedVehicleForCard.maintenanceLogs?.length || 0}</strong>
                  </span>
                </div>

                {!selectedVehicleForCard.maintenanceLogs || selectedVehicleForCard.maintenanceLogs.length === 0 ? (
                  <div className="p-8 text-center bg-slate-950/40 rounded-2xl border border-slate-800 text-slate-400 text-xs space-y-2">
                    <Activity className="w-8 h-8 mx-auto text-slate-600" />
                    <p>لا توجد أي أعمال صيانة مسجلة حتى الآن.</p>
                  </div>
                ) : (
                  <div className="space-y-3">
                    {selectedVehicleForCard.maintenanceLogs.map((log) => (
                      <div
                        key={log.id}
                        className="bg-slate-950 border border-slate-800 p-4 rounded-2xl space-y-2 hover:border-slate-700 transition-all"
                      >
                        <div className="flex items-center justify-between text-xs font-bold">
                          <div className="flex items-center gap-2">
                            <span className="px-2.5 py-0.5 rounded-lg bg-amber-500/20 text-amber-300 border border-amber-500/30 text-[11px]">
                              {log.type}
                            </span>
                            <span className="text-slate-400 font-mono text-[11px]">{log.date}</span>
                          </div>

                          <div className="flex items-center gap-2">
                            <span className="text-emerald-400 font-mono text-xs">
                              {log.cost > 0 ? `${log.cost} ريال` : 'بدون تكلفة'}
                            </span>
                            <span
                              className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                                log.status === 'مكتملة'
                                  ? 'bg-emerald-950 text-emerald-300 border border-emerald-800'
                                  : 'bg-amber-950 text-amber-300 border border-amber-800'
                              }`}
                            >
                              {log.status}
                            </span>
                          </div>
                        </div>

                        <p className="text-xs text-slate-200 font-semibold leading-relaxed">
                          {log.description}
                        </p>

                        <div className="grid grid-cols-1 md:grid-cols-2 gap-2 text-[11px] font-semibold text-slate-400 pt-1 border-t border-slate-900">
                          <div>
                            قطع الغيار المستبدلة: <strong className="text-slate-300">{log.sparePartNameUsed || log.partsReplaced || 'لم تستبدل'}</strong>
                          </div>
                          <div>
                            الفني / الورشة: <strong className="text-slate-300">{log.workshopOrTechnician}</strong>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Modal 3: Add Maintenance Entry (With Spare Part Auto Deduction) */}
      {isAddMaintenanceOpen && selectedVehicleForCard && (
        <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-md flex items-center justify-center p-4 overflow-y-auto">
          <div className="bg-slate-900 border border-amber-500/40 rounded-3xl w-full max-w-xl overflow-hidden shadow-2xl animate-fadeIn my-8">
            <div className="bg-gradient-to-l from-amber-950 to-slate-900 border-b border-amber-500/30 p-5 flex items-center justify-between">
              <div className="flex items-center space-x-2 space-x-reverse text-amber-400 font-black text-sm">
                <Wrench className="w-5 h-5 text-amber-400" />
                <span>تسجيل عمل صيانة جديد لـ: ({selectedVehicleForCard.name} - {selectedVehicleForCard.plateNumber})</span>
              </div>
              <button
                onClick={() => setIsAddMaintenanceOpen(false)}
                className="text-slate-400 hover:text-white p-1 rounded-xl bg-slate-800 cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleAddMaintenanceSubmit} className="p-6 space-y-4 text-xs font-bold text-slate-200">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="block mb-1.5 text-slate-300">نوع عمل الصيانة <span className="text-rose-500">*</span></label>
                  <select
                    value={newLog.type}
                    onChange={(e) => setNewLog({ ...newLog, type: e.target.value as any })}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-white focus:outline-none focus:border-amber-500"
                  >
                    <option value="صيانة دورية">صيانة دورية</option>
                    <option value="إصلاح أعطال">إصلاح أعطال</option>
                    <option value="تغيير زيوت وفلاتر">تغيير زيوت وفلاتر</option>
                    <option value="استبدال قطعة غيار">استبدال قطعة غيار</option>
                    <option value="صيانة إلكترونية وطاقة">صيانة إلكترونية وطاقة</option>
                    <option value="صيانة محرك">صيانة محرك</option>
                    <option value="صيانة هيدروليك">صيانة هيدروليك</option>
                    <option value="تغيير إطارات">تغيير إطارات</option>
                    <option value="فحص شامل">فحص شامل</option>
                  </select>
                </div>

                <div>
                  <label className="block mb-1.5 text-slate-300">تاريخ الصيانة <span className="text-rose-500">*</span></label>
                  <input
                    type="date"
                    required
                    value={newLog.date}
                    onChange={(e) => setNewLog({ ...newLog, date: e.target.value })}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-white focus:outline-none focus:border-amber-500"
                  />
                </div>
              </div>

              <div>
                <label className="block mb-1.5 text-slate-300">وصف وأعمال الصيانة المنفذة <span className="text-rose-500">*</span></label>
                <textarea
                  rows={2}
                  required
                  placeholder="أدخل التفاصيل الدقيقة للأعطال المصلحة أو الصيانة المنفذة..."
                  value={newLog.description}
                  onChange={(e) => setNewLog({ ...newLog, description: e.target.value })}
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl p-3 text-white focus:outline-none focus:border-amber-500"
                ></textarea>
              </div>

              {/* SPARE PART WAREHOUSE DEDUCTION SECTION */}
              <div className="bg-slate-950 border border-amber-500/30 p-4 rounded-2xl space-y-3">
                <div className="flex items-center justify-between">
                  <label className="flex items-center gap-2 cursor-pointer text-amber-300 font-black">
                    <input
                      type="checkbox"
                      checked={newLog.useWarehousePart}
                      onChange={(e) => setNewLog({ ...newLog, useWarehousePart: e.target.checked })}
                      className="w-4 h-4 accent-amber-500 rounded"
                    />
                    <Boxes className="w-4 h-4 text-amber-400" />
                    <span>ربط وخصم قطعة غيار مباشرة من المخزن الرئيسي</span>
                  </label>
                  <span className="text-[10px] text-slate-400">سيتم الخصم تلقائياً وتقييدها بكرت الصيانة</span>
                </div>

                {newLog.useWarehousePart && (
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-3 pt-2 border-t border-slate-800">
                    <div>
                      <label className="block mb-1 text-slate-300">اختر قطعة الغيار من المخزن:</label>
                      <select
                        value={newLog.sparePartIdUsed}
                        onChange={(e) => {
                          const partId = e.target.value;
                          const partObj = spareParts.find((sp) => sp.id === partId);
                          setNewLog({
                            ...newLog,
                            sparePartIdUsed: partId,
                            cost: partObj ? partObj.unitPrice * (newLog.sparePartQtyUsed || 1) : newLog.cost,
                            partsReplaced: partObj ? partObj.name : newLog.partsReplaced
                          });
                        }}
                        className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-white focus:outline-none focus:border-amber-500"
                      >
                        <option value="">-- اختر صنف قطعة الغيار --</option>
                        {spareParts.map((sp) => (
                          <option key={sp.id} value={sp.id} disabled={sp.quantity <= 0}>
                            {sp.name} - [{sp.code}] (المتاح: {sp.quantity} {sp.unitOfMeasure || 'قطعة'})
                          </option>
                        ))}
                      </select>
                    </div>

                    <div>
                      <label className="block mb-1 text-slate-300">الكمية المراد خصمها:</label>
                      <input
                        type="number"
                        min="1"
                        value={newLog.sparePartQtyUsed}
                        onChange={(e) => {
                          const qty = Math.max(1, Number(e.target.value));
                          const partObj = spareParts.find((sp) => sp.id === newLog.sparePartIdUsed);
                          setNewLog({
                            ...newLog,
                            sparePartQtyUsed: qty,
                            cost: partObj ? partObj.unitPrice * qty : newLog.cost
                          });
                        }}
                        className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-white focus:outline-none focus:border-amber-500"
                      />
                    </div>
                  </div>
                )}
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {!newLog.useWarehousePart && (
                  <div>
                    <label className="block mb-1.5 text-slate-300">قطع الغيار المستبدلة (يدوي)</label>
                    <input
                      type="text"
                      placeholder="مثال: فلتر زيت، طقم صوف، سير محرك..."
                      value={newLog.partsReplaced}
                      onChange={(e) => setNewLog({ ...newLog, partsReplaced: e.target.value })}
                      className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-white focus:outline-none focus:border-amber-500"
                    />
                  </div>
                )}

                <div>
                  <label className="block mb-1.5 text-slate-300">الفني / الورشة المسؤولة</label>
                  <input
                    type="text"
                    placeholder="اسم المهندس أو الفني العسكري"
                    value={newLog.workshopOrTechnician}
                    onChange={(e) => setNewLog({ ...newLog, workshopOrTechnician: e.target.value })}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-white focus:outline-none focus:border-amber-500"
                  />
                </div>

                <div>
                  <label className="block mb-1.5 text-slate-300">التكلفة المالية الإجمالية (ريال)</label>
                  <input
                    type="number"
                    min="0"
                    value={newLog.cost}
                    onChange={(e) => setNewLog({ ...newLog, cost: Number(e.target.value) })}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-white focus:outline-none focus:border-amber-500"
                  />
                </div>

                <div>
                  <label className="block mb-1.5 text-slate-300">حالة الصيانة الحالية</label>
                  <select
                    value={newLog.status}
                    onChange={(e) => setNewLog({ ...newLog, status: e.target.value as any })}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-white focus:outline-none focus:border-amber-500"
                  >
                    <option value="مكتملة">مكتملة (تم الفحص بنجاح)</option>
                    <option value="قيد التنفيذ">قيد التنفيذ (بالورشة)</option>
                    <option value="بانتظار قطع الغيار">بانتظار قطع الغيار</option>
                  </select>
                </div>
              </div>

              <div className="pt-3 border-t border-slate-800 flex justify-end gap-3">
                <button
                  type="button"
                  onClick={() => setIsAddMaintenanceOpen(false)}
                  className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-xl cursor-pointer"
                >
                  إلغاء
                </button>
                <button
                  type="submit"
                  className="px-6 py-2 bg-amber-600 hover:bg-amber-500 text-white font-bold rounded-xl shadow-lg cursor-pointer"
                >
                  اعتماد وحفظ الصيانة 🛠️
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Modal 4: Add / Edit Spare Part */}
      {isAddSparePartOpen && (
        <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-md flex items-center justify-center p-4 overflow-y-auto">
          <div className="bg-slate-900 border border-emerald-500/30 rounded-3xl w-full max-w-xl overflow-hidden shadow-2xl animate-fadeIn my-8">
            <div className="bg-gradient-to-l from-emerald-950 to-slate-900 border-b border-emerald-500/30 p-5 flex items-center justify-between">
              <div className="flex items-center space-x-3 space-x-reverse text-emerald-400 font-black text-lg">
                <Boxes className="w-6 h-6 text-emerald-400" />
                <span>{editingSparePart ? 'تعديل صنف قطعة غيار' : 'تسجيل توريد/وارد قطعة غيار للمخزن'}</span>
              </div>
              <button
                onClick={() => setIsAddSparePartOpen(false)}
                className="text-slate-400 hover:text-white p-1 rounded-xl bg-slate-800 cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSparePartSubmit} className="p-6 space-y-4 text-xs font-bold text-slate-200">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="block mb-1.5 text-slate-300">كود الصنف / الرقم الكتلوجي <span className="text-rose-500">*</span></label>
                  <input
                    type="text"
                    required
                    placeholder="مثال: SP-TOY-OIL"
                    value={sparePartForm.code}
                    onChange={(e) => setSparePartForm({ ...sparePartForm, code: e.target.value })}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-white font-mono focus:outline-none focus:border-emerald-500"
                  />
                </div>

                <div>
                  <label className="block mb-1.5 text-slate-300">اسم قطعة الغيار / الصنف <span className="text-rose-500">*</span></label>
                  <input
                    type="text"
                    required
                    placeholder="مثال: فلتر زيت تويوتا أصلي"
                    value={sparePartForm.name}
                    onChange={(e) => setSparePartForm({ ...sparePartForm, name: e.target.value })}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-white focus:outline-none focus:border-emerald-500"
                  />
                </div>

                <div>
                  <label className="block mb-1.5 text-slate-300">قسم قطعة الغيار</label>
                  <select
                    value={sparePartForm.category}
                    onChange={(e) => setSparePartForm({ ...sparePartForm, category: e.target.value })}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-white focus:outline-none focus:border-emerald-500"
                  >
                    <option value="زيوت وفلاتر">زيوت وفلاتر</option>
                    <option value="إطارات وبنشرات">إطارات وبنشرات</option>
                    <option value="قطع محركات">قطع محركات</option>
                    <option value="كهرباء وبطاريات">كهرباء وبطاريات</option>
                    <option value="مولدات وطاقة">مولدات وطاقة</option>
                    <option value="ألواح وانفرترات">ألواح وانفرترات</option>
                    <option value="أجهزة وطابعات">أجهزة وطابعات</option>
                    <option value="منظومات وإلكترونيات">منظومات وإلكترونيات</option>
                    <option value="أخرى">أخرى</option>
                  </select>
                </div>

                <div>
                  <label className="block mb-1.5 text-slate-300">الطرازات والآليات المتوافقة</label>
                  <input
                    type="text"
                    placeholder="مثال: تويوتا شاص / هايلكس 2020-2025"
                    value={sparePartForm.compatibleModels}
                    onChange={(e) => setSparePartForm({ ...sparePartForm, compatibleModels: e.target.value })}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-white focus:outline-none focus:border-emerald-500"
                  />
                </div>

                <div>
                  <label className="block mb-1.5 text-slate-300">الكمية المتوفرة حالياً بالمخزن <span className="text-rose-500">*</span></label>
                  <input
                    type="number"
                    min="0"
                    required
                    value={sparePartForm.quantity}
                    onChange={(e) => setSparePartForm({ ...sparePartForm, quantity: Number(e.target.value) })}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-white font-bold focus:outline-none focus:border-emerald-500"
                  />
                </div>

                <div>
                  <label className="block mb-1.5 text-slate-300">حد التنبيه بالنقص (حد الأمان)</label>
                  <input
                    type="number"
                    min="1"
                    value={sparePartForm.minThreshold}
                    onChange={(e) => setSparePartForm({ ...sparePartForm, minThreshold: Number(e.target.value) })}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-white focus:outline-none focus:border-emerald-500"
                  />
                </div>

                <div>
                  <label className="block mb-1.5 text-slate-300">السعر التقديري للقطعة (ريال)</label>
                  <input
                    type="number"
                    min="0"
                    value={sparePartForm.unitPrice}
                    onChange={(e) => setSparePartForm({ ...sparePartForm, unitPrice: Number(e.target.value) })}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-white focus:outline-none focus:border-emerald-500 font-mono"
                  />
                </div>

                <div>
                  <label className="block mb-1.5 text-slate-300">وحدة القياس</label>
                  <select
                    value={sparePartForm.unitOfMeasure}
                    onChange={(e) => setSparePartForm({ ...sparePartForm, unitOfMeasure: e.target.value })}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-white focus:outline-none focus:border-emerald-500"
                  >
                    <option value="قطعة">قطعة</option>
                    <option value="طقم">طقم</option>
                    <option value="حبة">حبة</option>
                    <option value="لتر">لتر</option>
                    <option value="إطار">إطار</option>
                    <option value="علبة">علبة</option>
                    <option value="لوح">لوح</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block mb-1.5 text-slate-300">موقع التخزين والرف بالمستودع</label>
                <input
                  type="text"
                  placeholder="مثال: المخزن الرئيسي - جناح A - رف 2"
                  value={sparePartForm.location}
                  onChange={(e) => setSparePartForm({ ...sparePartForm, location: e.target.value })}
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-white focus:outline-none focus:border-emerald-500"
                />
              </div>

              <div>
                <label className="block mb-1.5 text-slate-300">ملاحظات أو مواصفات جودة</label>
                <textarea
                  rows={2}
                  placeholder="وارد اليابان الأصلي، درجات جودة عالية..."
                  value={sparePartForm.notes}
                  onChange={(e) => setSparePartForm({ ...sparePartForm, notes: e.target.value })}
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl p-3 text-white focus:outline-none focus:border-emerald-500"
                ></textarea>
              </div>

              <div className="pt-3 border-t border-slate-800 flex justify-end gap-3">
                <button
                  type="button"
                  onClick={() => setIsAddSparePartOpen(false)}
                  className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-xl cursor-pointer"
                >
                  إلغاء
                </button>
                <button
                  type="submit"
                  className="px-6 py-2 bg-emerald-600 hover:bg-emerald-500 text-white font-bold rounded-xl shadow-lg cursor-pointer"
                >
                  {editingSparePart ? 'تحديث البيانات 💾' : 'إيداع الوارد بالمخزن 📦'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Modal 5: Print Report */}
      {isPrintReportOpen && createPortal(
        <div className="fixed inset-0 z-[99999] bg-slate-950/90 backdrop-blur-md flex items-center justify-center p-4 overflow-y-auto printable-modal-overlay print:p-0 print:bg-white print:static print:block">
          <div className="bg-white text-slate-900 rounded-3xl p-8 max-w-4xl w-full shadow-2xl printable-modal-card print:shadow-none print:w-full space-y-6 text-right font-['Tajawal'] dir-rtl">
            
            {/* Customizer Panel (Hidden during print) */}
            <div className="bg-amber-50 border-2 border-amber-300 rounded-2xl p-4 print:hidden text-xs">
              <p className="font-black text-amber-950 mb-2">تخصيص الرتبة والاسم والصفة للضباط المعنيين باعتِماد وتوقيع تقرير الجاهزية:</p>
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <div className="space-y-1 bg-white p-2.5 rounded-xl border border-amber-200">
                  <label className="block text-[11px] font-black text-slate-800">الضابط الأول:</label>
                  <input
                    type="text"
                    value={vehOfficer1Name}
                    onChange={(e) => setVehOfficer1Name(e.target.value)}
                    placeholder="الرتبة والاسم"
                    className="w-full bg-white border border-slate-300 rounded-lg px-2 py-1 font-bold text-slate-900 text-xs"
                  />
                  <input
                    type="text"
                    value={vehOfficer1Title}
                    onChange={(e) => setVehOfficer1Title(e.target.value)}
                    placeholder="المسمى الوظيفي (اختياري)"
                    className="w-full bg-white border border-slate-200 rounded-lg px-2 py-1 text-slate-700 text-xs mt-1"
                  />
                </div>

                <div className="space-y-1 bg-white p-2.5 rounded-xl border border-amber-200">
                  <label className="block text-[11px] font-black text-slate-800">الضابط الثاني:</label>
                  <input
                    type="text"
                    value={vehOfficer2Name}
                    onChange={(e) => setVehOfficer2Name(e.target.value)}
                    placeholder="الرتبة والاسم"
                    className="w-full bg-white border border-slate-300 rounded-lg px-2 py-1 font-bold text-slate-900 text-xs"
                  />
                  <input
                    type="text"
                    value={vehOfficer2Title}
                    onChange={(e) => setVehOfficer2Title(e.target.value)}
                    placeholder="المسمى الوظيفي (اختياري)"
                    className="w-full bg-white border border-slate-200 rounded-lg px-2 py-1 text-slate-700 text-xs mt-1"
                  />
                </div>

                <div className="space-y-1 bg-white p-2.5 rounded-xl border border-amber-200">
                  <label className="block text-[11px] font-black text-slate-800">الضابط الثالث:</label>
                  <input
                    type="text"
                    value={vehOfficer3Name}
                    onChange={(e) => setVehOfficer3Name(e.target.value)}
                    placeholder="الرتبة والاسم"
                    className="w-full bg-white border border-slate-300 rounded-lg px-2 py-1 font-bold text-slate-900 text-xs"
                  />
                  <input
                    type="text"
                    value={vehOfficer3Title}
                    onChange={(e) => setVehOfficer3Title(e.target.value)}
                    placeholder="المسمى الوظيفي (اختياري)"
                    className="w-full bg-white border border-slate-200 rounded-lg px-2 py-1 text-slate-700 text-xs mt-1"
                  />
                </div>
              </div>
            </div>

            {/* Report Content Container */}
            <div
              ref={readinessPrintRef}
              id="vehicles-readiness-printable-report"
              data-printable-content="true"
              className="space-y-6"
            >
              {/* Report Header */}
              {(() => {
                const headerInfo = getCurrentHeaderInfo();
              return (
                <div className="flex items-center justify-between border-b-2 border-slate-900 pb-4">
                  <div className="text-right space-y-1">
                    <h2 className="text-lg font-black text-slate-900">{headerInfo.forceName}</h2>
                    <h3 className="text-sm font-bold text-slate-800">{headerInfo.divisionName}</h3>
                    <h4 className="text-xs font-bold text-amber-800">{headerInfo.unitName}</h4>
                  </div>

                  <div className="text-center">
                    <div className="w-16 h-16 bg-amber-100 border-2 border-amber-800 rounded-full flex items-center justify-center text-amber-900 font-black text-xl mx-auto shadow-inner">
                      🚛
                    </div>
                    <span className="text-[10px] font-bold text-slate-600 mt-1 block">تقرير جاهزية ومخزون</span>
                  </div>

                  <div className="text-left text-xs space-y-1 font-mono">
                    <p>التاريخ: {new Date().toLocaleDateString('ar-YE')}</p>
                    <p>الرقم المرجعي: REP-{Date.now().toString().slice(-6)}</p>
                    <p>السرية: سرّي للغاية وحسّاس</p>
                  </div>
                </div>
              );
            })()}

            {/* Summary */}
            <div className="space-y-3">
              <h3 className="text-sm font-black text-slate-900 border-r-4 border-amber-700 pr-2">
                بيان ملخص مؤشرات جاهزية الأسطول ومخزن قطع الغيار
              </h3>

              <div className="grid grid-cols-4 gap-2 text-center text-xs font-bold">
                <div className="bg-slate-100 p-2.5 rounded-xl border border-slate-300">
                  <span className="block text-slate-600 text-[10px]">إجمالي الآليات والمعدات</span>
                  <strong className="text-base text-slate-900">{totalCount}</strong>
                </div>
                <div className="bg-emerald-100 p-2.5 rounded-xl border border-emerald-300 text-emerald-900">
                  <span className="block text-[10px]">العناصر الجاهزة</span>
                  <strong className="text-base">{readyCount}</strong>
                </div>
                <div className="bg-amber-100 p-2.5 rounded-xl border border-amber-300 text-amber-900">
                  <span className="block text-[10px]">أصناف قطع الغيار</span>
                  <strong className="text-base">{totalSparePartsTypes} صنف ({totalSparePartsQuantity} قطعة)</strong>
                </div>
                <div className="bg-sky-100 p-2.5 rounded-xl border border-sky-300 text-sky-900">
                  <span className="block text-[10px]">مؤشر الجاهزية الفنية</span>
                  <strong className="text-base">{avgReadiness}%</strong>
                </div>
              </div>
            </div>

            {/* Detailed Equipment Table */}
            <div className="space-y-2">
              <h3 className="text-sm font-black text-slate-900">كشف حصر وتجهيز العربات والمعدات التكتيكية</h3>
              <div className="overflow-x-auto border border-slate-300 rounded-xl">
                <table className="w-full text-xs text-right border-collapse">
                  <thead>
                    <tr className="bg-slate-100 border-b border-slate-300 font-black text-slate-800">
                      <th className="p-2 border-l border-slate-300">#</th>
                      <th className="p-2 border-l border-slate-300">اسم الآلية / المعدة</th>
                      <th className="p-2 border-l border-slate-300">الفئة</th>
                      <th className="p-2 border-l border-slate-300">الرقم التسلسلي / اللوحة</th>
                      <th className="p-2 border-l border-slate-300">الحالة</th>
                      <th className="p-2 border-l border-slate-300">الوحدة المخصصة</th>
                      <th className="p-2">الجاهزية</th>
                    </tr>
                  </thead>
                  <tbody>
                    {vehicles.map((v, idx) => (
                      <tr key={v.id} className="border-b border-slate-200 text-[11px] font-bold">
                        <td className="p-2 border-l border-slate-200">{idx + 1}</td>
                        <td className="p-2 border-l border-slate-200 font-bold">{v.name}</td>
                        <td className="p-2 border-l border-slate-200">{v.category}</td>
                        <td className="p-2 border-l border-slate-200 font-mono">{v.plateNumber}</td>
                        <td className="p-2 border-l border-slate-200">{v.status}</td>
                        <td className="p-2 border-l border-slate-200">{v.assignedUnit}</td>
                        <td className="p-2">{v.readinessPercentage}%</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>

            {/* Signatures */}
            <div className="pt-8 border-t-2 border-slate-900 grid grid-cols-3 gap-4 text-center text-xs font-bold text-slate-900 signature-block">
              <div className="space-y-2">
                {vehOfficer1Title.trim() !== '' && (
                  <p className="font-black">{vehOfficer1Title}</p>
                )}
                <p className="font-bold text-slate-900">{vehOfficer1Name || '..........................'}</p>
                <p className="text-slate-400 text-[10px] pt-2">التوقيع: ..........................</p>
              </div>

              <div className="space-y-2">
                {vehOfficer2Title.trim() !== '' && (
                  <p className="font-black">{vehOfficer2Title}</p>
                )}
                <p className="font-bold text-slate-900">{vehOfficer2Name || '..........................'}</p>
                <p className="text-slate-400 text-[10px] pt-2">التوقيع: ..........................</p>
              </div>

              <div className="space-y-2">
                {vehOfficer3Title.trim() !== '' && (
                  <p className="font-black">{vehOfficer3Title}</p>
                )}
                <p className="font-bold text-slate-900">{vehOfficer3Name || '..........................'}</p>
                <p className="text-slate-400 text-[10px] pt-2">التوقيع والختم الرسمي: ..........................</p>
              </div>
            </div>
          </div>

          {/* Buttons */}
          <div className="pt-6 border-t border-slate-200 flex flex-wrap items-center justify-end gap-3 print:hidden no-print">
              <button
                type="button"
                onClick={() => setIsPrintReportOpen(false)}
                className="px-4 py-2 bg-slate-200 hover:bg-slate-300 text-slate-800 rounded-xl font-bold cursor-pointer"
              >
                إغلاق
              </button>

              <button
                type="button"
                onClick={handleShareReadinessReport}
                className="px-4 py-2 bg-sky-600 hover:bg-sky-500 active:scale-95 text-white font-bold rounded-xl shadow-md flex items-center gap-2 cursor-pointer transition-all"
                title="مشاركة أو حفظ التقرير بصيغة PDF / تقرير معتمد لكافة الأجهزة"
              >
                <Share2 className="w-4 h-4" />
                مشاركة / حفظ PDF 📄
              </button>

              <button
                type="button"
                onClick={handlePrintReadinessReport}
                className="px-6 py-2 bg-amber-600 hover:bg-amber-700 active:scale-95 text-white font-bold rounded-xl shadow-lg flex items-center gap-2 cursor-pointer transition-all"
              >
                <Printer className="w-4 h-4" />
                أمر الطباعة 🖨️
              </button>
            </div>
          </div>
        </div>,
        document.body
      )}

      {/* Modal: Add Dispense Order (أمر صرف آليات وأجهزة) */}
      {isAddDispenseOpen && (
        <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-md flex items-center justify-center p-4 overflow-y-auto">
          <div className="bg-slate-900 border border-amber-500/40 rounded-3xl w-full max-w-4xl overflow-hidden shadow-2xl animate-fadeIn my-8">
            <div className="bg-gradient-to-l from-amber-950 via-slate-900 to-slate-900 border-b border-amber-500/30 p-5 flex items-center justify-between">
              <div className="flex items-center space-x-3 space-x-reverse text-amber-400 font-black text-lg">
                <FileText className="w-6 h-6 text-amber-400" />
                <span>إصدار أمر وجدول صرف عهدة (آليات عسكرية / أجهزة ومعدات)</span>
              </div>
              <button
                onClick={() => setIsAddDispenseOpen(false)}
                className="text-slate-400 hover:text-white p-1 rounded-xl bg-slate-800 cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleAddDispenseSubmit} className="p-6 space-y-6 text-xs font-bold text-slate-200 max-h-[80vh] overflow-y-auto">
              
              {/* SECTION 1: Item / Vehicle Selection */}
              <div className="bg-slate-950 p-4 rounded-2xl border border-amber-500/20 space-y-4">
                <div className="flex items-center justify-between border-b border-slate-800 pb-2">
                  <h3 className="text-amber-400 font-black text-sm flex items-center gap-2">
                    <Truck className="w-4 h-4" />
                    1. بيانات الآلية العسكرية أو الجهاز المصروف
                  </h3>

                  {/* Toggle Item Type */}
                  <div className="flex items-center gap-2 bg-slate-900 p-1 rounded-xl border border-slate-800">
                    <button
                      type="button"
                      onClick={() => setNewDispenseForm({ ...newDispenseForm, itemType: 'آلية عسكرية', itemCategory: 'طقم قتالي' })}
                      className={`px-3 py-1 rounded-lg text-xs font-bold transition-all cursor-pointer ${
                        newDispenseForm.itemType === 'آلية عسكرية'
                          ? 'bg-amber-500 text-slate-950 font-black shadow'
                          : 'text-slate-400 hover:text-white'
                      }`}
                    >
                      آلية عسكرية 🚚
                    </button>
                    <button
                      type="button"
                      onClick={() => setNewDispenseForm({ ...newDispenseForm, itemType: 'أجهزة ومعدات أخرى', itemCategory: 'مولدات كهرباء' })}
                      className={`px-3 py-1 rounded-lg text-xs font-bold transition-all cursor-pointer ${
                        newDispenseForm.itemType === 'أجهزة ومعدات أخرى'
                          ? 'bg-sky-500 text-slate-950 font-black shadow'
                          : 'text-slate-400 hover:text-white'
                      }`}
                    >
                      أجهزة ومعدات أخرى 💻
                    </button>
                  </div>
                </div>

                {/* Quick Select from Existing Inventory */}
                <div>
                  <label className="block mb-1.5 text-slate-300 font-bold">
                    اختر صنف مسبق التسجيل من الجاهزية (تعبئة تلقائية) أو اختر "إدخال يدوي مخصص":
                  </label>
                  <select
                    value={newDispenseForm.selectedVehicleId}
                    onChange={(e) => {
                      const vId = e.target.value;
                      if (!vId) {
                        setNewDispenseForm({
                          ...newDispenseForm,
                          selectedVehicleId: '',
                          itemName: '',
                          itemSerialOrPlate: '',
                          engineOrChassisSerial: ''
                        });
                      } else {
                        const found = vehicles.find((v) => v.id === vId);
                        if (found) {
                          setNewDispenseForm({
                            ...newDispenseForm,
                            selectedVehicleId: found.id,
                            itemName: found.name,
                            itemCategory: found.category,
                            itemSerialOrPlate: found.plateNumber,
                            engineOrChassisSerial: found.engineSerial || '',
                            itemCondition: found.status === 'جاهزة' ? 'جاهزة ومتاحة' : found.status
                          });
                        }
                      }
                    }}
                    className="w-full bg-slate-900 border border-slate-800 rounded-xl px-3 py-2 text-white focus:outline-none focus:border-amber-500"
                  >
                    <option value="">-- إدخال صنف مخصص جديد (غير مسجل في الجاهزية) --</option>
                    {vehicles.map((v) => (
                      <option key={v.id} value={v.id}>
                        [{v.category}] {v.name} - (لوحة/سيريال: {v.plateNumber}) - {v.status}
                      </option>
                    ))}
                  </select>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
                  <div>
                    <label className="block mb-1.5 text-slate-300">اسم الآلية / الجهاز <span className="text-rose-500">*</span></label>
                    <input
                      type="text"
                      required
                      placeholder="مثال: هايلكس 2024 / مولد كاتربيلر 50KVA"
                      value={newDispenseForm.itemName}
                      onChange={(e) => setNewDispenseForm({ ...newDispenseForm, itemName: e.target.value })}
                      className="w-full bg-slate-900 border border-slate-800 rounded-xl px-3 py-2 text-white focus:outline-none focus:border-amber-500"
                    />
                  </div>

                  <div>
                    <label className="block mb-1.5 text-slate-300">الفئة / التصنيف</label>
                    <input
                      type="text"
                      placeholder="مثال: هايلكس / مولدات / طابعات / اتصالات"
                      value={newDispenseForm.itemCategory}
                      onChange={(e) => setNewDispenseForm({ ...newDispenseForm, itemCategory: e.target.value })}
                      className="w-full bg-slate-900 border border-slate-800 rounded-xl px-3 py-2 text-white focus:outline-none focus:border-amber-500"
                    />
                  </div>

                  <div>
                    <label className="block mb-1.5 text-slate-300">رقم اللوحة / الرقم التسلسلي S/N <span className="text-rose-500">*</span></label>
                    <input
                      type="text"
                      required
                      placeholder="رقم اللوحة أو السيريال"
                      value={newDispenseForm.itemSerialOrPlate}
                      onChange={(e) => setNewDispenseForm({ ...newDispenseForm, itemSerialOrPlate: e.target.value })}
                      className="w-full bg-slate-900 border border-slate-800 rounded-xl px-3 py-2 text-white focus:outline-none focus:border-amber-500 font-mono"
                    />
                  </div>

                  <div>
                    <label className="block mb-1.5 text-slate-300">رقم الشاسي / السيريال الداخلي</label>
                    <input
                      type="text"
                      placeholder="رقم الشاسي أو المحرك"
                      value={newDispenseForm.engineOrChassisSerial}
                      onChange={(e) => setNewDispenseForm({ ...newDispenseForm, engineOrChassisSerial: e.target.value })}
                      className="w-full bg-slate-900 border border-slate-800 rounded-xl px-3 py-2 text-white focus:outline-none focus:border-amber-500 font-mono"
                    />
                  </div>

                  <div>
                    <label className="block mb-1.5 text-slate-300">حالة الصنف عند التسليم</label>
                    <select
                      value={newDispenseForm.itemCondition}
                      onChange={(e) => setNewDispenseForm({ ...newDispenseForm, itemCondition: e.target.value })}
                      className="w-full bg-slate-900 border border-slate-800 rounded-xl px-3 py-2 text-white focus:outline-none focus:border-amber-500"
                    >
                      <option value="جاهزة ومتاحة">جاهزة ومتاحة ممتازة</option>
                      <option value="جديدة بالمخزن">جديدة بالمخزن (كرتون)</option>
                      <option value="مستعملة بحالة جيدة">مستعملة بحالة جيدة</option>
                      <option value="تحت الصيانة الخفيفة">تحت الصيانة الخفيفة</option>
                    </select>
                  </div>

                  <div>
                    <label className="block mb-1.5 text-slate-300">الكمية المصروفة</label>
                    <input
                      type="number"
                      min="1"
                      value={newDispenseForm.quantity}
                      onChange={(e) => setNewDispenseForm({ ...newDispenseForm, quantity: Number(e.target.value) })}
                      className="w-full bg-slate-900 border border-slate-800 rounded-xl px-3 py-2 text-white focus:outline-none focus:border-amber-500"
                    />
                  </div>
                </div>
              </div>

              {/* SECTION 2: Recipient Information */}
              <div className="bg-slate-950 p-4 rounded-2xl border border-emerald-500/30 space-y-4">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between border-b border-slate-800 pb-3 gap-2">
                  <h3 className="text-emerald-400 font-black text-sm flex items-center gap-2">
                    <User className="w-4 h-4 text-emerald-400" />
                    <span>2. بيانات الشخص المستلم (المسؤول الأول عن العهدة)</span>
                  </h3>

                  {newDispenseForm.recipientMilitaryId && (
                    <span className="text-[11px] text-emerald-300 bg-emerald-950/80 border border-emerald-600/40 px-2.5 py-1 rounded-xl font-mono self-start sm:self-auto">
                      ✓ مستلم محدد: {newDispenseForm.recipientRank} / {newDispenseForm.recipientName} ({newDispenseForm.recipientMilitaryId})
                    </span>
                  )}
                </div>

                {/* Live Search by Name / Military ID for Recipient */}
                <div className="relative space-y-1">
                  <label className="block text-[11px] font-bold text-slate-300 flex items-center justify-between">
                    <span className="flex items-center gap-1.5 text-emerald-400">
                      <Search className="w-3.5 h-3.5" />
                      استيراد بيانات الفرد بالبحث بالاسم الرباعي أو الرقم الوظيفي:
                    </span>
                    <span className="text-[10px] text-slate-400 font-normal">
                      (انقر على أي فرد لتعبئة كافة بياناته وسجله تلقائياً)
                    </span>
                  </label>
                  
                  <div className="relative">
                    <Search className="w-4 h-4 text-emerald-400 absolute right-3.5 top-3 pointer-events-none" />
                    <input
                      type="text"
                      placeholder="اكتب اسم الفرد الرباعي أو رقمه العسكري للبحث والاستيراد..."
                      value={recipientSearchQuery}
                      onChange={(e) => {
                        setRecipientSearchQuery(e.target.value);
                        setIsRecipientDropdownOpen(true);
                      }}
                      onFocus={() => setIsRecipientDropdownOpen(true)}
                      className="w-full bg-slate-900 border border-emerald-500/50 rounded-xl pr-10 pl-10 py-2.5 text-xs text-white placeholder-slate-400 focus:outline-none focus:border-emerald-400 focus:ring-1 focus:ring-emerald-400 font-bold"
                    />
                    {recipientSearchQuery && (
                      <button
                        type="button"
                        onClick={() => {
                          setRecipientSearchQuery('');
                          setIsRecipientDropdownOpen(false);
                        }}
                        className="absolute left-3 top-2.5 text-slate-400 hover:text-white p-1 rounded-lg"
                        title="إلغاء البحث"
                      >
                        <X className="w-3.5 h-3.5" />
                      </button>
                    )}
                  </div>

                  {/* Dropdown search results */}
                  {isRecipientDropdownOpen && (
                    <div className="absolute z-50 left-0 right-0 mt-1 max-h-64 overflow-y-auto bg-slate-900 border-2 border-emerald-500/60 rounded-2xl shadow-2xl divide-y divide-slate-800">
                      <div className="p-2 bg-slate-950/90 text-[10px] text-slate-400 font-bold flex items-center justify-between sticky top-0 border-b border-slate-800">
                        <span>نتائج البحث من قاعدة الأفراد ({filteredRecipientPersonnel.length}):</span>
                        <button
                          type="button"
                          onClick={() => setIsRecipientDropdownOpen(false)}
                          className="text-slate-400 hover:text-white p-0.5"
                        >
                          إغلاق ✕
                        </button>
                      </div>

                      {filteredRecipientPersonnel.length === 0 ? (
                        <div className="p-4 text-center text-slate-400 text-xs">
                          لا يوجد أفراد يطابقون عبارة البحث "{recipientSearchQuery}"
                        </div>
                      ) : (
                        filteredRecipientPersonnel.map((p) => (
                          <div
                            key={p.militaryId}
                            onClick={() => handleSelectRecipient(p)}
                            className="p-3 hover:bg-emerald-950/50 cursor-pointer flex items-center justify-between text-xs transition-colors"
                          >
                            <div className="flex items-center space-x-3 space-x-reverse">
                              <PersonnelAvatar
                                photoUrl={p.photoUrl}
                                fullName={p.fullName}
                                rank={p.rank}
                                militaryId={p.militaryId}
                                size="sm"
                                shape="rounded"
                              />
                              <div>
                                <div className="font-black text-white flex items-center gap-2">
                                  <span>{p.rank} / {p.fullName}</span>
                                  <span className="font-mono text-emerald-300 bg-emerald-950 border border-emerald-800 px-1.5 py-0.5 rounded text-[10px]">
                                    {p.militaryId}
                                  </span>
                                </div>
                                <div className="text-[10px] text-slate-400 flex flex-wrap items-center gap-2 mt-0.5">
                                  <span>{p.unit}</span>
                                  {p.battalion && <span>• {p.battalion}</span>}
                                  {p.jobTitle && <span>• {p.jobTitle}</span>}
                                  {p.guarantorName && (
                                    <span className="text-purple-300 bg-purple-950/80 px-1.5 py-0.2 rounded border border-purple-800/60">
                                      🛡️ الضمين المقيد: {p.guarantorName}
                                    </span>
                                  )}
                                </div>
                              </div>
                            </div>
                            <span className="text-[10px] bg-emerald-600/30 text-emerald-300 font-bold px-2.5 py-1 rounded-xl border border-emerald-500/40 shrink-0">
                              استيراد البيانات ↙
                            </span>
                          </div>
                        ))
                      )}
                    </div>
                  )}
                </div>

                {/* Detected Guarantor Banner if available */}
                {detectedGuarantorFromRecipient && (
                  <div className="bg-gradient-to-r from-purple-950/70 via-slate-900 to-purple-950/50 border border-purple-500/40 rounded-xl p-3 flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs">
                    <div className="flex items-center gap-2 text-purple-200">
                      <Sparkles className="w-4 h-4 text-purple-400 shrink-0" />
                      <span>
                        يوجد ضمين مقيد في الملف الرسمي لهذا الفرد: <strong className="text-white font-black">{detectedGuarantorFromRecipient}</strong>
                      </span>
                    </div>
                    <button
                      type="button"
                      onClick={handleApplyDetectedGuarantor}
                      className="px-3.5 py-1.5 bg-purple-600 hover:bg-purple-500 text-white font-bold rounded-xl text-xs flex items-center gap-1.5 cursor-pointer shadow-lg transition-all shrink-0 self-start sm:self-auto border border-purple-400/40"
                    >
                      <Check className="w-3.5 h-3.5" />
                      <span>استيراد هذا الضمين للطلب تلقائياً ⚡</span>
                    </button>
                  </div>
                )}

                {/* Recipient Form Fields */}
                <div className="grid grid-cols-1 md:grid-cols-4 gap-3 pt-1">
                  <div>
                    <label className="block mb-1.5 text-slate-300">اسم المستلم الرباعي <span className="text-rose-500">*</span></label>
                    <input
                      type="text"
                      required
                      placeholder="اسم المستلم الكامل"
                      value={newDispenseForm.recipientName}
                      onChange={(e) => setNewDispenseForm({ ...newDispenseForm, recipientName: e.target.value })}
                      className="w-full bg-slate-900 border border-slate-800 rounded-xl px-3 py-2 text-white focus:outline-none focus:border-amber-500"
                    />
                  </div>

                  <div>
                    <label className="block mb-1.5 text-slate-300">الرقم العسكري <span className="text-rose-500">*</span></label>
                    <input
                      type="text"
                      required
                      placeholder="الرقم العسكري"
                      value={newDispenseForm.recipientMilitaryId}
                      onChange={(e) => setNewDispenseForm({ ...newDispenseForm, recipientMilitaryId: e.target.value })}
                      className="w-full bg-slate-900 border border-slate-800 rounded-xl px-3 py-2 text-white focus:outline-none focus:border-amber-500 font-mono"
                    />
                  </div>

                  <div>
                    <label className="block mb-1.5 text-slate-300">الرتبة العسكرية</label>
                    <input
                      type="text"
                      placeholder="مثال: رقيب / ملازم"
                      value={newDispenseForm.recipientRank}
                      onChange={(e) => setNewDispenseForm({ ...newDispenseForm, recipientRank: e.target.value })}
                      className="w-full bg-slate-900 border border-slate-800 rounded-xl px-3 py-2 text-white focus:outline-none focus:border-amber-500"
                    />
                  </div>

                  <div>
                    <label className="block mb-1.5 text-slate-300">الوحدة / اللواء <span className="text-rose-500">*</span></label>
                    <input
                      type="text"
                      required
                      placeholder="اسم اللواء أو الكتيبة"
                      value={newDispenseForm.recipientUnit}
                      onChange={(e) => setNewDispenseForm({ ...newDispenseForm, recipientUnit: e.target.value })}
                      className="w-full bg-slate-900 border border-slate-800 rounded-xl px-3 py-2 text-white focus:outline-none focus:border-amber-500"
                    />
                  </div>

                  <div>
                    <label className="block mb-1.5 text-slate-300">الكتيبة / السرية</label>
                    <input
                      type="text"
                      placeholder="الكتيبة أو السرية"
                      value={newDispenseForm.recipientBattalion}
                      onChange={(e) => setNewDispenseForm({ ...newDispenseForm, recipientBattalion: e.target.value })}
                      className="w-full bg-slate-900 border border-slate-800 rounded-xl px-3 py-2 text-white focus:outline-none focus:border-amber-500"
                    />
                  </div>

                  <div>
                    <label className="block mb-1.5 text-slate-300">المسمى الوظيفي</label>
                    <input
                      type="text"
                      placeholder="مثال: قائد دورية / سائق طقم"
                      value={newDispenseForm.recipientJobTitle}
                      onChange={(e) => setNewDispenseForm({ ...newDispenseForm, recipientJobTitle: e.target.value })}
                      className="w-full bg-slate-900 border border-slate-800 rounded-xl px-3 py-2 text-white focus:outline-none focus:border-amber-500"
                    />
                  </div>

                  <div>
                    <label className="block mb-1.5 text-slate-300">رقم الهاتف التواصل</label>
                    <input
                      type="text"
                      placeholder="77XXXXXXX"
                      value={newDispenseForm.recipientPhone}
                      onChange={(e) => setNewDispenseForm({ ...newDispenseForm, recipientPhone: e.target.value })}
                      className="w-full bg-slate-900 border border-slate-800 rounded-xl px-3 py-2 text-white focus:outline-none focus:border-amber-500 font-mono"
                    />
                  </div>

                  <div>
                    <label className="block mb-1.5 text-slate-300">رقم الهوية الوطنية/السجل</label>
                    <input
                      type="text"
                      placeholder="رقم الهوية"
                      value={newDispenseForm.recipientNationalId}
                      onChange={(e) => setNewDispenseForm({ ...newDispenseForm, recipientNationalId: e.target.value })}
                      className="w-full bg-slate-900 border border-slate-800 rounded-xl px-3 py-2 text-white focus:outline-none focus:border-amber-500 font-mono"
                    />
                  </div>
                </div>
              </div>

              {/* SECTION 3: Guarantor Information */}
              <div className="bg-slate-950 p-4 rounded-2xl border border-purple-500/30 space-y-4">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between border-b border-slate-800 pb-3 gap-2">
                  <div>
                    <h3 className="text-purple-400 font-black text-sm flex items-center gap-2">
                      <Shield className="w-4 h-4 text-purple-400" />
                      <span>3. بيانات الضمين / الكفيل (الضمانة والكفالة الرسمية)</span>
                    </h3>
                    <p className="text-[10px] text-slate-400 mt-0.5">
                      يمكنك استيراد الضمين بالبحث بالاسم من قاعدة البيانات، أو كتابة وإضافة بياناته يدوياً بكل حرية دون الحاجة للاستيراد.
                    </p>
                  </div>

                  {/* Mode Selector for Guarantor */}
                  <div className="flex items-center gap-1.5 bg-slate-900 p-1 rounded-xl border border-purple-500/30 self-start sm:self-auto">
                    <button
                      type="button"
                      onClick={() => setGuarantorEntryMode('import')}
                      className={`px-3 py-1 rounded-lg text-[11px] font-bold transition-all cursor-pointer ${
                        guarantorEntryMode === 'import'
                          ? 'bg-purple-600 text-white font-black shadow'
                          : 'text-slate-400 hover:text-white'
                      }`}
                    >
                      🔍 استيراد بالبحث
                    </button>
                    <button
                      type="button"
                      onClick={() => setGuarantorEntryMode('manual')}
                      className={`px-3 py-1 rounded-lg text-[11px] font-bold transition-all cursor-pointer ${
                        guarantorEntryMode === 'manual'
                          ? 'bg-amber-600 text-white font-black shadow'
                          : 'text-slate-400 hover:text-white'
                      }`}
                    >
                      ✏️ إدخال يدوي حر
                    </button>
                  </div>
                </div>

                {/* If Import Mode: Show Live Search Input for Guarantor */}
                {guarantorEntryMode === 'import' && (
                  <div className="relative space-y-1 bg-purple-950/20 p-3 rounded-xl border border-purple-500/30">
                    <label className="block text-[11px] font-bold text-purple-300 flex items-center justify-between">
                      <span className="flex items-center gap-1.5">
                        <Search className="w-3.5 h-3.5" />
                        ابحث باسم الضمين أو رقمه العسكري للاستيراد:
                      </span>
                      {newDispenseForm.guarantorName && (
                        <span className="text-[10px] text-purple-200 bg-purple-950 border border-purple-700 px-2 py-0.5 rounded font-mono">
                          المحدد حالياً: {newDispenseForm.guarantorName} ({newDispenseForm.guarantorMilitaryId || 'مدني'})
                        </span>
                      )}
                    </label>

                    <div className="relative">
                      <Search className="w-4 h-4 text-purple-400 absolute right-3.5 top-3 pointer-events-none" />
                      <input
                        type="text"
                        placeholder="اكتب اسم الضمين الرباعي أو رقمه العسكري للبحث والاستيراد..."
                        value={guarantorSearchQuery}
                        onChange={(e) => {
                          setGuarantorSearchQuery(e.target.value);
                          setIsGuarantorDropdownOpen(true);
                        }}
                        onFocus={() => setIsGuarantorDropdownOpen(true)}
                        className="w-full bg-slate-900 border border-purple-500/50 rounded-xl pr-10 pl-10 py-2.5 text-xs text-white placeholder-slate-400 focus:outline-none focus:border-purple-400 focus:ring-1 focus:ring-purple-400 font-bold"
                      />
                      {guarantorSearchQuery && (
                        <button
                          type="button"
                          onClick={() => {
                            setGuarantorSearchQuery('');
                            setIsGuarantorDropdownOpen(false);
                          }}
                          className="absolute left-3 top-2.5 text-slate-400 hover:text-white p-1 rounded-lg"
                          title="إلغاء البحث"
                        >
                          <X className="w-3.5 h-3.5" />
                        </button>
                      )}
                    </div>

                    {/* Dropdown search results for guarantor */}
                    {isGuarantorDropdownOpen && (
                      <div className="absolute z-50 left-3 right-3 mt-1 max-h-60 overflow-y-auto bg-slate-900 border-2 border-purple-500/60 rounded-2xl shadow-2xl divide-y divide-slate-800">
                        <div className="p-2 bg-slate-950/90 text-[10px] text-slate-400 font-bold flex items-center justify-between sticky top-0 border-b border-slate-800">
                          <span>نتائج البحث للضمين ({filteredGuarantorPersonnel.length}):</span>
                          <button
                            type="button"
                            onClick={() => setIsGuarantorDropdownOpen(false)}
                            className="text-slate-400 hover:text-white p-0.5"
                          >
                            إغلاق ✕
                          </button>
                        </div>

                        {filteredGuarantorPersonnel.length === 0 ? (
                          <div className="p-4 text-center text-slate-400 text-xs">
                            لا يوجد أفراد يطابقون عبارة البحث "{guarantorSearchQuery}"
                          </div>
                        ) : (
                          filteredGuarantorPersonnel.map((p) => (
                            <div
                              key={p.militaryId}
                              onClick={() => handleSelectGuarantor(p)}
                              className="p-3 hover:bg-purple-950/50 cursor-pointer flex items-center justify-between text-xs transition-colors"
                            >
                              <div className="flex items-center space-x-3 space-x-reverse">
                                <PersonnelAvatar
                                  photoUrl={p.photoUrl}
                                  fullName={p.fullName}
                                  rank={p.rank}
                                  militaryId={p.militaryId}
                                  size="sm"
                                  shape="rounded"
                                />
                                <div>
                                  <div className="font-black text-white flex items-center gap-2">
                                    <span>{p.rank} / {p.fullName}</span>
                                    <span className="font-mono text-purple-300 bg-purple-950 border border-purple-800 px-1.5 py-0.5 rounded text-[10px]">
                                      {p.militaryId}
                                    </span>
                                  </div>
                                  <div className="text-[10px] text-slate-400 flex items-center gap-2 mt-0.5">
                                    <span>{p.unit}</span>
                                    {p.phone && <span>• {p.phone}</span>}
                                  </div>
                                </div>
                              </div>
                              <span className="text-[10px] bg-purple-600/30 text-purple-300 font-bold px-2.5 py-1 rounded-xl border border-purple-500/40 shrink-0">
                                تعيين كضمين ↙
                              </span>
                            </div>
                          ))
                        )}
                      </div>
                    )}
                  </div>
                )}

                {/* If Manual Mode: Informative Banner */}
                {guarantorEntryMode === 'manual' && (
                  <div className="bg-amber-950/20 border border-amber-500/30 rounded-xl p-3 text-[11px] text-amber-200 flex items-center gap-2">
                    <span className="text-base">✍️</span>
                    <span>
                      <strong>وضع الإدخال اليدوي المباشر:</strong> يمكنك تعبئة حقول الضمين أدناه مباشرة دون الحاجة للاستيراد (مناسب للكفلاء المدنيين، التجار، الشيوخ، أو من هم خارج التشكيل).
                    </span>
                  </div>
                )}

                {/* Guarantor Form Fields (Always completely open and editable) */}
                <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
                  <div>
                    <label className="block mb-1.5 text-slate-300">اسم الضمين الرباعي <span className="text-rose-500">*</span></label>
                    <input
                      type="text"
                      required
                      placeholder="اسم الضمين الكامل"
                      value={newDispenseForm.guarantorName}
                      onChange={(e) => setNewDispenseForm({ ...newDispenseForm, guarantorName: e.target.value })}
                      className="w-full bg-slate-900 border border-slate-800 rounded-xl px-3 py-2 text-white focus:outline-none focus:border-purple-400 font-bold"
                    />
                  </div>

                  <div>
                    <label className="block mb-1.5 text-slate-300">
                      الرقم العسكري للضمين <span className="text-[10px] text-slate-400">(أو اكتب 'مدني')</span>
                    </label>
                    <input
                      type="text"
                      placeholder="الرقم العسكري أو اكتب 'مدني'"
                      value={newDispenseForm.guarantorMilitaryId}
                      onChange={(e) => setNewDispenseForm({ ...newDispenseForm, guarantorMilitaryId: e.target.value })}
                      className="w-full bg-slate-900 border border-slate-800 rounded-xl px-3 py-2 text-white focus:outline-none focus:border-purple-400 font-mono"
                    />
                  </div>

                  <div>
                    <label className="block mb-1.5 text-slate-300">رتبة أو صفة الضمين</label>
                    <input
                      type="text"
                      placeholder="مثال: مساعد أول / كفيل تجاري / شيخ"
                      value={newDispenseForm.guarantorRank}
                      onChange={(e) => setNewDispenseForm({ ...newDispenseForm, guarantorRank: e.target.value })}
                      className="w-full bg-slate-900 border border-slate-800 rounded-xl px-3 py-2 text-white focus:outline-none focus:border-purple-400"
                    />
                  </div>

                  <div>
                    <label className="block mb-1.5 text-slate-300">وحدة أو جهة عمل الضمين</label>
                    <input
                      type="text"
                      placeholder="مثال: قيادة اللواء / جهة مدنية / قطاع تجاري"
                      value={newDispenseForm.guarantorUnit}
                      onChange={(e) => setNewDispenseForm({ ...newDispenseForm, guarantorUnit: e.target.value })}
                      className="w-full bg-slate-900 border border-slate-800 rounded-xl px-3 py-2 text-white focus:outline-none focus:border-purple-400"
                    />
                  </div>

                  <div>
                    <label className="block mb-1.5 text-slate-300">رقم هاتف الضمين</label>
                    <input
                      type="text"
                      placeholder="رقم هاتف التواصل للضمين"
                      value={newDispenseForm.guarantorPhone}
                      onChange={(e) => setNewDispenseForm({ ...newDispenseForm, guarantorPhone: e.target.value })}
                      className="w-full bg-slate-900 border border-slate-800 rounded-xl px-3 py-2 text-white focus:outline-none focus:border-purple-400 font-mono"
                    />
                  </div>

                  <div>
                    <label className="block mb-1.5 text-slate-300">رقم هوية الضمين الوطنية</label>
                    <input
                      type="text"
                      placeholder="رقم الهوية الوطنية للضمين"
                      value={newDispenseForm.guarantorNationalId}
                      onChange={(e) => setNewDispenseForm({ ...newDispenseForm, guarantorNationalId: e.target.value })}
                      className="w-full bg-slate-900 border border-slate-800 rounded-xl px-3 py-2 text-white focus:outline-none focus:border-purple-400 font-mono"
                    />
                  </div>
                </div>
              </div>

              {/* SECTION 4: Order Details & Source */}
              <div className="bg-slate-950 p-4 rounded-2xl border border-sky-500/20 space-y-4">
                <h3 className="text-sky-400 font-black text-sm flex items-center gap-2 border-b border-slate-800 pb-2">
                  <FileText className="w-4 h-4" />
                  4. بيانات ومصدر أمر الصرف والمبررات
                </h3>

                <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
                  <div>
                    <label className="block mb-1.5 text-slate-300">رقم أمر الصرف <span className="text-rose-500">*</span></label>
                    <input
                      type="text"
                      required
                      value={newDispenseForm.orderNumber}
                      onChange={(e) => setNewDispenseForm({ ...newDispenseForm, orderNumber: e.target.value })}
                      className="w-full bg-slate-900 border border-slate-800 rounded-xl px-3 py-2 text-white focus:outline-none focus:border-amber-500 font-mono font-bold"
                    />
                  </div>

                  <div>
                    <label className="block mb-1.5 text-slate-300">تاريخ أمر الصرف <span className="text-rose-500">*</span></label>
                    <input
                      type="date"
                      required
                      value={newDispenseForm.orderDate}
                      onChange={(e) => setNewDispenseForm({ ...newDispenseForm, orderDate: e.target.value })}
                      className="w-full bg-slate-900 border border-slate-800 rounded-xl px-3 py-2 text-white focus:outline-none focus:border-amber-500 font-mono"
                    />
                  </div>

                  <div>
                    <label className="block mb-1.5 text-slate-300">مصدر أمر الصرف (الجهة الآمرة) <span className="text-rose-500">*</span></label>
                    <input
                      type="text"
                      required
                      placeholder="مثال: قرار قائد اللواء رقم (801) / غرفة العمليات"
                      value={newDispenseForm.orderSource}
                      onChange={(e) => setNewDispenseForm({ ...newDispenseForm, orderSource: e.target.value })}
                      className="w-full bg-slate-900 border border-slate-800 rounded-xl px-3 py-2 text-white focus:outline-none focus:border-amber-500"
                    />
                  </div>

                  <div className="md:col-span-2">
                    <label className="block mb-1.5 text-slate-300">سبب ومبرر الصرف <span className="text-rose-500">*</span></label>
                    <input
                      type="text"
                      required
                      placeholder="مثال: صرف عهدة لمهمة استطلاعية ودورية بالقطاع الشمالي"
                      value={newDispenseForm.dispenseReason}
                      onChange={(e) => setNewDispenseForm({ ...newDispenseForm, dispenseReason: e.target.value })}
                      className="w-full bg-slate-900 border border-slate-800 rounded-xl px-3 py-2 text-white focus:outline-none focus:border-amber-500"
                    />
                  </div>

                  <div>
                    <label className="block mb-1.5 text-slate-300">موقع الاستخدام / الوجهة</label>
                    <input
                      type="text"
                      placeholder="الموقع الميداني / التبة الشرقية"
                      value={newDispenseForm.locationOrDestination}
                      onChange={(e) => setNewDispenseForm({ ...newDispenseForm, locationOrDestination: e.target.value })}
                      className="w-full bg-slate-900 border border-slate-800 rounded-xl px-3 py-2 text-white focus:outline-none focus:border-amber-500"
                    />
                  </div>
                </div>

                <div>
                  <label className="block mb-1.5 text-slate-300">شروط وملاحظات الصرف والتعهد</label>
                  <textarea
                    rows={2}
                    value={newDispenseForm.notes}
                    onChange={(e) => setNewDispenseForm({ ...newDispenseForm, notes: e.target.value })}
                    className="w-full bg-slate-900 border border-slate-800 rounded-xl p-3 text-white focus:outline-none focus:border-amber-500"
                  />
                </div>
              </div>

              {/* Submit / Cancel buttons */}
              <div className="pt-4 border-t border-slate-800 flex justify-end gap-3">
                <button
                  type="button"
                  onClick={() => setIsAddDispenseOpen(false)}
                  className="px-5 py-2.5 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-xl font-bold cursor-pointer"
                >
                  إلغاء
                </button>
                <button
                  type="submit"
                  className="px-6 py-2.5 bg-gradient-to-r from-emerald-600 to-teal-700 hover:from-emerald-700 hover:to-teal-800 text-white font-black rounded-xl shadow-lg flex items-center gap-2 cursor-pointer border border-emerald-500/30"
                >
                  <Printer className="w-4 h-4" />
                  حفظ السند وتوليد الطباعة 🖨️
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Printable Dispense Voucher Modal */}
      {selectedOrderForVoucher && createPortal(
        <div className="fixed inset-0 z-[99999] bg-slate-950/80 backdrop-blur-md flex items-center justify-center p-4 overflow-y-auto printable-modal-overlay print:p-0 print:bg-white print:static print:block">
          <div className="bg-white text-slate-900 rounded-3xl w-full max-w-4xl p-8 shadow-2xl animate-fadeIn my-8 font-serif printable-modal-card print:p-0 print:shadow-none print:w-full print:max-w-none">
            
            {/* Action Bar (Hidden when printing) */}
            <div className="flex flex-wrap items-center justify-between pb-6 border-b border-slate-200 mb-6 print:hidden no-print gap-3">
              <div className="flex items-center gap-2">
                <span className="w-3 h-3 rounded-full bg-emerald-600"></span>
                <h3 className="font-sans font-black text-slate-900 text-lg">معاينة وتوثيق سند صرف العهدة</h3>
              </div>
              <div className="flex items-center gap-2.5">
                <button
                  type="button"
                  onClick={handleShareDispenseVoucher}
                  className="px-4 py-2 bg-sky-600 hover:bg-sky-500 active:scale-95 text-white font-sans font-bold rounded-xl text-xs flex items-center gap-1.5 shadow-md cursor-pointer transition-all"
                  title="مشاركة أو حفظ السند بصيغة PDF / تقرير معتمد"
                >
                  <Share2 className="w-4 h-4" />
                  مشاركة / حفظ PDF 📄
                </button>
                <button
                  type="button"
                  onClick={handlePrintDispenseVoucher}
                  className="px-5 py-2 bg-amber-600 hover:bg-amber-700 active:scale-95 text-white font-sans font-black rounded-xl text-xs flex items-center gap-2 shadow-lg cursor-pointer transition-all"
                >
                  <Printer className="w-4 h-4" />
                  أمر الطباعة 🖨️
                </button>
                <button
                  type="button"
                  onClick={() => setSelectedOrderForVoucher(null)}
                  className="px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 font-sans font-bold rounded-xl text-xs cursor-pointer"
                >
                  إغلاق
                </button>
              </div>
            </div>

            {/* Printable Document Body */}
            <div
              ref={voucherPrintRef}
              id="vehicle-dispense-printable-voucher"
              data-printable-content="true"
              className="space-y-6 text-right dir-rtl"
            >
              
              {/* Header */}
              {(() => {
                const headerInfo = getCurrentHeaderInfo();
                return (
                  <div className="flex items-center justify-between border-b-2 border-slate-900 pb-4">
                    <div className="text-right space-y-1">
                      <h2 className="text-base font-black text-slate-900">{headerInfo.forceName}</h2>
                      <h3 className="text-sm font-bold text-slate-800">{headerInfo.divisionName}</h3>
                      <h4 className="text-xs font-bold text-amber-900">{headerInfo.unitName} - فرع العربات والآليات</h4>
                    </div>

                    <div className="text-center">
                      <div className="w-16 h-16 bg-slate-100 border-2 border-slate-900 rounded-full flex items-center justify-center text-slate-900 font-black text-2xl mx-auto">
                        📜
                      </div>
                      <span className="text-[11px] font-black text-slate-900 mt-1 block uppercase tracking-wider">سند صرف ومحضر تسليم عهدة</span>
                    </div>

                    <div className="text-left text-xs space-y-1 font-mono">
                      <p><strong>رقم السند:</strong> {selectedOrderForVoucher.orderNumber}</p>
                      <p><strong>تاريخ الصرف:</strong> {selectedOrderForVoucher.orderDate}</p>
                      <p><strong>حالة الوثيقة:</strong> معتمد وموثق رسمياً</p>
                    </div>
                  </div>
                );
              })()}

              {/* Title Badge */}
              <div className="bg-slate-100 border border-slate-300 p-3 rounded-xl text-center">
                <h1 className="text-lg font-black text-slate-900">
                  سند صرف واستلام عهدة ({selectedOrderForVoucher.itemType})
                </h1>
                <p className="text-xs text-slate-600 font-sans mt-0.5">
                  بموجب قرار الجهة الآمرة: <span className="font-bold text-slate-900">{selectedOrderForVoucher.orderSource}</span>
                </p>
              </div>

              {/* Table 1: Item Details */}
              <div className="space-y-2">
                <h3 className="text-xs font-black text-slate-900 border-r-4 border-amber-800 pr-2">
                  أولاً: بيانات الآلية العسكرية / الجهاز المصروف
                </h3>
                <div className="border border-slate-300 rounded-xl overflow-hidden">
                  <table className="w-full text-xs text-right border-collapse">
                    <thead className="bg-slate-100 font-black text-slate-900 border-b border-slate-300">
                      <tr>
                        <th className="p-2.5 border-l border-slate-300">نوع الصنف</th>
                        <th className="p-2.5 border-l border-slate-300">اسم الآلية / الجهاز</th>
                        <th className="p-2.5 border-l border-slate-300">الفئة والتصنيف</th>
                        <th className="p-2.5 border-l border-slate-300">رقم اللوحة / S/N</th>
                        <th className="p-2.5 border-l border-slate-300">رقم الشاسي / السيريال</th>
                        <th className="p-2.5 border-l border-slate-300">الحالة الفنية</th>
                        <th className="p-2.5">الكمية</th>
                      </tr>
                    </thead>
                    <tbody className="font-sans font-bold">
                      <tr className="border-b border-slate-200">
                        <td className="p-2.5 border-l border-slate-200 text-amber-900">{selectedOrderForVoucher.itemType}</td>
                        <td className="p-2.5 border-l border-slate-200">{selectedOrderForVoucher.itemName}</td>
                        <td className="p-2.5 border-l border-slate-200">{selectedOrderForVoucher.itemCategory}</td>
                        <td className="p-2.5 border-l border-slate-200 font-mono text-slate-900">{selectedOrderForVoucher.itemSerialOrPlate}</td>
                        <td className="p-2.5 border-l border-slate-200 font-mono text-slate-700">{selectedOrderForVoucher.engineOrChassisSerial || '---'}</td>
                        <td className="p-2.5 border-l border-slate-200 text-emerald-800">{selectedOrderForVoucher.itemCondition}</td>
                        <td className="p-2.5 font-bold text-center">{selectedOrderForVoucher.quantity}</td>
                      </tr>
                    </tbody>
                  </table>
                </div>
              </div>

              {/* Table 2: Recipient & Guarantor Info */}
              <div className="grid grid-cols-2 gap-4">
                {/* Recipient Box */}
                <div className="border border-slate-300 p-3.5 rounded-xl space-y-2 bg-slate-50/50">
                  <h3 className="text-xs font-black text-emerald-900 border-r-4 border-emerald-800 pr-2">
                    ثانياً: بيانات الشخص المستلم (المسؤول)
                  </h3>
                  <div className="text-xs space-y-1 font-sans font-bold text-slate-800">
                    <p><span className="text-slate-500 font-normal">الاسم الكامل:</span> {selectedOrderForVoucher.recipientName}</p>
                    <p><span className="text-slate-500 font-normal">الرقم العسكري:</span> <span className="font-mono">{selectedOrderForVoucher.recipientMilitaryId}</span></p>
                    <p><span className="text-slate-500 font-normal">الرتبة العسكرية:</span> {selectedOrderForVoucher.recipientRank}</p>
                    <p><span className="text-slate-500 font-normal">الوحدة / الكتيبة:</span> {selectedOrderForVoucher.recipientUnit} {selectedOrderForVoucher.recipientBattalion ? `- ${selectedOrderForVoucher.recipientBattalion}` : ''}</p>
                    {selectedOrderForVoucher.recipientJobTitle && (
                      <p><span className="text-slate-500 font-normal">المسمى الوظيفي:</span> {selectedOrderForVoucher.recipientJobTitle}</p>
                    )}
                    {selectedOrderForVoucher.recipientPhone && (
                      <p><span className="text-slate-500 font-normal">رقم الجوال:</span> <span className="font-mono">{selectedOrderForVoucher.recipientPhone}</span></p>
                    )}
                    {selectedOrderForVoucher.recipientNationalId && (
                      <p><span className="text-slate-500 font-normal">رقم الهوية:</span> <span className="font-mono">{selectedOrderForVoucher.recipientNationalId}</span></p>
                    )}
                  </div>
                </div>

                {/* Guarantor Box */}
                <div className="border border-slate-300 p-3.5 rounded-xl space-y-2 bg-slate-50/50">
                  <h3 className="text-xs font-black text-purple-900 border-r-4 border-purple-800 pr-2">
                    ثالثاً: بيانات الضمين / الكفيل العسكري
                  </h3>
                  <div className="text-xs space-y-1 font-sans font-bold text-slate-800">
                    <p><span className="text-slate-500 font-normal">اسم الضمين:</span> {selectedOrderForVoucher.guarantorName}</p>
                    <p><span className="text-slate-500 font-normal">الرقم العسكري:</span> <span className="font-mono">{selectedOrderForVoucher.guarantorMilitaryId}</span></p>
                    <p><span className="text-slate-500 font-normal">رتبة الضمين:</span> {selectedOrderForVoucher.guarantorRank}</p>
                    <p><span className="text-slate-500 font-normal">وحدة الضمين:</span> {selectedOrderForVoucher.guarantorUnit}</p>
                    {selectedOrderForVoucher.guarantorPhone && (
                      <p><span className="text-slate-500 font-normal">رقم الجوال:</span> <span className="font-mono">{selectedOrderForVoucher.guarantorPhone}</span></p>
                    )}
                    {selectedOrderForVoucher.guarantorNationalId && (
                      <p><span className="text-slate-500 font-normal">رقم الهوية:</span> <span className="font-mono">{selectedOrderForVoucher.guarantorNationalId}</span></p>
                    )}
                  </div>
                </div>
              </div>

              {/* Order Reason & Location */}
              <div className="border border-slate-300 p-3 rounded-xl bg-amber-50/50 text-xs font-sans space-y-1">
                <p><strong>مصدر ومصدر أمر الصرف:</strong> {selectedOrderForVoucher.orderSource}</p>
                <p><strong>سبب ومبرر الصرف:</strong> {selectedOrderForVoucher.dispenseReason}</p>
                {selectedOrderForVoucher.locationOrDestination && (
                  <p><strong>موقع/وجهة التسليم الميداني:</strong> {selectedOrderForVoucher.locationOrDestination}</p>
                )}
                {selectedOrderForVoucher.notes && (
                  <p><strong>ملاحظات وشروط:</strong> {selectedOrderForVoucher.notes}</p>
                )}
              </div>

              {/* Legal Military Undertaking */}
              <div className="border-2 border-slate-800 p-3.5 rounded-xl bg-slate-100 text-[11px] leading-relaxed font-sans font-bold text-slate-900 space-y-1">
                <p className="font-black text-xs text-amber-950 underline mb-1">تعهد وإقرار قانوني وعسكري بالاستلام والحفاظ على العهدة:</p>
                <p>
                  أُقرّ أنا المستلم المذكور أعلاه بأني استلمت الآلية / المعدة الموضحة بياناتها بهذا السند بحالة جيدة وسليمة للاستخدام، وأتعهد بالمسؤولية العسكرية والقانونية الكاملة عن حفظها وصيانتها وإعادتها فور طلب القيادة، كما يتعهد الضمين بالكفالة العسكرية والمالية التامة في حال التلف الناتج عن الإهمال أو الفقدان.
                </p>
              </div>

              {/* Signature Blocks */}
              <div className="pt-6 border-t-2 border-slate-900 grid grid-cols-4 gap-2 text-center text-xs font-bold text-slate-900 signature-block">
                <div className="space-y-2">
                  <p className="font-black">توقيع المستلم</p>
                  <p className="text-[10px] text-slate-600">{selectedOrderForVoucher.recipientName}</p>
                  <p className="text-slate-400 text-[10px] pt-4">التوقيع: ..................</p>
                </div>

                <div className="space-y-2">
                  <p className="font-black">توقيع الضمين</p>
                  <p className="text-[10px] text-slate-600">{selectedOrderForVoucher.guarantorName}</p>
                  <p className="text-slate-400 text-[10px] pt-4">التوقيع: ..................</p>
                </div>

                <div className="space-y-2">
                  <p className="font-black">ركن العربات والآليات</p>
                  <p className="text-[10px] text-slate-600">ضابط الركن المعتمد</p>
                  <p className="text-slate-400 text-[10px] pt-4">التوقيع: ..................</p>
                </div>

                <div className="space-y-2">
                  <p className="font-black">يعتمد قائد اللواء / القيادة</p>
                  <p className="text-[10px] text-slate-600">الختم والاعتماد الرسميان</p>
                  <p className="text-slate-400 text-[10px] pt-4">التوقيع والختم: ..................</p>
                </div>
              </div>

            </div>
          </div>
        </div>,
        document.body
      )}

      {/* Modal: Edit Vehicle Information */}
      <VehicleEditModal
        isOpen={isEditVehicleOpen}
        vehicle={editingVehicle}
        onClose={() => {
          setIsEditVehicleOpen(false);
          setEditingVehicle(null);
        }}
        onSaveSuccess={(updated) => {
          reloadData();
          if (selectedVehicleForCard?.id === updated.id) {
            setSelectedVehicleForCard(updated);
          }
        }}
        currentAccountName={currentAccountName}
      />

      {/* Modal: Add or Edit Vehicle Return Order to Central Branch */}
      <VehicleReturnClearanceModal
        isOpen={isAddReturnOpen}
        onClose={() => {
          setIsAddReturnOpen(false);
          setEditingReturnOrder(null);
          setReturnPreselectedVehicle(null);
        }}
        onSaveSuccess={() => {
          reloadData();
        }}
        activeVehicles={vehicles}
        preselectedVehicle={returnPreselectedVehicle}
        editingOrder={editingReturnOrder}
        currentAccountName={currentAccountName}
      />

      {/* Modal: View and Print Return Clearance Voucher */}
      <VehicleReturnVoucherModal
        order={selectedReturnForVoucher}
        onClose={() => setSelectedReturnForVoucher(null)}
      />
    </div>
  );
};
