import React, { useState, useEffect } from 'react';
import {
  X,
  Download,
  Upload,
  Database,
  RefreshCw,
  FileCheck,
  AlertTriangle,
  CheckCircle2,
  Users,
  Shield,
  Truck,
  DollarSign,
  Building2,
  HardDrive,
  Info,
  Clock,
  Layers,
  Sparkles,
  ArrowDownToLine,
  FileCode2,
  ArrowRightLeft
} from 'lucide-react';
import { StorageService } from '../lib/storage';
import { OrganizationTenant, SystemBackupPayload, BackupRestoreResult, UserAccount, RestoreBackupOptions } from '../types';

interface SystemBackupRestoreModalProps {
  isOpen: boolean;
  onClose: () => void;
  activeTenant: OrganizationTenant;
  currentAccount?: UserAccount;
  onRefreshData?: () => void;
  onSwitchAccount?: (accountId: string) => void;
}

export const SystemBackupRestoreModal: React.FC<SystemBackupRestoreModalProps> = ({
  isOpen,
  onClose,
  activeTenant,
  currentAccount,
  onRefreshData,
  onSwitchAccount
}) => {
  const [activeTab, setActiveTab] = useState<'export' | 'restore' | 'snapshots' | 'info'>('export');
  const [isExporting, setIsExporting] = useState(false);
  const [isRestoring, setIsRestoring] = useState(false);
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [parsedBackup, setParsedBackup] = useState<any | null>(null);
  const [fileError, setFileError] = useState<string | null>(null);
  const [feedback, setFeedback] = useState<{ type: 'success' | 'error' | 'info'; message: string; stats?: string } | null>(null);
  const [restoreMode, setRestoreMode] = useState<'replace' | 'merge'>('replace');
  const [reassignToCurrentAccount, setReassignToCurrentAccount] = useState<boolean>(true);
  const [isReassigningExisting, setIsReassigningExisting] = useState(false);
  const [deviceSnapshots, setDeviceSnapshots] = useState<any[]>([]);
  const [storageHealth, setStorageHealth] = useState<any>(null);
  const [isCreatingSnapshot, setIsCreatingSnapshot] = useState(false);
  const [isRestoringSnapshot, setIsRestoringSnapshot] = useState(false);

  // Live Counts for Export Tab
  const [liveCounts, setLiveCounts] = useState({
    personnel: 0,
    weapons: 0,
    inventory: 0,
    vehicles: 0,
    spareParts: 0,
    payroll: 0,
    grants: 0,
    tenants: 0,
    users: 0,
    storageUsedKB: 0
  });

  const loadDeviceSnapshots = async () => {
    try {
      const snaps = await StorageService.getDeviceSnapshots();
      setDeviceSnapshots(snaps);
      const health = await StorageService.getStorageHealthMetrics();
      setStorageHealth(health);
    } catch (e) {}
  };

  useEffect(() => {
    if (isOpen) {
      loadCurrentStats();
      loadDeviceSnapshots();
      setFeedback(null);
      setSelectedFile(null);
      setParsedBackup(null);
      setFileError(null);
    }
  }, [isOpen]);

  const loadCurrentStats = () => {
    try {
      const p = StorageService.getPersonnel();
      const w = StorageService.getArmoryWeapons();
      const inv = StorageService.getArmoryInventory();
      const v = StorageService.getVehicles();
      const sp = StorageService.getSpareParts();
      const pay = StorageService.getPayrollRecords();
      const gr = StorageService.getFinancialGrants();
      const t = StorageService.getTenants();
      const metrics = StorageService.getStorageMetrics();

      setLiveCounts({
        personnel: p.length,
        weapons: w.length,
        inventory: inv.length,
        vehicles: v.length,
        spareParts: sp.length,
        payroll: pay.length,
        grants: gr.length,
        tenants: t.length,
        users: t.reduce((acc, tenant) => acc + (StorageService.getTenantUsers(tenant.id)?.length || 0), 0),
        storageUsedKB: Math.round(metrics.totalUsedBytes / 1024)
      });
    } catch (e) {
      console.error('Error loading backup stats:', e);
    }
  };

  if (!isOpen) return null;

  // --- Export Full Backup ---
  const handleExportBackup = () => {
    setIsExporting(true);
    setFeedback(null);

    try {
      const backupData: SystemBackupPayload = StorageService.exportFullSystemBackup();
      const jsonStr = JSON.stringify(backupData, null, 2);
      const blob = new Blob([jsonStr], { type: 'application/json;charset=utf-8' });
      const url = URL.createObjectURL(blob);
      
      const dateStr = new Date().toISOString().slice(0, 10);
      const safeTenantCode = activeTenant?.code || 'hq';
      const accountBadge = currentAccount?.shortCode || 'all';
      const filename = `military_backup_${safeTenantCode}_${accountBadge}_${dateStr}.json`;

      const downloadAnchor = document.createElement('a');
      downloadAnchor.href = url;
      downloadAnchor.download = filename;
      document.body.appendChild(downloadAnchor);
      downloadAnchor.click();
      downloadAnchor.remove();
      URL.revokeObjectURL(url);

      setFeedback({
        type: 'success',
        message: 'تم تصدير وتنزيل ملف النسخة الاحتياطية بنجاح!',
        stats: `الملف يحتوي على ${backupData.summary.personnelCount} فرد، و${backupData.summary.armoryWeaponsCount} قطعة سلاح، و${backupData.summary.vehiclesCount} آلية، و${backupData.summary.payrollRecordsCount} مسير مالي.`
      });
    } catch (err: any) {
      setFeedback({
        type: 'error',
        message: `فشل تصدير النسخة الاحتياطية: ${err.message || err}`
      });
    } finally {
      setIsExporting(false);
    }
  };

  // --- Handle File Select for Restore ---
  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setFeedback(null);
    setFileError(null);
    setParsedBackup(null);

    const files = e.target.files;
    if (!files || files.length === 0) return;

    const file = files[0];
    if (!file.name.endsWith('.json')) {
      setFileError('يرجى اختيار ملف بامتداد (.json)');
      return;
    }

    setSelectedFile(file);

    const reader = new FileReader();
    reader.onload = (event) => {
      try {
        const content = event.target?.result as string;
        const parsed = JSON.parse(content);
        setParsedBackup(parsed);
      } catch (err) {
        setFileError('الملف المحدد تالف أو ليس بصيغة JSON صالحة.');
        setParsedBackup(null);
      }
    };
    reader.onerror = () => {
      setFileError('حدث خطأ أثناء قراءة الملف من الجهاز.');
    };
    reader.readAsText(file);
  };

  // --- Execute Restore ---
  const handleExecuteRestore = () => {
    if (!parsedBackup) return;

    const isSubBrigade = currentAccount && !currentAccount.isMainCommand;
    const confirmMsg =
      restoreMode === 'replace'
        ? `⚠️ تنبيه هام: سيتم استبدال البيانات الحالية بالبيانات الموجودة في ملف النسخة الاحتياطية${
            isSubBrigade && reassignToCurrentAccount
              ? ` وتعيين كافة السجلات لحساب (${currentAccount.name})`
              : ''
          }. هل ترغب بالتأكيد في المتابعة؟`
        : `سيتم دمج سجلات النسخة الاحتياطية مع السجلات الحالية لمنع التكرار والحفاظ على البيانات المضافة${
            isSubBrigade && reassignToCurrentAccount
              ? ` مع إسناد السجلات لـ (${currentAccount.name})`
              : ''
          }. هل ترغب بالمتابعة؟`;

    if (window.confirm(confirmMsg)) {
      setIsRestoring(true);
      setFeedback(null);

      setTimeout(() => {
        try {
          const restoreOptions: RestoreBackupOptions = {
            mode: restoreMode,
            targetAccountId: currentAccount?.id,
            targetUnitName: currentAccount?.unitFilter || currentAccount?.name,
            reassignToCurrentAccount: isSubBrigade ? reassignToCurrentAccount : false
          };

          const result: BackupRestoreResult = StorageService.restoreFullSystemBackup(parsedBackup, restoreOptions);
          if (result.success) {
            setFeedback({
              type: 'success',
              message: result.message,
              stats: result.restoredStats
            });
            setSelectedFile(null);
            setParsedBackup(null);
            loadCurrentStats();
            if (onRefreshData) onRefreshData();
          } else {
            setFeedback({
              type: 'error',
              message: result.message
            });
          }
        } catch (err: any) {
          setFeedback({
            type: 'error',
            message: `فشلت عملية الاستعادة: ${err.message || err}`
          });
        } finally {
          setIsRestoring(false);
        }
      }, 200);
    }
  };

  // --- Instant Reassign of Existing Database Records to Current Account ---
  const handleReassignExistingData = () => {
    if (!currentAccount || currentAccount.isMainCommand) return;

    const confirmMsg = `هل ترغب في تحويل وتعيين كافة الأفراد والأسلحة والآليات والمسيرات المخزنة حالياً (${liveCounts.personnel} فرد) لتتبع حساب (${currentAccount.name}) فوراً؟\n\nستظهر جميع السجلات والمرفقات فوراً في سجل القوة البشرية لهذا اللواء.`;

    if (window.confirm(confirmMsg)) {
      setIsReassigningExisting(true);
      try {
        const res = StorageService.reassignAllPersonnelToAccount(currentAccount.id, currentAccount.unitFilter);
        loadCurrentStats();
        if (onRefreshData) onRefreshData();
        setFeedback({
          type: 'success',
          message: `تم بنجاح تعيين ونقل كافة السجلات لقوة (${currentAccount.name})!`,
          stats: `تم تعيين (${res.updatedPersonnelCount}) فرد، و(${res.updatedWeaponsCount}) قطعة سلاح، و(${res.updatedVehiclesCount}) آلية، و(${res.updatedPayrollCount}) مسير مالي لحساب ${currentAccount.name}.`
        });
      } catch (err: any) {
        setFeedback({
          type: 'error',
          message: `حدث خطأ: ${err.message || err}`
        });
      } finally {
        setIsReassigningExisting(false);
      }
    }
  };

  // --- Snapshot Handlers ---
  const handleCreateInstantSnapshot = async () => {
    setIsCreatingSnapshot(true);
    try {
      const snapId = await StorageService.createDeviceSnapshotNow();
      if (snapId) {
        await loadDeviceSnapshots();
        setFeedback({
          type: 'success',
          message: 'تم حفظ نسخة احتياطية فورية بنجاح في الذاكرة الدائمة لهذا الجهاز (IndexedDB) 🛡️'
        });
      }
    } catch (e: any) {
      setFeedback({ type: 'error', message: `تعذر حفظ النسخة: ${e.message || e}` });
    } finally {
      setIsCreatingSnapshot(false);
    }
  };

  const handleRestoreFromSnapshot = async (snapshotId: string, summary: string) => {
    if (window.confirm(`هل ترغب بالتأكيد في استعادة هذه النسخة التلقائية (${summary}) المحفوظة في هذا الجهاز؟\nسيتم استرجاع كافة السجلات كما كانت وقت إنشاء النسخة.`)) {
      setIsRestoringSnapshot(true);
      try {
        const ok = await StorageService.restoreDeviceSnapshot(snapshotId);
        if (ok) {
          loadCurrentStats();
          await loadDeviceSnapshots();
          if (onRefreshData) onRefreshData();
          setFeedback({
            type: 'success',
            message: 'تمت استعادة البيانات بنجاح تام من الذاكرة المحلية للجهاز!'
          });
        } else {
          setFeedback({ type: 'error', message: 'تعذر استعادة النسخة التلقائية.' });
        }
      } catch (e: any) {
        setFeedback({ type: 'error', message: `خطأ أثناء الاستعادة: ${e.message || e}` });
      } finally {
        setIsRestoringSnapshot(false);
      }
    }
  };

  // Helper to extract preview statistics and detected brigade units from parsed backup
  const getBackupPreviewStats = (data: any) => {
    if (!data) return null;
    const target = data.data || data;
    const isArray = Array.isArray(data);
    const personnelList = isArray ? data : (target.personnel || []);

    // Detect unique brigade units in backup
    const detectedUnits = Array.from(
      new Set(
        personnelList
          .map((p: any) => (p?.unit || '').trim())
          .filter(Boolean)
      )
    );

    return {
      version: data.version || '1.0',
      timestamp: data.exportTimestamp ? new Date(data.exportTimestamp).toLocaleString('ar-EG') : 'غير محدد',
      systemName: data.systemName || 'منظومة القيادة المركزية',
      activeTenantName: data.activeTenantName || 'الفرقة الثالثة مشاة',
      personnel: personnelList.length,
      tenants: isArray ? 0 : (target.tenants?.length || 0),
      weapons: isArray ? 0 : (target.armoryWeapons?.length || 0),
      vehicles: isArray ? 0 : (target.vehicles?.length || 0),
      payroll: isArray ? 0 : (target.payrollRecords?.length || 0),
      grants: isArray ? 0 : (target.financialGrants?.length || 0),
      auditLogs: isArray ? 0 : (target.auditLogs?.length || 0),
      detectedUnits: detectedUnits.length > 0 ? (detectedUnits as string[]) : ['غير محدد في الملف'],
      users: target.tenantUsersMap
        ? Object.values(target.tenantUsersMap).reduce((acc: number, cur: any) => acc + (cur?.length || 0), 0)
        : (target.accounts?.length || 0)
    };
  };

  const previewStats = parsedBackup ? getBackupPreviewStats(parsedBackup) : null;
  const isSubBrigadeAccount = currentAccount && !currentAccount.isMainCommand;

  return (
    <div
      id="system-backup-restore-modal"
      className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-xs animate-in fade-in duration-200"
      dir="rtl"
    >
      <div className="bg-white rounded-3xl shadow-2xl border border-slate-200 max-w-3xl w-full overflow-hidden flex flex-col max-h-[92vh]">
        {/* Header */}
        <div className="bg-gradient-to-r from-slate-900 via-slate-850 to-slate-900 text-white p-6 border-b border-slate-800 relative">
          <button
            id="btn-close-backup-modal"
            onClick={onClose}
            className="absolute top-5 left-5 p-2 text-slate-400 hover:text-white bg-slate-800/80 hover:bg-slate-800 rounded-full transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>

          <div className="flex items-center space-x-3.5 space-x-reverse">
            <div className="p-3 bg-amber-500/20 text-amber-400 rounded-2xl border border-amber-500/30 shadow-inner">
              <Database className="w-7 h-7" />
            </div>
            <div>
              <div className="flex items-center space-x-2 space-x-reverse">
                <h2 className="text-xl font-black font-['Tajawal'] text-white">
                  مركز النسخ الاحتياطي واستعادة البيانات الموحد
                </h2>
                <span className="text-[11px] px-2.5 py-0.5 rounded-full bg-amber-500/20 text-amber-300 font-bold border border-amber-500/30">
                  v4.0 Military Zero-Loss
                </span>
              </div>
              <p className="text-xs text-slate-300 mt-1 font-medium">
                حفظ وأرشفة قاعدة البيانات بالكامل وتنزيلها بصيغة JSON مع إمكانية الاستعادة الفورية والدمج الذكي
              </p>
              {currentAccount && (
                <div className="mt-2 inline-flex items-center space-x-1.5 space-x-reverse px-2.5 py-1 rounded-lg bg-slate-800/80 border border-slate-700 text-amber-300 text-[11px] font-bold">
                  <span>الحساب النشط الحالي:</span>
                  <span className="text-white font-extrabold">{currentAccount.badge} {currentAccount.name}</span>
                </div>
              )}
            </div>
          </div>

          {/* Navigation Tabs */}
          <div className="flex items-center space-x-2 space-x-reverse mt-6 pt-2 border-t border-slate-800/80">
            <button
              id="tab-btn-export"
              onClick={() => {
                setActiveTab('export');
                setFeedback(null);
              }}
              className={`px-4 py-2 rounded-xl font-bold text-xs flex items-center space-x-2 space-x-reverse transition-all cursor-pointer ${
                activeTab === 'export'
                  ? 'bg-amber-500 text-slate-950 shadow-md font-extrabold'
                  : 'text-slate-300 hover:bg-slate-800/60 hover:text-white'
              }`}
            >
              <Download className="w-4 h-4" />
              <span>تصدير وحفظ نسخة احتياطية</span>
            </button>

            <button
              id="tab-btn-restore"
              onClick={() => {
                setActiveTab('restore');
                setFeedback(null);
              }}
              className={`px-4 py-2 rounded-xl font-bold text-xs flex items-center space-x-2 space-x-reverse transition-all cursor-pointer ${
                activeTab === 'restore'
                  ? 'bg-emerald-600 text-white shadow-md font-extrabold'
                  : 'text-slate-300 hover:bg-slate-800/60 hover:text-white'
              }`}
            >
              <Upload className="w-4 h-4" />
              <span>استعادة وإدخال نسخة احتياطية</span>
            </button>

            <button
              id="tab-btn-snapshots"
              onClick={() => {
                setActiveTab('snapshots');
                setFeedback(null);
                loadDeviceSnapshots();
              }}
              className={`px-4 py-2 rounded-xl font-bold text-xs flex items-center space-x-2 space-x-reverse transition-all cursor-pointer ${
                activeTab === 'snapshots'
                  ? 'bg-purple-600 text-white shadow-md font-extrabold'
                  : 'text-slate-300 hover:bg-slate-800/60 hover:text-white'
              }`}
            >
              <HardDrive className="w-4 h-4 text-purple-300" />
              <span>النسخ التلقائي بالجهاز ({deviceSnapshots.length}) 🛡️</span>
            </button>

            <button
              id="tab-btn-info"
              onClick={() => {
                setActiveTab('info');
                setFeedback(null);
              }}
              className={`px-4 py-2 rounded-xl font-bold text-xs flex items-center space-x-2 space-x-reverse transition-all cursor-pointer ${
                activeTab === 'info'
                  ? 'bg-blue-600 text-white shadow-md font-extrabold'
                  : 'text-slate-300 hover:bg-slate-800/60 hover:text-white'
              }`}
            >
              <Info className="w-4 h-4" />
              <span>دليل الأمان والتعليمات</span>
            </button>
          </div>
        </div>

        {/* Modal Body */}
        <div className="p-6 overflow-y-auto space-y-6 flex-1 bg-slate-50/50">
          {/* Feedback Banner */}
          {feedback && (
            <div
              className={`p-4 rounded-2xl border flex items-start space-x-3 space-x-reverse animate-in fade-in ${
                feedback.type === 'success'
                  ? 'bg-emerald-50 border-emerald-300 text-emerald-950'
                  : feedback.type === 'error'
                  ? 'bg-rose-50 border-rose-300 text-rose-950'
                  : 'bg-blue-50 border-blue-300 text-blue-950'
              }`}
            >
              {feedback.type === 'success' ? (
                <CheckCircle2 className="w-5 h-5 text-emerald-600 shrink-0 mt-0.5" />
              ) : feedback.type === 'error' ? (
                <AlertTriangle className="w-5 h-5 text-rose-600 shrink-0 mt-0.5" />
              ) : (
                <Info className="w-5 h-5 text-blue-600 shrink-0 mt-0.5" />
              )}
              <div className="flex-1">
                <div className="font-black text-xs leading-relaxed">{feedback.message}</div>
                {feedback.stats && (
                  <div className="text-[11px] text-slate-600 mt-1 font-medium bg-white/70 p-2 rounded-xl border border-slate-200/60">
                    {feedback.stats}
                  </div>
                )}
              </div>
            </div>
          )}

          {/* TAB 1: EXPORT */}
          {activeTab === 'export' && (
            <div className="space-y-6">
              {/* Summary Stats Card */}
              <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs space-y-4">
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-2 space-x-reverse text-slate-900 font-extrabold text-sm">
                    <HardDrive className="w-5 h-5 text-amber-600" />
                    <span>محتويات وحجم البيانات الجاهزة للتصدير والحفظ:</span>
                  </div>
                  <span className="text-xs px-3 py-1 bg-slate-100 text-slate-700 font-bold rounded-full border border-slate-200">
                    الحجم التقديري: ~{liveCounts.storageUsedKB} KB
                  </span>
                </div>

                <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                  <div className="p-3 bg-slate-50 border border-slate-200 rounded-xl flex items-center space-x-3 space-x-reverse">
                    <div className="p-2 bg-emerald-100 text-emerald-700 rounded-lg">
                      <Users className="w-5 h-5" />
                    </div>
                    <div>
                      <span className="text-[10px] text-slate-500 block font-bold">القوة البشرية</span>
                      <span className="text-sm font-black text-slate-800">{liveCounts.personnel} فرد</span>
                    </div>
                  </div>

                  <div className="p-3 bg-slate-50 border border-slate-200 rounded-xl flex items-center space-x-3 space-x-reverse">
                    <div className="p-2 bg-amber-100 text-amber-700 rounded-lg">
                      <Shield className="w-5 h-5" />
                    </div>
                    <div>
                      <span className="text-[10px] text-slate-500 block font-bold">الأسلحة والذخائر</span>
                      <span className="text-sm font-black text-slate-800">{liveCounts.weapons} قطعة</span>
                    </div>
                  </div>

                  <div className="p-3 bg-slate-50 border border-slate-200 rounded-xl flex items-center space-x-3 space-x-reverse">
                    <div className="p-2 bg-purple-100 text-purple-700 rounded-lg">
                      <Truck className="w-5 h-5" />
                    </div>
                    <div>
                      <span className="text-[10px] text-slate-500 block font-bold">الآليات والأسطول</span>
                      <span className="text-sm font-black text-slate-800">{liveCounts.vehicles} آلية</span>
                    </div>
                  </div>

                  <div className="p-3 bg-slate-50 border border-slate-200 rounded-xl flex items-center space-x-3 space-x-reverse">
                    <div className="p-2 bg-teal-100 text-teal-700 rounded-lg">
                      <DollarSign className="w-5 h-5" />
                    </div>
                    <div>
                      <span className="text-[10px] text-slate-500 block font-bold">المسيرات والمنح</span>
                      <span className="text-sm font-black text-slate-800">{liveCounts.payroll + liveCounts.grants} مسير/سجل</span>
                    </div>
                  </div>
                </div>

                <div className="p-3.5 bg-amber-50/70 border border-amber-200 rounded-xl text-xs text-amber-900 leading-relaxed flex items-start space-x-2.5 space-x-reverse">
                  <Sparkles className="w-5 h-5 text-amber-600 shrink-0 mt-0.5" />
                  <div>
                    <span className="font-extrabold block">ميزة التصدير الشامل (All-in-One Military HQ):</span>
                    تتضمن النسخة المحفوظة جميع التشكيلات العسكرية، حسابات الصلاحيات، سجلات الحركات، تدقيق العمليات، والملفات والمرفقات الخاصة بالأفراد في ملف JSON مشفر ومنظم يسهل نقله بين الأجهزة واستعادته في أي وقت بدون اتصال بالإنترنت.
                  </div>
                </div>
              </div>

              {/* Action Button */}
              <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs flex flex-col sm:flex-row items-center justify-between gap-4">
                <div>
                  <h4 className="font-black text-sm text-slate-900">تنزيل النسخة الاحتياطية لجهازك</h4>
                  <p className="text-xs text-slate-500 mt-0.5">الملف جاهز للتخزين على قرص صلب أو فلاش ديسك خارجي</p>
                </div>

                <button
                  id="btn-export-backup-action"
                  type="button"
                  disabled={isExporting}
                  onClick={handleExportBackup}
                  className="w-full sm:w-auto px-6 py-3 bg-amber-500 hover:bg-amber-400 text-slate-950 font-black text-xs rounded-xl shadow-md transition-all flex items-center justify-center space-x-2 space-x-reverse cursor-pointer disabled:opacity-50"
                >
                  {isExporting ? (
                    <>
                      <RefreshCw className="w-4 h-4 animate-spin" />
                      <span>جاري التجهيز والحفظ...</span>
                    </>
                  ) : (
                    <>
                      <Download className="w-4 h-4" />
                      <span>حفظ واستخراج النسخة الاحتياطية الآن (.JSON) 💾</span>
                    </>
                  )}
                </button>
              </div>
            </div>
          )}

          {/* TAB 2: RESTORE */}
          {activeTab === 'restore' && (
            <div className="space-y-6">
              {/* File Upload Box */}
              <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs space-y-4">
                <div className="flex items-center space-x-2 space-x-reverse text-slate-900 font-extrabold text-sm">
                  <Upload className="w-5 h-5 text-emerald-600" />
                  <span>تحديد ملف النسخة الاحتياطية (.JSON):</span>
                </div>

                <div className="border-2 border-dashed border-slate-300 hover:border-emerald-500 bg-slate-50/50 hover:bg-emerald-50/20 p-8 rounded-2xl text-center transition-all cursor-pointer group">
                  <input
                    type="file"
                    accept=".json"
                    onChange={handleFileChange}
                    className="hidden"
                    id="system-restore-file-input"
                  />
                  <label htmlFor="system-restore-file-input" className="cursor-pointer block space-y-3">
                    <div className="w-14 h-14 bg-emerald-100 text-emerald-700 rounded-2xl flex items-center justify-center mx-auto group-hover:scale-110 transition-transform shadow-xs">
                      <FileCode2 className="w-7 h-7" />
                    </div>
                    <div>
                      <span className="block font-black text-sm text-slate-800">
                        {selectedFile ? `الملف المحدد: ${selectedFile.name}` : 'انقر هنا أو اسحب ملف النسخة الاحتياطية (JSON)'}
                      </span>
                      <span className="block text-xs text-slate-500 mt-1">
                        يدعم جميع إصدارات النسخ الاحتياطية لمنظومة القيادة العسكرية
                      </span>
                    </div>
                  </label>
                </div>

                {fileError && (
                  <div className="p-3 bg-rose-50 border border-rose-200 rounded-xl text-xs font-bold text-rose-800 flex items-center space-x-2 space-x-reverse">
                    <AlertTriangle className="w-4 h-4 text-rose-600 shrink-0" />
                    <span>{fileError}</span>
                  </div>
                )}
              </div>

              {/* Inspection Preview */}
              {previewStats && (
                <div className="bg-white p-5 rounded-2xl border border-emerald-300 shadow-sm space-y-4 animate-in fade-in">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-2 space-x-reverse text-emerald-900 font-extrabold text-sm">
                      <FileCheck className="w-5 h-5 text-emerald-600" />
                      <span>تقرير فحص محتويات ملف النسخة الاحتياطية:</span>
                    </div>
                    <span className="text-[11px] px-2.5 py-0.5 rounded-full bg-emerald-100 text-emerald-800 font-black">
                      تم التحقق من سلامة الملف ✅
                    </span>
                  </div>

                  <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5">
                    <div className="bg-slate-50 p-2.5 rounded-xl border border-slate-200">
                      <span className="text-[10px] text-slate-400 block font-bold">القوة البشرية</span>
                      <span className="text-xs font-black text-emerald-700">{previewStats.personnel} فرد</span>
                    </div>

                    <div className="bg-slate-50 p-2.5 rounded-xl border border-slate-200">
                      <span className="text-[10px] text-slate-400 block font-bold">قطع الأسلحة</span>
                      <span className="text-xs font-black text-amber-700">{previewStats.weapons} قطعة</span>
                    </div>

                    <div className="bg-slate-50 p-2.5 rounded-xl border border-slate-200">
                      <span className="text-[10px] text-slate-400 block font-bold">الآليات</span>
                      <span className="text-xs font-black text-purple-700">{previewStats.vehicles} آلية</span>
                    </div>

                    <div className="bg-slate-50 p-2.5 rounded-xl border border-slate-200">
                      <span className="text-[10px] text-slate-400 block font-bold">المسيرات المالية</span>
                      <span className="text-xs font-black text-teal-700">{previewStats.payroll} مسير</span>
                    </div>

                    <div className="bg-slate-50 p-2.5 rounded-xl border border-slate-200">
                      <span className="text-[10px] text-slate-400 block font-bold">المؤسسات والتشكيلات</span>
                      <span className="text-xs font-black text-blue-700">{previewStats.tenants} تشكيل</span>
                    </div>

                    <div className="bg-slate-50 p-2.5 rounded-xl border border-slate-200">
                      <span className="text-[10px] text-slate-400 block font-bold">المستخدمين</span>
                      <span className="text-xs font-black text-slate-700">{previewStats.users} مستخدم</span>
                    </div>

                    <div className="bg-slate-50 p-2.5 rounded-xl border border-slate-200 col-span-2">
                      <span className="text-[10px] text-slate-400 block font-bold">تاريخ إنشاء النسخة</span>
                      <span className="text-xs font-bold text-slate-600">{previewStats.timestamp}</span>
                    </div>
                  </div>

                  {/* Detected Origin Brigades */}
                  <div className="p-3 bg-slate-50 rounded-xl border border-slate-200 text-xs flex items-center justify-between">
                    <span className="text-slate-500 font-bold">الوحدات والألوية المكتشفة في الملف:</span>
                    <span className="font-extrabold text-slate-900 bg-white px-2 py-1 rounded-lg border border-slate-200">
                      {previewStats.detectedUnits.join(' ، ')}
                    </span>
                  </div>

                  {/* Account / Brigade Mapping Option */}
                  {isSubBrigadeAccount && (
                    <div className="p-4 bg-amber-50/90 border-2 border-amber-300 rounded-2xl space-y-3">
                      <div className="flex items-center space-x-2 space-x-reverse text-amber-900 font-black text-xs">
                        <AlertTriangle className="w-4 h-4 text-amber-600 shrink-0" />
                        <span>تخصيص انتماء السجلات (أنت مسجل بحساب: {currentAccount.name}):</span>
                      </div>
                      <p className="text-[11px] text-amber-900/90 leading-relaxed font-medium">
                        الملف يحتوي على بيانات أفراد. حدد كيفية التعامل مع انتماء الأفراد والآليات والمرفقات عند الاستيراد:
                      </p>
                      <div className="space-y-2">
                        <label className={`flex items-start space-x-2.5 space-x-reverse p-3 rounded-xl border cursor-pointer transition-all ${
                          reassignToCurrentAccount
                            ? 'bg-white border-amber-500 ring-2 ring-amber-400/30 shadow-xs'
                            : 'bg-amber-100/50 border-amber-200 hover:bg-white'
                        }`}>
                          <input
                            type="radio"
                            name="reassignAccountOption"
                            checked={reassignToCurrentAccount}
                            onChange={() => setReassignToCurrentAccount(true)}
                            className="mt-0.5 text-amber-600 focus:ring-amber-500"
                          />
                          <div>
                            <span className="font-black text-xs text-slate-900 block">
                              🎯 تعيين وتحويل كافة السجلات لحساب اللواء الحالي ({currentAccount.name})
                            </span>
                            <span className="text-[10px] text-emerald-800 font-bold block mt-0.5">
                              (موصى به) لتظهر فوراً في سجل القوة البشرية، المرفقات، والآليات التابعة لـ ({currentAccount.name}).
                            </span>
                          </div>
                        </label>

                        <label className={`flex items-start space-x-2.5 space-x-reverse p-3 rounded-xl border cursor-pointer transition-all ${
                          !reassignToCurrentAccount
                            ? 'bg-white border-slate-500 ring-2 ring-slate-400/30 shadow-xs'
                            : 'bg-amber-100/50 border-amber-200 hover:bg-white'
                        }`}>
                          <input
                            type="radio"
                            name="reassignAccountOption"
                            checked={!reassignToCurrentAccount}
                            onChange={() => setReassignToCurrentAccount(false)}
                            className="mt-0.5 text-slate-600 focus:ring-slate-500"
                          />
                          <div>
                            <span className="font-black text-xs text-slate-900 block">
                              🏢 الاحتفاظ بانتماء الألوية الأصلي الوارد في الملف ({previewStats.detectedUnits[0] || 'الأصلية'})
                            </span>
                            <span className="text-[10px] text-slate-500 block mt-0.5">
                              ستظل السجلات مرتبطة بلوائها الأصلي، ويمكنك مشاهدتها بالتبديل إلى حساب ذلك اللواء أو حساب القيادة المركزية.
                            </span>
                          </div>
                        </label>
                      </div>
                    </div>
                  )}

                  {/* Restore Options */}
                  <div className="pt-2 border-t border-slate-100 space-y-3">
                    <div className="text-xs font-black text-slate-800">اختر طريقة الاستعادة:</div>
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                      <label
                        className={`p-3 rounded-xl border cursor-pointer flex items-start space-x-2.5 space-x-reverse transition-all ${
                          restoreMode === 'replace'
                            ? 'bg-emerald-50/80 border-emerald-500 shadow-xs'
                            : 'bg-slate-50 border-slate-200 hover:bg-slate-100'
                        }`}
                      >
                        <input
                          type="radio"
                          name="restoreMode"
                          value="replace"
                          checked={restoreMode === 'replace'}
                          onChange={() => setRestoreMode('replace')}
                          className="mt-1 text-emerald-600 focus:ring-emerald-500"
                        />
                        <div>
                          <span className="font-black text-xs text-slate-900 block">
                            استعادة شاملة واستبدال (Full Clean Restore)
                          </span>
                          <span className="text-[11px] text-slate-500 block mt-0.5">
                            يستبدل بيانات المنظومة الحالية بالكامل ببيانات النسخة المرفوعة (الموصى به عند الانتقال لجهاز جديد).
                          </span>
                        </div>
                      </label>

                      <label
                        className={`p-3 rounded-xl border cursor-pointer flex items-start space-x-2.5 space-x-reverse transition-all ${
                          restoreMode === 'merge'
                            ? 'bg-blue-50/80 border-blue-500 shadow-xs'
                            : 'bg-slate-50 border-slate-200 hover:bg-slate-100'
                        }`}
                      >
                        <input
                          type="radio"
                          name="restoreMode"
                          value="merge"
                          checked={restoreMode === 'merge'}
                          onChange={() => setRestoreMode('merge')}
                          className="mt-1 text-blue-600 focus:ring-blue-500"
                        />
                        <div>
                          <span className="font-black text-xs text-slate-900 block">
                            دمج ذكي (Smart Merge)
                          </span>
                          <span className="text-[11px] text-slate-500 block mt-0.5">
                            يدمج السجلات ويحدث البيانات الحالية مع الاحتفاظ بأي أفراد أو أسلحة مضافة حديثاً.
                          </span>
                        </div>
                      </label>
                    </div>
                  </div>

                  {/* Execute Button */}
                  <div className="pt-3 flex items-center space-x-3 space-x-reverse">
                    <button
                      id="btn-execute-restore-action"
                      type="button"
                      disabled={isRestoring}
                      onClick={handleExecuteRestore}
                      className="px-6 py-3 bg-emerald-600 hover:bg-emerald-500 text-white font-black text-xs rounded-xl shadow-md transition-all flex items-center space-x-2 space-x-reverse cursor-pointer disabled:opacity-50"
                    >
                      {isRestoring ? (
                        <>
                          <RefreshCw className="w-4 h-4 animate-spin" />
                          <span>جاري معالجة واستعادة السجلات...</span>
                        </>
                      ) : (
                        <>
                          <RefreshCw className="w-4 h-4" />
                          <span>تنفيذ الاستعادة وتحديث المنظومة الآن 🔄</span>
                        </>
                      )}
                    </button>

                    <button
                      type="button"
                      onClick={() => {
                        setSelectedFile(null);
                        setParsedBackup(null);
                      }}
                      className="px-4 py-3 bg-slate-200 hover:bg-slate-300 text-slate-700 font-bold text-xs rounded-xl cursor-pointer"
                    >
                      إلغاء
                    </button>
                  </div>
                </div>
              )}

              {/* Quick Fix / Reassign Existing Stored Data */}
              {isSubBrigadeAccount && liveCounts.personnel > 0 && (
                <div className="bg-slate-100 p-4 rounded-2xl border border-slate-300/80 flex flex-col sm:flex-row items-center justify-between gap-3 text-xs">
                  <div>
                    <span className="font-black text-slate-900 block">
                      هل قمت بإدخال نسخة سابقة ولا تظهر السجلات في ({currentAccount.name})؟
                    </span>
                    <span className="text-slate-600 text-[11px] block mt-0.5">
                      توجد حالياً ({liveCounts.personnel} فرد) في المنظومة. يمكنك نقلها وتعيينها فوراً لقوة هذا الحساب.
                    </span>
                  </div>
                  <button
                    type="button"
                    disabled={isReassigningExisting}
                    onClick={handleReassignExistingData}
                    className="shrink-0 px-4 py-2.5 bg-slate-900 hover:bg-slate-800 text-amber-300 font-black text-xs rounded-xl transition-all flex items-center space-x-1.5 space-x-reverse cursor-pointer shadow-xs disabled:opacity-50"
                  >
                    <ArrowRightLeft className="w-3.5 h-3.5" />
                    <span>{isReassigningExisting ? 'جاري التعيين...' : `تعيين السجلات لـ (${currentAccount.name}) ⚡`}</span>
                  </button>
                </div>
              )}
            </div>
          )}

          {/* TAB: ON-DEVICE AUTOMATIC SNAPSHOTS (Zero Data Loss) */}
          {activeTab === 'snapshots' && (
            <div className="space-y-5">
              {/* Storage Health & Persistence Status Box */}
              <div className="bg-gradient-to-r from-purple-900 to-indigo-950 p-5 rounded-2xl text-white shadow-md border border-purple-800">
                <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
                  <div className="space-y-1">
                    <div className="flex items-center space-x-2 space-x-reverse">
                      <HardDrive className="w-5 h-5 text-purple-400" />
                      <span className="font-black text-sm">حالة التخزين والذاكرة الدائمة في هذا الجهاز (IndexedDB v3)</span>
                      <span className="px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 text-[10px] font-extrabold border border-emerald-500/40">
                        محمي ضد الإلغاء والتحديث
                      </span>
                    </div>
                    <p className="text-xs text-purple-200">
                      يتم حفظ البيانات تلقائياً على القرص الصلب/ذاكرة الجهاز المحلية مع نسخ متدحرجة لحمايتك من فقدان أي بيانات أثناء تحديث التطبيق أو المتصفح.
                    </p>
                  </div>

                  <button
                    type="button"
                    disabled={isCreatingSnapshot}
                    onClick={handleCreateInstantSnapshot}
                    className="shrink-0 px-4 py-2 bg-gradient-to-r from-purple-500 to-indigo-500 hover:from-purple-400 hover:to-indigo-400 text-white font-extrabold text-xs rounded-xl shadow-md transition-all flex items-center space-x-2 space-x-reverse cursor-pointer disabled:opacity-50"
                  >
                    <Sparkles className="w-4 h-4 text-amber-300" />
                    <span>{isCreatingSnapshot ? 'جاري الحفظ...' : 'إنشاء نسخة فورية بالجهاز الآن 🛡️'}</span>
                  </button>
                </div>

                {storageHealth && (
                  <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5 mt-4 pt-3 border-t border-purple-800/80 text-[11px]">
                    <div className="bg-purple-950/60 p-2 rounded-xl">
                      <span className="text-purple-300 block">التخزين المستديم (Browser Persist):</span>
                      <span className="font-extrabold text-emerald-300">
                        {storageHealth.persisted ? 'مفعل ومؤمّن 100% ✅' : 'نشط (IndexedDB)'}
                      </span>
                    </div>
                    <div className="bg-purple-950/60 p-2 rounded-xl">
                      <span className="text-purple-300 block">المساحة المتوفرة على القرص:</span>
                      <span className="font-extrabold text-white">{storageHealth.quotaGB} جيجابايت</span>
                    </div>
                    <div className="bg-purple-950/60 p-2 rounded-xl">
                      <span className="text-purple-300 block">عدد النسخ التلقائية المحفوظة:</span>
                      <span className="font-extrabold text-amber-300">{storageHealth.hasSnapshots} نسخ متدحرجة</span>
                    </div>
                    <div className="bg-purple-950/60 p-2 rounded-xl">
                      <span className="text-purple-300 block">آخر فحص / حفظ بالجهاز:</span>
                      <span className="font-mono font-bold text-slate-200">
                        {storageHealth.lastSavedAt ? new Date(storageHealth.lastSavedAt).toLocaleTimeString('ar-SA') : 'الآن'}
                      </span>
                    </div>
                  </div>
                )}
              </div>

              {/* Snapshots List */}
              <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs space-y-4">
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-2 space-x-reverse font-extrabold text-slate-900 text-sm">
                    <Clock className="w-4 h-4 text-purple-600" />
                    <span>سجل النسخ الاحتياطية التلقائية المحفوظة في هذا الجهاز:</span>
                  </div>
                  <span className="text-xs text-slate-500 font-bold">
                    إجمالي النسخ: {deviceSnapshots.length}
                  </span>
                </div>

                {deviceSnapshots.length === 0 ? (
                  <div className="p-8 text-center bg-slate-50 rounded-2xl border border-dashed border-slate-200 text-slate-500 text-xs">
                    <HardDrive className="w-10 h-10 mx-auto text-slate-300 mb-2" />
                    <p className="font-bold text-slate-700">لم يتم تسجيل نسخ تلقائية بعد في ذاكرة هذا الجهاز.</p>
                    <p className="mt-1 text-slate-500">
                      يقوم النظام بأخذ نسخة تلقائية دورية عند أي تعديل، أو يمكنك الضغط على "إنشاء نسخة فورية بالجهاز الآن".
                    </p>
                  </div>
                ) : (
                  <div className="space-y-3">
                    {deviceSnapshots.map((snap, idx) => (
                      <div
                        key={snap.id}
                        className="p-4 rounded-xl border border-slate-200 bg-slate-50 hover:bg-white hover:border-purple-300 transition-all flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3"
                      >
                        <div className="space-y-1">
                          <div className="flex items-center space-x-2 space-x-reverse">
                            <span className="font-black text-slate-900 text-xs font-mono">
                              {new Date(snap.timestamp).toLocaleString('ar-SA')}
                            </span>
                            {idx === 0 && (
                              <span className="px-2 py-0.5 rounded-full bg-emerald-100 text-emerald-800 text-[10px] font-black">
                                أحدث نسخة محفوظة 🌟
                              </span>
                            )}
                          </div>
                          <p className="text-xs text-slate-600 font-medium">
                            ملخص السجلات: {snap.countSummary || 'كامل السجلات العسكرية والمالية والجاهزية'}
                          </p>
                        </div>

                        <button
                          type="button"
                          disabled={isRestoringSnapshot}
                          onClick={() => handleRestoreFromSnapshot(snap.id, snap.countSummary)}
                          className="px-4 py-2 bg-purple-600 hover:bg-purple-700 text-white font-extrabold text-xs rounded-xl shadow-xs transition-all flex items-center space-x-1.5 space-x-reverse cursor-pointer disabled:opacity-50 shrink-0"
                        >
                          <RefreshCw className="w-3.5 h-3.5" />
                          <span>استعادة فورية من هذه النسخة 🔄</span>
                        </button>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            </div>
          )}

          {/* TAB 3: INFO & SECURITY */}
          {activeTab === 'info' && (
            <div className="space-y-4">
              <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs space-y-4 text-xs text-slate-700 leading-relaxed">
                <div className="flex items-center space-x-2 space-x-reverse text-slate-900 font-extrabold text-sm">
                  <Shield className="w-5 h-5 text-blue-600" />
                  <span>ضوابط وإجراءات الأمان وحفظ النسخ الاحتياطية:</span>
                </div>

                <div className="space-y-3">
                  <div className="p-3 bg-slate-50 rounded-xl border border-slate-200">
                    <span className="font-black text-slate-900 block mb-1">1. التخزين المحلي المشفر (Local Persistence):</span>
                    تعتمد المنظومة تقنية Zero Data Loss متعددة المستويات (Memory Cache + IndexedDB + LocalStorage Chunks)، مما يضمن عدم ضياع البيانات حتى عند إغلاق المتصفح أو انقطاع التيار الكهربائي.
                  </div>

                  <div className="p-3 bg-slate-50 rounded-xl border border-slate-200">
                    <span className="font-black text-slate-900 block mb-1">2. انتقال البيانات بين حسابات الألوية:</span>
                    عند استخراج نسخة احتياطية من لواء وإدخالها في حساب لواء آخر، يوفر النظام خيار التعيين الذكي لنقل سجلات القوة البشرية، المرفقات، والأسلحة لتتبع الحساب الجديد مباشرة، أو الاحتفاظ بتبعيتها الأصلية.
                  </div>

                  <div className="p-3 bg-slate-50 rounded-xl border border-slate-200">
                    <span className="font-black text-slate-900 block mb-1">3. شمولية المرفقات والملفات:</span>
                    تتضمن النسخة الاحتياطية كافة الملفات المستندية، قرارات التعيين، التعهدات، الصور الشخصية، وسجلات الحركات والتدقيق بالكامل دون فقدان أي سجل.
                  </div>
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Modal Footer */}
        <div className="p-4 bg-white border-t border-slate-200 flex items-center justify-between text-xs text-slate-500">
          <div className="flex items-center space-x-2 space-x-reverse">
            <Shield className="w-4 h-4 text-amber-500" />
            <span>نظام الحفظ العسكري المشفر - جميع الحقوق محفوظة لقيادة الفرقة</span>
          </div>
          <button
            onClick={onClose}
            className="px-5 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold rounded-xl transition-colors cursor-pointer"
          >
            إغلاق
          </button>
        </div>
      </div>
    </div>
  );
};
