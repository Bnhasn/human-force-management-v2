import React, { useEffect, useRef, useState } from 'react';
import { createPortal } from 'react-dom';
import { QRCodeSVG } from 'qrcode.react';
import { X, Printer, Shield, FileText, CheckCircle2, DollarSign, Calendar, Building2, User, Landmark, Sparkles, Share2 } from 'lucide-react';
import { PayrollMonthlyRecord, PayrollMonthBatch } from '../types';
import { getCurrentHeaderInfo } from '../lib/headerUtils';
import {
  preparePrintableDocument,
  executeUnifiedPrint,
  shareOrSavePrintableDocument
} from '../lib/unifiedPrintService';

interface PayrollPrintReportModalProps {
  isOpen: boolean;
  onClose: () => void;
  batch: PayrollMonthBatch | null;
  records: PayrollMonthlyRecord[];
  unitFilter?: string;
  selectedIndividualRecord?: PayrollMonthlyRecord | null;
}

export const PayrollPrintReportModal: React.FC<PayrollPrintReportModalProps> = ({
  isOpen,
  onClose,
  batch,
  records,
  unitFilter,
  selectedIndividualRecord
}) => {
  const printableRef = useRef<HTMLDivElement>(null);
  const [isDocumentReady, setIsDocumentReady] = useState(false);

  // Prepare document resources (fonts, layout) for Android, Windows and Web print
  useEffect(() => {
    if (!isOpen) return;
    setIsDocumentReady(false);
    let isCancelled = false;

    preparePrintableDocument(printableRef.current).then(() => {
      if (!isCancelled) {
        setIsDocumentReady(true);
      }
    });

    return () => {
      isCancelled = true;
    };
  }, [isOpen, selectedIndividualRecord, records, unitFilter]);

  // Manage printing body classes to guarantee 100% isolation of background app/tables during print
  useEffect(() => {
    if (!isOpen) return;

    document.body.classList.add('is-printing-modal');
    document.body.setAttribute('data-printing-modal', 'true');

    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        onClose();
      } else if ((e.ctrlKey || e.metaKey) && e.key === 'p') {
        e.preventDefault();
        handlePrint();
      }
    };

    window.addEventListener('keydown', handleKeyDown);

    return () => {
      document.body.classList.remove('is-printing-modal');
      document.body.removeAttribute('data-printing-modal');
      window.removeEventListener('keydown', handleKeyDown);
    };
  }, [isOpen, onClose]);

  if (!isOpen) return null;

  const handlePrint = async () => {
    await executeUnifiedPrint(printableRef.current, {
      documentTitle: selectedIndividualRecord
        ? `قسيمة_راتب_${selectedIndividualRecord.militaryId}_${selectedIndividualRecord.fullName}`
        : `مسير_مرتبات_${batch?.monthYear || 'عام'}`,
      orientation: selectedIndividualRecord ? 'portrait' : 'landscape'
    });
  };

  const handleSharePdf = async () => {
    const title = selectedIndividualRecord
      ? `قسيمة راتب ${selectedIndividualRecord.rank} ${selectedIndividualRecord.fullName}`
      : `كشف مسير مرتبات القوة شهر ${batch?.monthYear || ''}`;
    const filename = selectedIndividualRecord
      ? `قسيمة_راتب_${selectedIndividualRecord.militaryId}.html`
      : `مسير_مرتبات_${batch?.monthYear || 'عام'}.html`;

    await shareOrSavePrintableDocument(printableRef.current, {
      title,
      filename,
      orientation: selectedIndividualRecord ? 'portrait' : 'landscape'
    });
  };

  const filteredRecords = unitFilter && unitFilter !== 'الكل'
    ? records.filter((r) => r.unit === unitFilter)
    : records;

  const displayRecords = selectedIndividualRecord ? [selectedIndividualRecord] : filteredRecords;

  const totalBasic = displayRecords.reduce((acc, r) => acc + (r.basicSalary || 0), 0);
  const totalAllowances = displayRecords.reduce((acc, r) => acc + (r.totalAllowances || 0), 0);
  const totalDeductions = displayRecords.reduce((acc, r) => acc + (r.totalDeductions || 0), 0);
  const totalNet = displayRecords.reduce((acc, r) => acc + (r.netSalary || 0), 0);

  const monthTitle = batch?.monthYear || new Date().toISOString().slice(0, 7);
  const currentDateFormatted = new Date().toLocaleDateString('ar-YE', {
    year: 'numeric',
    month: 'long',
    day: 'numeric'
  });
  const refCode = `FIN-PAY-${monthTitle.replace('-', '')}-${selectedIndividualRecord ? selectedIndividualRecord.militaryId : 'ALL'}`;

  // QR Code Payload for Instant Mobile/Tablet Verification
  const qrPayload = selectedIndividualRecord
    ? `
سند صرف مالي وقسيمة راتب عسكري
--------------------------------
الرقم المرجعي: ${refCode}
الفرد: ${selectedIndividualRecord.rank} / ${selectedIndividualRecord.fullName}
الرقم العسكري: ${selectedIndividualRecord.militaryId}
الوحدة: ${selectedIndividualRecord.unit}
الشهر المستحق: ${monthTitle}
الراتب الأساسي: ${selectedIndividualRecord.basicSalary.toLocaleString('ar-SA')} ر.س
إجمالي البدلات: +${selectedIndividualRecord.totalAllowances.toLocaleString('ar-SA')} ر.س
إجمالي الخصميات: -${selectedIndividualRecord.totalDeductions.toLocaleString('ar-SA')} ر.س
الصافي المعتمد للصرف: ${selectedIndividualRecord.netSalary.toLocaleString('ar-SA')} ر.س
جهة الصرف / البنك: ${selectedIndividualRecord.bankName || 'الصرف النقدي / الخزينة'}
حالة الصرف: ${selectedIndividualRecord.status}
تاريخ الطباعة: ${new Date().toISOString()}
`.trim()
    : `
كشف مسير مرتبات القوة العسكرية
--------------------------------
الشهر: ${monthTitle}
الوحدة: ${unitFilter || 'جميع الوحدات'}
إجمالي القوة: ${displayRecords.length} فرد
إجمالي صافي الصرف: ${totalNet.toLocaleString('ar-SA')} ر.س
حالة المسير: ${batch?.status || 'معتمد للصرف'}
`.trim();

  const modalContent = (
    <div className="fixed inset-0 z-[99999] flex items-center justify-center p-2 sm:p-4 bg-slate-950/90 backdrop-blur-md overflow-hidden printable-modal-overlay font-['Cairo',sans-serif] print:p-0 print:bg-white print:static print:block">
      
      {/* Screen Container Card */}
      <div className="bg-white rounded-3xl max-w-5xl w-full shadow-2xl overflow-hidden my-2 sm:my-4 border border-slate-300 printable-modal-card print:max-h-none print:h-auto print:border-none print:shadow-none print:rounded-none print:max-w-none print:w-full print:p-0 print:m-0 print:bg-white print:text-black flex flex-col max-h-[96vh]">
        
        {/* Top Control Bar (Hidden during Print) */}
        <div className="bg-slate-950 text-white p-4 flex flex-wrap items-center justify-between gap-3 border-b-2 border-teal-500/80 shadow-md shrink-0 print:hidden no-print">
          <div className="flex items-center space-x-3 space-x-reverse">
            <div className="w-10 h-10 rounded-xl bg-teal-500/20 border border-teal-400/50 flex items-center justify-center text-teal-300">
              <Printer className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-extrabold text-sm sm:text-base text-white font-['Tajawal'] flex items-center gap-2">
                <span>{selectedIndividualRecord ? 'سند صرف مالي وقسيمة راتب رسمية' : `كشف مسير مرتبات القوة - شهر (${monthTitle})`}</span>
                <span className="font-mono text-xs bg-teal-500/20 text-teal-300 border border-teal-500/40 px-2 py-0.5 rounded-md">
                  {refCode}
                </span>
              </h3>
              <p className="text-xs text-slate-300">
                جاهز للطباعة والتصدير الورقي المعتمد بصيغة رسمية معزولة وخالية من أي تداخل
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            {/* Document readiness indicator */}
            <div className={`hidden sm:flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-bold border transition-colors ${
              isDocumentReady
                ? 'bg-emerald-950/60 text-emerald-300 border-emerald-500/40'
                : 'bg-amber-950/60 text-amber-300 border-amber-500/40 animate-pulse'
            }`}>
              <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
              <span>{isDocumentReady ? 'المستند جاهز للطباعة' : 'جاري تجهيز الخطوط...'}</span>
            </div>

            <button
              onClick={handlePrint}
              type="button"
              className="px-4 sm:px-5 py-2 bg-teal-600 hover:bg-teal-500 active:scale-95 text-white rounded-xl text-xs font-black transition-all shadow-lg flex items-center space-x-2 space-x-reverse cursor-pointer"
            >
              <Printer className="w-4 h-4" />
              <span>طباعة المستند فوراً 🖨️</span>
            </button>

            <button
              onClick={handleSharePdf}
              type="button"
              className="px-3.5 py-2 bg-sky-600 hover:bg-sky-500 active:scale-95 text-white rounded-xl text-xs font-bold transition-all shadow-md flex items-center space-x-1.5 space-x-reverse cursor-pointer"
              title="مشاركة أو حفظ التقرير بصيغة PDF / ملف رسمي لكافة الأجهزة"
            >
              <Share2 className="w-4 h-4" />
              <span>مشاركة / حفظ PDF 📄</span>
            </button>

            <button
              onClick={onClose}
              type="button"
              className="p-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white transition-colors cursor-pointer"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Printable Official Document Body */}
        <div
          ref={printableRef}
          id="payroll-printable-area"
          data-printable-content="true"
          className="overflow-y-auto p-6 sm:p-8 space-y-6 text-right bg-white text-slate-900 font-['Cairo',sans-serif] print:overflow-visible print:p-2 print:max-h-none print:space-y-4"
        >
          
          {/* Header Banner */}
          {(() => {
            const headerInfo = getCurrentHeaderInfo(unitFilter || selectedIndividualRecord?.unit);
            return (
              <div className="border-b-2 border-slate-900 pb-4 flex items-center justify-between">
                <div className="space-y-1 text-right">
                  <h4 className="text-xs font-black text-slate-900">{headerInfo.forceName}</h4>
                  <h4 className="text-xs font-black text-slate-800">{headerInfo.divisionName}</h4>
                  <h4 className="text-xs font-extrabold text-amber-900">{headerInfo.unitName}</h4>
                  <p className="text-[10px] text-slate-600 font-bold">الشؤون المالية / إدارة المرتبات والحسابات</p>
                </div>

                <div className="text-center space-y-1">
                  <div className="w-14 h-14 mx-auto rounded-2xl bg-slate-900 text-amber-400 flex items-center justify-center border-2 border-amber-400 shadow-xs font-black text-xl print:border-black print:text-black print:bg-white">
                    🛡️
                  </div>
                  <h2 className="font-black text-base sm:text-lg text-slate-950 font-['Tajawal'] tracking-tight">
                    {selectedIndividualRecord ? 'سند صرف مالي وقسيمة راتب رسمية' : 'كشف مسير مرتبات القوة العسكرية'}
                  </h2>
                  <div className="inline-block bg-slate-100 border border-slate-400 px-3 py-0.5 rounded-full text-xs font-extrabold text-slate-900 print:border-black">
                    شهر الاستحقاق: <span className="font-mono">{monthTitle}</span>
                  </div>
                </div>

                <div className="text-left space-y-1 text-xs">
                  <div><span className="font-bold text-slate-600">الرقم المرجعي:</span> <span className="font-mono font-black">{refCode}</span></div>
                  <div><span className="font-bold text-slate-600">تاريخ الإصدار:</span> <span className="font-mono font-bold">{currentDateFormatted}</span></div>
                  <div><span className="font-bold text-slate-600">الوحدة:</span> <span className="font-bold text-slate-900">{unitFilter || selectedIndividualRecord?.unit || 'جميع الوحدات'}</span></div>
                  <div>
                    <span className="font-bold text-slate-600">الحالة:</span>{' '}
                    <span className="font-black text-slate-900 bg-slate-100 px-2 py-0.5 rounded border border-slate-300 print:border-black">
                      {selectedIndividualRecord ? selectedIndividualRecord.status : (batch?.status || 'معتمد للصرف')}
                    </span>
                  </div>
                </div>
              </div>
            );
          })()}

          {/* ========================================================================= */}
          {/* VIEW 1: SINGLE INDIVIDUAL FINANCIAL DISBURSEMENT VOUCHER (سند صرف مالي فردي) */}
          {/* ========================================================================= */}
          {selectedIndividualRecord ? (
            <div className="space-y-4">
              
              {/* Personnel Personal & Military Identity Info Box */}
              <div className="grid grid-cols-1 md:grid-cols-3 gap-3 bg-slate-50 border-2 border-slate-800 rounded-2xl p-4 text-xs font-bold text-slate-800 print:bg-white print:border-black">
                <div className="space-y-1">
                  <span className="text-[10px] text-slate-500 block">الاسم والصفة العسكرية:</span>
                  <p className="text-sm font-black text-slate-950 font-['Tajawal']">
                    {selectedIndividualRecord.rank} / {selectedIndividualRecord.fullName}
                  </p>
                </div>

                <div className="space-y-1">
                  <span className="text-[10px] text-slate-500 block">الرقم العسكري والتوزيع:</span>
                  <p className="font-mono font-black text-slate-900">
                    {selectedIndividualRecord.militaryId} - {selectedIndividualRecord.unit} {selectedIndividualRecord.battalion ? `(${selectedIndividualRecord.battalion})` : ''}
                  </p>
                </div>

                <div className="space-y-1">
                  <span className="text-[10px] text-slate-500 block">جهة الصرف والحساب:</span>
                  <p className="font-bold text-teal-950">
                    {selectedIndividualRecord.bankName || 'خزينة الفرع المالي'} {selectedIndividualRecord.bankAccountNumber ? `(حساب: ${selectedIndividualRecord.bankAccountNumber})` : ''}
                  </p>
                </div>
              </div>

              {/* Financial Ledger Breakdown Grid */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs">
                
                {/* Column 1: Basic Salary & Additions/Allowances */}
                <div className="bg-white rounded-2xl border-2 border-slate-300 p-4 space-y-3 print:border-black">
                  <div className="flex items-center justify-between border-b-2 border-emerald-700 pb-2">
                    <span className="font-black text-emerald-950 text-sm">الاستحقاقات والبدلات (+)</span>
                    <span className="font-mono font-black text-emerald-900 text-sm">
                      {(selectedIndividualRecord.basicSalary + selectedIndividualRecord.totalAllowances).toLocaleString('ar-SA')} ر.س
                    </span>
                  </div>

                  <div className="space-y-2">
                    <div className="flex justify-between items-center bg-slate-50 p-2 rounded-xl border border-slate-200">
                      <span className="font-bold text-slate-800">الراتب الأساسي المعتمد:</span>
                      <span className="font-mono font-black text-slate-950">{selectedIndividualRecord.basicSalary.toLocaleString('ar-SA')} ر.س</span>
                    </div>

                    {selectedIndividualRecord.allowances && selectedIndividualRecord.allowances.length > 0 ? (
                      <div className="space-y-1.5 pt-1">
                        <span className="text-[10px] font-bold text-slate-500 block">تفاصيل البدلات والعلاوات:</span>
                        {selectedIndividualRecord.allowances.map((a, idx) => (
                          <div key={idx} className="flex justify-between items-center text-[11px] bg-emerald-50/70 p-1.5 rounded-lg border border-emerald-200">
                            <span className="font-bold text-emerald-950">• {a.title}</span>
                            <span className="font-mono font-bold text-emerald-900">+{a.amount.toLocaleString('ar-SA')} ر.س</span>
                          </div>
                        ))}
                      </div>
                    ) : (
                      <p className="text-[11px] text-slate-400 italic py-1">لا توجد بدلات إضافية مضافة لهذا الشهر</p>
                    )}
                  </div>
                </div>

                {/* Column 2: Deductions & Penalties */}
                <div className="bg-white rounded-2xl border-2 border-slate-300 p-4 space-y-3 print:border-black">
                  <div className="flex items-center justify-between border-b-2 border-rose-700 pb-2">
                    <span className="font-black text-rose-950 text-sm">الاستقطاعات والخصميات (-)</span>
                    <span className="font-mono font-black text-rose-900 text-sm">
                      -{selectedIndividualRecord.totalDeductions.toLocaleString('ar-SA')} ر.س
                    </span>
                  </div>

                  <div className="space-y-2">
                    {selectedIndividualRecord.deductions && selectedIndividualRecord.deductions.length > 0 ? (
                      <div className="space-y-1.5">
                        {selectedIndividualRecord.deductions.map((d, idx) => (
                          <div key={idx} className="bg-rose-50 p-2 rounded-xl border border-rose-200 space-y-0.5">
                            <div className="flex justify-between items-center font-black text-rose-950 text-xs">
                              <span>• {d.category} {(d as any).daysCount || (d as any).days ? `(${(d as any).daysCount || (d as any).days} يوم)` : ''}</span>
                              <span className="font-mono text-rose-900">-{d.amount.toLocaleString('ar-SA')} ر.س</span>
                            </div>
                            {d.reason && (
                              <p className="text-[10px] text-rose-800 font-bold leading-tight">{d.reason}</p>
                            )}
                          </div>
                        ))}
                      </div>
                    ) : (
                      <div className="p-4 bg-slate-50 rounded-xl border border-slate-200 text-center text-slate-500 font-bold text-[11px]">
                        ✅ لم يُسجل أي خصم أو استقطاع على الفرد خلال شهر الاستحقاق.
                      </div>
                    )}
                  </div>
                </div>

              </div>

              {/* Total Approved Payout Banner with Security QR Code */}
              <div className="bg-slate-900 text-white rounded-2xl p-4 border-2 border-amber-500 flex flex-col sm:flex-row items-center justify-between gap-4 print:bg-white print:text-black print:border-black">
                <div className="space-y-1">
                  <span className="text-xs text-amber-300 font-bold print:text-black block">صافي المبلغ المعتمد للصرف النهائي:</span>
                  <div className="flex items-baseline gap-2">
                    <span className="text-2xl sm:text-3xl font-black font-mono text-white print:text-black">
                      {selectedIndividualRecord.netSalary.toLocaleString('ar-SA')}
                    </span>
                    <span className="text-sm font-bold text-amber-300 print:text-black">ريال سعودي فقط لا غير</span>
                  </div>
                  <p className="text-[11px] text-slate-300 print:text-slate-700 font-mono">
                    حالة الصرف: {selectedIndividualRecord.status} | الشهر: {monthTitle}
                  </p>
                </div>

                {/* QR Code */}
                <div className="flex items-center gap-3 bg-white p-2 rounded-xl border border-slate-300 text-slate-900 shrink-0">
                  <QRCodeSVG value={qrPayload} size={64} level="M" />
                  <div className="text-[9px] font-mono leading-tight space-y-0.5">
                    <span className="font-black text-slate-900 block">توثيق إلكتروني</span>
                    <span className="text-slate-600 block">{refCode}</span>
                    <span className="text-emerald-800 font-bold block">سند معتمد ومطابق</span>
                  </div>
                </div>
              </div>

            </div>
          ) : (
            /* ========================================================================= */
            /* VIEW 2: FULL FORCE PAYROLL DISBURSEMENT LEDGER (كشف مسير مرتبات القوة بالكامل) */
            /* ========================================================================= */
            <div className="space-y-4">
              
              {/* Totals Summary KPI Banner */}
              <div className="grid grid-cols-4 gap-3 bg-slate-50 border-2 border-slate-800 rounded-2xl p-4 text-center print:bg-white print:border-black">
                <div className="border-l border-slate-300 pl-2">
                  <span className="text-[10px] font-extrabold text-slate-500 block">إجمالي قوة الكشف</span>
                  <span className="text-base font-black text-slate-900 font-mono">{displayRecords.length} فرد</span>
                </div>
                <div className="border-l border-slate-300 pl-2">
                  <span className="text-[10px] font-extrabold text-slate-500 block">إجمالي المرتبات الأساسية</span>
                  <span className="text-sm font-black text-slate-900 font-mono">{totalBasic.toLocaleString('ar-SA')} ر.س</span>
                </div>
                <div className="border-l border-slate-300 pl-2">
                  <span className="text-[10px] font-extrabold text-rose-700 block">إجمالي الخصميات</span>
                  <span className="text-sm font-black text-rose-700 font-mono">-{totalDeductions.toLocaleString('ar-SA')} ر.س</span>
                </div>
                <div>
                  <span className="text-[10px] font-extrabold text-emerald-800 block">صافي الصرف المعتمد</span>
                  <span className="text-base font-black text-emerald-900 font-mono">{totalNet.toLocaleString('ar-SA')} ر.س</span>
                </div>
              </div>

              {/* Ledger Table */}
              <div className="overflow-x-auto border-2 border-slate-900 rounded-xl print:border-black">
                <table className="w-full text-right text-xs border-collapse">
                  <thead>
                    <tr className="bg-slate-900 text-white font-extrabold font-['Tajawal'] text-[10px] print:bg-slate-200 print:text-black">
                      <th className="p-2 border border-slate-800 text-center">#</th>
                      <th className="p-2 border border-slate-800">الرقم العسكري</th>
                      <th className="p-2 border border-slate-800">الرتبة والاسم الكامل</th>
                      <th className="p-2 border border-slate-800">الوحدة</th>
                      <th className="p-2 border border-slate-800 text-center">الأساسي</th>
                      <th className="p-2 border border-slate-800 text-center">البدلات</th>
                      <th className="p-2 border border-slate-800 text-center">الخصميات/السبب</th>
                      <th className="p-2 border border-slate-800 text-center">إجمالي الخصم</th>
                      <th className="p-2 border border-slate-800 text-center">الصافي (ر.س)</th>
                      <th className="p-2 border border-slate-800 text-center min-w-[100px]">التوقيع / البصمة</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-300">
                    {displayRecords.map((r, idx) => (
                      <tr key={r.id} className={idx % 2 === 0 ? 'bg-white' : 'bg-slate-50'}>
                        <td className="p-2 font-mono font-bold text-center text-slate-600">{idx + 1}</td>
                        <td className="p-2 font-mono font-black text-slate-900">{r.militaryId}</td>
                        <td className="p-2 font-bold text-slate-900">
                          {r.rank} / {r.fullName}
                        </td>
                        <td className="p-2 text-[10px] text-slate-700">{r.unit}</td>
                        <td className="p-2 font-mono text-center font-bold">{r.basicSalary.toLocaleString('ar-SA')}</td>
                        <td className="p-2 font-mono text-center text-emerald-800 font-bold">+{r.totalAllowances.toLocaleString('ar-SA')}</td>
                        <td className="p-2 text-[10px] max-w-xs">
                          {r.deductions.length === 0 ? (
                            <span className="text-slate-400">—</span>
                          ) : (
                            <div className="space-y-0.5">
                              {r.deductions.map((d, dIdx) => (
                                <div key={dIdx} className="text-rose-800 font-bold leading-tight">
                                  [{d.category}]: {d.reason || `${d.amount} ر.س`}
                                </div>
                              ))}
                            </div>
                          )}
                        </td>
                        <td className="p-2 font-mono text-center text-rose-700 font-black">
                          {r.totalDeductions > 0 ? `-${r.totalDeductions.toLocaleString('ar-SA')}` : '0'}
                        </td>
                        <td className="p-2 font-mono text-center font-black text-slate-900 bg-emerald-50/80 border-x border-emerald-200">
                          {r.netSalary.toLocaleString('ar-SA')}
                        </td>
                        <td className="p-2 border border-slate-300"></td>
                      </tr>
                    ))}

                    {/* Final Grand Totals Row - Appears strictly at the end of the ledger on the LAST page */}
                    <tr className="bg-slate-900 text-white font-black font-mono text-xs print:bg-slate-200 print:text-black border-t-2 border-slate-900 print:border-black break-inside-avoid page-break-inside-avoid">
                      <td colSpan={4} className="p-2.5 text-right font-['Tajawal'] font-black">
                        الإجمالي العام لمسير المرتبات ({displayRecords.length} فرد):
                      </td>
                      <td className="p-2.5 text-center font-bold">{totalBasic.toLocaleString('ar-SA')}</td>
                      <td className="p-2.5 text-center text-emerald-300 print:text-black font-bold">+{totalAllowances.toLocaleString('ar-SA')}</td>
                      <td className="p-2.5 text-center"></td>
                      <td className="p-2.5 text-center text-rose-300 print:text-black font-bold">-{totalDeductions.toLocaleString('ar-SA')}</td>
                      <td className="p-2.5 text-center text-amber-300 print:text-black font-black text-sm">{totalNet.toLocaleString('ar-SA')} ر.س</td>
                      <td className="p-2.5 text-center text-[10px] text-slate-300 print:text-black font-sans font-bold">معتمد</td>
                    </tr>
                  </tbody>
                </table>
              </div>

            </div>
          )}

          {/* Official Signatures & Endorsement Block */}
          <div className="pt-6 border-t-2 border-slate-900 grid grid-cols-3 gap-4 text-center text-xs signature-block print:pt-4">
            <div className="space-y-6">
              <div>
                <span className="font-extrabold text-slate-900 block">إعداد وتدقيق / المحاسب المالي</span>
                <span className="text-[10px] text-slate-500">قسم الشؤون المالية والحسابات</span>
              </div>
              <div className="border-b border-dashed border-slate-400 w-3/4 mx-auto pb-1 text-slate-400 text-[10px]">
                التوقيع: ............................
              </div>
            </div>

            <div className="space-y-6">
              <div>
                <span className="font-extrabold text-slate-900 block">مراجعة / رئيس شؤون الأفراد</span>
                <span className="text-[10px] text-slate-500">إدارة القوى البشرية والسجلات</span>
              </div>
              <div className="border-b border-dashed border-slate-400 w-3/4 mx-auto pb-1 text-slate-400 text-[10px]">
                التوقيع: ............................
              </div>
            </div>

            <div className="space-y-6">
              <div>
                <span className="font-extrabold text-slate-900 block">
                  {selectedIndividualRecord ? 'توقيع وبصمة المستلم' : 'يعتمد للصرف / قائد المحور - اللواء'}
                </span>
                <span className="text-[10px] text-slate-500">
                  {selectedIndividualRecord ? 'إقرار باستلام كامل المستحق' : 'القيادة العامة والمنطقة العسكرية'}
                </span>
              </div>
              <div className="border-b border-dashed border-slate-400 w-3/4 mx-auto pb-1 text-slate-400 text-[10px]">
                {selectedIndividualRecord ? 'التوقيع / البصمة: ...................' : 'التوقيع والختم الرسمي: ...................'}
              </div>
            </div>
          </div>

        </div>
      </div>
    </div>
  );

  return createPortal(modalContent, document.body);
};
