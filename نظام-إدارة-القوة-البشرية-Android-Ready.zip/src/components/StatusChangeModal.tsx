import React, { useState, useEffect, useMemo } from 'react';
import {
  X,
  Check,
  Shield,
  Building2,
  Calendar,
  Clock,
  AlertTriangle,
  FileText,
  Sparkles,
  ArrowRightLeft,
  UserCheck,
  Scale,
  GraduationCap,
  BookOpen,
  ShieldAlert,
  Crosshair
} from 'lucide-react';
import { PersonnelRecord, PersonnelStatus } from '../types';
import { PersonnelAvatar } from './PersonnelAvatar';
import { StorageService } from '../lib/storage';

interface StatusChangeModalProps {
  isOpen: boolean;
  onClose: () => void;
  personnel: PersonnelRecord | null;
  onConfirm: (
    militaryId: string,
    newStatus: PersonnelStatus,
    extraDetails?: { secondedUnit?: string; trainingCourseType?: string; reason?: string; effectiveDate?: string }
  ) => void;
}

const COMMON_SECONDED_UNITS = [
  'وزارة الدفاع / هيئة الأركان العامة',
  'قيادة القوات المشتركة',
  'قيادة القوات البحرية والدفاع الساحلي',
  'قيادة المنطقة العسكرية الأولى',
  'قيادة المنطقة العسكرية الثانية',
  'قيادة المنطقة العسكرية الرابعة',
  'دائرة الاستخبارات والاستطلاع العسكري',
  'دائرة شؤون الأفراد والاحتياط العام',
  'قيادة حرس الحدود',
  'قيادة الشرطة العسكرية المركزية',
  'اللواء الأول مشاة بحري',
  'اللواء الثاني حرس حدود'
];

const COMMON_TRAINING_COURSES = [
  'دورة قادة فصائل وسرايا',
  'دورة تأهيل ضباط صف',
  'دورة صاعقة ومظلات',
  'دورة قناصة ورماية ميدانية',
  'دورة هندسة ومتفجرات',
  'دورة إشارة واتصالات عسكرية',
  'دورة تدريب مدربين (TOT)',
  'دورة أمن وحماية شخصيات',
  'دورة إسعافات وطب ميداني',
  'دورة قيادة مدرعات وآليات',
  'دورة قيادة وأركان صغرى',
  'دورة تخصصية متقدمة'
];

export const StatusChangeModal: React.FC<StatusChangeModalProps> = ({
  isOpen,
  onClose,
  personnel,
  onConfirm
}) => {
  const todayStr = new Date().toISOString().split('T')[0];

  const [targetStatus, setTargetStatus] = useState<PersonnelStatus>('متواجد');
  const [secondedUnit, setSecondedUnit] = useState<string>('');
  const [trainingCourseType, setTrainingCourseType] = useState<string>('');
  const [reason, setReason] = useState<string>('');
  const [effectiveDate, setEffectiveDate] = useState<string>(todayStr);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (isOpen && personnel) {
      setTargetStatus(personnel.currentStatus);
      setSecondedUnit(personnel.secondedUnit || '');
      setTrainingCourseType(personnel.trainingCourseType || '');
      setReason('');
      setEffectiveDate(todayStr);
      setError(null);
    }
  }, [isOpen, personnel, todayStr]);

  // Compute duration of current status so far
  const currentStatusStartDate = useMemo(() => {
    if (!personnel) return todayStr;
    if (personnel.lastStatusChangeDate) return personnel.lastStatusChangeDate;
    const firstAtt = personnel.logs?.attendance?.[0];
    if (firstAtt?.startDate) return firstAtt.startDate;
    if (firstAtt?.date) return firstAtt.date;
    return personnel.enlistmentDate || todayStr;
  }, [personnel, todayStr]);

  const elapsedDays = useMemo(() => {
    if (!currentStatusStartDate || !effectiveDate) return 1;
    const start = new Date(currentStatusStartDate);
    const end = new Date(effectiveDate);
    const diffTime = end.getTime() - start.getTime();
    const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
    return diffDays > 0 ? diffDays : 1;
  }, [currentStatusStartDate, effectiveDate]);

  if (!isOpen || !personnel) return null;

  const isStatusChanging = targetStatus !== personnel.currentStatus;
  const isSeconded = targetStatus === 'منتدب';
  const isTraining = targetStatus === 'دورة تدريبية داخلية' || targetStatus === 'دورة تدريبية خارجية';

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();

    if (isSeconded && !secondedUnit.trim()) {
      setError('يرجى كتابة أو اختيار اسم الوحدة / الجهة المنتدب إليها الفرد.');
      return;
    }

    if (isTraining && !trainingCourseType.trim()) {
      setError('يرجى كتابة أو اختيار نوع ومسمى الدورة التدريبية.');
      return;
    }

    onConfirm(personnel.militaryId, targetStatus, {
      secondedUnit: isSeconded ? secondedUnit.trim() : undefined,
      trainingCourseType: isTraining ? trainingCourseType.trim() : undefined,
      reason: reason.trim() || undefined,
      effectiveDate
    });

    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/70 backdrop-blur-xs font-['Cairo',sans-serif] select-none animate-fadeIn">
      <div className="bg-white border-2 border-emerald-500/40 rounded-3xl max-w-xl w-full shadow-2xl overflow-hidden text-right">
        
        {/* Header */}
        <div className="bg-gradient-to-r from-slate-900 via-indigo-950 to-slate-900 p-5 text-white flex items-center justify-between">
          <div className="flex items-center space-x-3 space-x-reverse">
            <div className="w-10 h-10 rounded-2xl bg-emerald-500/20 border border-emerald-400/50 flex items-center justify-center text-emerald-400">
              <ArrowRightLeft className="w-6 h-6" />
            </div>
            <div>
              <h3 className="font-black text-lg text-emerald-300 font-['Tajawal']">
                تغيير حالة الجاهزية وتقييد السجل الانضباطي ⚡
              </h3>
              <p className="text-xs text-slate-300">
                تحديث التمام الميداني وتوثيق عدد أيام الحالة بسجل الحركة والأمن
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            type="button"
            className="p-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white transition-colors border border-slate-700 cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Form Body */}
        <form onSubmit={handleSubmit} className="p-6 space-y-5 max-h-[80vh] overflow-y-auto">
          
          {/* Target Personnel Info Card */}
          <div className="bg-slate-50 border border-slate-200 rounded-2xl p-4 flex items-center justify-between">
            <div className="flex items-center space-x-3 space-x-reverse">
              <PersonnelAvatar
                photoUrl={personnel.photoUrl}
                fullName={personnel.fullName}
                rank={personnel.rank}
                militaryId={personnel.militaryId}
                size="md"
                shape="rounded"
              />
              <div>
                <div className="font-extrabold text-slate-900 text-sm">
                  {personnel.rank} / {personnel.fullName}
                </div>
                <div className="text-xs text-slate-500 flex items-center space-x-2 space-x-reverse mt-0.5">
                  <span className="font-mono bg-emerald-100 text-emerald-900 px-2 py-0.5 rounded font-bold">
                    {personnel.militaryId}
                  </span>
                  <span>•</span>
                  <span>{personnel.unit}</span>
                </div>
              </div>
            </div>

            {/* Current Status Pill */}
            <div className="text-left">
              <span className="text-[10px] text-slate-400 font-bold block">الحالة الحالية</span>
              <span className="text-xs font-black bg-emerald-100 text-emerald-900 border border-emerald-300 px-3 py-1 rounded-lg">
                {personnel.currentStatus}
              </span>
            </div>
          </div>

          {/* Duration Banner of Current Status */}
          <div className="bg-amber-50/80 border border-amber-300 rounded-2xl p-3.5 flex items-start space-x-3 space-x-reverse">
            <div className="w-8 h-8 rounded-xl bg-amber-500/20 text-amber-800 border border-amber-400 flex items-center justify-center shrink-0 mt-0.5">
              <Clock className="w-4 h-4" />
            </div>
            <div className="text-xs text-amber-950 space-y-0.5">
              <div className="font-bold flex items-center space-x-1.5 space-x-reverse">
                <span>تاريخ آخر تغيير للحالة:</span>
                <span className="font-mono bg-amber-200/80 px-2 py-0.5 rounded font-black text-amber-900">
                  {currentStatusStartDate}
                </span>
                <span>(مر عليها: <strong className="text-rose-700 font-black">{elapsedDays} أيام</strong>)</span>
              </div>
              <p className="text-[11px] text-amber-900">
                عند تغيير الحالة الآن، سيقوم النظام تلقائياً بترحيل وتقييد الـ ({elapsedDays}) أيام في سجل الانضباط والتمام والقرارات الإدارية للفرد.
              </p>
            </div>
          </div>

          {/* New Status Selection Grid */}
          <div className="space-y-2">
            <label className="text-xs font-black text-slate-800 flex items-center space-x-1.5 space-x-reverse">
              <Shield className="w-4 h-4 text-emerald-700" />
              <span>اختر الحالة الجديدة للجاهزية *</span>
            </label>
            <div className="grid grid-cols-3 sm:grid-cols-4 gap-2">
              {(
                [
                  'متواجد',
                  'في الميدان',
                  'مأمورية',
                  'منتدب',
                  'دورة تدريبية داخلية',
                  'دورة تدريبية خارجية',
                  'إجازة',
                  'إذن',
                  'مستشفى',
                  'جريح',
                  'غياب',
                  'فرار',
                  'فرار بالسلاح',
                  'اسير',
                  'شهيد',
                  'معاق',
                  'مفقود',
                  'موقوف',
                  'احتياط'
                ] as PersonnelStatus[]
              ).map((st) => {
                const isSelected = targetStatus === st;
                return (
                  <button
                    key={st}
                    type="button"
                    onClick={() => {
                      setTargetStatus(st);
                      if (error) setError(null);
                    }}
                    className={`px-2.5 py-2 rounded-xl text-xs font-bold border transition-all text-center cursor-pointer ${
                      isSelected
                        ? st === 'منتدب'
                          ? 'bg-purple-700 text-white border-purple-800 shadow-md ring-2 ring-purple-400'
                          : st === 'دورة تدريبية داخلية' || st === 'دورة تدريبية خارجية'
                          ? 'bg-indigo-700 text-white border-indigo-800 shadow-md ring-2 ring-indigo-400'
                          : st === 'شهيد'
                          ? 'bg-emerald-950 text-emerald-100 border-emerald-800 shadow-md ring-2 ring-emerald-500'
                          : st === 'اسير' || st === 'معاق'
                          ? 'bg-zinc-800 text-white border-zinc-900 shadow-md ring-2 ring-zinc-500'
                          : st === 'جريح'
                          ? 'bg-rose-900 text-rose-100 border-rose-950 shadow-md ring-2 ring-rose-500'
                          : st === 'فرار بالسلاح'
                          ? 'bg-rose-950 text-rose-100 border-rose-900 shadow-md ring-2 ring-rose-500 font-extrabold animate-pulse'
                          : st === 'فرار' || st === 'غياب'
                          ? 'bg-rose-700 text-white border-rose-800 shadow-md ring-2 ring-rose-400'
                          : 'bg-emerald-700 text-white border-emerald-800 shadow-md ring-2 ring-emerald-400'
                        : 'bg-slate-50 text-slate-800 border-slate-200 hover:bg-slate-100 hover:border-slate-300'
                    }`}
                  >
                    {st === 'منتدب'
                      ? 'منتدب 🏛️'
                      : st === 'دورة تدريبية داخلية'
                      ? 'دورة داخلية 🎓'
                      : st === 'دورة تدريبية خارجية'
                      ? 'دورة خارجية ✈️'
                      : st === 'اسير'
                      ? 'اسير ⛓️'
                      : st === 'شهيد'
                      ? 'شهيد 🎖️'
                      : st === 'معاق'
                      ? 'معاق ♿'
                      : st === 'جريح'
                      ? 'جريح 🩹'
                      : st === 'فرار بالسلاح'
                      ? 'فرار بالسلاح ⚠️'
                      : st === 'فرار'
                      ? 'فرار 🚨'
                      : st === 'غياب'
                      ? 'غياب ⚠️'
                      : st === 'مفقود'
                      ? 'مفقود ❓'
                      : st}
                  </button>
                );
              })}
            </div>
          </div>

          {/* Deserter With Weapon Warning & Active Custody Details */}
          {targetStatus === 'فرار بالسلاح' && (() => {
            const activeWeapon = StorageService.getActiveWeaponForPersonnel(personnel);
            return (
              <div className="bg-rose-950/10 border-2 border-rose-600 rounded-2xl p-4 space-y-3 animate-fadeIn text-right">
                <div className="flex items-center space-x-2 space-x-reverse text-rose-900 font-black text-xs">
                  <ShieldAlert className="w-5 h-5 text-rose-700 animate-pulse shrink-0" />
                  <span>بلاغ أمني عاجل: تقييد حالة الفرد كـ (فرار بالسلاح) ⚠️</span>
                </div>
                <p className="text-xs text-rose-800 leading-relaxed font-semibold">
                  تحذير أمني واستخباراتي: سيتم تثبيت واقعة هروب الفرد بالسلاح العسكري في سجل الجاهزية وإشعار فرع التسليح والنيابة العسكرية فوراً لحصر السلاح والذخيرة المقيدة بعهدته.
                </p>

                {activeWeapon ? (
                  <div className="bg-white border-2 border-rose-400 rounded-xl p-3 space-y-1.5 shadow-xs">
                    <div className="text-[11px] font-black text-rose-950 flex items-center justify-between">
                      <span className="flex items-center space-x-1.5 space-x-reverse">
                        <Crosshair className="w-3.5 h-3.5 text-rose-700" />
                        <span>بيانات السلاح المقيد بحوزة الفرد:</span>
                      </span>
                      <span className="bg-rose-100 text-rose-800 px-2 py-0.5 rounded text-[10px] font-mono font-bold">
                        مطلوب ضبطه وتوريده 🚫
                      </span>
                    </div>
                    <div className="grid grid-cols-2 gap-2 text-xs pt-1 text-slate-800">
                      <div>نوع السلاح: <strong className="font-extrabold text-rose-900">{activeWeapon.weaponType}</strong></div>
                      <div>الرقم التسلسلي: <strong className="font-mono font-bold text-rose-900">{activeWeapon.weaponSerial}</strong></div>
                      <div>الذخيرة: <strong className="font-mono text-amber-800">{activeWeapon.ammoQty || 0} طلقة</strong></div>
                      <div>تاريخ الصرف: <strong className="font-mono text-slate-700">{activeWeapon.issueDate}</strong></div>
                    </div>
                  </div>
                ) : (
                  <div className="bg-amber-50 border border-amber-300 rounded-xl p-2.5 text-xs text-amber-900 font-bold flex items-center space-x-2 space-x-reverse">
                    <AlertTriangle className="w-4 h-4 text-amber-700 shrink-0" />
                    <span>تنبيه: لا يوجد سلاح رسمي مقيد حالياً باسم هذا الفرد في شعبة التسليح. يرجى التأكد من صحة البلاغ.</span>
                  </div>
                )}
              </div>
            );
          })()}

          {/* Training Course Field (Only when targetStatus is 'دورة تدريبية داخلية' or 'دورة تدريبية خارجية') */}
          {isTraining && (
            <div className="bg-indigo-50/80 border-2 border-indigo-300 rounded-2xl p-4 space-y-3 animate-fadeIn">
              <div className="flex items-center space-x-2 space-x-reverse text-indigo-950 font-black text-xs">
                <GraduationCap className="w-4 h-4 text-indigo-700" />
                <span>تحديد نوع ومسمى الدورة التدريبية ({targetStatus === 'دورة تدريبية خارجية' ? 'خارجية' : 'داخلية'}) *</span>
              </div>

              {/* Presets */}
              <div className="space-y-1">
                <span className="text-[11px] text-indigo-800 font-bold block">اختيار سريع للدورات الشائعة:</span>
                <div className="flex flex-wrap gap-1.5 max-h-28 overflow-y-auto p-1 bg-white border border-indigo-200 rounded-xl">
                  {COMMON_TRAINING_COURSES.map((course) => (
                    <button
                      key={course}
                      type="button"
                      onClick={() => {
                        setTrainingCourseType(course);
                        if (error) setError(null);
                      }}
                      className={`text-[11px] px-2.5 py-1 rounded-lg font-bold border transition-all cursor-pointer ${
                        trainingCourseType === course
                          ? 'bg-indigo-700 text-white border-indigo-800 shadow-xs'
                          : 'bg-indigo-50 text-indigo-900 border-indigo-200 hover:bg-indigo-100'
                      }`}
                    >
                      {course}
                    </button>
                  ))}
                </div>
              </div>

              {/* Direct Input */}
              <div>
                <input
                  type="text"
                  required
                  value={trainingCourseType}
                  onChange={(e) => {
                    setTrainingCourseType(e.target.value);
                    if (error) setError(null);
                  }}
                  placeholder="أدخل مسمى ونوع الدورة التدريبية بالتفصيل..."
                  className="w-full px-3.5 py-2.5 bg-white border-2 border-indigo-300 focus:border-indigo-600 rounded-xl text-xs font-extrabold text-indigo-950 outline-hidden transition-colors"
                />
              </div>
            </div>
          )}

          {/* Seconded Unit Field (Only when targetStatus is 'منتدب') */}
          {isSeconded && (
            <div className="bg-purple-50/80 border-2 border-purple-300 rounded-2xl p-4 space-y-3 animate-fadeIn">
              <div className="flex items-center space-x-2 space-x-reverse text-purple-950 font-black text-xs">
                <Building2 className="w-4 h-4 text-purple-700" />
                <span>تحديد الوحدة والجهة المنتدب إليها (إجباري عند الانتداب) *</span>
              </div>

              {/* Presets */}
              <div className="space-y-1">
                <span className="text-[11px] text-purple-800 font-bold block">اختيار سريع للجهات الرسمية الشائعة:</span>
                <div className="flex flex-wrap gap-1.5 max-h-28 overflow-y-auto p-1 bg-white border border-purple-200 rounded-xl">
                  {COMMON_SECONDED_UNITS.map((unit) => (
                    <button
                      key={unit}
                      type="button"
                      onClick={() => {
                        setSecondedUnit(unit);
                        if (error) setError(null);
                      }}
                      className={`text-[11px] px-2.5 py-1 rounded-lg font-bold border transition-all cursor-pointer ${
                        secondedUnit === unit
                          ? 'bg-purple-700 text-white border-purple-800 shadow-xs'
                          : 'bg-purple-50 text-purple-900 border-purple-200 hover:bg-purple-100'
                      }`}
                    >
                      {unit}
                    </button>
                  ))}
                </div>
              </div>

              {/* Direct Input */}
              <div>
                <input
                  type="text"
                  required
                  value={secondedUnit}
                  onChange={(e) => {
                    setSecondedUnit(e.target.value);
                    if (error) setError(null);
                  }}
                  placeholder="أدخل اسم الوحدة أو الجهة المنتدب إليها..."
                  className="w-full px-3.5 py-2.5 bg-white border-2 border-purple-300 focus:border-purple-600 rounded-xl text-xs font-extrabold text-purple-950 outline-hidden transition-colors"
                />
              </div>
            </div>
          )}

          {/* Effective Date & Reason Fields */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            
            {/* Effective Date */}
            <div className="space-y-1.5">
              <label className="text-xs font-bold text-slate-700 flex items-center space-x-1.5 space-x-reverse">
                <Calendar className="w-3.5 h-3.5 text-slate-500" />
                <span>تاريخ اعتماد تغيير الحالة</span>
              </label>
              <input
                type="date"
                value={effectiveDate}
                onChange={(e) => setEffectiveDate(e.target.value)}
                className="w-full px-3 py-2 bg-slate-50 border border-slate-300 focus:border-emerald-600 focus:bg-white rounded-xl text-xs font-bold text-slate-800 outline-hidden transition-colors"
              />
            </div>

            {/* Reason */}
            <div className="space-y-1.5">
              <label className="text-xs font-bold text-slate-700 flex items-center space-x-1.5 space-x-reverse">
                <FileText className="w-3.5 h-3.5 text-slate-500" />
                <span>سبب / مرجع القرار الإداري (اختياري)</span>
              </label>
              <input
                type="text"
                value={reason}
                onChange={(e) => setReason(e.target.value)}
                placeholder="توجيهات القيادة / تسوية الوضع..."
                className="w-full px-3 py-2 bg-slate-50 border border-slate-300 focus:border-emerald-600 focus:bg-white rounded-xl text-xs text-slate-800 outline-hidden transition-colors"
              />
            </div>

          </div>

          {/* Discipline Record Audit Banner */}
          {isStatusChanging && (
            <div className="bg-emerald-50 border border-emerald-300 rounded-2xl p-3.5 flex items-start space-x-3 space-x-reverse text-emerald-950 text-xs">
              <Scale className="w-4 h-4 text-emerald-700 shrink-0 mt-0.5" />
              <div className="space-y-1">
                <div className="font-extrabold text-emerald-900">
                  توثيق انضباطي آلي ⚖️
                </div>
                <p className="text-[11px] text-emerald-800">
                  سيتم توثيق تقييد الفترة السابقة (<strong className="text-emerald-950">{personnel.currentStatus}</strong> لمدة <strong className="text-rose-700 font-black">{elapsedDays} يوم</strong>) وتسجيلها في السجل الانضباطي والأمني وبطاقة التحركات بالفرد.
                </p>
              </div>
            </div>
          )}

          {error && (
            <div className="p-3 bg-rose-50 border border-rose-300 rounded-xl text-xs font-bold text-rose-700">
              {error}
            </div>
          )}

          {/* Actions */}
          <div className="pt-3 border-t border-slate-200 flex items-center justify-end gap-2">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2.5 bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-bold rounded-xl transition-colors cursor-pointer"
            >
              إلغاء
            </button>
            <button
              type="submit"
              className="px-5 py-2.5 bg-emerald-700 hover:bg-emerald-800 text-white text-xs font-black rounded-xl transition-all shadow-md hover:shadow-lg flex items-center space-x-1.5 space-x-reverse cursor-pointer"
            >
              <Check className="w-4 h-4 text-white" />
              <span>اعتماد وتوثيق التغيير ⚡</span>
            </button>
          </div>

        </form>
      </div>
    </div>
  );
};
