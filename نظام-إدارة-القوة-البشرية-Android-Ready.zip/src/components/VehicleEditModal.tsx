import React, { useState, useEffect } from 'react';
import { VehicleItem, VehicleCategory, VehicleReadinessStatus } from '../types';
import { StorageService } from '../lib/storage';
import {
  X,
  Save,
  Truck,
  Hash,
  Activity,
  MapPin,
  User,
  Fuel,
  Calendar,
  Gauge,
  FileText,
  CheckCircle2,
  AlertTriangle
} from 'lucide-react';

interface VehicleEditModalProps {
  isOpen: boolean;
  vehicle: VehicleItem | null;
  onClose: () => void;
  onSaveSuccess: (updatedVehicle: VehicleItem) => void;
  currentAccountName?: string;
}

const VEHICLE_CATEGORIES: VehicleCategory[] = [
  'طقم قتالي',
  'طقم مصفح',
  'هايلكس',
  'شاص خدمات',
  'لاندكروزر',
  'إسعاف ميداني',
  'وايت ماء',
  'دينا تموين',
  'بوزة ديزل',
  'شيول / جرافة',
  'معدة هندسية',
  'ونش إنقاذ',
  'مدرعة تكتيكية',
  'دراجة استطلاع',
  'مولدات كهرباء',
  'منظومات اتصالات',
  'أخرى'
];

const FUEL_OPTIONS: VehicleItem['fuelLevel'][] = [
  'ممتاز (ممتلئ)',
  'جيد (3/4)',
  'متوسط (1/2)',
  'منخفض (1/4)',
  'حرج (خالي)',
  'طاقة شمسية/كهرباء',
  'غير مطبق'
];

const STATUS_OPTIONS: { value: VehicleReadinessStatus; label: string; desc: string }[] = [
  { value: 'جاهزة', label: 'جاهزة للخدمة', desc: 'تعمل بكفاءة عالية في الميدان' },
  { value: 'منصرف', label: 'منصرف بعهدة', desc: 'مسلمة لضابط أو وحدة بموجب أمر صرف' },
  { value: 'لم يتم صرفها', label: 'لم يتم صرفها (مخزنة)', desc: 'متواجدة في هناجر وجاهزية اللواء' },
  { value: 'تحت الصيانة', label: 'تحت الصيانة والإصلاح', desc: 'في الورشة الميدانية أو المركزية' },
  { value: 'خارج الجاهزية', label: 'خارج الجاهزية (معطلة)', desc: 'أعطال جسيمة تمنع التشغيل' },
  { value: 'مرجعة للفنية والحركة المركزية', label: 'مرجعة للفنية والحركة المركزية', desc: 'تم تسليمها وإخلاء العهدة لفرع الفنية الرئيسي' }
];

export const VehicleEditModal: React.FC<VehicleEditModalProps> = ({
  isOpen,
  vehicle,
  onClose,
  onSaveSuccess,
  currentAccountName = 'مسؤول ركن العربات والآليات'
}) => {
  const [formData, setFormData] = useState<Partial<VehicleItem>>({});
  const [isCustomCategory, setIsCustomCategory] = useState(false);
  const [customCategoryText, setCustomCategoryText] = useState('');
  const [isSaving, setIsSaving] = useState(false);
  const [errorMessage, setErrorMessage] = useState('');
  const [successMessage, setSuccessMessage] = useState('');

  useEffect(() => {
    if (vehicle) {
      setFormData({
        name: vehicle.name || '',
        category: vehicle.category,
        plateNumber: vehicle.plateNumber || '',
        engineSerial: vehicle.engineSerial || '',
        status: vehicle.status || 'جاهزة',
        readinessPercentage: vehicle.readinessPercentage ?? 90,
        assignedUnit: vehicle.assignedUnit || '',
        assignedDriverName: vehicle.assignedDriverName || '',
        assignedDriverMilitaryId: vehicle.assignedDriverMilitaryId || '',
        fuelLevel: vehicle.fuelLevel || 'ممتاز (ممتلئ)',
        location: vehicle.location || '',
        lastMaintenanceDate: vehicle.lastMaintenanceDate || '',
        nextMaintenanceDate: vehicle.nextMaintenanceDate || '',
        yearOfModel: vehicle.yearOfModel || '',
        mileageKm: vehicle.mileageKm || 0,
        notes: vehicle.notes || ''
      });

      if (!VEHICLE_CATEGORIES.includes(vehicle.category)) {
        setIsCustomCategory(true);
        setCustomCategoryText(vehicle.category);
      } else {
        setIsCustomCategory(false);
        setCustomCategoryText('');
      }
      setErrorMessage('');
      setSuccessMessage('');
    }
  }, [vehicle, isOpen]);

  if (!isOpen || !vehicle) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMessage('');
    setSuccessMessage('');

    if (!formData.name?.trim()) {
      setErrorMessage('يرجى كتابة اسم أو طراز الآلية / المعدة');
      return;
    }
    if (!formData.plateNumber?.trim()) {
      setErrorMessage('يرجى كتابة رقم اللوحة أو السيريال');
      return;
    }

    const finalCategory: VehicleCategory = isCustomCategory
      ? (customCategoryText.trim() as VehicleCategory) || 'أخرى'
      : (formData.category as VehicleCategory) || 'طقم قتالي';

    setIsSaving(true);

    try {
      const updates: Partial<VehicleItem> = {
        ...formData,
        category: finalCategory,
        readinessPercentage: Number(formData.readinessPercentage) || 0,
        mileageKm: Number(formData.mileageKm) || 0
      };

      StorageService.updateVehicle(vehicle.id, updates, currentAccountName);
      
      const updatedVehicle: VehicleItem = {
        ...vehicle,
        ...updates
      };

      setSuccessMessage('تم حفظ وتحديث بيانات الآلية بنجاح');
      setTimeout(() => {
        setIsSaving(false);
        onSaveSuccess(updatedVehicle);
        onClose();
      }, 500);
    } catch (err: any) {
      console.error(err);
      setErrorMessage('حدث خطأ أثناء حفظ التعديلات');
      setIsSaving(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-950/85 backdrop-blur-md flex items-center justify-center p-3 sm:p-4 overflow-y-auto">
      <div className="bg-slate-900 border border-amber-500/50 rounded-3xl w-full max-w-3xl overflow-hidden shadow-2xl animate-fadeIn my-6">
        {/* Header */}
        <div className="bg-gradient-to-l from-amber-950 via-slate-900 to-amber-900 border-b border-amber-500/30 p-5 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-amber-500/20 border border-amber-500/40 flex items-center justify-center text-amber-400">
              <Truck className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-lg font-black text-white flex items-center gap-2">
                تعديل بيانات العربة / الآلية / المعدة
              </h2>
              <p className="text-xs text-slate-400 font-semibold mt-0.5">
                تحديث المواصفات الفنية، التخصيص الميداني، وحالة الجاهزية لـ ({vehicle.plateNumber})
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="text-slate-400 hover:text-white p-2 rounded-xl bg-slate-800/80 border border-slate-700 cursor-pointer transition-all"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Form Body */}
        <form onSubmit={handleSubmit} className="p-6 space-y-6 max-h-[82vh] overflow-y-auto">
          {errorMessage && (
            <div className="bg-rose-950/60 border border-rose-800 text-rose-300 px-4 py-3 rounded-2xl text-xs flex items-center gap-2">
              <AlertTriangle className="w-4 h-4 flex-shrink-0" />
              <span>{errorMessage}</span>
            </div>
          )}

          {successMessage && (
            <div className="bg-emerald-950/60 border border-emerald-800 text-emerald-300 px-4 py-3 rounded-2xl text-xs flex items-center gap-2">
              <CheckCircle2 className="w-4 h-4 flex-shrink-0" />
              <span>{successMessage}</span>
            </div>
          )}

          {/* Section 1: Basic Identifiers */}
          <div className="bg-slate-950/60 border border-slate-800 p-4 rounded-2xl space-y-4">
            <div className="text-xs font-black text-amber-400 flex items-center gap-2 border-b border-slate-800 pb-2">
              <Hash className="w-4 h-4" />
              البيانات التعريفية واللوحات
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-bold text-slate-300 mb-1.5">
                  اسم أو طراز الآلية / المعدة <span className="text-rose-400">*</span>
                </label>
                <input
                  type="text"
                  value={formData.name || ''}
                  onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                  className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3.5 py-2 text-xs text-white focus:border-amber-500 outline-none"
                  placeholder="مثال: طقم تويوتا شاص قتالي 2024"
                  required
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-300 mb-1.5">
                  رقم اللوحة / الرقم العسكري أو التسلسلي <span className="text-rose-400">*</span>
                </label>
                <input
                  type="text"
                  value={formData.plateNumber || ''}
                  onChange={(e) => setFormData({ ...formData, plateNumber: e.target.value })}
                  className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3.5 py-2 text-xs text-amber-400 font-mono focus:border-amber-500 outline-none"
                  placeholder="مثال: طقم-1042/عسكري"
                  required
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-300 mb-1.5">
                  فئة الآلية أو المعدة
                </label>
                <select
                  value={isCustomCategory ? 'أخرى' : (formData.category || 'طقم قتالي')}
                  onChange={(e) => {
                    if (e.target.value === 'أخرى') {
                      setIsCustomCategory(true);
                    } else {
                      setIsCustomCategory(false);
                      setFormData({ ...formData, category: e.target.value as VehicleCategory });
                    }
                  }}
                  className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3.5 py-2 text-xs text-white focus:border-amber-500 outline-none cursor-pointer"
                >
                  {VEHICLE_CATEGORIES.map((cat) => (
                    <option key={cat} value={cat}>
                      {cat}
                    </option>
                  ))}
                </select>
                {isCustomCategory && (
                  <input
                    type="text"
                    value={customCategoryText}
                    onChange={(e) => setCustomCategoryText(e.target.value)}
                    placeholder="اكتب الفئة المخصصة هنا..."
                    className="w-full mt-2 bg-slate-900 border border-amber-500/60 rounded-xl px-3.5 py-2 text-xs text-white outline-none"
                  />
                )}
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-300 mb-1.5">
                  رقم المحرك / رقم الشاسي (S/N)
                </label>
                <input
                  type="text"
                  value={formData.engineSerial || ''}
                  onChange={(e) => setFormData({ ...formData, engineSerial: e.target.value })}
                  className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3.5 py-2 text-xs text-white font-mono focus:border-amber-500 outline-none"
                  placeholder="مثال: ENG-TOY-2024-99812"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-300 mb-1.5">
                  سنة الصنع / الموديل
                </label>
                <input
                  type="text"
                  value={formData.yearOfModel || ''}
                  onChange={(e) => setFormData({ ...formData, yearOfModel: e.target.value })}
                  className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3.5 py-2 text-xs text-white focus:border-amber-500 outline-none"
                  placeholder="مثال: 2024"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-300 mb-1.5">
                  قراءة العداد (كم) أو ساعات التشغيل
                </label>
                <div className="relative">
                  <input
                    type="number"
                    value={formData.mileageKm ?? 0}
                    onChange={(e) => setFormData({ ...formData, mileageKm: Number(e.target.value) })}
                    className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3.5 py-2 text-xs text-white focus:border-amber-500 outline-none pr-9"
                    placeholder="0"
                  />
                  <Gauge className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
                </div>
              </div>
            </div>
          </div>

          {/* Section 2: Technical Status & Readiness */}
          <div className="bg-slate-950/60 border border-slate-800 p-4 rounded-2xl space-y-4">
            <div className="text-xs font-black text-amber-400 flex items-center gap-2 border-b border-slate-800 pb-2">
              <Activity className="w-4 h-4" />
              حالة الجاهزية والكفاءة الفنية
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-bold text-slate-300 mb-1.5">
                  حالة الجاهزية الرسمية
                </label>
                <select
                  value={formData.status || 'جاهزة'}
                  onChange={(e) => setFormData({ ...formData, status: e.target.value as VehicleReadinessStatus })}
                  className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3.5 py-2 text-xs text-amber-300 font-bold focus:border-amber-500 outline-none cursor-pointer"
                >
                  {STATUS_OPTIONS.map((st) => (
                    <option key={st.value} value={st.value}>
                      {st.label} ({st.desc})
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-300 mb-1.5">
                  نسبة الكفاءة الفنية: <strong className="text-amber-400">{formData.readinessPercentage ?? 90}%</strong>
                </label>
                <div className="flex items-center gap-3">
                  <input
                    type="range"
                    min="0"
                    max="100"
                    value={formData.readinessPercentage ?? 90}
                    onChange={(e) => setFormData({ ...formData, readinessPercentage: Number(e.target.value) })}
                    className="flex-1 accent-amber-500 h-2 bg-slate-800 rounded-lg cursor-pointer"
                  />
                  <input
                    type="number"
                    min="0"
                    max="100"
                    value={formData.readinessPercentage ?? 90}
                    onChange={(e) => setFormData({ ...formData, readinessPercentage: Number(e.target.value) })}
                    className="w-16 bg-slate-900 border border-slate-700 rounded-xl px-2 py-1 text-center text-xs text-white font-bold"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-300 mb-1.5">
                  مستوى الوقود / الطاقة
                </label>
                <div className="relative">
                  <select
                    value={formData.fuelLevel || 'ممتاز (ممتلئ)'}
                    onChange={(e) => setFormData({ ...formData, fuelLevel: e.target.value as VehicleItem['fuelLevel'] })}
                    className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3.5 py-2 text-xs text-white focus:border-amber-500 outline-none cursor-pointer"
                  >
                    {FUEL_OPTIONS.map((f) => (
                      <option key={f} value={f}>
                        {f}
                      </option>
                    ))}
                  </select>
                  <Fuel className="w-4 h-4 text-amber-400 absolute left-3 top-2.5 pointer-events-none" />
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-300 mb-1.5">
                  الموقع الميداني الحالي / المعسكر
                </label>
                <div className="relative">
                  <input
                    type="text"
                    value={formData.location || ''}
                    onChange={(e) => setFormData({ ...formData, location: e.target.value })}
                    className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3.5 py-2 text-xs text-white focus:border-amber-500 outline-none"
                    placeholder="مثال: الموقع القتالي المتقدم - القطاع الشرقي"
                  />
                  <MapPin className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
                </div>
              </div>
            </div>
          </div>

          {/* Section 3: Assignment & Custody */}
          <div className="bg-slate-950/60 border border-slate-800 p-4 rounded-2xl space-y-4">
            <div className="text-xs font-black text-amber-400 flex items-center gap-2 border-b border-slate-800 pb-2">
              <User className="w-4 h-4" />
              التخصيص والمسؤولية الميدانية (العهدة)
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div>
                <label className="block text-xs font-bold text-slate-300 mb-1.5">
                  الوحدة / اللواء المخصص له
                </label>
                <input
                  type="text"
                  value={formData.assignedUnit || ''}
                  onChange={(e) => setFormData({ ...formData, assignedUnit: e.target.value })}
                  className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3.5 py-2 text-xs text-white focus:border-amber-500 outline-none"
                  placeholder="مثال: اللواء الأول - كتيبة المهام"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-300 mb-1.5">
                  اسم السائق / المسؤول عن العهدة
                </label>
                <input
                  type="text"
                  value={formData.assignedDriverName || ''}
                  onChange={(e) => setFormData({ ...formData, assignedDriverName: e.target.value })}
                  className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3.5 py-2 text-xs text-white focus:border-amber-500 outline-none"
                  placeholder="اسم الضابط أو السائق المسلم له"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-300 mb-1.5">
                  الرقم العسكري للمستلم
                </label>
                <input
                  type="text"
                  value={formData.assignedDriverMilitaryId || ''}
                  onChange={(e) => setFormData({ ...formData, assignedDriverMilitaryId: e.target.value })}
                  className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3.5 py-2 text-xs text-white font-mono focus:border-amber-500 outline-none"
                  placeholder="مثال: 109283"
                />
              </div>
            </div>
          </div>

          {/* Section 4: Maintenance Schedule & Notes */}
          <div className="bg-slate-950/60 border border-slate-800 p-4 rounded-2xl space-y-4">
            <div className="text-xs font-black text-amber-400 flex items-center gap-2 border-b border-slate-800 pb-2">
              <Calendar className="w-4 h-4" />
              مواعيد الصيانة والملاحظات الفنية
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-bold text-slate-300 mb-1.5">
                  تاريخ آخر صيانة تم إجراؤها
                </label>
                <input
                  type="date"
                  value={formData.lastMaintenanceDate || ''}
                  onChange={(e) => setFormData({ ...formData, lastMaintenanceDate: e.target.value })}
                  className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3.5 py-2 text-xs text-white focus:border-amber-500 outline-none"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-300 mb-1.5">
                  تاريخ الصيانة الدورية القادمة المقترحة
                </label>
                <input
                  type="date"
                  value={formData.nextMaintenanceDate || ''}
                  onChange={(e) => setFormData({ ...formData, nextMaintenanceDate: e.target.value })}
                  className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3.5 py-2 text-xs text-white focus:border-amber-500 outline-none"
                />
              </div>

              <div className="md:col-span-2">
                <label className="block text-xs font-bold text-slate-300 mb-1.5">
                  ملاحظات ومواصفات فنية إضافية
                </label>
                <textarea
                  value={formData.notes || ''}
                  onChange={(e) => setFormData({ ...formData, notes: e.target.value })}
                  rows={3}
                  className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3.5 py-2.5 text-xs text-white focus:border-amber-500 outline-none resize-none leading-relaxed"
                  placeholder="أي ملاحظات حول حالة المحرك، الإطارات، التجهيزات العسكرية، أو إضافات السلاح..."
                />
              </div>
            </div>
          </div>

          {/* Footer Actions */}
          <div className="border-t border-slate-800 pt-4 flex items-center justify-end gap-3">
            <button
              type="button"
              onClick={onClose}
              className="px-5 py-2.5 rounded-2xl bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-bold transition-all cursor-pointer"
            >
              إلغاء
            </button>

            <button
              type="submit"
              disabled={isSaving}
              className="px-6 py-2.5 rounded-2xl bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-600 hover:to-amber-700 text-slate-950 font-black text-xs shadow-lg shadow-amber-500/20 flex items-center gap-2 transition-all cursor-pointer disabled:opacity-50"
            >
              <Save className="w-4 h-4" />
              {isSaving ? 'جارٍ حفظ التعديلات...' : 'حفظ التعديلات وتحديث السجل'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
