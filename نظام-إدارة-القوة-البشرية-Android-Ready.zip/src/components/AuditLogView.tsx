import React, { useState, useEffect } from 'react';
import { ShieldAlert, Search, Filter, Clock, User, Building, FileCheck, ShieldCheck, Eye, Lock, Database, RefreshCw, Trash2, CheckCircle2, AlertTriangle, XCircle, ArrowUpRight, ArrowDownLeft } from 'lucide-react';
import { AuditLogEntry, DepartmentRole, UserAccount, StorageOperationLog } from '../types';
import { getAllAccounts } from '../data/accountsData';
import { StorageService } from '../lib/storage';

interface AuditLogViewProps {
  auditLogs: AuditLogEntry[];
  currentAccount?: UserAccount;
}

export const AuditLogView: React.FC<AuditLogViewProps> = ({ auditLogs, currentAccount }) => {
  const [activeTab, setActiveTab] = useState<'audit' | 'storage_diagnostic'>('audit');
  const [searchTerm, setSearchTerm] = useState('');
  const [deptFilter, setDeptFilter] = useState('الكل');
  const [accountFilter, setAccountFilter] = useState('الكل');

  // Storage Diagnostic Logs State
  const [storageLogs, setStorageLogs] = useState<StorageOperationLog[]>([]);
  const [storageTypeFilter, setStorageTypeFilter] = useState<string>('الكل');
  const [storageStatusFilter, setStorageStatusFilter] = useState<string>('الكل');

  const loadStorageLogs = () => {
    setStorageLogs(StorageService.getStorageOperationLogs());
  };

  useEffect(() => {
    loadStorageLogs();
  }, [activeTab]);

  const isHQ = currentAccount?.isMainCommand ?? true;
  const allAccounts = getAllAccounts();

  const filteredLogs = auditLogs.filter((log) => {
    const search = searchTerm.trim().toLowerCase();
    const matchesSearch =
      !search ||
      String(log.userName || '').toLowerCase().includes(search) ||
      String(log.action || '').toLowerCase().includes(search) ||
      String(log.targetName || '').toLowerCase().includes(search) ||
      String(log.targetMilitaryId || '').toLowerCase().includes(search) ||
      String(log.accountName || '').toLowerCase().includes(search) ||
      String(log.department || '').toLowerCase().includes(search) ||
      String(log.details || '').toLowerCase().includes(search);

    const matchesDept = deptFilter === 'الكل' || log.department === deptFilter;

    const matchesAccount =
      accountFilter === 'الكل' ||
      log.accountId === accountFilter ||
      (log.accountName && (log.accountName === accountFilter || log.accountName.includes(accountFilter)));

    return matchesSearch && matchesDept && matchesAccount;
  });

  const filteredStorageLogs = storageLogs.filter((log) => {
    const search = searchTerm.trim().toLowerCase();
    const matchesSearch =
      !search ||
      String(log.actor || '').toLowerCase().includes(search) ||
      String(log.type || '').toLowerCase().includes(search) ||
      String(log.fullName || '').toLowerCase().includes(search) ||
      String(log.militaryId || '').toLowerCase().includes(search) ||
      String(log.unit || '').toLowerCase().includes(search) ||
      String(log.details || '').toLowerCase().includes(search);

    const matchesType = storageTypeFilter === 'الكل' || log.type === storageTypeFilter;
    const matchesStatus = storageStatusFilter === 'الكل' || log.status === storageStatusFilter;

    return matchesSearch && matchesType && matchesStatus;
  });

  const handleClearStorageLogs = () => {
    if (window.confirm('هل أنت متأكد من رغبتك في تفريغ سجل تتبع التخزين؟')) {
      StorageService.clearStorageOperationLogs();
      loadStorageLogs();
    }
  };

  return (
    <div className="space-y-6 pb-12">
      {/* Top Banner - HQ vs Isolated Account */}
      {isHQ ? (
        <div className="bg-gradient-to-r from-amber-900 via-slate-900 to-amber-950 text-white rounded-2xl p-6 shadow-md border border-amber-500/30">
          <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
            <div className="flex items-center space-x-3 space-x-reverse">
              <div className="p-3 bg-amber-500/20 rounded-xl border border-amber-400/30">
                <ShieldCheck className="w-7 h-7 text-amber-400" />
              </div>
              <div>
                <div className="flex items-center space-x-2 space-x-reverse">
                  <h2 className="text-lg font-black text-white font-['Tajawal']">
                    سجل التدقيق المركزي ومراقبة التخزين والمزامنة
                  </h2>
                  <span className="bg-amber-500/30 text-amber-300 border border-amber-400/40 text-[10px] font-bold px-2 py-0.5 rounded-full">
                    👑 إشراف شامل وتتبع حي
                  </span>
                </div>
                <p className="text-xs text-amber-100/80 mt-1 font-medium">
                  مراقبة فورية وتوثيق رقمي كامل لكافة عمليات إدخال البيانات، التعديلات، وعمليات حفظ ومزامنة قاعدة البيانات السحابية Firebase.
                </p>
              </div>
            </div>

            <div className="flex items-center gap-2">
              <div className="text-xs font-mono bg-black/40 border border-amber-500/30 px-3 py-2 rounded-xl text-amber-300 font-bold whitespace-nowrap">
                قيود التدقيق: {auditLogs.length} | سجلات التخزين: {storageLogs.length}
              </div>
            </div>
          </div>
        </div>
      ) : (
        <div className="bg-gradient-to-r from-emerald-900 via-slate-900 to-emerald-950 text-white rounded-2xl p-6 shadow-md border border-emerald-500/30">
          <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
            <div className="flex items-center space-x-3 space-x-reverse">
              <div className="p-3 bg-emerald-500/20 rounded-xl border border-emerald-400/30">
                <Lock className="w-7 h-7 text-emerald-400" />
              </div>
              <div>
                <div className="flex items-center space-x-2 space-x-reverse">
                  <h2 className="text-lg font-black text-white font-['Tajawal']">
                    سجل التدقيق والتتبع - ({currentAccount?.name})
                  </h2>
                  <span className="bg-emerald-500/30 text-emerald-300 border border-emerald-400/40 text-[10px] font-bold px-2 py-0.5 rounded-full">
                    🛡️ سجل معزول للحساب
                  </span>
                </div>
                <p className="text-xs text-emerald-100/80 mt-1 font-medium">
                  يقتصر العرض على التعديلات والحركات والمدخلات المسجلة بواسطة ({currentAccount?.name}) أو الخاصة بقوة هذا الحساب فقط.
                </p>
              </div>
            </div>

            <div className="text-xs font-mono bg-black/40 border border-emerald-500/30 px-3 py-2 rounded-xl text-emerald-300 font-bold whitespace-nowrap">
              القيود المسجلة: {auditLogs.length}
            </div>
          </div>
        </div>
      )}

      {/* Tabs Selector */}
      <div className="flex items-center space-x-2 space-x-reverse bg-slate-100 p-1.5 rounded-2xl border border-slate-200">
        <button
          onClick={() => setActiveTab('audit')}
          className={`flex-1 flex items-center justify-center space-x-2 space-x-reverse py-2.5 px-4 rounded-xl font-bold text-xs transition-all ${
            activeTab === 'audit'
              ? 'bg-white text-slate-900 shadow-sm border border-slate-200'
              : 'text-slate-600 hover:text-slate-900'
          }`}
        >
          <ShieldAlert className="w-4 h-4 text-emerald-600" />
          <span>سجل التدقيق الإداري والعمليات ({filteredLogs.length})</span>
        </button>

        <button
          onClick={() => {
            setActiveTab('storage_diagnostic');
            loadStorageLogs();
          }}
          className={`flex-1 flex items-center justify-center space-x-2 space-x-reverse py-2.5 px-4 rounded-xl font-bold text-xs transition-all ${
            activeTab === 'storage_diagnostic'
              ? 'bg-white text-slate-900 shadow-sm border border-slate-200'
              : 'text-slate-600 hover:text-slate-900'
          }`}
        >
          <Database className="w-4 h-4 text-amber-600" />
          <span>سجل تتبع التخزين والمزامنة السحابية ({storageLogs.length})</span>
        </button>
      </div>

      {activeTab === 'audit' ? (
        <>
          {/* Filter & Search Controls */}
          <div className="bg-white border border-slate-200 rounded-2xl p-4 shadow-sm grid grid-cols-1 sm:grid-cols-3 gap-3">
            <div className="relative">
              <Search className="w-4 h-4 absolute right-3 top-1/2 -translate-y-1/2 text-slate-400" />
              <input
                type="text"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                placeholder="بحث بالاسم، الإجراء، الرقم الوظيفي..."
                className="w-full bg-slate-50 border border-slate-300 rounded-xl pr-9 pl-3 py-2 text-xs text-slate-800 placeholder-slate-400 focus:outline-none focus:bg-white focus:border-emerald-600"
              />
            </div>

            {/* Account Filter - visible especially for HQ */}
            <div>
              <select
                value={accountFilter}
                onChange={(e) => setAccountFilter(e.target.value)}
                className="w-full bg-slate-50 border border-slate-300 rounded-xl px-3 py-2 text-xs text-slate-800 font-bold focus:outline-none focus:bg-white focus:border-emerald-600"
              >
                <option value="الكل">جميع الحسابات والألوية</option>
                {allAccounts.map((acc) => (
                  <option key={acc.id} value={acc.id}>
                    {acc.name} ({acc.badge})
                  </option>
                ))}
              </select>
            </div>

            <div>
              <select
                value={deptFilter}
                onChange={(e) => setDeptFilter(e.target.value)}
                className="w-full bg-slate-50 border border-slate-300 rounded-xl px-3 py-2 text-xs text-slate-800 font-bold focus:outline-none focus:bg-white focus:border-emerald-600"
              >
                <option value="الكل">جميع الإدارات والفروع</option>
                <option value="القيادة الرئيسية">القيادة الرئيسية</option>
                <option value="إدارة الموارد البشرية">إدارة الموارد البشرية</option>
                <option value="إدارة التسليح">إدارة التسليح والذخيرة</option>
                <option value="إدارة التدريب">إدارة التدريب والدورات</option>
                <option value="الإدارة المالية">الإدارة المالية والميزانية</option>
                <option value="الاستخبارات والأمن">الاستخبارات والأمن العسكري</option>
                <option value="الإدارة الطبية العسكرية">الإدارة الطبية العسكرية</option>
                <option value="الإدارة الفنية">الإدارة الفنية والصيانة</option>
                <option value="إدارة التموين والإمداد">إدارة التموين والإمداد</option>
                <option value="جاهزية العربات والآليات">فرع جاهزية العربات والآليات</option>
              </select>
            </div>
          </div>

          {/* Audit Log Timeline Table */}
          <div className="bg-white border border-slate-200 rounded-2xl shadow-sm overflow-hidden">
            <div className="overflow-x-auto">
              <table className="w-full text-right text-xs">
                <thead className="bg-slate-50 text-slate-700 font-bold border-b border-slate-200">
                  <tr>
                    <th className="px-4 py-3">الوقت والتاريخ</th>
                    <th className="px-4 py-3">الحساب / اللواء</th>
                    <th className="px-4 py-3">المستخدم والفرع</th>
                    <th className="px-4 py-3">نوع الإجراء</th>
                    <th className="px-4 py-3">الفرد المستهدف</th>
                    <th className="px-4 py-3">تفاصيل الحركة المسجلة</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {filteredLogs.length === 0 ? (
                    <tr>
                      <td colSpan={6} className="text-center py-8 text-slate-400 font-bold">
                        لا توجد قيود تدقيق مطابقة لمعايير البحث الحالية
                      </td>
                    </tr>
                  ) : (
                    filteredLogs.map((log) => {
                      const accName = log.accountName || 'لواء القيادة';
                      const isHqLog = accName.includes('القيادة') || log.accountId === 'hq';

                      return (
                        <tr key={log.id} className="hover:bg-slate-50 transition-colors">
                          <td className="px-4 py-3 font-mono text-slate-500 text-[11px] whitespace-nowrap">
                            {log.timestamp}
                          </td>
                          <td className="px-4 py-3 whitespace-nowrap">
                            <span
                              className={`inline-flex items-center px-2 py-0.5 rounded-full text-[10px] font-bold border ${
                                isHqLog
                                  ? 'bg-amber-50 text-amber-800 border-amber-300'
                                  : 'bg-emerald-50 text-emerald-800 border-emerald-300'
                              }`}
                            >
                              {accName}
                            </span>
                          </td>
                          <td className="px-4 py-3">
                            <div className="font-bold text-slate-900">{log.userName}</div>
                            <div className="text-[10px] text-slate-500 font-medium">{log.department}</div>
                          </td>
                          <td className="px-4 py-3">
                            <span className="bg-slate-100 text-slate-800 border border-slate-300 px-2 py-0.5 rounded text-[11px] font-bold">
                              {log.action}
                            </span>
                          </td>
                          <td className="px-4 py-3">
                            <div className="font-bold text-slate-800">{log.targetName}</div>
                            <div className="text-[10px] text-slate-500 font-mono">{log.targetMilitaryId}</div>
                          </td>
                          <td className="px-4 py-3 text-slate-700 max-w-sm">{log.details}</td>
                        </tr>
                      );
                    })
                  )}
                </tbody>
              </table>
            </div>
          </div>
        </>
      ) : (
        <>
          {/* Storage Diagnostic Tab Controls */}
          <div className="bg-white border border-slate-200 rounded-2xl p-4 shadow-sm flex flex-col md:flex-row items-stretch md:items-center justify-between gap-3">
            <div className="flex-1 grid grid-cols-1 sm:grid-cols-3 gap-3">
              <div className="relative">
                <Search className="w-4 h-4 absolute right-3 top-1/2 -translate-y-1/2 text-slate-400" />
                <input
                  type="text"
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  placeholder="بحث في سجل التخزين..."
                  className="w-full bg-slate-50 border border-slate-300 rounded-xl pr-9 pl-3 py-2 text-xs text-slate-800 placeholder-slate-400 focus:outline-none focus:bg-white focus:border-amber-600"
                />
              </div>

              <div>
                <select
                  value={storageTypeFilter}
                  onChange={(e) => setStorageTypeFilter(e.target.value)}
                  className="w-full bg-slate-50 border border-slate-300 rounded-xl px-3 py-2 text-xs text-slate-800 font-bold focus:outline-none focus:bg-white focus:border-amber-600"
                >
                  <option value="الكل">جميع أنواع العمليات</option>
                  <option value="ADD_PERSONNEL">إضافة فرد جديد (ADD)</option>
                  <option value="UPDATE_PERSONNEL">تعديل فرد (UPDATE)</option>
                  <option value="DELETE_PERSONNEL">حذف إلى المحذوفات (DELETE)</option>
                  <option value="RESTORE_PERSONNEL">استعادة من المحذوفات (RESTORE)</option>
                  <option value="SAVE_PERSONNEL">حفظ القوة الإجمالية (SAVE)</option>
                  <option value="CLOUD_SNAPSHOT_MERGE">دمج المزامنة السحابية (CLOUD_MERGE)</option>
                  <option value="DEDUPLICATE">دمج التكرار (DEDUPLICATE)</option>
                </select>
              </div>

              <div>
                <select
                  value={storageStatusFilter}
                  onChange={(e) => setStorageStatusFilter(e.target.value)}
                  className="w-full bg-slate-50 border border-slate-300 rounded-xl px-3 py-2 text-xs text-slate-800 font-bold focus:outline-none focus:bg-white focus:border-amber-600"
                >
                  <option value="الكل">جميع الحالات</option>
                  <option value="نجاح">نجاح</option>
                  <option value="تحذير">تحذير</option>
                  <option value="خطأ">خطأ</option>
                </select>
              </div>
            </div>

            <div className="flex items-center space-x-2 space-x-reverse self-end md:self-auto">
              <button
                onClick={loadStorageLogs}
                className="flex items-center space-x-1.5 space-x-reverse bg-slate-100 hover:bg-slate-200 text-slate-800 px-3 py-2 rounded-xl text-xs font-bold border border-slate-300 transition-colors"
                title="تحديث السجلات"
              >
                <RefreshCw className="w-3.5 h-3.5" />
                <span>تحديث</span>
              </button>

              <button
                onClick={handleClearStorageLogs}
                className="flex items-center space-x-1.5 space-x-reverse bg-rose-50 hover:bg-rose-100 text-rose-700 px-3 py-2 rounded-xl text-xs font-bold border border-rose-200 transition-colors"
                title="تفريغ السجل"
              >
                <Trash2 className="w-3.5 h-3.5" />
                <span>تفريغ السجل</span>
              </button>
            </div>
          </div>

          {/* Storage Diagnostic Table */}
          <div className="bg-white border border-slate-200 rounded-2xl shadow-sm overflow-hidden">
            <div className="overflow-x-auto">
              <table className="w-full text-right text-xs">
                <thead className="bg-slate-50 text-slate-700 font-bold border-b border-slate-200">
                  <tr>
                    <th className="px-4 py-3">الوقت</th>
                    <th className="px-4 py-3">نوع العملية</th>
                    <th className="px-4 py-3">المنفذ / الفرع</th>
                    <th className="px-4 py-3">الفرد / المستهدف</th>
                    <th className="px-4 py-3 text-center">العدد (قبل ➔ بعد)</th>
                    <th className="px-4 py-3">الحالة</th>
                    <th className="px-4 py-3">تفاصيل التتبع الدقيقة</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {filteredStorageLogs.length === 0 ? (
                    <tr>
                      <td colSpan={7} className="text-center py-10 text-slate-400 font-bold">
                        لا توجد سجلات تتبع للتخزين مطابقة للبحث
                      </td>
                    </tr>
                  ) : (
                    filteredStorageLogs.map((log) => {
                      const isSuccess = log.status === 'نجاح';
                      const isWarning = log.status === 'تحذير';

                      const typeBadge = (() => {
                        switch (log.type) {
                          case 'ADD_PERSONNEL':
                            return 'bg-emerald-50 text-emerald-700 border-emerald-300';
                          case 'UPDATE_PERSONNEL':
                            return 'bg-blue-50 text-blue-700 border-blue-300';
                          case 'DELETE_PERSONNEL':
                            return 'bg-rose-50 text-rose-700 border-rose-300';
                          case 'RESTORE_PERSONNEL':
                            return 'bg-purple-50 text-purple-700 border-purple-300';
                          case 'CLOUD_SNAPSHOT_MERGE':
                            return 'bg-amber-50 text-amber-800 border-amber-300';
                          case 'SAVE_PERSONNEL':
                            return 'bg-teal-50 text-teal-700 border-teal-300';
                          default:
                            return 'bg-slate-50 text-slate-700 border-slate-300';
                        }
                      })();

                      return (
                        <tr key={log.id} className="hover:bg-slate-50 transition-colors">
                          <td className="px-4 py-3 font-mono text-slate-500 text-[11px] whitespace-nowrap">
                            {log.timestamp}
                          </td>
                          <td className="px-4 py-3 whitespace-nowrap">
                            <span className={`inline-flex items-center px-2 py-0.5 rounded-full text-[10px] font-bold border ${typeBadge}`}>
                              {log.type}
                            </span>
                          </td>
                          <td className="px-4 py-3">
                            <div className="font-bold text-slate-900">{log.actor}</div>
                            <div className="text-[10px] text-slate-500 font-medium">{log.actorDepartment || '-'}</div>
                          </td>
                          <td className="px-4 py-3">
                            {log.fullName ? (
                              <>
                                <div className="font-bold text-slate-800">{log.rank ? `${log.rank} / ` : ''}{log.fullName}</div>
                                <div className="text-[10px] text-slate-500 font-mono">{log.militaryId || '-'} {log.unit ? `(${log.unit})` : ''}</div>
                              </>
                            ) : (
                              <span className="text-slate-400 font-medium">سجل عام</span>
                            )}
                          </td>
                          <td className="px-4 py-3 text-center whitespace-nowrap font-mono">
                            {log.countBefore !== undefined && log.countAfter !== undefined ? (
                              <span className="inline-flex items-center space-x-1 space-x-reverse bg-slate-100 px-2 py-0.5 rounded border border-slate-200 text-[11px] font-bold text-slate-700">
                                <span>{log.countBefore}</span>
                                <span className="text-slate-400">➔</span>
                                <span className="text-slate-900">{log.countAfter}</span>
                                {log.deltaCount !== undefined && log.deltaCount !== 0 && (
                                  <span className={`text-[10px] font-bold ${log.deltaCount > 0 ? 'text-emerald-600' : 'text-rose-600'}`}>
                                    ({log.deltaCount > 0 ? `+${log.deltaCount}` : log.deltaCount})
                                  </span>
                                )}
                              </span>
                            ) : (
                              <span className="text-slate-400">-</span>
                            )}
                          </td>
                          <td className="px-4 py-3 whitespace-nowrap">
                            <span
                              className={`inline-flex items-center space-x-1 space-x-reverse px-2 py-0.5 rounded text-[10px] font-bold border ${
                                isSuccess
                                  ? 'bg-emerald-50 text-emerald-800 border-emerald-300'
                                  : isWarning
                                  ? 'bg-amber-50 text-amber-800 border-amber-300'
                                  : 'bg-rose-50 text-rose-800 border-rose-300'
                              }`}
                            >
                              {isSuccess ? (
                                <CheckCircle2 className="w-3 h-3 text-emerald-600" />
                              ) : isWarning ? (
                                <AlertTriangle className="w-3 h-3 text-amber-600" />
                              ) : (
                                <XCircle className="w-3 h-3 text-rose-600" />
                              )}
                              <span>{log.status}</span>
                            </span>
                          </td>
                          <td className="px-4 py-3 text-slate-700 max-w-md">
                            <div>{log.details}</div>
                            {log.changesSummary && log.changesSummary.length > 0 && (
                              <div className="mt-1 flex flex-wrap gap-1">
                                {log.changesSummary.map((ch, idx) => (
                                  <span key={idx} className="bg-slate-100 border border-slate-200 text-slate-700 text-[10px] px-1.5 py-0.2 rounded">
                                    {ch}
                                  </span>
                                ))}
                              </div>
                            )}
                          </td>
                        </tr>
                      );
                    })
                  )}
                </tbody>
              </table>
            </div>
          </div>
        </>
      )}
    </div>
  );
};

