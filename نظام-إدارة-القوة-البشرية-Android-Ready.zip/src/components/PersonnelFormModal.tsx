import React, { useState, useEffect, useRef } from 'react';
import { X, Save, User, Shield, BookOpen, Fingerprint, Image, AlertTriangle, RotateCcw, CheckCircle2, ChevronRight, ChevronLeft, ArrowRight, ArrowLeft } from 'lucide-react';
import { PersonnelRecord, MilitaryRank, PersonnelStatus } from '../types';
import { ImageUploadPicker } from './ImageUploadPicker';
import { StorageService } from '../lib/storage';

const DRAFT_STORAGE_KEY = 'military_personnel_entry_draft_v1';

interface PersonnelFormModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSave: (record: PersonnelRecord) => void;
  editingPersonnel?: PersonnelRecord | null;
  defaultUnit?: string;
}

export const PersonnelFormModal: React.FC<PersonnelFormModalProps> = ({
  isOpen,
  onClose,
  onSave,
  editingPersonnel,
  defaultUnit
}) => {
  const [activeSubTab, setActiveSubTab] = useState<'basic' | 'military' | 'qualifications'>('basic');
  const [hasRestoredDraft, setHasRestoredDraft] = useState(false);
  const isInitialMount = useRef(true);

  // Form State
  const [militaryId, setMilitaryId] = useState('');
  const [nationalId, setNationalId] = useState('');
  const [fullName, setFullName] = useState('');
  const [rank, setRank] = useState<MilitaryRank>('جندي');
  const [dob, setDob] = useState('1998-01-01');
  const [pob, setPob] = useState('صنعاء');
  const [maritalStatus, setMaritalStatus] = useState<'أعزب' | 'متزوج' | 'مطلق' | 'أرمل'>('أعزب');
  const [education, setEducation] = useState('ثانوية عامة');
  const [specialization, setSpecialization] = useState('مشاة عامة');
  const [bloodType, setBloodType] = useState<'A+' | 'A-' | 'B+' | 'B-' | 'AB+' | 'AB-' | 'O+' | 'O-'>('O+');
  const [phone, setPhone] = useState('0500000000');
  const [motherName, setMotherName] = useState('');
  const [guarantorName, setGuarantorName] = useState('');
  const [relativeName, setRelativeName] = useState('');
  const [relativePhone, setRelativePhone] = useState('');
  const [photoUrl, setPhotoUrl] = useState('');
  const [biometricsRecorded, setBiometricsRecorded] = useState(true);

  const [unit, setUnit] = useState('اللواء الأول المدرع');
  const [battalion, setBattalion] = useState('الكتيبة الأولى دبابات');
  const [company, setCompany] = useState('السرية الأولى');
  const [platoon, setPlatoon] = useState('الفصيل الأول');
  const [jobTitle, setJobTitle] = useState('جندي مشاة مرافقة');
  const [enlistmentDate, setEnlistmentDate] = useState('2022-01-01');
  const [currentStatus, setCurrentStatus] = useState<PersonnelStatus>('متواجد');
  const [secondedUnit, setSecondedUnit] = useState('');
  const [trainingCourseType, setTrainingCourseType] = useState('');

  // Handle initialization and draft recovery
  useEffect(() => {
    if (!isOpen) return;

    if (editingPersonnel) {
      setHasRestoredDraft(false);
      setMilitaryId(editingPersonnel.militaryId);
      setNationalId(editingPersonnel.nationalId);
      setFullName(editingPersonnel.fullName);
      setRank(editingPersonnel.rank);
      setDob(editingPersonnel.dob);
      setPob(editingPersonnel.pob);
      setMaritalStatus(editingPersonnel.maritalStatus);
      setEducation(editingPersonnel.education);
      setSpecialization(editingPersonnel.specialization);
      setBloodType(editingPersonnel.bloodType);
      setPhone(editingPersonnel.phone);
      setMotherName(editingPersonnel.motherName || '');
      setGuarantorName(editingPersonnel.guarantorName || '');
      setRelativeName(editingPersonnel.relativeName || '');
      setRelativePhone(editingPersonnel.relativePhone || '');
      setPhotoUrl(editingPersonnel.photoUrl);
      setBiometricsRecorded(editingPersonnel.biometricsRecorded);
      setUnit(editingPersonnel.unit);
      setBattalion(editingPersonnel.battalion);
      setCompany(editingPersonnel.company);
      setPlatoon(editingPersonnel.platoon);
      setJobTitle(editingPersonnel.jobTitle);
      setEnlistmentDate(editingPersonnel.enlistmentDate);
      setCurrentStatus(editingPersonnel.currentStatus);
      setSecondedUnit(editingPersonnel.secondedUnit || '');
      setTrainingCourseType(editingPersonnel.trainingCourseType || '');
    } else {
      // Check if there is an unsaved draft saved locally from prior session or app update
      try {
        const savedDraftRaw = localStorage.getItem(DRAFT_STORAGE_KEY);
        if (savedDraftRaw) {
          const draft = JSON.parse(savedDraftRaw);
          if (draft && (draft.fullName || draft.militaryId)) {
            setMilitaryId(draft.militaryId || `MIL-${Math.floor(100000 + Math.random() * 900000)}`);
            setNationalId(draft.nationalId || `10${Math.floor(100000000 + Math.random() * 900000000)}`);
            setFullName(draft.fullName || '');
            setRank(draft.rank || 'جندي');
            setDob(draft.dob || '1998-01-01');
            setPob(draft.pob || 'صنعاء');
            setMaritalStatus(draft.maritalStatus || 'أعزب');
            setEducation(draft.education || 'ثانوية عامة');
            setSpecialization(draft.specialization || 'مشاة عامة');
            setBloodType(draft.bloodType || 'O+');
            setPhone(draft.phone || '0501234567');
            setMotherName(draft.motherName || '');
            setGuarantorName(draft.guarantorName || '');
            setRelativeName(draft.relativeName || '');
            setRelativePhone(draft.relativePhone || '');
            setPhotoUrl(draft.photoUrl || '');
            setBiometricsRecorded(draft.biometricsRecorded ?? true);
            setUnit(draft.unit || (defaultUnit && defaultUnit !== 'الكل' ? defaultUnit : 'اللواء الأول'));
            setBattalion(draft.battalion || 'الكتيبة الأولى دبابات');
            setCompany(draft.company || 'السرية الأولى');
            setPlatoon(draft.platoon || 'الفصيل الأول');
            setJobTitle(draft.jobTitle || 'جندي مشاة مرافقة');
            setEnlistmentDate(draft.enlistmentDate || '2022-01-01');
            setCurrentStatus(draft.currentStatus || 'متواجد');
            setSecondedUnit(draft.secondedUnit || '');
            setTrainingCourseType(draft.trainingCourseType || '');
            setHasRestoredDraft(true);
            return;
          }
        }
      } catch (e) {}

      // Fresh initialization
      setHasRestoredDraft(false);
      setMilitaryId(`MIL-${Math.floor(100000 + Math.random() * 900000)}`);
      setNationalId(`10${Math.floor(100000000 + Math.random() * 900000000)}`);
      setFullName('');
      setRank('جندي');
      setDob('1998-01-01');
      setPob('صنعاء');
      setMaritalStatus('أعزب');
      setEducation('ثانوية عامة');
      setSpecialization('مشاة عامة');
      setBloodType('O+');
      setPhone('0501234567');
      setMotherName('');
      setGuarantorName('');
      setRelativeName('');
      setRelativePhone('');
      setPhotoUrl('');
      setBiometricsRecorded(true);
      setUnit(defaultUnit && defaultUnit !== 'الكل' ? defaultUnit : 'اللواء الأول');
      setBattalion('الكتيبة الأولى دبابات');
      setCompany('السرية الأولى');
      setPlatoon('الفصيل الأول');
      setJobTitle('جندي مشاة مرافقة');
      setEnlistmentDate('2022-01-01');
      setCurrentStatus('متواجد');
      setSecondedUnit('');
      setTrainingCourseType('');
    }
  }, [editingPersonnel, isOpen]);

  // Debounced auto-save draft to device storage to prevent any data loss on refresh or update
  useEffect(() => {
    if (!isOpen || editingPersonnel) return;
    if (isInitialMount.current) {
      isInitialMount.current = false;
      return;
    }

    const timer = setTimeout(() => {
      if (fullName.trim().length > 0 || militaryId) {
        try {
          const draftPayload = {
            militaryId,
            nationalId,
            fullName,
            rank,
            dob,
            pob,
            maritalStatus,
            education,
            specialization,
            bloodType,
            phone,
            motherName,
            guarantorName,
            relativeName,
            relativePhone,
            photoUrl: photoUrl.startsWith('data:image') && photoUrl.length > 30000 ? '' : photoUrl,
            biometricsRecorded,
            unit,
            battalion,
            company,
            platoon,
            jobTitle,
            enlistmentDate,
            currentStatus,
            secondedUnit,
            trainingCourseType
          };
          localStorage.setItem(DRAFT_STORAGE_KEY, JSON.stringify(draftPayload));
        } catch (e) {}
      }
    }, 400);

    return () => clearTimeout(timer);
  }, [
    isOpen,
    editingPersonnel,
    militaryId,
    nationalId,
    fullName,
    rank,
    dob,
    pob,
    maritalStatus,
    education,
    specialization,
    bloodType,
    phone,
    motherName,
    guarantorName,
    relativeName,
    relativePhone,
    photoUrl,
    biometricsRecorded,
    unit,
    battalion,
    company,
    platoon,
    jobTitle,
    enlistmentDate,
    currentStatus,
    secondedUnit,
    trainingCourseType
  ]);

  const clearDraft = () => {
    try {
      localStorage.removeItem(DRAFT_STORAGE_KEY);
      setHasRestoredDraft(false);
      setMilitaryId(`MIL-${Math.floor(100000 + Math.random() * 900000)}`);
      setNationalId(`10${Math.floor(100000000 + Math.random() * 900000000)}`);
      setFullName('');
      setSecondedUnit('');
      setTrainingCourseType('');
    } catch {}
  };

  if (!isOpen) return null;

  const duplicateMatch = !editingPersonnel
    ? StorageService.checkForDuplicatePersonnel(militaryId, nationalId, fullName)
    : undefined;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!fullName || !militaryId) return;

    const record: PersonnelRecord = {
      militaryId,
      nationalId,
      fullName,
      rank,
      dob,
      pob,
      maritalStatus,
      education,
      specialization,
      bloodType,
      phone,
      motherName,
      guarantorName,
      relativeName,
      relativePhone,
      photoUrl,
      biometricsRecorded,
      unit,
      battalion,
      company,
      platoon,
      jobTitle,
      enlistmentDate,
      currentStatus,
      secondedUnit: currentStatus === 'منتدب' ? secondedUnit : undefined,
      trainingCourseType: (currentStatus === 'دورة تدريبية داخلية' || currentStatus === 'دورة تدريبية خارجية') ? trainingCourseType : undefined,
      logs: editingPersonnel?.logs || {
        movement: [],
        attendance: [],
        medical: [],
        financial: [],
        security: [],
        armament: [],
        training: [],
        attachments: []
      }
    };

    onSave(record);
    try {
      localStorage.removeItem(DRAFT_STORAGE_KEY);
    } catch {}
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex flex-col sm:items-center sm:justify-center p-0 sm:p-4 bg-slate-950/80 backdrop-blur-xs overflow-hidden">
      <div className="relative w-full max-w-4xl bg-white sm:border sm:border-slate-200 sm:rounded-3xl shadow-2xl overflow-hidden flex flex-col h-[100dvh] sm:h-auto sm:max-h-[94vh] animate-in fade-in zoom-in-95 duration-200">
        
        {/* Header */}
        <div className="flex items-center justify-between px-3 sm:px-6 py-2.5 sm:py-3.5 bg-slate-900 border-b border-slate-800 shrink-0">
          <div className="flex items-center space-x-2.5 sm:space-x-3 space-x-reverse min-w-0">
            <div className="w-8 h-8 sm:w-10 sm:h-10 rounded-xl bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 flex items-center justify-center font-bold shrink-0">
              <Shield className="w-4 h-4 sm:w-5 sm:h-5" />
            </div>
            <div className="min-w-0">
              <h3 className="text-xs sm:text-base font-bold text-white font-['Tajawal'] truncate">
                {editingPersonnel ? `تعديل ملف الفرد: ${editingPersonnel.fullName}` : 'إضافة فرد جديد للقوة البشرية'}
              </h3>
              <p className="text-[10px] sm:text-[11px] text-slate-400 truncate">
                {activeSubTab === 'basic' && 'النافذة 1: البيانات الشخصية والأساسية'}
                {activeSubTab === 'military' && 'النافذة 2: البيانات والرتبة العسكرية والوحدات'}
                {activeSubTab === 'qualifications' && 'النافذة 3: المؤهلات والتخصص والجاهزية'}
              </p>
            </div>
          </div>

          <div className="flex items-center space-x-1.5 sm:space-x-2 space-x-reverse shrink-0">
            <button
              type="button"
              onClick={onClose}
              className="p-1.5 sm:p-2 text-slate-400 hover:text-white bg-slate-800 hover:bg-slate-700 rounded-lg sm:rounded-xl transition-colors cursor-pointer"
              title="إغلاق النافذة"
            >
              <X className="w-4 h-4 sm:w-5 sm:h-5" />
            </button>
          </div>
        </div>

        {/* Restored Draft Banner */}
        {hasRestoredDraft && !editingPersonnel && (
          <div className="mx-3 sm:mx-6 mt-2.5 p-2 sm:p-2.5 bg-amber-50 border border-amber-300 rounded-xl sm:rounded-2xl text-amber-950 flex items-center justify-between shadow-xs shrink-0">
            <div className="flex items-center space-x-2 space-x-reverse text-xs">
              <CheckCircle2 className="w-4 h-4 text-amber-700 shrink-0" />
              <span>
                <strong>حماية البيانات:</strong> تم استعادة المسودة تلقائياً.
              </span>
            </div>
            <button
              type="button"
              onClick={clearDraft}
              className="text-[11px] font-bold text-amber-900 bg-amber-200/80 hover:bg-amber-300 px-2.5 py-1 rounded-lg transition-colors flex items-center space-x-1 space-x-reverse cursor-pointer shrink-0"
            >
              <RotateCcw className="w-3.5 h-3.5" />
              <span>بدء جديد</span>
            </button>
          </div>
        )}

        {/* Duplicate Personnel Alert Banner */}
        {duplicateMatch && (
          <div className="mx-3 sm:mx-6 mt-2.5 p-2.5 sm:p-3 bg-rose-50 border-2 border-rose-500 rounded-xl sm:rounded-2xl text-rose-900 shadow-md shrink-0">
            <div className="flex items-start space-x-2.5 space-x-reverse">
              <div className="p-1.5 bg-rose-600 text-white rounded-lg font-bold shrink-0 mt-0.5">
                <AlertTriangle className="w-4 h-4 animate-pulse" />
              </div>
              <div className="flex-1 text-xs">
                <div className="font-black text-xs sm:text-sm text-rose-950 font-['Tajawal'] flex items-center justify-between">
                  <span>🚨 إنذار تكرار: بيانات هذا الفرد مسجلة مسبقاً!</span>
                  <span className="bg-rose-200 text-rose-900 text-[10px] font-mono px-2 py-0.5 rounded-full font-bold">
                    تطابق
                  </span>
                </div>
                <div className="mt-1.5 bg-white/90 border border-rose-200 rounded-lg p-2 grid grid-cols-2 sm:grid-cols-4 gap-1.5 font-mono text-[10px] sm:text-[11px] text-slate-800 font-bold">
                  <div>الاسم: {duplicateMatch.fullName}</div>
                  <div>الرقم: {duplicateMatch.militaryId}</div>
                  <div>الهوية: {duplicateMatch.nationalId || 'غير مسجلة'}</div>
                  <div>الوحدة: {duplicateMatch.unit}</div>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* Form Subtabs Navigation Bar - Sticky, Mobile Touch-Optimized & Always Visible */}
        <div className="sticky top-0 z-20 px-2 sm:px-6 py-2 bg-slate-100 border-b border-slate-200 shrink-0 shadow-2xs">
          <div className="flex items-center justify-between gap-1 sm:gap-2">
            
            {/* Prev Arrow for Quick Mobile Jump */}
            <button
              type="button"
              onClick={() => {
                if (activeSubTab === 'qualifications') setActiveSubTab('military');
                else if (activeSubTab === 'military') setActiveSubTab('basic');
              }}
              disabled={activeSubTab === 'basic'}
              className="sm:hidden p-2.5 bg-white disabled:opacity-25 disabled:pointer-events-none rounded-xl border border-slate-300 text-slate-700 shadow-2xs active:bg-slate-200"
              title="النافذة السابقة"
            >
              <ChevronRight className="w-4 h-4" />
            </button>

            {/* The 3 Subtabs */}
            <div className="grid grid-cols-3 gap-1 sm:gap-2 flex-1">
              <button
                type="button"
                onClick={() => setActiveSubTab('basic')}
                className={`flex items-center justify-center space-x-1 sm:space-x-2 space-x-reverse py-2 sm:py-2.5 px-1 sm:px-2 rounded-xl transition-all font-black text-xs sm:text-sm cursor-pointer ${
                  activeSubTab === 'basic'
                    ? 'bg-emerald-700 text-white shadow-md shadow-emerald-900/30 ring-2 ring-emerald-500/50'
                    : 'bg-white hover:bg-slate-50 text-slate-700 border border-slate-300'
                }`}
              >
                <User className="w-3.5 h-3.5 sm:w-4 sm:h-4 shrink-0" />
                <span className="truncate">1. الشخصية 👤</span>
              </button>

              <button
                type="button"
                onClick={() => setActiveSubTab('military')}
                className={`flex items-center justify-center space-x-1 sm:space-x-2 space-x-reverse py-2 sm:py-2.5 px-1 sm:px-2 rounded-xl transition-all font-black text-xs sm:text-sm cursor-pointer ${
                  activeSubTab === 'military'
                    ? 'bg-blue-700 text-white shadow-md shadow-blue-900/30 ring-2 ring-blue-500/50'
                    : 'bg-white hover:bg-slate-50 text-slate-700 border border-slate-300'
                }`}
              >
                <Shield className="w-3.5 h-3.5 sm:w-4 sm:h-4 shrink-0" />
                <span className="truncate">2. العسكرية 🛡️</span>
              </button>

              <button
                type="button"
                onClick={() => setActiveSubTab('qualifications')}
                className={`flex items-center justify-center space-x-1 sm:space-x-2 space-x-reverse py-2 sm:py-2.5 px-1 sm:px-2 rounded-xl transition-all font-black text-xs sm:text-sm cursor-pointer ${
                  activeSubTab === 'qualifications'
                    ? 'bg-purple-700 text-white shadow-md shadow-purple-900/30 ring-2 ring-purple-500/50'
                    : 'bg-white hover:bg-slate-50 text-slate-700 border border-slate-300'
                }`}
              >
                <BookOpen className="w-3.5 h-3.5 sm:w-4 sm:h-4 shrink-0" />
                <span className="truncate">3. المؤهلات 📚</span>
              </button>
            </div>

            {/* Next Arrow for Quick Mobile Jump */}
            <button
              type="button"
              onClick={() => {
                if (activeSubTab === 'basic') setActiveSubTab('military');
                else if (activeSubTab === 'military') setActiveSubTab('qualifications');
              }}
              disabled={activeSubTab === 'qualifications'}
              className="sm:hidden p-2.5 bg-white disabled:opacity-25 disabled:pointer-events-none rounded-xl border border-slate-300 text-slate-700 shadow-2xs active:bg-slate-200"
              title="النافذة التالية"
            >
              <ChevronLeft className="w-4 h-4" />
            </button>
          </div>

          {/* Progress Indicator */}
          <div className="w-full bg-slate-200 h-1.5 rounded-full mt-1.5 overflow-hidden">
            <div
              className={`h-full transition-all duration-300 ${
                activeSubTab === 'basic' ? 'bg-emerald-600' : activeSubTab === 'military' ? 'bg-blue-600' : 'bg-purple-600'
              }`}
              style={{
                width: activeSubTab === 'basic' ? '33.33%' : activeSubTab === 'military' ? '66.66%' : '100%'
              }}
            />
          </div>
        </div>

        {/* Form Body & Content */}
        <form onSubmit={handleSubmit} className="flex flex-col flex-1 overflow-hidden">
          
          <div className="flex-1 overflow-y-auto overscroll-contain p-3.5 sm:p-6 space-y-4 text-right pb-10">
            
            {/* Tab 1: Basic Personal Info */}
            {activeSubTab === 'basic' && (
              <div className="space-y-4 animate-in fade-in duration-150">
                <div className="p-2.5 bg-emerald-50/80 border border-emerald-300 rounded-xl text-emerald-950 text-xs font-bold flex items-center justify-between">
                  <div className="flex items-center space-x-1.5 space-x-reverse">
                    <span className="w-2 h-2 rounded-full bg-emerald-600 animate-pulse"></span>
                    <span>النافذة 1 من 3: البيانات الشخصية والأساسية للفرد</span>
                  </div>
                  <button
                    type="button"
                    onClick={() => setActiveSubTab('military')}
                    className="text-emerald-800 hover:text-emerald-950 bg-emerald-200/60 hover:bg-emerald-200 px-2.5 py-1 rounded-lg flex items-center space-x-1 space-x-reverse cursor-pointer font-black text-[11px]"
                  >
                    <span>الانتقال للبيانات العسكرية 🛡️ ←</span>
                  </button>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-3.5">
                  <div>
                    <label className="block text-xs font-bold text-slate-700 mb-1">الرقم الوظيفي / العسكري *</label>
                    <input
                      type="text"
                      required
                      value={militaryId}
                      onChange={(e) => setMilitaryId(e.target.value)}
                      className="w-full bg-slate-50 border border-slate-300 rounded-xl px-3 py-2 text-xs text-emerald-800 font-mono font-bold focus:outline-none focus:bg-white focus:border-emerald-600"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-bold text-slate-700 mb-1">الرقم الوطني (الهوية) *</label>
                    <input
                      type="text"
                      required
                      value={nationalId}
                      onChange={(e) => setNationalId(e.target.value)}
                      className="w-full bg-slate-50 border border-slate-300 rounded-xl px-3 py-2 text-xs text-slate-800 focus:outline-none focus:bg-white focus:border-emerald-600"
                    />
                  </div>

                  <div className="sm:col-span-2 md:col-span-1">
                    <label className="block text-xs font-bold text-slate-700 mb-1">الاسم الرباعي الكامل *</label>
                    <input
                      type="text"
                      required
                      value={fullName}
                      onChange={(e) => setFullName(e.target.value)}
                      placeholder="مثال: خالد بن عبد الله الآنسي"
                      className="w-full bg-slate-50 border border-slate-300 rounded-xl px-3 py-2 text-xs text-slate-900 font-bold focus:outline-none focus:bg-white focus:border-emerald-600"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-bold text-slate-700 mb-1">تاريخ الميلاد</label>
                    <input
                      type="date"
                      value={dob}
                      onChange={(e) => setDob(e.target.value)}
                      className="w-full bg-slate-50 border border-slate-300 rounded-xl px-3 py-2 text-xs text-slate-800 focus:outline-none focus:bg-white focus:border-emerald-600"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-bold text-slate-700 mb-1">مكان الميلاد / المحافظة</label>
                    <input
                      type="text"
                      value={pob}
                      onChange={(e) => setPob(e.target.value)}
                      className="w-full bg-slate-50 border border-slate-300 rounded-xl px-3 py-2 text-xs text-slate-800 focus:outline-none focus:bg-white focus:border-emerald-600"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-bold text-slate-700 mb-1">الحالة الاجتماعية</label>
                    <select
                      value={maritalStatus}
                      onChange={(e) => setMaritalStatus(e.target.value as any)}
                      className="w-full bg-slate-50 border border-slate-300 rounded-xl px-3 py-2 text-xs text-slate-800 font-bold focus:outline-none focus:bg-white focus:border-emerald-600"
                    >
                      <option value="أعزب">أعزب</option>
                      <option value="متزوج">متزوج</option>
                      <option value="مطلق">مطلق</option>
                      <option value="أرمل">أرمل</option>
                    </select>
                  </div>

                  <div>
                    <label className="block text-xs font-bold text-slate-700 mb-1">رقم هاتف الفرد</label>
                    <input
                      type="text"
                      value={phone}
                      onChange={(e) => setPhone(e.target.value)}
                      className="w-full bg-slate-50 border border-slate-300 rounded-xl px-3 py-2 text-xs text-slate-800 focus:outline-none focus:bg-white focus:border-emerald-600 font-mono"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-bold text-slate-700 mb-1">اسم الأم</label>
                    <input
                      type="text"
                      value={motherName}
                      onChange={(e) => setMotherName(e.target.value)}
                      placeholder="اسم والدة الفرد..."
                      className="w-full bg-slate-50 border border-slate-300 rounded-xl px-3 py-2 text-xs text-slate-800 focus:outline-none focus:bg-white focus:border-emerald-600"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-bold text-slate-700 mb-1">اسم الضمين (الكفيل الضامن)</label>
                    <input
                      type="text"
                      value={guarantorName}
                      onChange={(e) => setGuarantorName(e.target.value)}
                      placeholder="اسم الضمين أو الكفيل..."
                      className="w-full bg-slate-50 border border-slate-300 rounded-xl px-3 py-2 text-xs text-slate-800 focus:outline-none focus:bg-white focus:border-emerald-600"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-bold text-slate-700 mb-1">اسم أقرب الأقارب / صلة القرابة</label>
                    <input
                      type="text"
                      value={relativeName}
                      onChange={(e) => setRelativeName(e.target.value)}
                      placeholder="مثال: محمد علي (أخ) / أحمد خالد (والد)"
                      className="w-full bg-slate-50 border border-slate-300 rounded-xl px-3 py-2 text-xs text-slate-800 focus:outline-none focus:bg-white focus:border-emerald-600"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-bold text-slate-700 mb-1">رقم هاتف القريب للضرورة</label>
                    <input
                      type="text"
                      value={relativePhone}
                      onChange={(e) => setRelativePhone(e.target.value)}
                      placeholder="05xxxxxxx"
                      className="w-full bg-slate-50 border border-slate-300 rounded-xl px-3 py-2 text-xs text-slate-800 focus:outline-none focus:bg-white focus:border-emerald-600 font-mono"
                    />
                  </div>

                  <div className="sm:col-span-2 md:col-span-3">
                    <ImageUploadPicker
                      currentPhotoUrl={photoUrl}
                      onPhotoChange={setPhotoUrl}
                      label="الصورة الشخصية للفرد (مع إمكانية التصوير المباشر بالكاميرا أو الرفع من المعرض)"
                    />
                  </div>

                  <div className="sm:col-span-2 md:col-span-3 flex items-center space-x-2 space-x-reverse pt-2">
                    <input
                      type="checkbox"
                      id="biometrics"
                      checked={biometricsRecorded}
                      onChange={(e) => setBiometricsRecorded(e.target.checked)}
                      className="w-4 h-4 rounded text-emerald-700 focus:ring-emerald-600 bg-slate-50 border-slate-300 cursor-pointer"
                    />
                    <label htmlFor="biometrics" className="text-xs font-bold text-slate-700 cursor-pointer">
                      تم تسجيل البصمة الحيوية بالفرد بالنظام المعتمد
                    </label>
                  </div>

                  {/* Tab 1 In-Content Forward Step Card */}
                  <div className="sm:col-span-2 md:col-span-3 pt-3 border-t border-slate-200">
                    <button
                      type="button"
                      onClick={() => setActiveSubTab('military')}
                      className="w-full flex items-center justify-between p-3.5 bg-gradient-to-r from-blue-50 to-indigo-50 hover:from-blue-100 hover:to-indigo-100 border-2 border-blue-400 rounded-2xl text-blue-950 font-black text-xs sm:text-sm transition-all shadow-sm cursor-pointer"
                    >
                      <div className="flex items-center space-x-2 space-x-reverse">
                        <span className="p-1.5 bg-blue-600 text-white rounded-xl">
                          <Shield className="w-4 h-4" />
                        </span>
                        <div className="text-right">
                          <div className="font-extrabold text-blue-950">الانتقال للنافذة 2: البيانات العسكرية والوحدات والجاهزية 🛡️</div>
                          <div className="text-[10px] text-blue-700 font-normal">تسجيل الرتبة، اللواء، الكتيبة، السرية، وتاريخ التجنيد</div>
                        </div>
                      </div>
                      <span className="text-blue-800 font-black bg-white px-3 py-1.5 rounded-xl border border-blue-300 shadow-2xs">
                        متابعة ➔
                      </span>
                    </button>
                  </div>
                </div>
              </div>
            )}

            {/* Tab 2: Military Role & Unit */}
            {activeSubTab === 'military' && (
              <div className="space-y-4 animate-in fade-in duration-150">
                <div className="p-2.5 bg-blue-50/80 border border-blue-300 rounded-xl text-blue-950 text-xs font-bold flex items-center justify-between">
                  <div className="flex items-center space-x-1.5 space-x-reverse">
                    <span className="w-2 h-2 rounded-full bg-blue-600 animate-pulse"></span>
                    <span>النافذة 2 من 3: البيانات العسكرية والوحدات والجاهزية</span>
                  </div>
                  <div className="flex items-center space-x-1.5 space-x-reverse text-[11px]">
                    <button
                      type="button"
                      onClick={() => setActiveSubTab('basic')}
                      className="text-slate-700 hover:text-slate-900 bg-white hover:bg-slate-100 px-2.5 py-1 rounded-lg border border-slate-300 font-bold cursor-pointer"
                    >
                      <span>← السابقة (الشخصية)</span>
                    </button>
                    <button
                      type="button"
                      onClick={() => setActiveSubTab('qualifications')}
                      className="text-blue-800 hover:text-blue-950 bg-blue-200/70 hover:bg-blue-200 px-2.5 py-1 rounded-lg font-black cursor-pointer"
                    >
                      <span>التالية (المؤهلات) 📚 →</span>
                    </button>
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-3.5">
                  <div>
                    <label className="block text-xs font-bold text-slate-700 mb-1">الرتبة العسكرية *</label>
                    <select
                      value={rank}
                      onChange={(e) => setRank(e.target.value as MilitaryRank)}
                      className="w-full bg-slate-50 border border-slate-300 rounded-xl px-3 py-2 text-xs text-emerald-800 font-bold focus:outline-none focus:bg-white focus:border-emerald-600"
                    >
                      <option value="فريق أول">فريق أول</option>
                      <option value="فريق">فريق</option>
                      <option value="لواء">لواء</option>
                      <option value="عميد">عميد</option>
                      <option value="عقيد">عقيد</option>
                      <option value="مقدم">مقدم</option>
                      <option value="رائد">رائد</option>
                      <option value="نقيب">نقيب</option>
                      <option value="ملازم أول">ملازم أول</option>
                      <option value="ملازم">ملازم</option>
                      <option value="رئيس رقباء">رئيس رقباء</option>
                      <option value="رقيب أول">رقيب أول</option>
                      <option value="رقيب">رقيب</option>
                      <option value="وكيل رقيب">وكيل رقيب</option>
                      <option value="عريف">عريف</option>
                      <option value="جندي أول">جندي أول</option>
                      <option value="جندي">جندي</option>
                    </select>
                    <div className="mt-1 flex items-center justify-between text-[11px] bg-emerald-50 border border-emerald-200 text-emerald-900 px-2 py-0.5 rounded-lg">
                      <span className="font-medium">المرتب الأساسي:</span>
                      <span className="font-black font-mono text-emerald-700">
                        {StorageService.getDefaultSalaryForRank(rank, jobTitle).toLocaleString('ar-SA')} ر.س
                      </span>
                    </div>
                  </div>

                  <div>
                    <label className="block text-xs font-bold text-slate-700 mb-1">الوحدة الرئيسية (اللواء / التشكيل)</label>
                    <input
                      type="text"
                      value={unit}
                      onChange={(e) => setUnit(e.target.value)}
                      className="w-full bg-slate-50 border border-slate-300 rounded-xl px-3 py-2 text-xs text-slate-800 font-bold focus:outline-none focus:bg-white focus:border-emerald-600"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-bold text-slate-700 mb-1">الكتيبة</label>
                    <input
                      type="text"
                      value={battalion}
                      onChange={(e) => setBattalion(e.target.value)}
                      className="w-full bg-slate-50 border border-slate-300 rounded-xl px-3 py-2 text-xs text-slate-800 focus:outline-none focus:bg-white focus:border-emerald-600"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-bold text-slate-700 mb-1">السرية</label>
                    <input
                      type="text"
                      value={company}
                      onChange={(e) => setCompany(e.target.value)}
                      className="w-full bg-slate-50 border border-slate-300 rounded-xl px-3 py-2 text-xs text-slate-800 focus:outline-none focus:bg-white focus:border-emerald-600"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-bold text-slate-700 mb-1">الفصيل</label>
                    <input
                      type="text"
                      value={platoon}
                      onChange={(e) => setPlatoon(e.target.value)}
                      className="w-full bg-slate-50 border border-slate-300 rounded-xl px-3 py-2 text-xs text-slate-800 focus:outline-none focus:bg-white focus:border-emerald-600"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-bold text-slate-700 mb-1">المسمى الوظيفي العسكري</label>
                    <input
                      type="text"
                      value={jobTitle}
                      onChange={(e) => setJobTitle(e.target.value)}
                      className="w-full bg-slate-50 border border-slate-300 rounded-xl px-3 py-2 text-xs text-slate-800 focus:outline-none focus:bg-white focus:border-emerald-600"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-bold text-slate-700 mb-1">تاريخ الالتحاق بالخدمة</label>
                    <input
                      type="date"
                      value={enlistmentDate}
                      onChange={(e) => setEnlistmentDate(e.target.value)}
                      className="w-full bg-slate-50 border border-slate-300 rounded-xl px-3 py-2 text-xs text-slate-800 focus:outline-none focus:bg-white focus:border-emerald-600"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-bold text-slate-700 mb-1">الحالة الحالية المبدئية</label>
                    <select
                      value={currentStatus}
                      onChange={(e) => setCurrentStatus(e.target.value as PersonnelStatus)}
                      className="w-full bg-slate-50 border border-slate-300 rounded-xl px-3 py-2 text-xs font-bold text-emerald-800 focus:outline-none focus:bg-white focus:border-emerald-600"
                    >
                      <option value="متواجد">متواجد</option>
                      <option value="في الميدان">في الميدان</option>
                      <option value="مأمورية">مأمورية</option>
                      <option value="منتدب">منتدب (انتداب خارجي)</option>
                      <option value="دورة تدريبية داخلية">دورة تدريبية داخلية 🎓</option>
                      <option value="دورة تدريبية خارجية">دورة تدريبية خارجية ✈️</option>
                      <option value="إجازة">إجازة</option>
                      <option value="إذن">إذن</option>
                      <option value="مستشفى">مستشفى</option>
                      <option value="جريح">جريح 🩹</option>
                      <option value="غياب">غياب</option>
                      <option value="فرار">فرار</option>
                      <option value="اسير">اسير ⛓️</option>
                      <option value="شهيد">شهيد 🎖️</option>
                      <option value="معاق">معاق ♿</option>
                      <option value="مفقود">مفقود ❓</option>
                      <option value="موقوف">موقوف</option>
                      <option value="احتياط">احتياط</option>
                    </select>
                  </div>

                  {currentStatus === 'منتدب' && (
                    <div className="sm:col-span-2 md:col-span-3">
                      <label className="block text-xs font-bold text-amber-900 mb-1">الوحدة المنتدب لديها *</label>
                      <input
                        type="text"
                        required
                        value={secondedUnit}
                        onChange={(e) => setSecondedUnit(e.target.value)}
                        placeholder="أدخل اسم الجهة أو الوحدة المنتدب لديها (مثال: قيادة المنطقة البحرية)..."
                        className="w-full bg-amber-50 border border-amber-300 rounded-xl px-3 py-2 text-xs font-bold text-slate-900 focus:outline-none focus:bg-white focus:border-amber-600"
                      />
                    </div>
                  )}

                  {(currentStatus === 'دورة تدريبية داخلية' || currentStatus === 'دورة تدريبية خارجية') && (
                    <div className="sm:col-span-2 md:col-span-3">
                      <label className="block text-xs font-bold text-indigo-900 mb-1">نوع ومسمى الدورة التدريبية *</label>
                      <input
                        type="text"
                        required
                        value={trainingCourseType}
                        onChange={(e) => setTrainingCourseType(e.target.value)}
                        placeholder="أدخل نوع ومسمى الدورة التدريبية (مثال: دورة قادة سرايا، دورة صاعقة)..."
                        className="w-full bg-indigo-50 border border-indigo-300 rounded-xl px-3 py-2 text-xs font-bold text-slate-900 focus:outline-none focus:bg-white focus:border-indigo-600"
                      />
                    </div>
                  )}

                  {/* Tab 2 Bottom Action Bar */}
                  <div className="sm:col-span-2 md:col-span-3 pt-3 border-t border-slate-200 flex flex-col sm:flex-row gap-2">
                    <button
                      type="button"
                      onClick={() => setActiveSubTab('basic')}
                      className="flex-1 flex items-center justify-center space-x-1.5 space-x-reverse p-3 bg-slate-100 hover:bg-slate-200 border border-slate-300 rounded-xl text-slate-800 font-bold text-xs transition-all cursor-pointer"
                    >
                      <User className="w-4 h-4 text-slate-600" />
                      <span>← العودة للنافذة 1 (البيانات الشخصية)</span>
                    </button>
                    <button
                      type="button"
                      onClick={() => setActiveSubTab('qualifications')}
                      className="flex-1 flex items-center justify-center space-x-1.5 space-x-reverse p-3 bg-gradient-to-r from-purple-50 to-pink-50 hover:from-purple-100 hover:to-pink-100 border-2 border-purple-400 rounded-xl text-purple-950 font-black text-xs transition-all cursor-pointer shadow-xs"
                    >
                      <BookOpen className="w-4 h-4 text-purple-700" />
                      <span>الانتقال للنافذة 3: المؤهلات والتخصص وفصيلة الدم 📚 ➔</span>
                    </button>
                  </div>
                </div>
              </div>
            )}

            {/* Tab 3: Education & Medical Specs */}
            {activeSubTab === 'qualifications' && (
              <div className="space-y-4 animate-in fade-in duration-150">
                <div className="p-2.5 bg-purple-50/80 border border-purple-300 rounded-xl text-purple-950 text-xs font-bold flex items-center justify-between">
                  <div className="flex items-center space-x-1.5 space-x-reverse">
                    <span className="w-2 h-2 rounded-full bg-purple-600 animate-pulse"></span>
                    <span>النافذة 3 من 3: المؤهلات العلمية والتخصص وفصيلة الدم</span>
                  </div>
                  <button
                    type="button"
                    onClick={() => setActiveSubTab('military')}
                    className="text-purple-800 hover:text-purple-950 bg-purple-200/70 hover:bg-purple-200 px-2.5 py-1 rounded-lg flex items-center space-x-1 space-x-reverse cursor-pointer font-bold text-[11px]"
                  >
                    <span>← العودة للبيانات العسكرية 🛡️</span>
                  </button>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-3.5">
                  <div>
                    <label className="block text-xs font-bold text-slate-700 mb-1">المؤهل العلمي</label>
                    <input
                      type="text"
                      value={education}
                      onChange={(e) => setEducation(e.target.value)}
                      placeholder="بكالوريوس علوم عسكرية / ثانوية..."
                      className="w-full bg-slate-50 border border-slate-300 rounded-xl px-3 py-2 text-xs text-slate-800 focus:outline-none focus:bg-white focus:border-emerald-600"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-bold text-slate-700 mb-1">التخصص والدراسة</label>
                    <input
                      type="text"
                      value={specialization}
                      onChange={(e) => setSpecialization(e.target.value)}
                      placeholder="مشاة آلي / هندسة اتصالات..."
                      className="w-full bg-slate-50 border border-slate-300 rounded-xl px-3 py-2 text-xs text-slate-800 focus:outline-none focus:bg-white focus:border-emerald-600"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-bold text-slate-700 mb-1">فصيلة الدم *</label>
                    <select
                      value={bloodType}
                      onChange={(e) => setBloodType(e.target.value as any)}
                      className="w-full bg-slate-50 border border-slate-300 rounded-xl px-3 py-2 text-xs font-mono font-bold text-rose-700 focus:outline-none focus:bg-white focus:border-emerald-600"
                    >
                      <option value="A+">A+</option>
                      <option value="A-">A-</option>
                      <option value="B+">B+</option>
                      <option value="B-">B-</option>
                      <option value="AB+">AB+</option>
                      <option value="AB-">AB-</option>
                      <option value="O+">O+</option>
                      <option value="O-">O-</option>
                    </select>
                  </div>

                  {/* Tab 3 Bottom Action Bar */}
                  <div className="sm:col-span-2 md:col-span-3 pt-3 border-t border-slate-200 flex flex-col sm:flex-row gap-2">
                    <button
                      type="button"
                      onClick={() => setActiveSubTab('military')}
                      className="flex-1 flex items-center justify-center space-x-1.5 space-x-reverse p-3 bg-slate-100 hover:bg-slate-200 border border-slate-300 rounded-xl text-slate-800 font-bold text-xs transition-all cursor-pointer"
                    >
                      <Shield className="w-4 h-4 text-blue-600" />
                      <span>← العودة للنافذة 2 (البيانات العسكرية)</span>
                    </button>
                    <div className="flex-1 p-2.5 bg-emerald-50 border border-emerald-300 rounded-xl text-emerald-900 text-xs font-bold flex items-center justify-center space-x-1.5 space-x-reverse">
                      <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
                      <span>اكتملت النوافذ الثلاث — جاهز للحفظ بالسجل 💾</span>
                    </div>
                  </div>
                </div>
              </div>
            )}

          </div>

          {/* Sticky Mobile & Desktop Footer Actions - Always Accessible */}
          <div className="sticky bottom-0 bg-slate-900 text-white border-t border-slate-800 px-3 sm:px-6 py-2.5 sm:py-3 shrink-0 flex items-center justify-between gap-2 shadow-2xl z-30 pb-[max(0.75rem,env(safe-area-inset-bottom))]">
            <div className="flex items-center space-x-1.5 sm:space-x-2 space-x-reverse">
              <button
                type="button"
                onClick={onClose}
                className="px-3 sm:px-4 py-2 bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white rounded-xl text-xs font-bold transition-all cursor-pointer border border-slate-700"
              >
                إلغاء
              </button>

              {activeSubTab !== 'basic' && (
                <button
                  type="button"
                  onClick={() => {
                    if (activeSubTab === 'qualifications') setActiveSubTab('military');
                    else if (activeSubTab === 'military') setActiveSubTab('basic');
                  }}
                  className="px-3 py-2 bg-slate-800 hover:bg-slate-700 text-slate-100 rounded-xl text-xs font-bold transition-all flex items-center space-x-1 space-x-reverse cursor-pointer border border-slate-700 shadow-xs"
                >
                  <span>السابق ←</span>
                </button>
              )}
            </div>

            <div className="flex items-center space-x-2 space-x-reverse">
              {activeSubTab !== 'qualifications' ? (
                <button
                  type="button"
                  onClick={() => {
                    if (activeSubTab === 'basic') setActiveSubTab('military');
                    else if (activeSubTab === 'military') setActiveSubTab('qualifications');
                  }}
                  className="px-3.5 sm:px-4 py-2 bg-blue-600 hover:bg-blue-500 text-white rounded-xl text-xs font-black transition-all shadow-md flex items-center space-x-1 space-x-reverse cursor-pointer ring-1 ring-blue-400"
                >
                  <span>{activeSubTab === 'basic' ? 'التالي: العسكرية 🛡️' : 'التالي: المؤهلات 📚'} ➔</span>
                </button>
              ) : null}

              <button
                type="submit"
                className="flex items-center space-x-1.5 space-x-reverse bg-emerald-600 hover:bg-emerald-500 text-white px-4 sm:px-6 py-2 rounded-xl text-xs font-black transition-all shadow-lg hover:shadow-emerald-900/30 cursor-pointer shrink-0 ring-2 ring-emerald-400/50"
              >
                <Save className="w-4 h-4" />
                <span>حفظ بالسجل 💾</span>
              </button>
            </div>
          </div>

        </form>

      </div>
    </div>
  );
};
