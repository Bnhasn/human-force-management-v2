import React, { useState } from 'react';
import {
  Users,
  ShieldAlert,
  Crosshair,
  Award,
  DollarSign,
  Lock,
  Wrench,
  Package,
  Plus,
  CheckCircle2,
  Calendar,
  Activity,
  AlertOctagon,
  FileText,
  Upload,
  Image as ImageIcon,
  Paperclip,
  Printer
} from 'lucide-react';
import { PersonnelRecord, DepartmentRole, PersonnelStatus } from '../types';
import { StorageService } from '../lib/storage';
import { compressImageFile } from '../lib/imageUtils';
import { ArmamentBranchWorkspace } from './ArmamentBranchWorkspace';
import { VehiclesReadinessWorkspace } from './VehiclesReadinessWorkspace';
import { TargetPersonnelSearchSelect } from './TargetPersonnelSearchSelect';
import { PersonnelAvatar } from './PersonnelAvatar';
import { ApprovalVoucherModal, VoucherData } from './ApprovalVoucherModal';
import { PayrollManagementWorkspace } from './PayrollManagementWorkspace';

export interface DepartmentWorkspacesProps {
  currentRole: DepartmentRole;
  onRoleChange?: (role: DepartmentRole) => void;
  personnel: PersonnelRecord[];
  onRefresh: () => void;
  onSelectPersonnel: (militaryId: string) => void;
  currentAccountName?: string;
  isMainCommand?: boolean;
}

export const BRANCH_DEPARTMENTS_LIST: Array<{
  role: DepartmentRole;
  title: string;
  shortTitle: string;
  icon: string;
  badge: string;
  accent: string;
  activeBg: string;
  desc: string;
}> = [
  {
    role: 'إدارة الموارد البشرية',
    title: 'إدارة الموارد البشرية والقرارات الإدارية',
    shortTitle: 'الموارد البشرية (HR)',
    icon: '👥',
    badge: 'إجازات وأذونات ومأموريات',
    accent: 'border-blue-500 text-blue-400',
    activeBg: 'bg-blue-600 text-white shadow-md shadow-blue-900/40',
    desc: 'إصدار قرارات الإجازات، الأذونات، المأموريات، الانتداب، وتحديث حالات التمام'
  },
  {
    role: 'إدارة التسليح',
    title: 'فرع التسليح والذخائر والعهد القتالية',
    shortTitle: 'التسليح والذخائر',
    icon: '🎯',
    badge: 'سجلات الأسلحة والذخيرة',
    accent: 'border-amber-500 text-amber-400',
    activeBg: 'bg-amber-600 text-white shadow-md shadow-amber-900/40',
    desc: 'صرف واسترجاع بنادق M4A1، كلاشينكوف، المسدسات، وصناديق الذخيرة والعهد'
  },
  {
    role: 'جاهزية العربات والآليات',
    title: 'فرع جاهزية العربات والآليات والمدرعات',
    shortTitle: 'العربات والآليات',
    icon: '🚛',
    badge: 'أطقم وحركة الآليات والصيانة',
    accent: 'border-emerald-500 text-emerald-400',
    activeBg: 'bg-emerald-600 text-white shadow-md shadow-emerald-900/40',
    desc: 'متابعة أطقم المركبات، جاهزية العربات القتالية، سجلات الصيانة، والوقود'
  },
  {
    role: 'الإدارة الطبية العسكرية',
    title: 'الإدارة الطبية العسكرية والمستشفيات',
    shortTitle: 'الخدمات الطبية',
    icon: '🏥',
    badge: 'تنويم ووصفات وتعافي',
    accent: 'border-pink-500 text-pink-400',
    activeBg: 'bg-pink-600 text-white shadow-md shadow-pink-900/40',
    desc: 'توثيق التنويم الطبي، الوصفات العلاجية، فترات التعافي، ومتابعة اللياقة الطبية'
  },
  {
    role: 'إدارة التموين والإمداد',
    title: 'إدارة التموين والإمداد والمهمات',
    shortTitle: 'التموين والمهمات',
    icon: '📦',
    badge: 'بدلات ودروع وتجهيزات',
    accent: 'border-indigo-500 text-indigo-400',
    activeBg: 'bg-indigo-600 text-white shadow-md shadow-indigo-900/40',
    desc: 'صرف وتوثيق البدلات العسكرية، البساطير، الدروع، الخوذ، والمعدات الميدانية'
  },
  {
    role: 'إدارة التدريب',
    title: 'إدارة التدريب والدورات العسكرية والتخصصية',
    shortTitle: 'التدريب والدورات',
    icon: '🎓',
    badge: 'دورات وشهادات ورماية',
    accent: 'border-purple-500 text-purple-400',
    activeBg: 'bg-purple-600 text-white shadow-md shadow-purple-900/40',
    desc: 'تسجيل الالتحاق بالدورات التخصصية، تعيين الضباط المشرفين، وشهادات الاجتياز'
  },
  {
    role: 'الاستخبارات والأمن',
    title: 'فرع الاستخبارات والأمن العسكري والتحقيقات',
    shortTitle: 'الاستخبارات والأمن',
    icon: '🕵️',
    badge: 'قيود أمنية وتوقيف ومحاضر',
    accent: 'border-rose-500 text-rose-400',
    activeBg: 'bg-rose-600 text-white shadow-md shadow-rose-900/40',
    desc: 'تقييد الأوامر والمخالفات الأمنية، التحقيقات، إرفاق صور المحاضر، وقرارات التوقيف'
  },
  {
    role: 'الإدارة المالية',
    title: 'الإدارة المالية ومسيرات الرواتب والمستحقات',
    shortTitle: 'المالية والرواتب',
    icon: '💰',
    badge: 'رواتب واستقطاعات وحوافز',
    accent: 'border-teal-500 text-teal-400',
    activeBg: 'bg-teal-600 text-white shadow-md shadow-teal-900/40',
    desc: 'كشوف المرتبات الشهرية، المكافآت الميدانية، الاستقطاعات، وسندات الصرف المالي'
  }
];

export const DepartmentWorkspaces: React.FC<DepartmentWorkspacesProps> = ({
  currentRole,
  onRoleChange,
  personnel,
  onRefresh,
  onSelectPersonnel,
  currentAccountName = 'لواء القيادة',
  isMainCommand = true
}) => {
  const [selectedMilitaryId, setSelectedMilitaryId] = useState<string>(
    personnel[0]?.militaryId || ''
  );

  // Form states
  const [reason, setReason] = useState('');
  const [amount, setAmount] = useState<number>(1000);
  const [days, setDays] = useState<number>(7);
  const [statusInput, setStatusInput] = useState<PersonnelStatus>('إجازة');
  const [secondedUnitInput, setSecondedUnitInput] = useState<string>('قيادة المنطقة العسكرية / انتداب خارجي');
  const [weaponSerial, setWeaponSerial] = useState('');
  const [weaponType, setWeaponType] = useState('بندقية M4A1 5.56mm');
  const [ammoQty, setAmmoQty] = useState<number>(120);

  // Medical states
  const [diagnosis, setDiagnosis] = useState('');
  const [hospitalName, setHospitalName] = useState('المستشفى العسكري المركزي');
  const [doctorName, setDoctorName] = useState('د. طبيب عسكري مناظر');
  const [prescriptionDetails, setPrescriptionDetails] = useState('برنامج علاج ودواء متكامل وتأهيل بدني');
  const [recoveryStartDate, setRecoveryStartDate] = useState<string>(new Date().toISOString().split('T')[0]);
  const [recoveryEndDate, setRecoveryEndDate] = useState<string>(new Date().toISOString().split('T')[0]);

  // Security states
  const [violationText, setViolationText] = useState('');
  const [securityFileUrl, setSecurityFileUrl] = useState<string>('');
  const [securityFileName, setSecurityFileName] = useState<string>('');
  const [securityDate, setSecurityDate] = useState<string>(new Date().toISOString().split('T')[0]);
  const [securityPenalty, setSecurityPenalty] = useState<string>('إنذار مسلكي رسمي وحجز تحفظي');
  const [securityWarningLevel, setSecurityWarningLevel] = useState<'منخفض' | 'متوسط' | 'عالي' | 'حرج'>('عالي');
  const [securityStatus, setSecurityStatus] = useState<'قيد التحقيق' | 'تم البت' | 'محال للنيابة العسكرية' | 'منتهي'>('قيد التحقيق');
  const [securityDetain, setSecurityDetain] = useState<boolean>(true);
  const [securityDetails, setSecurityDetails] = useState<string>('');

  // Training states
  const [courseName, setCourseName] = useState('');
  const [courseType, setCourseType] = useState<'ميداني' | 'قيادي' | 'تقني' | 'أمني' | 'تخصصي' | 'خارجي'>('ميداني');
  const [trainingLocation, setTrainingLocation] = useState('معهد القوات المسلحة / الميدان الرئيسي');
  const [courseStartDate, setCourseStartDate] = useState<string>(new Date().toISOString().split('T')[0]);
  const [courseEndDate, setCourseEndDate] = useState<string>(new Date().toISOString().split('T')[0]);
  const [supervisorOfficer, setSupervisorOfficer] = useState('العقيد ركن / أحمد الهلالي');
  const [courseGrade, setCourseGrade] = useState<'ممتاز' | 'جيد جداً' | 'جيد' | 'مقبول' | 'مؤهل'>('ممتاز');

  // Supply / Equipment states
  const [supplyType, setSupplyType] = useState<'بدلة عسكرية' | 'بسطار/حذاء' | 'خوذة/دروع' | 'معدات ميدانية' | 'مؤن/تجهيزات' | 'مهمات أخرى'>('بدلة عسكرية');
  const [supplyItemName, setSupplyItemName] = useState('بدلة تمويه ميدانية رسمية 2026');
  const [supplyQty, setSupplyQty] = useState<number>(2);
  const [supplyCondition, setSupplyCondition] = useState<'جديد' | 'مستعمل ممتازة' | 'مستعمل جيدة' | 'مستهلك'>('جديد');
  const [supplySerial, setSupplySerial] = useState('');
  const [supplyNotes, setSupplyNotes] = useState('');

  const [notification, setNotification] = useState<string | null>(null);

  // Approval Voucher Modal States
  const [showVoucherModal, setShowVoucherModal] = useState<boolean>(false);
  const [voucherData, setVoucherData] = useState<VoucherData | null>(null);

  const showSuccessNotice = (msg: string) => {
    setNotification(msg);
    setTimeout(() => setNotification(null), 6000);
  };

  const activeSoldier = personnel.find((p) => p.militaryId === selectedMilitaryId) || personnel[0];

  // HR Action: Grant Leave/Permission/Mission/Status
  const handleHRAction = (e: React.FormEvent) => {
    e.preventDefault();
    if (!activeSoldier) return;

    StorageService.updateStatus(
      activeSoldier.militaryId,
      statusInput,
      reason || `قرار من فرع ${currentRole}`,
      currentAccountName || 'مسؤول فرع HR',
      currentRole,
      statusInput === 'منتدب' ? { secondedUnit: secondedUnitInput } : undefined
    );

    const refNum = `HR-${Date.now().toString().slice(-6)}-${Math.floor(1000 + Math.random() * 9000)}`;
    const now = new Date();
    const formattedTimestamp = `${now.toISOString().split('T')[0]} ${now.toTimeString().split(' ')[0]}`;

    const voucher: VoucherData = {
      id: `VCH-HR-${Math.floor(100000 + Math.random() * 900000)}`,
      type: statusInput === 'إجازة' ? 'leave' : statusInput === 'إذن' ? 'permission' : 'hr',
      title: statusInput === 'إجازة' ? 'سند اعتماد ومصادقة إجازة رسمية' : statusInput === 'إذن' ? 'سند إصدار إذن خروج وتواجد' : `سند اعتماد قرار إداري (${statusInput})`,
      personnel: activeSoldier,
      startDate: now.toISOString().split('T')[0],
      duration: 'حسب القرار الإداري المعتمد',
      details: reason || `تم إصدار القيد والقرار الإداري رسمياً وتحديث حالة الجاهزية إلى (${statusInput})`,
      approvedBy: currentAccountName || currentRole,
      department: currentRole,
      timestamp: formattedTimestamp,
      referenceNumber: refNum,
      additionalInfo: [
        { label: 'الحالة الجديدة', value: statusInput },
        ...(statusInput === 'منتدب' ? [{ label: 'الوحدة المنتدب إليها', value: secondedUnitInput }] : []),
        { label: 'الجهة المصادرة', value: currentRole },
        { label: 'مستوى الاعتماد', value: 'مصادق ومعتمد آلياً' }
      ]
    };

    setVoucherData(voucher);
    setShowVoucherModal(true);
    showSuccessNotice(`تم تحديث حالة الفرد ${activeSoldier.fullName} إلى (${statusInput}) بنجاح وطباعة السند جاهزة`);
    setReason('');
    onRefresh();
  };

  // Armament Action: Issue Weapon & Ammo
  const handleArmamentAction = (e: React.FormEvent) => {
    e.preventDefault();
    if (!activeSoldier) return;

    const serial = weaponSerial || `WPN-${Math.floor(10000 + Math.random() * 90000)}`;

    StorageService.addArmamentLog(
      activeSoldier.militaryId,
      {
        weaponSerial: serial,
        weaponType,
        issueDate: new Date().toISOString().split('T')[0],
        ammoQty,
        firelinesCount: 4,
        ammoHistory: [
          {
            id: `ah-${Date.now()}`,
            type: 'صرف',
            quantity: ammoQty,
            date: new Date().toISOString().split('T')[0],
            reason: reason || 'صرف حزمة التسليح الميدانية',
            issuedBy: currentRole
          }
        ],
        condition: 'ممتازة',
        technicalNotes: 'فحص دوري معتمد بالسلامة'
      },
      'ضابط التسليح',
      currentRole
    );

    showSuccessNotice(`تم صرف السلاح (${weaponType}) والذخيرة للفرد ${activeSoldier.fullName}`);
    setWeaponSerial('');
    setReason('');
    onRefresh();
  };

  // Medical Action: Admit & Register Diagnosis & Prescription
  const handleMedicalAction = (e: React.FormEvent) => {
    e.preventDefault();
    if (!activeSoldier) return;

    StorageService.addMedicalLog(
      activeSoldier.militaryId,
      {
        date: new Date().toISOString().split('T')[0],
        diagnosis: diagnosis || 'حالة مرضية وعلاج تخصصي بالمستشفى',
        hospital: hospitalName,
        doctor: doctorName,
        sickLeaveDays: days,
        medications: prescriptionDetails
          ? [
              {
                id: `m-${Date.now()}`,
                name: prescriptionDetails,
                dose: 'حسب الخطة الطبية وتوصيات الاستشاري',
                dateDispensed: new Date().toISOString().split('T')[0],
                prescribedBy: doctorName
              }
            ]
          : [],
        prescriptionDetails,
        recoveryStartDate,
        recoveryEndDate,
        isReturnToDuty: false
      },
      doctorName || 'طبيب الفرع الطبي',
      currentRole,
      true // Admit to hospital
    );

    const refNum = `MED-${Date.now().toString().slice(-6)}-${Math.floor(1000 + Math.random() * 9000)}`;
    const now = new Date();
    const formattedTimestamp = `${now.toISOString().split('T')[0]} ${now.toTimeString().split(' ')[0]}`;

    const voucher: VoucherData = {
      id: `VCH-MED-${Math.floor(100000 + Math.random() * 900000)}`,
      type: 'medical',
      title: days > 0 ? 'سند منح إجازة مرضية وعودة علاجية' : 'سند مصادقة وتقرير طبي معتمد',
      personnel: activeSoldier,
      startDate: recoveryStartDate || now.toISOString().split('T')[0],
      endDate: recoveryEndDate || 'حسب التقرير الطبي',
      duration: days > 0 ? `${days} أيام` : 'مراجعة وتقييم طبي',
      details: `التشخيص الطبي: ${diagnosis || 'مراجعة تخصصية'} | المستشفى: ${hospitalName} | الطبيب: ${doctorName}`,
      approvedBy: doctorName || 'الخدمات الطبية العسكرية',
      department: 'الخدمات الطبية',
      timestamp: formattedTimestamp,
      referenceNumber: refNum,
      additionalInfo: [
        { label: 'المستشفى المعالج', value: hospitalName },
        { label: 'الطبيب الاستشاري', value: doctorName },
        { label: 'مدة الإجازة المرضية', value: `${days} أيام` }
      ]
    };

    setVoucherData(voucher);
    setShowVoucherModal(true);
    showSuccessNotice(`تم توثيق الوصفة الطبية وفترة التعافي للفرد (${activeSoldier.fullName}) وطباعة السند جاهزة`);
    setDiagnosis('');
    onRefresh();
  };

  // Finance Action: Disburse Salary/Bonus/Loan
  const handleFinanceAction = (e: React.FormEvent) => {
    e.preventDefault();
    if (!activeSoldier) return;

    StorageService.addFinancialLog(
      activeSoldier.militaryId,
      {
        date: new Date().toISOString().split('T')[0],
        type: 'مكافأة',
        amount,
        reason: reason || 'مكافأة تميز وحافز عملياتي',
        transactionDate: new Date().toISOString().split('T')[0]
      },
      'المحاسب المالي العسكري',
      currentRole
    );

    showSuccessNotice(`تم صرف مبلغ ${amount.toLocaleString()} ريال للفرد ${activeSoldier.fullName}`);
    setReason('');
    onRefresh();
  };

  // Security Action: Issue Security Infraction / Arrest Order
  const handleSecurityAction = (e: React.FormEvent) => {
    e.preventDefault();
    if (!activeSoldier) {
      alert('يرجى اختيار الفرد المستهدف أولاً من قائمة الاختيار بفي أعلى مساحة العمل');
      return;
    }

    if (!violationText.trim()) {
      alert('يرجى كتابة نص المخالفة أو القرار الأمني');
      return;
    }

    const investigationText = securityDetails.trim()
      ? securityDetails.trim()
      : (securityFileName ? `مرفق محضر/وثيقة أمنية: ${securityFileName}` : 'تم إجراء التحقيق الانضباطي وتوثيق المحضر الرسمي');

    StorageService.addSecurityLog(
      activeSoldier.militaryId,
      {
        date: securityDate || new Date().toISOString().split('T')[0],
        violation: violationText.trim(),
        investigationDetails: investigationText,
        penalty: securityPenalty || 'إنذار مسلكي رسمي وحجز تحفظي',
        warningLevel: securityWarningLevel,
        authority: currentRole,
        status: securityStatus
      },
      'ضابط الأمن والاستخبارات',
      currentRole,
      securityDetain
    );

    // Save attached image/file directly to personnel record attachments
    if (securityFileUrl) {
      StorageService.addAttachment(
        activeSoldier.militaryId,
        {
          title: securityFileName || 'وثيقة ومحضر استخباراتي وأمني',
          category: 'وثيقة أمنية',
          fileType: securityFileUrl.startsWith('data:image') ? 'image' : 'pdf',
          uploadDate: securityDate || new Date().toISOString().split('T')[0],
          fileSize: '1.5 MB',
          fileUrl: securityFileUrl,
          uploadedBy: currentRole,
          notes: violationText
        },
        'فرع الاستخبارات والأمن العسكري',
        currentRole
      );
    }

    showSuccessNotice(`تم توثيق القيد الأمني والمرفقات بنجاح للفرد (${activeSoldier.fullName})${securityDetain ? ' وتوقيفه تحفظياً' : ''}`);
    setViolationText('');
    setSecurityDetails('');
    setSecurityFileUrl('');
    setSecurityFileName('');
    onRefresh();
  };

  // Training Action: Course Enrolment
  const handleTrainingAction = (e: React.FormEvent) => {
    e.preventDefault();
    if (!activeSoldier) return;

    StorageService.registerTrainingCourse(
      activeSoldier.militaryId,
      {
        courseName: courseName || 'دورة المهارات القتالية المتقدمة',
        courseType,
        startDate: courseStartDate,
        endDate: courseEndDate,
        supervisorOfficer,
        trainingLocation,
        grade: courseGrade,
        evaluation: 'دورة تدريبية متقدمة لرفع الجاهزية وتطوير المهارات القتالية الميدانية',
        certificates: 'شهادة دورة تخصصية معتمدة',
        updateStatusToField: true
      },
      supervisorOfficer || 'ضابط التدريب والدورات',
      currentRole
    );

    const refNum = `TRN-${Date.now().toString().slice(-6)}-${Math.floor(1000 + Math.random() * 9000)}`;
    const now = new Date();
    const formattedTimestamp = `${now.toISOString().split('T')[0]} ${now.toTimeString().split(' ')[0]}`;

    const voucher: VoucherData = {
      id: `VCH-TRN-${Math.floor(100000 + Math.random() * 900000)}`,
      type: 'training',
      title: 'سند اعتماد وتسجيل دورة تدريبية تخصصية',
      personnel: activeSoldier,
      startDate: courseStartDate,
      endDate: courseEndDate,
      duration: 'حسب الخطة التدريبية المعتمدة',
      details: `اسم الدورة: ${courseName} | المقر: ${trainingLocation} | المشرف: ${supervisorOfficer}`,
      approvedBy: supervisorOfficer || 'فرع التدريب والعمليات',
      department: 'التدريب والعمليات',
      timestamp: formattedTimestamp,
      referenceNumber: refNum,
      additionalInfo: [
        { label: 'مسار الدورة', value: courseType },
        { label: 'مقر التدريب', value: trainingLocation },
        { label: 'التقدير المستهدف', value: courseGrade }
      ]
    };

    setVoucherData(voucher);
    setShowVoucherModal(true);
    showSuccessNotice(`تم تسجيل الفرد (${activeSoldier.fullName}) بالدورة التدريبية (${courseName}) وطباعة السند جاهزة`);
    setCourseName('');
    onRefresh();
  };

  // Supply Action: Issue Clothing, Equipment, Uniforms
  const handleSupplyAction = (e: React.FormEvent) => {
    e.preventDefault();
    if (!activeSoldier) return;

    StorageService.addSupplyLog(
      activeSoldier.militaryId,
      {
        itemType: supplyType,
        itemName: supplyItemName || 'بدلة ومهمات عسكرية رسمية',
        quantity: supplyQty,
        issueDate: new Date().toISOString().split('T')[0],
        condition: supplyCondition,
        issuedBy: currentRole,
        serialNumber: supplySerial || `EQP-${Math.floor(1000 + Math.random() * 9000)}`,
        notes: supplyNotes || 'صرف بفرع التموين والإمداد'
      },
      'ضابط التموين والإمداد',
      currentRole
    );

    showSuccessNotice(`تم صرف وتوثيق (${supplyItemName || 'المهمات والبدلات العسكرية'}) للفرد ${activeSoldier.fullName} بالسجل الإلكتروني`);
    setSupplyItemName('');
    setSupplySerial('');
    setSupplyNotes('');
    onRefresh();
  };

  return (
    <div className="space-y-6 pb-12">
      
      {/* Top Banner Notice */}
      {notification && (
        <div className="bg-emerald-50 border border-emerald-300 text-emerald-950 p-4 rounded-2xl flex flex-col md:flex-row items-start md:items-center justify-between gap-3 shadow-sm">
          <div className="flex items-center space-x-3 space-x-reverse">
            <CheckCircle2 className="w-5 h-5 text-emerald-700 shrink-0" />
            <span className="font-bold text-xs">{notification}</span>
          </div>
          {voucherData && (
            <button
              type="button"
              onClick={() => setShowVoucherModal(true)}
              className="bg-emerald-800 hover:bg-emerald-900 text-white font-bold px-3.5 py-1.5 rounded-xl text-xs flex items-center space-x-1.5 space-x-reverse shadow-xs transition-all cursor-pointer shrink-0"
            >
              <Printer className="w-3.5 h-3.5" />
              <span>طباعة سند الاعتماد والباركود 🖨️</span>
            </button>
          )}
        </div>
      )}

      {/* Interactive Quick Branch Switcher Bar */}
      <div className="bg-slate-900 border-2 border-slate-700 rounded-3xl p-4 shadow-xl text-white space-y-3">
        <div className="flex flex-wrap items-center justify-between gap-2 px-1">
          <div className="flex items-center space-x-2 space-x-reverse">
            <span className="p-1.5 bg-emerald-500/20 text-emerald-300 border border-emerald-500/40 rounded-lg text-xs font-black">
              🏢 التبديل السريع بين الفروع
            </span>
            <span className="text-xs text-slate-300 font-bold font-['Tajawal']">
              اختر الفرع التخصصي المطلوب للعمل عليه وتوثيق القيود:
            </span>
          </div>
          <span className="text-[11px] text-amber-300 font-mono font-bold bg-slate-950 px-2.5 py-1 rounded-full border border-slate-800">
            الحساب: {currentAccountName}
          </span>
        </div>

        {/* Branch Buttons Grid */}
        <div className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-8 gap-2">
          {BRANCH_DEPARTMENTS_LIST.map((dept) => {
            const isActive = currentRole === dept.role;
            return (
              <button
                key={dept.role}
                type="button"
                onClick={() => {
                  if (onRoleChange) {
                    onRoleChange(dept.role);
                  }
                }}
                className={`p-2.5 rounded-2xl flex flex-col items-center justify-center text-center transition-all cursor-pointer border ${
                  isActive
                    ? `${dept.activeBg} border-white/60 scale-[1.03] ring-2 ring-emerald-400`
                    : 'bg-slate-950/80 hover:bg-slate-800 text-slate-300 border-slate-800 hover:border-slate-700'
                }`}
                title={dept.desc}
              >
                <span className="text-xl mb-1">{dept.icon}</span>
                <span className="text-[11px] font-extrabold font-['Tajawal'] line-clamp-1">
                  {dept.shortTitle}
                </span>
                <span className={`text-[9px] mt-0.5 px-1.5 py-0.2 rounded-md ${
                  isActive ? 'bg-black/30 text-white font-bold' : 'text-slate-400'
                }`}>
                  {isActive ? 'الفرع النشط ✓' : 'انقر للفتح'}
                </span>
              </button>
            );
          })}
        </div>
      </div>

      {/* Header Banner */}
      <div className="bg-white border border-slate-200 rounded-2xl p-6 shadow-sm flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center space-x-2 space-x-reverse">
            <span className="text-xl">🏢</span>
            <h2 className="text-xl font-black text-slate-900 font-['Tajawal']">
              مساحة العمل الخاصة بفرع: ({currentRole})
            </h2>
          </div>
          <p className="text-xs text-slate-500 mt-1 font-medium">
            صلاحية تنفيذ القرارات والإصدارات الخاصة بفرعك وتحديث الملف الإلكتروني والجاهزية تلقائياً
          </p>
        </div>

        {/* Selected Soldier Card */}
        {activeSoldier && (
          <div className="bg-slate-50 border border-slate-200 rounded-xl p-3 flex items-center space-x-3 space-x-reverse min-w-[240px]">
            <PersonnelAvatar
              photoUrl={activeSoldier.photoUrl}
              fullName={activeSoldier.fullName}
              rank={activeSoldier.rank}
              militaryId={activeSoldier.militaryId}
              size="sm"
              shape="rounded"
            />
            <div>
              <div className="text-xs font-bold text-slate-900">{activeSoldier.fullName}</div>
              <div className="text-[10px] text-emerald-800 font-mono font-bold">{activeSoldier.rank} • {activeSoldier.militaryId}</div>
            </div>
          </div>
        )}
      </div>

      {/* Searchable Target Soldier Selector Bar */}
      <div className="bg-white border border-slate-200 rounded-2xl p-4 shadow-sm">
        <TargetPersonnelSearchSelect
          personnel={personnel}
          selectedMilitaryId={selectedMilitaryId}
          onSelect={(militaryId) => setSelectedMilitaryId(militaryId)}
          label="اختيار الفرد المستهدف بالقرار أو الإجراء الإداري (ابحث بالاسم أو الرقم الوظيفي):"
          placeholder="ابحث بالاسم أو الرقم العسكري/الوظيفي أو الوحدة..."
        />
      </div>

      {/* Dynamic Action Panel based on Department Role */}

      {/* 1. HR MANAGEMENT WORKSPACE */}
      {(currentRole === 'إدارة الموارد البشرية' || currentRole === 'القيادة الرئيسية') && (
        <div className="bg-white border border-slate-200 rounded-2xl p-6 shadow-sm space-y-4">
          <div className="flex items-center space-x-2 space-x-reverse border-b border-slate-200 pb-3">
            <Users className="w-5 h-5 text-blue-700" />
            <h3 className="text-base font-bold text-slate-900 font-['Tajawal']">
              إصدار القرارات الإدارية (إجازات، أذونات، مأموريات، فرار)
            </h3>
          </div>

          <form onSubmit={handleHRAction} className="space-y-4 text-xs text-right">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="block text-slate-700 font-bold mb-1">نوع القرار أو الحالة الجديدة *</label>
                <select
                  value={statusInput}
                  onChange={(e) => setStatusInput(e.target.value as PersonnelStatus)}
                  className="w-full bg-slate-50 border border-slate-300 rounded-xl px-3 py-2 text-slate-900 font-bold focus:outline-none focus:bg-white focus:border-emerald-600"
                >
                  <option value="إجازة">منح إجازة سنوية/ميدانية</option>
                  <option value="إذن">إصدار إذن خروج مؤقت</option>
                  <option value="مأمورية">تكليف بمأمورية خارجية</option>
                  <option value="منتدب">تكليف بانتداب خارجي (منتدب)</option>
                  <option value="متواجد">إعادة للخدمة والتواجد بالتمام</option>
                  <option value="في الميدان">انتقال للميدان والانتشار</option>
                  <option value="غياب">تسجيل غياب عن التتمام</option>
                  <option value="فرار">تسجيل فرار رسمي</option>
                  <option value="احتياط">إدراج بقوة الاحتياط</option>
                </select>
              </div>

              {statusInput === 'منتدب' && (
                <div>
                  <label className="block text-purple-900 font-bold mb-1">الوحدة / الجهة المنتدب لديها *</label>
                  <input
                    type="text"
                    required
                    value={secondedUnitInput}
                    onChange={(e) => setSecondedUnitInput(e.target.value)}
                    placeholder="مثال: قيادة المنطقة البحرية الأولى..."
                    className="w-full bg-purple-50 border-2 border-purple-300 rounded-xl px-3 py-2 text-purple-950 font-bold focus:outline-none focus:bg-white focus:border-purple-600"
                  />
                </div>
              )}

              <div>
                <label className="block text-slate-700 font-bold mb-1">سبب القرار والتفاصيل *</label>
                <input
                  type="text"
                  required
                  value={reason}
                  onChange={(e) => setReason(e.target.value)}
                  placeholder="أدخل نص الأسباب والتوجيه الإداري..."
                  className="w-full bg-slate-50 border border-slate-300 rounded-xl px-3 py-2 text-slate-800 focus:outline-none focus:bg-white focus:border-emerald-600"
                />
              </div>
            </div>

            <button
              type="submit"
              className="bg-blue-700 hover:bg-blue-800 text-white font-bold px-6 py-2 rounded-xl transition-all shadow-sm"
            >
              اعتماد القرار الإداري وتحديث الجاهزية اللحظية
            </button>
          </form>
        </div>
      )}

      {/* 2. ARMAMENT WORKSPACE */}
      {(currentRole === 'إدارة التسليح' || currentRole === 'القيادة الرئيسية') && (
        <ArmamentBranchWorkspace
          currentRole={currentRole}
          personnel={personnel}
          onRefresh={onRefresh}
          onSelectPersonnel={onSelectPersonnel}
          currentAccountName={currentAccountName}
        />
      )}

      {/* 3. MEDICAL WORKSPACE */}
      {(currentRole === 'الإدارة الطبية العسكرية' || currentRole === 'القيادة الرئيسية') && (
        <div className="bg-white border border-slate-200 rounded-2xl p-6 shadow-sm space-y-4">
          <div className="flex items-center space-x-2 space-x-reverse border-b border-slate-200 pb-3">
            <Activity className="w-5 h-5 text-pink-700" />
            <h3 className="text-base font-bold text-slate-900 font-['Tajawal']">
              الإدارة الطبية العسكرية: تسجيل الوصفات العلاجية وفترة التعافي واستعادة الجاهزية
            </h3>
          </div>

          <form onSubmit={handleMedicalAction} className="space-y-4 text-xs text-right">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div>
                <label className="block text-slate-700 font-bold mb-1">التشخيص الطبي *</label>
                <input
                  type="text"
                  required
                  value={diagnosis}
                  onChange={(e) => setDiagnosis(e.target.value)}
                  placeholder="التشخيص الجراحي أو الباطني..."
                  className="w-full bg-slate-50 border border-slate-300 rounded-xl px-3 py-2 text-slate-800 focus:outline-none focus:bg-white focus:border-emerald-600"
                />
              </div>

              <div>
                <label className="block text-slate-700 font-bold mb-1">اسم المستشفى العسكري</label>
                <input
                  type="text"
                  value={hospitalName}
                  onChange={(e) => setHospitalName(e.target.value)}
                  className="w-full bg-slate-50 border border-slate-300 rounded-xl px-3 py-2 text-slate-800 focus:outline-none focus:bg-white focus:border-emerald-600"
                />
              </div>

              <div>
                <label className="block text-slate-700 font-bold mb-1">الطبيب المشرف والمعالج</label>
                <input
                  type="text"
                  value={doctorName}
                  onChange={(e) => setDoctorName(e.target.value)}
                  className="w-full bg-slate-50 border border-slate-300 rounded-xl px-3 py-2 text-slate-800 focus:outline-none focus:bg-white focus:border-emerald-600"
                />
              </div>

              <div>
                <label className="block text-slate-700 font-bold mb-1">تاريخ بداية التعافي *</label>
                <input
                  type="date"
                  required
                  value={recoveryStartDate}
                  onChange={(e) => setRecoveryStartDate(e.target.value)}
                  className="w-full bg-slate-50 border border-slate-300 rounded-xl px-3 py-2 text-slate-800 font-bold focus:outline-none focus:bg-white focus:border-emerald-600"
                />
              </div>

              <div>
                <label className="block text-slate-700 font-bold mb-1">تاريخ انتهاء التعافي (استعادة الجاهزية) *</label>
                <input
                  type="date"
                  required
                  value={recoveryEndDate}
                  onChange={(e) => setRecoveryEndDate(e.target.value)}
                  className="w-full bg-pink-50 border border-pink-300 text-pink-950 font-mono font-bold rounded-xl px-3 py-2 focus:outline-none focus:bg-white focus:border-emerald-600"
                />
              </div>

              <div>
                <label className="block text-slate-700 font-bold mb-1">تفاصيل الوصفة العلاجية والدوائية</label>
                <input
                  type="text"
                  value={prescriptionDetails}
                  onChange={(e) => setPrescriptionDetails(e.target.value)}
                  placeholder="الوصفة العلاجية والدوائية..."
                  className="w-full bg-slate-50 border border-slate-300 rounded-xl px-3 py-2 text-slate-800 focus:outline-none focus:bg-white focus:border-emerald-600"
                />
              </div>
            </div>

            <button
              type="submit"
              className="bg-pink-700 hover:bg-pink-800 text-white font-bold px-6 py-2.5 rounded-xl transition-all shadow-sm cursor-pointer"
            >
              توثيق الوصفة الطبية وفترة التعافي وتحديث منحنى الجاهزية 🏥⚡
            </button>
          </form>
        </div>
      )}

      {/* 4. SUPPLY & LOGISTICS WORKSPACE (إدارة التموين والإمداد: صرف المهمات والبدلات العسكرية) */}
      {(currentRole === 'إدارة التموين والإمداد' || currentRole === 'القيادة الرئيسية') && (
        <div className="bg-white border border-slate-200 rounded-2xl p-6 shadow-sm space-y-4">
          <div className="flex items-center space-x-2 space-x-reverse border-b border-slate-200 pb-3">
            <Package className="w-5 h-5 text-indigo-700" />
            <div>
              <h3 className="text-base font-bold text-slate-900 font-['Tajawal']">
                إدارة التموين والإمداد: صرف وتوثيق المهمات والبدلات العسكرية والعتاد
              </h3>
              <p className="text-[11px] text-slate-500 font-medium">
                تقييد وتسجيل كل عملية صرف للمهمات، البدلات الرسمية، البساطير، الدروع، والمعدات الميدانية مع توثيق القيد بالملف الفردي مباشرة.
              </p>
            </div>
          </div>

          <form onSubmit={handleSupplyAction} className="space-y-4 text-xs text-right">
            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-4">
              <div>
                <label className="block text-slate-700 font-bold mb-1">نوع الصنف / المهمة (إدخال يدوي) *</label>
                <input
                  type="text"
                  required
                  list="dept-supply-types-list"
                  value={supplyType}
                  onChange={(e) => setSupplyType(e.target.value as any)}
                  placeholder="اكتب تصنيف الصنف يدوياً..."
                  className="w-full bg-slate-50 border border-slate-300 rounded-xl px-3 py-2 text-slate-900 font-bold focus:outline-none focus:bg-white focus:border-emerald-600"
                />
                <datalist id="dept-supply-types-list">
                  <option value="بدلة عسكرية" />
                  <option value="بسطار/حذاء" />
                  <option value="خوذة/دروع" />
                  <option value="معدات ميدانية" />
                  <option value="مؤن/تجهيزات" />
                  <option value="أجهزة اتصالات" />
                  <option value="مهمات عسكرية أخرى" />
                </datalist>
              </div>

              <div>
                <label className="block text-slate-700 font-bold mb-1">مسمى الصنف والمواصفات *</label>
                <input
                  type="text"
                  required
                  value={supplyItemName}
                  onChange={(e) => setSupplyItemName(e.target.value)}
                  placeholder="بدلة تمويه 2026 / بسطار تكتيكي..."
                  className="w-full bg-slate-50 border border-slate-300 rounded-xl px-3 py-2 text-slate-800 focus:outline-none focus:bg-white focus:border-emerald-600"
                />
              </div>

              <div>
                <label className="block text-slate-700 font-bold mb-1">الكمية المصروفة *</label>
                <input
                  type="number"
                  min={1}
                  required
                  value={supplyQty}
                  onChange={(e) => setSupplyQty(Number(e.target.value))}
                  className="w-full bg-slate-50 border border-slate-300 rounded-xl px-3 py-2 text-slate-800 font-mono font-bold focus:outline-none focus:bg-white focus:border-emerald-600"
                />
              </div>

              <div>
                <label className="block text-slate-700 font-bold mb-1">حالة الصنف</label>
                <select
                  value={supplyCondition}
                  onChange={(e) => setSupplyCondition(e.target.value as any)}
                  className="w-full bg-slate-50 border border-slate-300 rounded-xl px-3 py-2 text-slate-800 font-bold focus:outline-none focus:bg-white focus:border-emerald-600"
                >
                  <option value="جديد">جديد بالكرتون</option>
                  <option value="مستعمل ممتازة">مستعمل - حالة ممتازة</option>
                  <option value="مستعمل جيدة">مستعمل - حالة جيدة</option>
                  <option value="مستهلك">مستهلك / تحتاج تبديل</option>
                </select>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="block text-slate-700 font-bold mb-1">الرقم التسلسلي / كود العهدة (اختياري)</label>
                <input
                  type="text"
                  value={supplySerial}
                  onChange={(e) => setSupplySerial(e.target.value)}
                  placeholder="UNIF-2026-901..."
                  className="w-full bg-slate-50 border border-slate-300 rounded-xl px-3 py-2 text-slate-800 font-mono focus:outline-none focus:bg-white focus:border-emerald-600"
                />
              </div>

              <div>
                <label className="block text-slate-700 font-bold mb-1">ملاحظات والتوجيه الإداري للصرف</label>
                <input
                  type="text"
                  value={supplyNotes}
                  onChange={(e) => setSupplyNotes(e.target.value)}
                  placeholder="أدخل أي ملاحظات خاصة بعهد الصرف..."
                  className="w-full bg-slate-50 border border-slate-300 rounded-xl px-3 py-2 text-slate-800 focus:outline-none focus:bg-white focus:border-emerald-600"
                />
              </div>
            </div>

            <button
              type="submit"
              className="bg-indigo-700 hover:bg-indigo-800 text-white font-bold px-6 py-2 rounded-xl transition-all shadow-sm"
            >
              اعتماد وتقييد عملية الصرف بالسجل الإلكتروني للفرد
            </button>
          </form>
        </div>
      )}

      {/* 4. FINANCIAL WORKSPACE */}
      {(currentRole === 'الإدارة المالية' || currentRole === 'القيادة الرئيسية') && (
        <PayrollManagementWorkspace
          currentRole={currentRole}
          currentUserAccountName={currentAccountName}
        />
      )}

      {/* 5. SECURITY WORKSPACE */}
      {(currentRole === 'الاستخبارات والأمن' || currentRole === 'القيادة الرئيسية') && (
        <div className="bg-white border border-rose-200 rounded-2xl p-6 shadow-sm space-y-5">
          <div className="flex items-center justify-between border-b border-rose-200 pb-3">
            <div className="flex items-center space-x-2 space-x-reverse">
              <Lock className="w-5 h-5 text-rose-700" />
              <h3 className="text-base font-bold text-slate-900 font-['Tajawal']">
                الاستخبارات والأمن العسكري: تقييد القيود والأوامر الأمنية والمخالفات
              </h3>
            </div>
            {activeSoldier && (
              <span className="bg-rose-100 text-rose-900 border border-rose-300 px-3 py-1 rounded-xl text-xs font-bold font-['Tajawal']">
                الفرد المستهدف: {activeSoldier.rank} / {activeSoldier.fullName} ({activeSoldier.militaryId})
              </span>
            )}
          </div>

          <form onSubmit={handleSecurityAction} className="space-y-4 text-xs text-right">
            
            {/* Target Soldier Quick Selector inside form */}
            <div className="bg-slate-50 border border-slate-200 p-3 rounded-xl">
              <TargetPersonnelSearchSelect
                personnel={personnel}
                selectedMilitaryId={selectedMilitaryId}
                onSelect={(id) => setSelectedMilitaryId(id)}
                label="اختر الفرد المستهدف بالقرار الأمني والمخالفة:"
                placeholder="ابحث بالاسم أو الرقم الوظيفي..."
              />
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div>
                <label className="block text-slate-700 font-bold mb-1">تاريخ الواقعة / القرار *</label>
                <input
                  type="date"
                  required
                  value={securityDate}
                  onChange={(e) => setSecurityDate(e.target.value)}
                  className="w-full bg-slate-50 border border-slate-300 rounded-xl px-3 py-2 text-slate-900 font-bold focus:outline-none focus:bg-white focus:border-rose-600"
                />
              </div>

              <div>
                <label className="block text-slate-700 font-bold mb-1">درجة الخطورة *</label>
                <select
                  value={securityWarningLevel}
                  onChange={(e) => setSecurityWarningLevel(e.target.value as any)}
                  className="w-full bg-slate-50 border border-slate-300 rounded-xl px-3 py-2 text-slate-900 font-bold focus:outline-none focus:bg-white focus:border-rose-600"
                >
                  <option value="منخفض">منخفض - تنبيه مسلكي</option>
                  <option value="متوسط">متوسط - مخالفة تعليمات</option>
                  <option value="عالي">عالي - قيد أمني/انضباطي</option>
                  <option value="حرج">حرج - قضايا جسيمة/توقيف</option>
                </select>
              </div>

              <div>
                <label className="block text-slate-700 font-bold mb-1">حالة القيد الانضباطي *</label>
                <select
                  value={securityStatus}
                  onChange={(e) => setSecurityStatus(e.target.value as any)}
                  className="w-full bg-slate-50 border border-slate-300 rounded-xl px-3 py-2 text-slate-900 font-bold focus:outline-none focus:bg-white focus:border-rose-600"
                >
                  <option value="قيد التحقيق">قيد التحقيق والاستجواب</option>
                  <option value="تم البت">تم البت وصدور القرار</option>
                  <option value="محال للنيابة العسكرية">محال للنيابة العسكرية</option>
                  <option value="منتهي">منتهي / حفظ الملف</option>
                </select>
              </div>
            </div>

            <div>
              <label className="block text-slate-700 font-bold mb-1">موضوع المخالفة / القرار الأمني *</label>
              <input
                type="text"
                required
                value={violationText}
                onChange={(e) => setViolationText(e.target.value)}
                placeholder="مثال: مخالفة ضوابط السرية والتمام / تجاوز التعليمات العسكرية..."
                className="w-full bg-slate-50 border border-slate-300 rounded-xl px-3 py-2 text-slate-900 font-bold focus:outline-none focus:bg-white focus:border-rose-600"
              />
            </div>

            <div>
              <label className="block text-slate-700 font-bold mb-1">العقوبة / القرار الصادر *</label>
              <div className="space-y-2">
                <input
                  type="text"
                  required
                  value={securityPenalty}
                  onChange={(e) => setSecurityPenalty(e.target.value)}
                  placeholder="مثال: إنذار مسلكي رسمي / حجز تحفظي 5 أيام / خصم راتب..."
                  className="w-full bg-slate-50 border border-slate-300 rounded-xl px-3 py-2 text-slate-900 font-bold focus:outline-none focus:bg-white focus:border-rose-600"
                />
                <div className="flex flex-wrap gap-1.5 text-[10px]">
                  <span className="text-slate-500 font-bold self-center">اختيارات سريعة:</span>
                  {[
                    'إنذار مسلكي رسمي',
                    'حجز تحفظي وتوقيف',
                    'خصم 3 أيام من الراتب',
                    'لفت نظر انضباطي',
                    'إحالة للمحكمة العسكرية',
                    'تنبيه شفهي وثائقي'
                  ].map((preset) => (
                    <button
                      key={preset}
                      type="button"
                      onClick={() => setSecurityPenalty(preset)}
                      className="bg-slate-100 hover:bg-rose-100 text-slate-700 hover:text-rose-900 border border-slate-200 px-2 py-0.5 rounded-lg font-bold transition-all cursor-pointer"
                    >
                      {preset}
                    </button>
                  ))}
                </div>
              </div>
            </div>

            <div>
              <label className="block text-slate-700 font-bold mb-1">تفاصيل المحضر والتحقيق الاستخباراتي</label>
              <textarea
                rows={3}
                value={securityDetails}
                onChange={(e) => setSecurityDetails(e.target.value)}
                placeholder="أدخل نص المحضر ومجريات التحقيق والتوجيهات الاستخباراتية..."
                className="w-full bg-slate-50 border border-slate-300 rounded-xl p-3 text-slate-800 focus:outline-none focus:bg-white focus:border-rose-600"
              ></textarea>
            </div>

            {/* Detain Toggle Option */}
            <div className="bg-amber-50 border border-amber-200 p-3 rounded-xl flex items-center justify-between">
              <label className="flex items-center space-x-2 space-x-reverse cursor-pointer font-bold text-amber-950 text-xs">
                <input
                  type="checkbox"
                  checked={securityDetain}
                  onChange={(e) => setSecurityDetain(e.target.checked)}
                  className="w-4 h-4 text-rose-700 rounded border-slate-300 focus:ring-rose-500"
                />
                <span>توقيف الفرد آلياً وتحويل حالته في التمام إلى (موقوف / محتجز)</span>
              </label>
              <span className="text-[10px] text-amber-800 font-bold">
                {securityDetain ? 'سيتم تغيير حالة الفرد آلياً إلى موقوف' : 'لن يتم تغيير حالة الفرد بالتمام'}
              </span>
            </div>

            {/* Security Attachment / Image Upload Section */}
            <div className="bg-rose-50/70 border border-rose-200 p-3.5 rounded-xl space-y-2">
              <label className="block text-rose-900 font-bold flex items-center space-x-1.5 space-x-reverse">
                <Paperclip className="w-4 h-4 text-rose-700" />
                <span>إرفاق ملف / صورة وثيقة استخباراتية وأمنية (تظهر فوراً بملف الفرد):</span>
              </label>

              <div className="flex flex-col sm:flex-row items-center gap-3">
                <label className="cursor-pointer bg-white border border-rose-300 hover:bg-rose-100 text-rose-900 px-4 py-2 rounded-xl flex items-center space-x-2 space-x-reverse font-bold shadow-xs transition-all">
                  <Upload className="w-4 h-4 text-rose-700" />
                  <span>اختر صورة أو وثيقة من جهازك</span>
                  <input
                    type="file"
                    accept="image/*,application/pdf,.doc,.docx"
                    className="hidden"
                    onChange={async (e) => {
                      const file = e.target.files?.[0];
                      if (file) {
                        setSecurityFileName(file.name);
                        try {
                          const compressedUrl = await compressImageFile(file);
                          setSecurityFileUrl(compressedUrl);
                        } catch (err) {
                          console.error('Failed to compress file:', err);
                        }
                      }
                    }}
                  />
                </label>

                {securityFileName && (
                  <div className="flex items-center space-x-2 space-x-reverse text-xs bg-white px-3 py-1.5 rounded-lg border border-rose-200 font-bold text-slate-800">
                    <ImageIcon className="w-4 h-4 text-rose-600" />
                    <span className="truncate max-w-[200px]">{securityFileName}</span>
                    <button
                      type="button"
                      onClick={() => {
                        setSecurityFileUrl('');
                        setSecurityFileName('');
                      }}
                      className="text-rose-600 hover:text-rose-800 mr-2 font-black"
                    >
                      ✕
                    </button>
                  </div>
                )}
              </div>

              {securityFileUrl && securityFileUrl.startsWith('data:image') && (
                <div className="mt-2">
                  <span className="text-[10px] text-slate-500 font-bold block mb-1">معاينة الصورة المرفقة:</span>
                  <img
                    src={securityFileUrl}
                    alt="معاينة المرفق الأمني"
                    className="w-32 h-24 object-cover rounded-xl border-2 border-rose-400 shadow-sm"
                  />
                </div>
              )}
            </div>

            <button
              type="submit"
              className="w-full sm:w-auto bg-rose-700 hover:bg-rose-800 text-white font-bold px-8 py-2.5 rounded-xl transition-all shadow-md cursor-pointer flex items-center justify-center space-x-2 space-x-reverse"
            >
              <Lock className="w-4 h-4" />
              <span>اعتماد القيد الأمني والمرفقات {securityDetain ? 'وتوقيف الفرد' : ''}</span>
            </button>
          </form>
        </div>
      )}

      {/* 6. TRAINING WORKSPACE */}
      {(currentRole === 'إدارة التدريب' || currentRole === 'القيادة الرئيسية') && (
        <div className="bg-white border border-slate-200 rounded-2xl p-6 shadow-sm space-y-4">
          <div className="flex items-center space-x-2 space-x-reverse border-b border-slate-200 pb-3">
            <Award className="w-5 h-5 text-purple-700" />
            <h3 className="text-base font-bold text-slate-900 font-['Tajawal']">
              إدارة التدريب: الالتحاق بالدورات العسكرية وتعيين المشرف وتحديث القيد
            </h3>
          </div>

          <form onSubmit={handleTrainingAction} className="space-y-4 text-xs text-right">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div className="md:col-span-2">
                <label className="block text-slate-700 font-bold mb-1">اسم الدورة العسكرية *</label>
                <input
                  type="text"
                  required
                  value={courseName}
                  onChange={(e) => setCourseName(e.target.value)}
                  placeholder="دورة صيانة مدرعات / دورة قناصة / دورة قيادة..."
                  className="w-full bg-slate-50 border border-slate-300 rounded-xl px-3 py-2 text-slate-800 font-bold focus:outline-none focus:bg-white focus:border-purple-600"
                />
              </div>

              <div>
                <label className="block text-slate-700 font-bold mb-1">نوع الدورة</label>
                <select
                  value={courseType}
                  onChange={(e) => setCourseType(e.target.value as any)}
                  className="w-full bg-slate-50 border border-slate-300 rounded-xl px-3 py-2 text-slate-800 font-bold focus:outline-none focus:bg-white focus:border-purple-600"
                >
                  <option value="ميداني">ميداني وتكتيكي</option>
                  <option value="قيادي">قيادي وإداري</option>
                  <option value="تقني">تقني وفني</option>
                  <option value="أمني">أمني واستخباراتي</option>
                  <option value="تخصصي">تخصصي نوعي</option>
                  <option value="خارجي">دورة خارجية</option>
                </select>
              </div>

              <div>
                <label className="block text-slate-700 font-bold mb-1">الضابط المشرف على الدورة *</label>
                <input
                  type="text"
                  required
                  value={supervisorOfficer}
                  onChange={(e) => setSupervisorOfficer(e.target.value)}
                  placeholder="رتبة واسم الضابط المشرف..."
                  className="w-full bg-slate-50 border border-slate-300 rounded-xl px-3 py-2 text-slate-800 font-bold focus:outline-none focus:bg-white focus:border-purple-600"
                />
              </div>

              <div>
                <label className="block text-slate-700 font-bold mb-1">تاريخ بداية الدورة *</label>
                <input
                  type="date"
                  required
                  value={courseStartDate}
                  onChange={(e) => setCourseStartDate(e.target.value)}
                  className="w-full bg-slate-50 border border-slate-300 rounded-xl px-3 py-2 text-slate-800 font-bold focus:outline-none focus:bg-white focus:border-purple-600"
                />
              </div>

              <div>
                <label className="block text-slate-700 font-bold mb-1">تاريخ انتهاء الدورة *</label>
                <input
                  type="date"
                  required
                  value={courseEndDate}
                  onChange={(e) => setCourseEndDate(e.target.value)}
                  className="w-full bg-purple-50 border border-purple-300 text-purple-950 font-mono font-bold rounded-xl px-3 py-2 focus:outline-none focus:bg-white focus:border-purple-600"
                />
              </div>

              <div className="md:col-span-2">
                <label className="block text-slate-700 font-bold mb-1">مكان ومقر التدريب</label>
                <input
                  type="text"
                  value={trainingLocation}
                  onChange={(e) => setTrainingLocation(e.target.value)}
                  className="w-full bg-slate-50 border border-slate-300 rounded-xl px-3 py-2 text-slate-800 focus:outline-none focus:bg-white focus:border-purple-600"
                />
              </div>

              <div>
                <label className="block text-slate-700 font-bold mb-1">التقدير المتوقع</label>
                <select
                  value={courseGrade}
                  onChange={(e) => setCourseGrade(e.target.value as any)}
                  className="w-full bg-slate-50 border border-slate-300 rounded-xl px-3 py-2 text-slate-800 font-bold focus:outline-none focus:bg-white focus:border-purple-600"
                >
                  <option value="ممتاز">ممتاز</option>
                  <option value="جيد جداً">جيد جداً</option>
                  <option value="جيد">جيد</option>
                  <option value="مقبول">مقبول</option>
                  <option value="مؤهل">مؤهل / اجتاز</option>
                </select>
              </div>
            </div>

            <button
              type="submit"
              className="bg-purple-700 hover:bg-purple-800 text-white font-bold px-6 py-2.5 rounded-xl transition-all shadow-sm cursor-pointer"
            >
              إدراج القيد بسجل الدورات وتحديث مؤشرات الجاهزية 🎓⚡
            </button>
          </form>
        </div>
      )}

      {/* 8. VEHICLES & EQUIPMENT READINESS WORKSPACE */}
      {(currentRole === 'جاهزية العربات والآليات' ||
        currentRole === 'القيادة الرئيسية' ||
        currentAccountName.includes('عربات') ||
        currentAccountName.includes('آليات') ||
        currentAccountName.includes('جاهزية')) && (
        <VehiclesReadinessWorkspace
          currentAccountName={currentAccountName}
          isMainCommand={isMainCommand}
        />
      )}

      {/* Approval Voucher Modal */}
      <ApprovalVoucherModal
        isOpen={showVoucherModal}
        onClose={() => setShowVoucherModal(false)}
        voucherData={voucherData}
      />

    </div>
  );
};
