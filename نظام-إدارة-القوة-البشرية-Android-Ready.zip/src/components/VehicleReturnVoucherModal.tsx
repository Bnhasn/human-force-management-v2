import React, { useRef, useState, useEffect } from 'react';
import { VehicleReturnClearanceOrder } from '../types';
import { QRCodeSVG } from 'qrcode.react';
import {
  Printer,
  X,
  ShieldCheck,
  Truck,
  UserCheck,
  Wrench,
  CheckCircle2,
  Calendar,
  AlertCircle,
  Share2
} from 'lucide-react';
import { getCurrentHeaderInfo } from '../lib/headerUtils';
import {
  preparePrintableDocument,
  executeUnifiedPrint,
  shareOrSavePrintableDocument
} from '../lib/unifiedPrintService';

interface VehicleReturnVoucherModalProps {
  order: VehicleReturnClearanceOrder | null;
  onClose: () => void;
}

export const VehicleReturnVoucherModal: React.FC<VehicleReturnVoucherModalProps> = ({
  order,
  onClose
}) => {
  const printContentRef = useRef<HTMLDivElement>(null);
  const [isDocumentReady, setIsDocumentReady] = useState(false);

  useEffect(() => {
    if (!order) return;
    setIsDocumentReady(false);
    let isCancelled = false;

    preparePrintableDocument(printContentRef.current).then(() => {
      if (!isCancelled) {
        setIsDocumentReady(true);
      }
    });

    return () => {
      isCancelled = true;
    };
  }, [order]);

  if (!order) return null;

  const headerInfo = getCurrentHeaderInfo();

  const handlePrint = async () => {
    await executeUnifiedPrint(printContentRef.current, {
      documentTitle: `سند_إخلاء_عهدة_عربة_${order.returnNumber}_${order.plateNumber}`,
      orientation: 'portrait'
    });
  };

  const handleSharePdf = async () => {
    await shareOrSavePrintableDocument(printContentRef.current, {
      title: `سند إخلاء عهدة عربة - ${order.returnNumber}`,
      filename: `إخلاء_عهدة_${order.returnNumber}.html`,
      orientation: 'portrait'
    });
  };

  const qrData = JSON.stringify({
    voucher: order.returnNumber,
    vehicle: order.vehicleName,
    plate: order.plateNumber,
    date: order.returnDate,
    handoverPerson: order.handoverPersonName,
    receivingBranch: order.recipientBranch || 'فرع الفنية والحركة المركزي الرئيسي',
    condition: order.conditionAtHandover,
    status: order.clearanceStatus
  });

  return (
    <div className="fixed inset-0 z-50 bg-slate-950/85 backdrop-blur-md flex items-center justify-center p-2 sm:p-4 overflow-y-auto printable-modal-overlay print:p-0 print:bg-white print:static print:block">
      <div className="bg-slate-900 border border-indigo-500/50 rounded-3xl w-full max-w-4xl overflow-hidden shadow-2xl animate-fadeIn my-6 printable-modal-card print:border-none print:shadow-none print:rounded-none print:m-0 print:w-full print:bg-white">
        {/* Modal Top Bar (Hidden in Print) */}
        <div className="bg-gradient-to-l from-indigo-950 via-slate-900 to-indigo-900 border-b border-indigo-500/40 p-4 flex items-center justify-between print:hidden no-print">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-xl bg-indigo-500/20 border border-indigo-500/40 flex items-center justify-center text-indigo-400">
              <ShieldCheck className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-base font-black text-white flex items-center gap-2">
                معاينة وطباعة سند إخلاء العهدة الرسمي
              </h2>
              <p className="text-xs text-indigo-300 font-mono">
                رقم السند: {order.returnNumber}
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            {/* Document readiness indicator */}
            <div className={`hidden sm:flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-bold border transition-colors ${
              isDocumentReady
                ? 'bg-emerald-950/60 text-emerald-300 border-emerald-500/40'
                : 'bg-amber-950/60 text-amber-300 border-amber-500/40 animate-pulse'
            }`}>
              <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
              <span>{isDocumentReady ? 'المستند جاهز للطباعة' : 'جاري تجهيز الخطوط...'}</span>
            </div>

            <button
              onClick={handlePrint}
              className="px-4 py-2 bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-600 active:scale-95 text-slate-950 font-black text-xs rounded-xl shadow-lg flex items-center gap-2 cursor-pointer transition-all"
            >
              <Printer className="w-4 h-4" />
              أمر الطباعة 🖨️
            </button>

            <button
              onClick={handleSharePdf}
              className="px-3.5 py-2 bg-sky-600 hover:bg-sky-500 active:scale-95 text-white font-bold text-xs rounded-xl shadow-md flex items-center gap-1.5 cursor-pointer transition-all"
              title="مشاركة أو حفظ السند بصيغة PDF / تقرير معتمد"
            >
              <Share2 className="w-4 h-4" />
              مشاركة / حفظ PDF 📄
            </button>

            <button
              onClick={onClose}
              className="p-2 text-slate-400 hover:text-white bg-slate-800 rounded-xl border border-slate-700 cursor-pointer"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Printable Paper Canvas */}
        <div className="p-4 sm:p-6 max-h-[85vh] overflow-y-auto print:max-h-none print:overflow-visible print:p-0 bg-slate-950/50">
          <div
            ref={printContentRef}
            id="vehicle-return-printable-area"
            data-printable-content="true"
            className="bg-white text-slate-900 p-6 sm:p-8 rounded-2xl shadow-xl border border-slate-300 print:border-none print:shadow-none print:rounded-none print:p-6 max-w-3xl mx-auto space-y-5 print:w-full"
            dir="rtl"
          >
            {/* Document Official Military Header */}
            <div className="border-b-2 border-slate-800 pb-4">
              <div className="flex items-start justify-between">
                {/* Right: Force & Division Details */}
                <div className="text-right space-y-0.5">
                  <div className="font-bold text-xs text-slate-600">الجمهورية اليمنية</div>
                  <div className="font-bold text-xs text-slate-700">وزارة الدفاع ورئاسة هيئة الأركان العامة</div>
                  <div className="font-black text-xs text-slate-900">{headerInfo.forceName}</div>
                  <div className="font-bold text-xs text-slate-700">{headerInfo.divisionName} - {headerInfo.unitName}</div>
                  <div className="font-black text-xs text-indigo-900">ركن الفنية والحركة - إدارة الجاهزية الميدانية</div>
                </div>

                {/* Center: Emblem / Title Badge */}
                <div className="text-center space-y-1">
                  <div className="w-16 h-16 mx-auto flex items-center justify-center">
                    <img
                      src="/yemen-emblem.png"
                      alt="شعار الجمهورية"
                      className="max-h-16 w-auto object-contain mx-auto"
                      onError={(e) => {
                        // Fallback badge if image is missing
                        (e.target as HTMLElement).style.display = 'none';
                      }}
                    />
                  </div>
                  <span className="inline-block px-3 py-1 bg-indigo-900 text-white font-black text-xs rounded border border-indigo-950 shadow-sm">
                    وثيقة عسكرية رسمية
                  </span>
                </div>

                {/* Left: Voucher Serial & QR Code */}
                <div className="text-left space-y-1 flex flex-col items-end">
                  <div className="p-1 bg-white border border-slate-300 rounded shadow-xs">
                    <QRCodeSVG value={qrData} size={58} />
                  </div>
                  <div className="text-[10px] text-slate-700 font-mono font-bold">
                    الرقم: <span className="text-indigo-950 font-black">{order.returnNumber}</span>
                  </div>
                  <div className="text-[10px] text-slate-700 font-mono">
                    التاريخ: {order.returnDate}
                  </div>
                  {order.returnTime && (
                    <div className="text-[10px] text-slate-600 font-mono">
                      الوقت: {order.returnTime}
                    </div>
                  )}
                </div>
              </div>

              {/* Main Document Headline */}
              <div className="mt-4 text-center">
                <h1 className="text-lg font-black text-slate-900 tracking-wide border-y border-slate-300 py-1.5 bg-slate-100/70">
                  سند إخلاء عهدة وتسليم آلية / معدة إلى فرع الفنية والحركة المركزي الرئيسي
                </h1>
              </div>
            </div>

            {/* Authority Reference Text */}
            <div className="text-[11px] text-slate-700 bg-slate-50 border border-slate-200 p-2.5 rounded-lg flex items-center justify-between">
              <div>
                <span className="font-bold text-slate-900">الجهة الآمرة بالإرجاع: </span>
                <span>{order.returnAuthority || 'قيادة اللواء وركن الفنية والحركة'}</span>
              </div>
              <div>
                <span className="font-bold text-slate-900">سبب الإرجاع: </span>
                <span>{order.returnReason}</span>
              </div>
            </div>

            {/* Table 1: Vehicle & Equipment Specifications */}
            <div className="space-y-1.5">
              <div className="font-black text-xs text-indigo-950 flex items-center gap-1.5 border-b border-indigo-200 pb-1">
                <Truck className="w-3.5 h-3.5 text-indigo-800" />
                <span>أولاً: بيانات ومواصفات الآلية أو المعدة المسلّمة</span>
              </div>

              <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 text-xs">
                <div className="bg-slate-50 border border-slate-200 p-2 rounded">
                  <span className="text-[10px] text-slate-500 block">اسم الآلية / المعدة:</span>
                  <strong className="text-slate-900 font-black block mt-0.5">{order.vehicleName}</strong>
                </div>

                <div className="bg-slate-50 border border-slate-200 p-2 rounded">
                  <span className="text-[10px] text-slate-500 block">رقم اللوحة / السيريال:</span>
                  <strong className="text-indigo-900 font-mono font-black block mt-0.5">{order.plateNumber}</strong>
                </div>

                <div className="bg-slate-50 border border-slate-200 p-2 rounded">
                  <span className="text-[10px] text-slate-500 block">الفئة:</span>
                  <strong className="text-slate-800 block mt-0.5">{order.vehicleCategory}</strong>
                </div>

                <div className="bg-slate-50 border border-slate-200 p-2 rounded">
                  <span className="text-[10px] text-slate-500 block">رقم المحرك / الشاسي:</span>
                  <strong className="text-slate-800 font-mono block mt-0.5">{order.engineSerial || 'مطابق للسجلات'}</strong>
                </div>

                <div className="bg-slate-50 border border-slate-200 p-2 rounded">
                  <span className="text-[10px] text-slate-500 block">عداد الكيلومترات / ساعات التشغيل:</span>
                  <strong className="text-slate-900 font-mono block mt-0.5">
                    {order.mileageKmAtReturn ? `${order.mileageKmAtReturn.toLocaleString()} كم` : 'غير مسجل'}
                  </strong>
                </div>

                <div className="bg-slate-50 border border-slate-200 p-2 rounded">
                  <span className="text-[10px] text-slate-500 block">مستوى الوقود وقت التسليم:</span>
                  <strong className="text-slate-800 block mt-0.5">{order.fuelLevelAtReturn || 'متوسط (1/2)'}</strong>
                </div>

                <div className="bg-slate-50 border border-slate-200 p-2 rounded col-span-2">
                  <span className="text-[10px] text-slate-500 block">الوحدة العسكرية المسلّمة:</span>
                  <strong className="text-slate-800 block mt-0.5">{order.handoverPersonUnit || 'اللواء الميداني'}</strong>
                </div>
              </div>
            </div>

            {/* Table 2: Handover Person & Receiving Officer */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
              {/* Handover Custodian */}
              <div className="border border-slate-300 rounded-lg p-3 space-y-1.5 bg-slate-50/50">
                <div className="font-black text-xs text-slate-900 border-b border-slate-200 pb-1 flex items-center justify-between">
                  <span>ثانياً: المسلّم (مخلِي العهدة)</span>
                  <span className="text-[10px] bg-slate-200 px-1.5 py-0.5 rounded text-slate-700">طرف أول</span>
                </div>
                <div className="space-y-1 text-[11px]">
                  <div><span className="text-slate-500">الاسم:</span> <strong className="text-slate-900">{order.handoverPersonName}</strong></div>
                  <div><span className="text-slate-500">الرتبة العسكرية:</span> <strong className="text-slate-800">{order.handoverPersonRank}</strong></div>
                  <div><span className="text-slate-500">الرقم العسكري:</span> <strong className="text-slate-800 font-mono">{order.handoverPersonMilitaryId}</strong></div>
                  <div><span className="text-slate-500">الوحدة / اللواء:</span> <span className="text-slate-700">{order.handoverPersonUnit}</span></div>
                  {order.handoverPersonPhone && (
                    <div><span className="text-slate-500">الهاتف:</span> <span className="text-slate-700 font-mono">{order.handoverPersonPhone}</span></div>
                  )}
                </div>
              </div>

              {/* Receiving Technical Team */}
              <div className="border border-indigo-200 rounded-lg p-3 space-y-1.5 bg-indigo-50/30">
                <div className="font-black text-xs text-indigo-950 border-b border-indigo-200 pb-1 flex items-center justify-between">
                  <span>ثالثاً: لجنة الاستلام بالفنية والحركة</span>
                  <span className="text-[10px] bg-indigo-100 text-indigo-900 px-1.5 py-0.5 rounded">طرف ثانٍ (مستلم)</span>
                </div>
                <div className="space-y-1 text-[11px]">
                  <div><span className="text-slate-500">فرع الاستلام:</span> <strong className="text-indigo-950">{order.recipientBranch || 'فرع الفنية والحركة المركزي الرئيسي'}</strong></div>
                  <div><span className="text-slate-500">ضابط الاستلام:</span> <strong className="text-slate-900">{order.receivingOfficerName}</strong> ({order.receivingOfficerRank})</div>
                  {order.receivingOfficerMilitaryId && (
                    <div><span className="text-slate-500">الرقم العسكري:</span> <strong className="text-slate-800 font-mono">{order.receivingOfficerMilitaryId}</strong></div>
                  )}
                  {order.receivingTechnicianName && (
                    <div><span className="text-slate-500">الفني الفاحص:</span> <strong className="text-slate-800">{order.receivingTechnicianName}</strong></div>
                  )}
                </div>
              </div>
            </div>

            {/* SECTION 4: CONDITION NOTE AT HANDOVER (THE PRIMARY HIGHLIGHTED FIELD) */}
            <div className="border-2 border-indigo-800 rounded-xl p-3.5 bg-indigo-50/50 space-y-2.5">
              <div className="flex items-center justify-between border-b border-indigo-200 pb-1.5">
                <div className="font-black text-xs text-indigo-950 flex items-center gap-1.5">
                  <Wrench className="w-4 h-4 text-indigo-700" />
                  <span>رابعاً: محضر الفحص الفني وحالة العربة وقت تسليمها إلى فرع الفنية والحركة الرئيسي</span>
                </div>
                <span className="text-[10px] font-bold px-2 py-0.5 rounded bg-indigo-900 text-white">
                  الحالة الفنية: {order.conditionAtHandover}
                </span>
              </div>

              {/* Handover Condition Notes */}
              <div className="bg-white border border-indigo-200 p-3 rounded-lg text-xs leading-relaxed text-slate-800">
                <span className="font-bold text-slate-900 block mb-1 text-[11px]">
                  ملاحظة حالة العربة المسجلة عند التسليم لفرع الفنية والحركة:
                </span>
                <p className="font-medium whitespace-pre-wrap">{order.handoverConditionNotes}</p>
              </div>

              {/* Technical Defects if any */}
              {order.technicalDefects && (
                <div className="bg-amber-50 border border-amber-200 p-2.5 rounded-lg text-xs text-amber-950 flex items-start gap-2">
                  <AlertCircle className="w-4 h-4 text-amber-600 flex-shrink-0 mt-0.5" />
                  <div>
                    <strong className="block text-[11px] text-amber-900">النواقص أو الأعطال المرصودة وقت التسليم:</strong>
                    <span>{order.technicalDefects}</span>
                  </div>
                </div>
              )}

              {/* Accessories Checklist Summary */}
              {order.accessoriesChecklist && (
                <div className="pt-1">
                  <span className="text-[10px] font-bold text-slate-700 block mb-1">
                    جرد الملحقات والتجهيزات الفنية المستلمة مع الآلية:
                  </span>
                  <div className="grid grid-cols-3 gap-2 text-[10px] text-slate-700 bg-white p-2 rounded border border-slate-200">
                    <div className="flex items-center gap-1">
                      <span className={order.accessoriesChecklist.spareTire ? 'text-emerald-600 font-bold' : 'text-slate-400'}>
                        {order.accessoriesChecklist.spareTire ? '☑' : '☒'} الإطار الاحتياطي
                      </span>
                    </div>
                    <div className="flex items-center gap-1">
                      <span className={order.accessoriesChecklist.jackAndTools ? 'text-emerald-600 font-bold' : 'text-slate-400'}>
                        {order.accessoriesChecklist.jackAndTools ? '☑' : '☒'} العفريتة ومعدات الطوارئ
                      </span>
                    </div>
                    <div className="flex items-center gap-1">
                      <span className={order.accessoriesChecklist.radioComms ? 'text-emerald-600 font-bold' : 'text-slate-400'}>
                        {order.accessoriesChecklist.radioComms ? '☑' : '☒'} جهاز اللاسلكي
                      </span>
                    </div>
                    <div className="flex items-center gap-1">
                      <span className={order.accessoriesChecklist.fireExtinguisher ? 'text-emerald-600 font-bold' : 'text-slate-400'}>
                        {order.accessoriesChecklist.fireExtinguisher ? '☑' : '☒'} طفاية الحريق
                      </span>
                    </div>
                    <div className="flex items-center gap-1">
                      <span className={order.accessoriesChecklist.keysHandedOver ? 'text-emerald-600 font-bold' : 'text-slate-400'}>
                        {order.accessoriesChecklist.keysHandedOver ? '☑' : '☒'} المفاتيح الأصلية
                      </span>
                    </div>
                    <div className="flex items-center gap-1">
                      <span className={order.accessoriesChecklist.registrationDocs ? 'text-emerald-600 font-bold' : 'text-slate-400'}>
                        {order.accessoriesChecklist.registrationDocs ? '☑' : '☒'} وثائق وكروت الآلية
                      </span>
                    </div>
                  </div>
                  {order.accessoriesChecklist.otherEquipment && (
                    <div className="text-[10px] text-slate-600 mt-1">
                      تجهيزات إضافية: <strong>{order.accessoriesChecklist.otherEquipment}</strong>
                    </div>
                  )}
                </div>
              )}
            </div>

            {/* Official Clearance Declaration */}
            <div className="bg-slate-100 border border-slate-300 p-3 rounded-lg text-xs leading-relaxed text-center font-bold text-slate-800">
              <p>
                « نشهد نحن فرع الفنية والحركة المركزي الرئيسي بأنه بموجب هذا السند تم استلام الآلية المذكورة أعلاه، وبناءً على محضر الفحص الفني المدوّن أعلاه، يُعتبر المسلّم / 
                <span className="text-indigo-950 font-black px-1">({order.handoverPersonName})</span> 
                بريء الذمة ومخلى عهدته بالكامل عن هذه الآلية وتوابعها اعتباراً من تاريخ توقيع هذا السند. »
              </p>
            </div>

            {/* Official Quadruple Signatures and Stamps */}
            <div className="pt-4 border-t-2 border-slate-800">
              <div className="grid grid-cols-4 gap-2 text-center text-xs">
                {/* 1. المسلّم ومخلِي العهدة */}
                <div className="space-y-8">
                  <div>
                    <div className="font-bold text-[11px] text-slate-700">المسلّم (مخلِي العهدة)</div>
                    <div className="text-[10px] text-slate-500 font-semibold">{order.handoverPersonName}</div>
                  </div>
                  <div className="border-t border-dashed border-slate-400 pt-1 text-[10px] text-slate-500">
                    التوقيع: ........................
                  </div>
                </div>

                {/* 2. الفني الفاحص */}
                <div className="space-y-8">
                  <div>
                    <div className="font-bold text-[11px] text-slate-700">الفني الفاحص</div>
                    <div className="text-[10px] text-slate-500 font-semibold">{order.receivingTechnicianName || 'المهندس المختص'}</div>
                  </div>
                  <div className="border-t border-dashed border-slate-400 pt-1 text-[10px] text-slate-500">
                    التوقيع: ........................
                  </div>
                </div>

                {/* 3. ضابط استلام الفنية والحركة */}
                <div className="space-y-8">
                  <div>
                    <div className="font-bold text-[11px] text-slate-700">ضابط استلام الفنية والحركة</div>
                    <div className="text-[10px] text-slate-500 font-semibold">{order.receivingOfficerName}</div>
                  </div>
                  <div className="border-t border-dashed border-slate-400 pt-1 text-[10px] text-slate-500">
                    التوقيع: ........................
                  </div>
                </div>

                {/* 4. الختم والمصادقة */}
                <div className="space-y-3 flex flex-col items-center">
                  <div>
                    <div className="font-bold text-[11px] text-indigo-950">مدير فرع الفنية والحركة الرئيسي</div>
                    <div className="text-[10px] text-slate-600 font-semibold">{order.headOfBranchApproval || 'العميد ركن / مسعد القحطاني'}</div>
                  </div>
                  <div className="w-16 h-16 border-2 border-indigo-900 border-dashed rounded-full flex items-center justify-center text-[9px] font-black text-indigo-900 rotate-[-12deg] bg-indigo-50/50">
                    ختم الفرع المركزي
                  </div>
                </div>
              </div>
            </div>

            {/* Footer Notice */}
            <div className="text-center text-[9px] text-slate-500 pt-2 border-t border-slate-200">
              وثيقة نظام جاهزية العربات والآليات الموحد - صدرت إلكترونياً وتخضع للرقابة والتفتيش الفني الدوري
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
