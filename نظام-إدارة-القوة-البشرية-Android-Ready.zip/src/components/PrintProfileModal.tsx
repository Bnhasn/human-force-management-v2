import React, { useState, useMemo, useRef, useEffect } from 'react';
import { createPortal } from 'react-dom';
import { getCurrentHeaderInfo } from '../lib/headerUtils';
import { Shield, Printer, X, FileCheck, UserPlus, FileText, CheckCircle2, Activity, Award, AlertTriangle, HeartPulse, DollarSign, Package, Repeat, Calendar, MapPin, User, Crosshair, Phone, Clock, FileSpreadsheet, Filter, CheckSquare, Layers, Share2, Loader2, ArrowRight } from 'lucide-react';
import { PersonnelRecord } from '../types';
import { PersonnelAvatar } from './PersonnelAvatar';
import { executeUnifiedPrint, shareOrSavePrintableDocument, preparePrintableDocument } from '../lib/unifiedPrintService';
import { StorageService } from '../lib/storage';

interface PrintProfileModalProps {
  personnel: PersonnelRecord | null;
  reportTitle?: string;
  reportData?: PersonnelRecord[];
  reportType?: string;
  onClose: () => void;
  currentAccountName?: string;
}

export const PrintProfileModal: React.FC<PrintProfileModalProps> = ({
  personnel,
  reportTitle,
  reportData,
  reportType,
  onClose,
  currentAccountName = 'قيادة الفرقة الثالثة'
}) => {
  if (!personnel && (!reportData || reportData.length === 0)) return null;

  const activeReportType = reportType || (
    reportTitle?.includes('أمن') || reportTitle?.includes('مخالفات') ? 'security' :
    reportTitle?.includes('طب') || reportTitle?.includes('منوم') ? 'medical' :
    reportTitle?.includes('تسليح') || reportTitle?.includes('سلاح') || reportTitle?.includes('ذخير') ? 'armament' :
    reportTitle?.includes('تدريب') || reportTitle?.includes('دورات') ? 'training' :
    reportTitle?.includes('مالي') || reportTitle?.includes('رواتب') ? 'financial' :
    reportTitle?.includes('غياب') || reportTitle?.includes('إجاز') || reportTitle?.includes('فرار') ? 'absences' :
    reportTitle?.includes('جاهزية') ? 'readiness' :
    reportTitle?.includes('يومي') ? 'daily' : 'comprehensive'
  );

  const getBranchOfficerDefaults = (type: string) => {
    switch (type) {
      case 'security':
        return {
          t1: 'المحقق العسكري / ضابط التحقيق',
          t2: 'رئيس فرع الاستخبارات والأمن العسكري',
          t3: 'قائد اللواء / قائد الفرقة'
        };
      case 'medical':
        return {
          t1: 'الطبيب المعالج / المناوب',
          t2: 'مدير الإدارة الطبية العسكرية',
          t3: 'قائد اللواء / رئيس الأركان'
        };
      case 'armament':
        return {
          t1: 'أمين مستودع الأسلحة والذخائر',
          t2: 'رئيس فرع التسليح والعهد القتالية',
          t3: 'قائد اللواء / الفرقة'
        };
      case 'training':
        return {
          t1: 'الضابط المشرف على التدريب',
          t2: 'رئيس شعبة التدريب والدورات',
          t3: 'قائد جناح / معهد التدريب'
        };
      case 'absences':
        return {
          t1: 'ضابط السجلات وشؤون الأفراد',
          t2: 'ركن القوة البشرية (HR)',
          t3: 'قائد الكتيبة / قائد اللواء'
        };
      case 'financial':
        return {
          t1: 'المحاسب المالي / الصراف',
          t2: 'رئيس الشعبة المالية والميزانية',
          t3: 'المراقب المالي / قائد اللواء'
        };
      case 'readiness':
      case 'daily':
        return {
          t1: 'ركن عمليات وتدريب اللواء',
          t2: 'رئيس أركان حرب اللواء',
          t3: 'قائد اللواء / قائد الفرقة'
        };
      default:
        return {
          t1: 'ركن القوة البشرية وشؤون الأفراد',
          t2: 'رئيس أركان حرب اللواء',
          t3: 'قائد اللواء / قائد الفرقة'
        };
    }
  };

  const branchDefaults = getBranchOfficerDefaults(activeReportType);

  const [officer1Title, setOfficer1Title] = useState(() => {
    return localStorage.getItem(`saved_off1_title_${activeReportType}`) || branchDefaults.t1;
  });
  const [officer1Name, setOfficer1Name] = useState(() => {
    return localStorage.getItem(`saved_off1_name_${activeReportType}`) || '';
  });

  const [officer2Title, setOfficer2Title] = useState(() => {
    return localStorage.getItem(`saved_off2_title_${activeReportType}`) || branchDefaults.t2;
  });
  const [officer2Name, setOfficer2Name] = useState(() => {
    return localStorage.getItem(`saved_off2_name_${activeReportType}`) || '';
  });

  const [officer3Title, setOfficer3Title] = useState(() => {
    return localStorage.getItem(`saved_off3_title_${activeReportType}`) || branchDefaults.t3;
  });
  const [officer3Name, setOfficer3Name] = useState(() => {
    return localStorage.getItem(`saved_off3_name_${activeReportType}`) || '';
  });

  const handleOfficerChange = (setter: React.Dispatch<React.SetStateAction<string>>, key: string, val: string) => {
    setter(val);
    try {
      localStorage.setItem(key, val);
    } catch (e) {}
  };

  // Helper to extract exact active weapon custody per individual in report
  const resolveArmamentRow = (p: PersonnelRecord) => {
    // 1. Find active log from logs.armament (not returned or discharged)
    const activeLog = p.logs?.armament?.find(
      (a) => !a.returnDate && a.status !== 'مورد' && a.weaponSerial && a.weaponSerial !== 'ذخيرة فقط' && a.weaponSerial !== '-'
    ) || (p.logs?.armament && p.logs.armament.length > 0 ? p.logs.armament[0] : undefined);

    const direct = p.armament;

    const hasWeapon = !!(
      (activeLog && activeLog.weaponSerial && activeLog.weaponSerial !== '-' && activeLog.weaponSerial !== 'ذخيرة فقط') ||
      (direct && direct.serialNumber && direct.serialNumber !== '-') ||
      (p.assignedWeapon && p.assignedWeapon.trim() !== '' && p.assignedWeapon !== 'غير مسند' && p.assignedWeapon !== '-')
    );

    const weaponType = activeLog?.weaponType || direct?.weaponType || direct?.name || p.assignedWeapon || (hasWeapon ? 'سلاح فردي' : 'غير مسند (-)');
    const weaponSerial = activeLog?.weaponSerial || direct?.serialNumber || direct?.weaponSerial || '-';
    const status = activeLog?.status || (hasWeapon ? 'بحوزته' : 'غير مسلّح');
    const condition = activeLog?.condition || (hasWeapon ? 'جيدة' : '-');
    const firelinesCount = hasWeapon
      ? (Number(activeLog?.firelinesCount) || Number(direct?.magazinesCount) || 0)
      : 0;
    const ammoQty = hasWeapon
      ? (Number(activeLog?.ammoQty) || Number(direct?.ammoQty) || Number(direct?.ammoCount) || 0)
      : 0;
    const issueDate = activeLog?.issueDate || '-';
    const technicalNotes = activeLog?.technicalNotes || direct?.notes || '-';

    return {
      hasWeapon,
      weaponType,
      weaponSerial,
      status,
      condition,
      firelinesCount,
      ammoQty,
      issueDate,
      technicalNotes
    };
  };

  const armamentRows = useMemo(() => {
    if (activeReportType !== 'armament' || !reportData) return [];
    return reportData.map((p, idx) => ({
      p,
      idx: idx + 1,
      ...resolveArmamentRow(p)
    }));
  }, [reportData, activeReportType]);

  const armamentTotals = useMemo(() => {
    let weaponsCount = 0;
    let magazinesCount = 0;
    let ammoQuantity = 0;
    let armedCount = 0;

    armamentRows.forEach((r) => {
      if (r.hasWeapon) {
        weaponsCount += 1;
        armedCount += 1;
      }
      magazinesCount += r.firelinesCount;
      ammoQuantity += r.ammoQty;
    });

    return {
      weaponsCount,
      magazinesCount,
      ammoQuantity,
      armedCount
    };
  }, [armamentRows]);

  // Custom Section Selector State for Printing
  const [selectedSections, setSelectedSections] = useState({
    summary: true,      // البطاقة التعريفية والتمام
    admin: true,        // السجل الإداري والشخصي
    movement: true,     // حركة التنقلات
    armament: true,     // سجل العهد والتسليح
    supply: true,       // المهمات والتجهيزات
    attendance: true,   // التحضير والغياب
    medical: true,      // السجل الطبي والعيادات
    financial: true,    // السجل المالي والرواتب
    security: true,     // السجل الأمني والمخالفات
    training: true      // سجل الدورات والتأهيل
  });

  const toggleSection = (key: keyof typeof selectedSections) => {
    setSelectedSections((prev) => ({
      ...prev,
      [key]: !prev[key]
    }));
  };

  const selectAllSections = () => {
    setSelectedSections({
      summary: true,
      admin: true,
      movement: true,
      armament: true,
      supply: true,
      attendance: true,
      medical: true,
      financial: true,
      security: true,
      training: true
    });
  };

  const unselectAllSections = () => {
    setSelectedSections({
      summary: true, // Keep basic summary ID card
      admin: false,
      movement: false,
      armament: false,
      supply: false,
      attendance: false,
      medical: false,
      financial: false,
      security: false,
      training: false
    });
  };

  const selectPreset = (preset: 'medicalOnly' | 'financialOnly' | 'armamentOnly' | 'adminOnly') => {
    if (preset === 'medicalOnly') {
      setSelectedSections({
        summary: true,
        admin: false,
        movement: false,
        armament: false,
        supply: false,
        attendance: false,
        medical: true,
        financial: false,
        security: false,
        training: false
      });
    } else if (preset === 'financialOnly') {
      setSelectedSections({
        summary: true,
        admin: false,
        movement: false,
        armament: false,
        supply: false,
        attendance: false,
        medical: false,
        financial: true,
        security: false,
        training: false
      });
    } else if (preset === 'armamentOnly') {
      setSelectedSections({
        summary: true,
        admin: false,
        movement: false,
        armament: true,
        supply: true,
        attendance: false,
        medical: false,
        financial: false,
        security: false,
        training: false
      });
    } else if (preset === 'adminOnly') {
      setSelectedSections({
        summary: true,
        admin: true,
        movement: true,
        armament: false,
        supply: false,
        attendance: true,
        medical: false,
        financial: false,
        security: false,
        training: false
      });
    }
  };

  const printableRef = useRef<HTMLDivElement>(null);
  const [isDocumentReady, setIsDocumentReady] = useState<boolean>(false);
  const [isPrinting, setIsPrinting] = useState<boolean>(false);

  useEffect(() => {
    setIsDocumentReady(false);
    const timer = setTimeout(() => {
      preparePrintableDocument(printableRef.current).then(() => {
        setIsDocumentReady(true);
      });
    }, 200);
    return () => clearTimeout(timer);
  }, [personnel, reportData, selectedSections, activeReportType]);

  const documentTitle = personnel
    ? `ملف_الفرد_${personnel.rank}_${personnel.fullName.replace(/\s+/g, '_')}_${personnel.militaryId}`
    : `${(reportTitle || 'تقرير_عسكري_موحد').replace(/\s+/g, '_')}_${new Date().toISOString().split('T')[0]}`;

  const handlePrint = async () => {
    if (isPrinting) return;
    setIsPrinting(true);
    try {
      await executeUnifiedPrint({
        element: printableRef.current,
        documentTitle
      });
    } catch (err) {
      console.error('Print error:', err);
    } finally {
      setIsPrinting(false);
    }
  };

  const handleShareOrSave = async () => {
    if (isPrinting || !printableRef.current) return;
    setIsPrinting(true);
    try {
      await shareOrSavePrintableDocument(printableRef.current, documentTitle);
    } catch (err) {
      console.error('Share/Save error:', err);
    } finally {
      setIsPrinting(false);
    }
  };

  return createPortal(
    <div className="fixed inset-0 z-[100] flex flex-col items-center justify-center p-2 sm:p-4 bg-slate-950/90 backdrop-blur-md overflow-hidden print:p-0 print:bg-white print:static printable-modal-overlay">
      
      {/* Container */}
      <div className="bg-white text-slate-900 border border-slate-300 rounded-3xl max-w-5xl w-full shadow-2xl relative my-2 sm:my-4 max-h-[94vh] flex flex-col overflow-hidden print:max-h-none print:border-none print:shadow-none print:p-0 print:m-0 print:w-full printable-modal-card">
        
        {/* Sticky Header with Action Controls (Print, Share, Return to List) */}
        <div className="sticky top-0 z-30 bg-slate-900 text-white p-3.5 sm:p-4 rounded-t-3xl border-b-2 border-emerald-500/80 shadow-md flex flex-wrap items-center justify-between gap-3 print:hidden no-print shrink-0">
          <div className="flex items-center space-x-2.5 space-x-reverse">
            <div className="w-9 h-9 rounded-xl bg-emerald-600 flex items-center justify-center text-white shrink-0 shadow-sm">
              <Printer className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2 flex-wrap">
                <h2 className="text-xs sm:text-sm font-black text-amber-300 font-['Tajawal']">
                  معاينة وتخصيص طباعة الملف العسكري الموحد
                </h2>
                {isDocumentReady ? (
                  <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-bold bg-emerald-950/80 text-emerald-400 border border-emerald-700/80">
                    <CheckCircle2 className="w-3 h-3 text-emerald-400" />
                    <span>المستند جاهز للطباعة</span>
                  </span>
                ) : (
                  <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-bold bg-amber-950/80 text-amber-300 border border-amber-700/80">
                    <Loader2 className="w-3 h-3 animate-spin text-amber-400" />
                    <span>جاري فحص الصور والخطوط...</span>
                  </span>
                )}
              </div>
              <p className="text-[11px] text-slate-300 font-medium mt-0.5">
                {personnel ? `الفرد: ${personnel.rank} / ${personnel.fullName} (${personnel.militaryId})` : reportTitle || 'التقرير الموحد'}
              </p>
            </div>
          </div>

          <div className="flex items-center space-x-2 space-x-reverse flex-wrap gap-1.5">
            {/* Prominent Return to List Button */}
            <button
              type="button"
              onClick={onClose}
              className="bg-slate-800 hover:bg-slate-700 text-amber-300 hover:text-white border border-amber-500/50 font-extrabold px-3 py-1.5 sm:px-3.5 sm:py-2 rounded-xl text-xs transition-all shadow-md flex items-center space-x-1.5 space-x-reverse cursor-pointer"
              title="العودة للقائمة السابقة وإغلاق نافذة المعاينة والطباعة"
            >
              <ArrowRight className="w-4 h-4 text-amber-400" />
              <span>العودة للقائمة السابقة ↩️</span>
            </button>

            {/* Share / Save Standalone HTML/PDF (Android & Windows) */}
            <button
              type="button"
              onClick={handleShareOrSave}
              disabled={isPrinting}
              className="bg-sky-700 hover:bg-sky-600 active:scale-95 text-white font-extrabold px-3 py-1.5 sm:px-3.5 sm:py-2 rounded-xl text-xs transition-all shadow-md cursor-pointer flex items-center space-x-1.5 space-x-reverse disabled:opacity-50"
              title="مشاركة أو حفظ المستند كملف مستقل (متوافق مع أندرويد وويندوز بدون نوافذ منبثقة)"
            >
              {isPrinting ? <Loader2 className="w-4 h-4 animate-spin" /> : <Share2 className="w-4 h-4" />}
              <span>مشاركة / حفظ PDF 📄</span>
            </button>

            {/* Instant Unified Print Button */}
            <button
              type="button"
              onClick={handlePrint}
              disabled={isPrinting}
              className="bg-emerald-600 hover:bg-emerald-500 active:scale-95 text-white font-extrabold px-3.5 py-1.5 sm:px-4 sm:py-2 rounded-xl text-xs transition-all shadow-md cursor-pointer flex items-center space-x-1.5 space-x-reverse disabled:opacity-50"
              title="أمر الطباعة المباشرة من المتصفح أو نظام التشغيل"
            >
              {isPrinting ? <Loader2 className="w-4 h-4 animate-spin" /> : <Printer className="w-4 h-4" />}
              <span>طباعة المستند 🖨️</span>
            </button>

            {/* Close Icon Button */}
            <button
              type="button"
              onClick={onClose}
              className="w-8 h-8 sm:w-9 sm:h-9 flex items-center justify-center text-slate-300 hover:text-white bg-slate-800 hover:bg-slate-700 rounded-xl cursor-pointer transition-all border border-slate-700"
              title="إغلاق والعودة"
            >
              <X className="w-4 h-4 sm:w-5 sm:h-5" />
            </button>
          </div>
        </div>

        {/* Scrollable Document Body Container */}
        <div className="overflow-y-auto p-4 sm:p-6 md:p-8 flex-1 space-y-6">

        {/* Dynamic Officer Approval Settings Panel (Hidden on Print) */}
        <div className="bg-gradient-to-r from-emerald-50 to-teal-50 border-2 border-emerald-300 rounded-2xl p-4 mb-4 print:hidden shadow-xs font-['Cairo',sans-serif]">
          <div className="flex items-center space-x-2 space-x-reverse text-emerald-950 font-black text-xs mb-3">
            <UserPlus className="w-4 h-4 text-emerald-700 shrink-0" />
            <span>تحديد وتخصيص الرتبة والاسم والصفة للضباط المعنيين بالتوقيع والاعتماد:</span>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-3 text-xs">
            <div className="space-y-1 bg-white/80 p-2.5 rounded-xl border border-emerald-200">
              <label className="block text-[11px] font-black text-slate-800">الضابط / المعتمد الأول:</label>
              <input
                type="text"
                value={officer1Name}
                onChange={(e) => handleOfficerChange(setOfficer1Name, `saved_off1_name_${activeReportType}`, e.target.value)}
                placeholder="الرتبة والاسم"
                className="w-full bg-white border border-emerald-300 rounded-lg px-2.5 py-1 font-bold text-slate-900 text-xs focus:ring-2 focus:ring-emerald-500 focus:outline-none"
              />
              <input
                type="text"
                value={officer1Title}
                onChange={(e) => handleOfficerChange(setOfficer1Title, `saved_off1_title_${activeReportType}`, e.target.value)}
                placeholder="المسمى الوظيفي / الصفة"
                className="w-full bg-white border border-emerald-200 rounded-lg px-2.5 py-1 text-slate-700 text-xs focus:ring-2 focus:ring-emerald-500 focus:outline-none mt-1"
              />
            </div>

            <div className="space-y-1 bg-white/80 p-2.5 rounded-xl border border-emerald-200">
              <label className="block text-[11px] font-black text-slate-800">الضابط / المعتمد الثاني:</label>
              <input
                type="text"
                value={officer2Name}
                onChange={(e) => handleOfficerChange(setOfficer2Name, `saved_off2_name_${activeReportType}`, e.target.value)}
                placeholder="الرتبة والاسم"
                className="w-full bg-white border border-emerald-300 rounded-lg px-2.5 py-1 font-bold text-slate-900 text-xs focus:ring-2 focus:ring-emerald-500 focus:outline-none"
              />
              <input
                type="text"
                value={officer2Title}
                onChange={(e) => handleOfficerChange(setOfficer2Title, `saved_off2_title_${activeReportType}`, e.target.value)}
                placeholder="المسمى الوظيفي / الصفة"
                className="w-full bg-white border border-emerald-200 rounded-lg px-2.5 py-1 text-slate-700 text-xs focus:ring-2 focus:ring-emerald-500 focus:outline-none mt-1"
              />
            </div>

            <div className="space-y-1 bg-white/80 p-2.5 rounded-xl border border-emerald-200">
              <label className="block text-[11px] font-black text-slate-800">الضابط / المعتمد الثالث:</label>
              <input
                type="text"
                value={officer3Name}
                onChange={(e) => handleOfficerChange(setOfficer3Name, `saved_off3_name_${activeReportType}`, e.target.value)}
                placeholder="الرتبة والاسم"
                className="w-full bg-white border border-emerald-300 rounded-lg px-2.5 py-1 font-bold text-slate-900 text-xs focus:ring-2 focus:ring-emerald-500 focus:outline-none"
              />
              <input
                type="text"
                value={officer3Title}
                onChange={(e) => handleOfficerChange(setOfficer3Title, `saved_off3_title_${activeReportType}`, e.target.value)}
                placeholder="المسمى الوظيفي / الصفة"
                className="w-full bg-white border border-emerald-200 rounded-lg px-2.5 py-1 text-slate-700 text-xs focus:ring-2 focus:ring-emerald-500 focus:outline-none mt-1"
              />
            </div>
          </div>
        </div>

        {/* Section Selection Panel for Custom Paper-Saving Print (Hidden on Print) */}
        {personnel && (
          <div className="bg-slate-50 border-2 border-slate-300 rounded-2xl p-4 mb-6 print:hidden shadow-xs font-['Cairo',sans-serif]">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 mb-3 pb-2 border-b border-slate-200">
              <div className="flex items-center space-x-2 space-x-reverse text-slate-900 font-black text-xs">
                <Filter className="w-4 h-4 text-emerald-700 shrink-0" />
                <span>تخصيص واختيار السجلات المطلوب طباعتها (لتوفير الورق وتسهيل الأرشفة):</span>
              </div>
              <div className="flex items-center space-x-2 space-x-reverse text-[11px] font-bold">
                <button
                  type="button"
                  onClick={selectAllSections}
                  className="text-emerald-800 hover:text-emerald-900 bg-emerald-100 hover:bg-emerald-200 border border-emerald-300 px-2.5 py-1 rounded-lg transition-colors cursor-pointer"
                >
                  تحديد جميع السجلات
                </button>
                <button
                  type="button"
                  onClick={unselectAllSections}
                  className="text-slate-700 hover:text-slate-900 bg-slate-200 hover:bg-slate-300 border border-slate-300 px-2.5 py-1 rounded-lg transition-colors cursor-pointer"
                >
                  إلغاء التحديد
                </button>
              </div>
            </div>

            {/* Section Toggles Checkbox Grid */}
            <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-5 gap-2 text-xs">
              <label className={`flex items-center space-x-2 space-x-reverse p-2 rounded-xl border cursor-pointer transition-all ${selectedSections.summary ? 'bg-emerald-50 border-emerald-500 text-emerald-950 font-black shadow-xs' : 'bg-white border-slate-200 text-slate-500 hover:bg-slate-100'}`}>
                <input
                  type="checkbox"
                  checked={selectedSections.summary}
                  onChange={() => toggleSection('summary')}
                  className="rounded text-emerald-600 focus:ring-emerald-500 w-4 h-4 accent-emerald-600 cursor-pointer"
                />
                <span className="text-[11px] truncate">بطاقة الفرد والتمام</span>
              </label>

              <label className={`flex items-center space-x-2 space-x-reverse p-2 rounded-xl border cursor-pointer transition-all ${selectedSections.admin ? 'bg-emerald-50 border-emerald-500 text-emerald-950 font-black shadow-xs' : 'bg-white border-slate-200 text-slate-500 hover:bg-slate-100'}`}>
                <input
                  type="checkbox"
                  checked={selectedSections.admin}
                  onChange={() => toggleSection('admin')}
                  className="rounded text-emerald-600 focus:ring-emerald-500 w-4 h-4 accent-emerald-600 cursor-pointer"
                />
                <span className="text-[11px] truncate">السجل الإداري والشخصي</span>
              </label>

              <label className={`flex items-center space-x-2 space-x-reverse p-2 rounded-xl border cursor-pointer transition-all ${selectedSections.movement ? 'bg-emerald-50 border-emerald-500 text-emerald-950 font-black shadow-xs' : 'bg-white border-slate-200 text-slate-500 hover:bg-slate-100'}`}>
                <input
                  type="checkbox"
                  checked={selectedSections.movement}
                  onChange={() => toggleSection('movement')}
                  className="rounded text-emerald-600 focus:ring-emerald-500 w-4 h-4 accent-emerald-600 cursor-pointer"
                />
                <span className="text-[11px] truncate">الحركة والتنقلات</span>
              </label>

              <label className={`flex items-center space-x-2 space-x-reverse p-2 rounded-xl border cursor-pointer transition-all ${selectedSections.armament ? 'bg-emerald-50 border-emerald-500 text-emerald-950 font-black shadow-xs' : 'bg-white border-slate-200 text-slate-500 hover:bg-slate-100'}`}>
                <input
                  type="checkbox"
                  checked={selectedSections.armament}
                  onChange={() => toggleSection('armament')}
                  className="rounded text-emerald-600 focus:ring-emerald-500 w-4 h-4 accent-emerald-600 cursor-pointer"
                />
                <span className="text-[11px] truncate">سجل العهد والتسليح</span>
              </label>

              <label className={`flex items-center space-x-2 space-x-reverse p-2 rounded-xl border cursor-pointer transition-all ${selectedSections.supply ? 'bg-emerald-50 border-emerald-500 text-emerald-950 font-black shadow-xs' : 'bg-white border-slate-200 text-slate-500 hover:bg-slate-100'}`}>
                <input
                  type="checkbox"
                  checked={selectedSections.supply}
                  onChange={() => toggleSection('supply')}
                  className="rounded text-emerald-600 focus:ring-emerald-500 w-4 h-4 accent-emerald-600 cursor-pointer"
                />
                <span className="text-[11px] truncate">المهمات والتجهيزات</span>
              </label>

              <label className={`flex items-center space-x-2 space-x-reverse p-2 rounded-xl border cursor-pointer transition-all ${selectedSections.attendance ? 'bg-emerald-50 border-emerald-500 text-emerald-950 font-black shadow-xs' : 'bg-white border-slate-200 text-slate-500 hover:bg-slate-100'}`}>
                <input
                  type="checkbox"
                  checked={selectedSections.attendance}
                  onChange={() => toggleSection('attendance')}
                  className="rounded text-emerald-600 focus:ring-emerald-500 w-4 h-4 accent-emerald-600 cursor-pointer"
                />
                <span className="text-[11px] truncate">التحضير والغياب والفرار</span>
              </label>

              <label className={`flex items-center space-x-2 space-x-reverse p-2 rounded-xl border cursor-pointer transition-all ${selectedSections.medical ? 'bg-emerald-50 border-emerald-500 text-emerald-950 font-black shadow-xs' : 'bg-white border-slate-200 text-slate-500 hover:bg-slate-100'}`}>
                <input
                  type="checkbox"
                  checked={selectedSections.medical}
                  onChange={() => toggleSection('medical')}
                  className="rounded text-emerald-600 focus:ring-emerald-500 w-4 h-4 accent-emerald-600 cursor-pointer"
                />
                <span className="text-[11px] truncate">السجل الطبي والعيادات</span>
              </label>

              <label className={`flex items-center space-x-2 space-x-reverse p-2 rounded-xl border cursor-pointer transition-all ${selectedSections.financial ? 'bg-emerald-50 border-emerald-500 text-emerald-950 font-black shadow-xs' : 'bg-white border-slate-200 text-slate-500 hover:bg-slate-100'}`}>
                <input
                  type="checkbox"
                  checked={selectedSections.financial}
                  onChange={() => toggleSection('financial')}
                  className="rounded text-emerald-600 focus:ring-emerald-500 w-4 h-4 accent-emerald-600 cursor-pointer"
                />
                <span className="text-[11px] truncate">السجل المالي والرواتب</span>
              </label>

              <label className={`flex items-center space-x-2 space-x-reverse p-2 rounded-xl border cursor-pointer transition-all ${selectedSections.security ? 'bg-emerald-50 border-emerald-500 text-emerald-950 font-black shadow-xs' : 'bg-white border-slate-200 text-slate-500 hover:bg-slate-100'}`}>
                <input
                  type="checkbox"
                  checked={selectedSections.security}
                  onChange={() => toggleSection('security')}
                  className="rounded text-emerald-600 focus:ring-emerald-500 w-4 h-4 accent-emerald-600 cursor-pointer"
                />
                <span className="text-[11px] truncate">السجل الأمني والمخالفات</span>
              </label>

              <label className={`flex items-center space-x-2 space-x-reverse p-2 rounded-xl border cursor-pointer transition-all ${selectedSections.training ? 'bg-emerald-50 border-emerald-500 text-emerald-950 font-black shadow-xs' : 'bg-white border-slate-200 text-slate-500 hover:bg-slate-100'}`}>
                <input
                  type="checkbox"
                  checked={selectedSections.training}
                  onChange={() => toggleSection('training')}
                  className="rounded text-emerald-600 focus:ring-emerald-500 w-4 h-4 accent-emerald-600 cursor-pointer"
                />
                <span className="text-[11px] truncate">سجل الدورات والتأهيل</span>
              </label>
            </div>

            {/* Presets Quick Toolbar */}
            <div className="flex flex-wrap items-center gap-2 mt-3 pt-2.5 border-t border-slate-200 text-[11px]">
              <span className="text-slate-600 font-bold ml-1">قوالب طباعة جاهزة وسريعة:</span>
              <button
                type="button"
                onClick={() => selectPreset('medicalOnly')}
                className="bg-white hover:bg-emerald-100 text-emerald-900 border border-emerald-300 px-3 py-1 rounded-xl font-bold transition-all shadow-2xs cursor-pointer flex items-center space-x-1 space-x-reverse"
              >
                <span>🏥 السجل الطبي فقط</span>
              </button>
              <button
                type="button"
                onClick={() => selectPreset('financialOnly')}
                className="bg-white hover:bg-emerald-100 text-emerald-900 border border-emerald-300 px-3 py-1 rounded-xl font-bold transition-all shadow-2xs cursor-pointer flex items-center space-x-1 space-x-reverse"
              >
                <span>💰 السجل المالي والرواتب</span>
              </button>
              <button
                type="button"
                onClick={() => selectPreset('armamentOnly')}
                className="bg-white hover:bg-emerald-100 text-emerald-900 border border-emerald-300 px-3 py-1 rounded-xl font-bold transition-all shadow-2xs cursor-pointer flex items-center space-x-1 space-x-reverse"
              >
                <span>🔫 العهد والتسليح والمهمات</span>
              </button>
              <button
                type="button"
                onClick={() => selectPreset('adminOnly')}
                className="bg-white hover:bg-emerald-100 text-emerald-900 border border-emerald-300 px-3 py-1 rounded-xl font-bold transition-all shadow-2xs cursor-pointer flex items-center space-x-1 space-x-reverse"
              >
                <span>📁 الملف الإداري والتمام</span>
              </button>
            </div>
          </div>
        )}

        {/* PRINTABLE OFFICIAL MILITARY FORM CONTENT */}
        <div ref={printableRef} id="printable-official-form-content" data-printable-content="true" className="space-y-6 text-right font-['Cairo',sans-serif]">
          
          {/* Header Seal */}
          {(() => {
            const headerInfo = getCurrentHeaderInfo(personnel?.unit || currentAccountName);
            return (
              <div className="flex items-center justify-between border-b-2 border-slate-900 pb-4">
                <div>
                  <h1 className="text-xl font-black text-slate-900 font-['Tajawal']">{headerInfo.forceName}</h1>
                  <h2 className="text-sm font-black text-slate-800">{headerInfo.divisionName}</h2>
                  <p className="text-xs font-bold text-amber-900">{headerInfo.unitName}</p>
                </div>

                <div className="text-center">
                  <div className="w-16 h-16 border-2 border-slate-900 rounded-full flex items-center justify-center mx-auto bg-slate-50 font-black text-[10px] text-slate-900 text-center leading-tight shadow-xs">
                    قوات الطوارى<br/>اليمنية
                  </div>
                  <span className="text-[10px] text-slate-600 font-extrabold block mt-1">سري للغاية وخاص جداً</span>
                </div>

                <div className="text-left text-xs font-mono space-y-0.5 dir-ltr">
                  <div className="text-right">رقم الملف: <strong className="font-bold text-slate-900">{personnel?.militaryId || `REP-${Math.floor(1000 + Math.random() * 9000)}`}</strong></div>
                  <div className="text-right">تاريخ الطباعة: <strong className="font-bold text-slate-900">{new Date().toISOString().split('T')[0]}</strong></div>
                  <div className="text-right">الحالة: <strong className="text-emerald-700 font-bold">ملف عسكري شامل وموثق</strong></div>
                </div>
              </div>
            );
          })()}

          {/* SINGLE PERSONNEL COMPLETE COMPREHENSIVE PRINT SHEET */}
          {personnel ? (
            <div className="space-y-6">
              
              {/* TOP SUMMARY BANNER */}
              {selectedSections.summary && (
                <div className="bg-slate-50 border-2 border-slate-300 rounded-2xl p-4 flex flex-col md:flex-row items-center justify-between gap-4 print:break-inside-avoid">
                  <div className="flex items-center space-x-4 space-x-reverse">
                    <PersonnelAvatar
                      photoUrl={personnel.photoUrl}
                      fullName={personnel.fullName}
                      rank={personnel.rank}
                      militaryId={personnel.militaryId}
                      size="xl"
                      shape="rounded"
                      className="border-2 border-slate-700 shadow-md shrink-0 print:border-slate-800"
                    />
                    <div>
                      <div className="flex items-center space-x-2 space-x-reverse">
                        <span className="bg-slate-900 text-white text-[11px] font-black px-2.5 py-0.5 rounded-lg">
                          {personnel.rank}
                        </span>
                        <h3 className="text-xl font-black text-slate-900 font-['Tajawal']">{personnel.fullName}</h3>
                      </div>
                      <p className="text-xs font-extrabold text-emerald-800 mt-1">
                        الرقم العسكري / الوظيفي: <span className="font-mono text-slate-900 text-sm">{personnel.militaryId}</span> • السجل المدني: <span className="font-mono text-slate-900">{personnel.nationalId}</span>
                      </p>
                      <p className="text-xs font-bold text-slate-700 mt-1">
                        الوحدة: {personnel.unit} | الكتيبة: {personnel.battalion} | السرية: {personnel.company} | الفصيل: {personnel.platoon}
                      </p>
                      <p className="text-xs text-slate-600 mt-0.5">
                        الوظيفة الحالية: <strong className="text-slate-900">{personnel.jobTitle}</strong> | تاريخ الالتحاق: <strong className="text-slate-900">{personnel.enlistmentDate}</strong>
                      </p>
                    </div>
                  </div>

                  <div className="text-left border-r-2 border-slate-300 pr-5 shrink-0 space-y-1">
                    <div className="text-xs font-bold text-slate-600">حالة التمام والخدمة الحالية</div>
                    <div className="text-base font-black text-emerald-800 bg-emerald-50 px-3 py-1 rounded-xl border border-emerald-300 inline-block">
                      {personnel.currentStatus}
                    </div>
                    {personnel.currentStatus === 'منتدب' && personnel.secondedUnit && (
                      <div className="text-xs text-purple-900 font-bold bg-purple-50 px-2 py-0.5 rounded border border-purple-200">
                        الجهة: {personnel.secondedUnit}
                      </div>
                    )}
                    {(personnel.currentStatus === 'دورة تدريبية داخلية' || personnel.currentStatus === 'دورة تدريبية خارجية') && personnel.trainingCourseType && (
                      <div className="text-xs text-indigo-900 font-bold bg-indigo-50 px-2 py-0.5 rounded border border-indigo-200">
                        الدورة: {personnel.trainingCourseType}
                      </div>
                    )}
                    <div className="text-xs text-slate-700 font-bold">فصيلة الدم: <strong className="text-red-700">{personnel.bloodType}</strong></div>
                    <div className="text-[11px] text-slate-500 font-bold">البصمة الحيوية: {personnel.biometricsRecorded ? '✅ مسجلة وموثقة' : '❌ غير مسجلة'}</div>
                  </div>
                </div>
              )}

              {/* 1. SECTION: PERSONAL & ADMINISTRATIVE DETAILS */}
              {selectedSections.admin && (
                <div className="border border-slate-300 rounded-2xl p-4 bg-slate-50/70 space-y-3 print:break-inside-avoid">
                  <h4 className="text-xs font-black text-slate-900 border-b border-slate-300 pb-2 flex items-center space-x-1.5 space-x-reverse">
                    <User className="w-4 h-4 text-emerald-700" />
                    <span>أولاً: السجل الإداري والشخصي والبيانات الاجتماعية</span>
                  </h4>
                  <div className="grid grid-cols-2 md:grid-cols-4 gap-3 text-xs">
                    <div>تاريخ الميلاد: <strong>{personnel.dob}</strong></div>
                    <div>مكان الميلاد: <strong>{personnel.pob}</strong></div>
                    <div>الحالة الاجتماعية: <strong>{personnel.maritalStatus}</strong></div>
                    <div>المؤهل العلمي: <strong>{personnel.education}</strong></div>
                    <div>التخصص الرئيسي: <strong>{personnel.specialization}</strong></div>
                    <div>رقم الهاتف: <strong className="font-mono">{personnel.phone}</strong></div>
                    <div>اسم الأم: <strong>{personnel.motherName || 'غير مسجل'}</strong></div>
                    <div>الضامن / الكفيل: <strong>{personnel.guarantorName || 'غير مسجل'}</strong></div>
                    <div>أقرب أقاربه للطوارئ: <strong>{personnel.relativeName || 'غير مسجل'}</strong></div>
                    <div>هاتف القريب: <strong className="font-mono">{personnel.relativePhone || 'غير مسجل'}</strong></div>
                    <div>تاريخ بداية الخدمة: <strong>{personnel.enlistmentDate}</strong></div>
                    <div>الوحدة المنتدب لديها: <strong>{personnel.secondedUnit || 'لا يوجد'}</strong></div>
                    <div>نوع ومسمى الدورة التدريبية: <strong>{personnel.trainingCourseType || 'لا يوجد'}</strong></div>
                  </div>
                </div>
              )}

              {/* 2. SECTION: MOVEMENT & TRANSFER LOG (سجل الحركة والتنقلات والإنهاء والإنضمام) */}
              {selectedSections.movement && (
                <div className="border border-slate-300 rounded-2xl p-4 space-y-3 print:break-inside-avoid">
                  <h4 className="text-xs font-black text-slate-900 border-b border-slate-300 pb-2 flex items-center justify-between">
                    <div className="flex items-center space-x-1.5 space-x-reverse">
                      <Repeat className="w-4 h-4 text-emerald-700" />
                      <span>ثانياً: سجل حركة التنقلات الإدارية والترقيات والإنضمام بين الكتيبات والوحدات</span>
                    </div>
                    <span className="text-[10px] font-bold text-slate-500">عدد السجلات: ({personnel.logs.movement?.length || 0})</span>
                  </h4>
                  
                  {(!personnel.logs.movement || personnel.logs.movement.length === 0) ? (
                    <p className="text-xs text-slate-500 font-bold py-2 text-center">لا توجد تنقلات أو أوامر إدارية مسجلة للفرد سابقاً.</p>
                  ) : (
                    <table className="w-full text-right text-xs border border-slate-300">
                      <thead className="bg-slate-100 text-slate-900 font-bold border-b border-slate-300">
                        <tr>
                          <th className="p-2 border-l">التاريخ</th>
                          <th className="p-2 border-l">نوع الحركة</th>
                          <th className="p-2 border-l">من وحدة / كتيبة</th>
                          <th className="p-2 border-l">إلى وحدة / كتيبة</th>
                          <th className="p-2 border-l">تفاصيل وأسباب الحركة والتنقل</th>
                          <th className="p-2">مرجع الأمر الإداري والجهة المصدرة</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-slate-200">
                        {personnel.logs.movement.map((m) => (
                          <tr key={m.id}>
                            <td className="p-2 border-l font-mono text-slate-900">{m.date}</td>
                            <td className="p-2 border-l font-bold text-emerald-800">{m.type}</td>
                            <td className="p-2 border-l text-slate-800">{m.fromUnit || '-'}</td>
                            <td className="p-2 border-l font-bold text-slate-900">{m.toUnit || '-'}</td>
                            <td className="p-2 border-l text-slate-700">{m.reason || m.details || '-'}</td>
                            <td className="p-2 text-slate-600 font-mono text-[11px]">{m.orderReference || m.issuingAuthority || '-'}</td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  )}
                </div>
              )}

              {/* 3. SECTION: ARMAMENT & WEAPON CUSTODY LOG (سجل العهد والأسلحة والذخيرة) */}
              {selectedSections.armament && (
                <div className="border border-slate-300 rounded-2xl p-4 space-y-3 print:break-inside-avoid">
                  <h4 className="text-xs font-black text-slate-900 border-b border-slate-300 pb-2 flex items-center justify-between">
                    <div className="flex items-center space-x-1.5 space-x-reverse">
                      <Crosshair className="w-4 h-4 text-emerald-700" />
                      <span>ثالثاً: سجل العهد الشخصية والأسلحة والذخائر المسندة</span>
                    </div>
                    <span className="text-[10px] font-bold text-slate-500">عدد القطع: ({personnel.logs.armament?.length || 0})</span>
                  </h4>

                  {(!personnel.logs.armament || personnel.logs.armament.length === 0) ? (
                    <p className="text-xs text-slate-500 font-bold py-2 text-center">لا توجد عهد أسلحة شخصية عسكرية مصروفة مسجلة حالياً.</p>
                  ) : (
                    <table className="w-full text-right text-xs border border-slate-300">
                      <thead className="bg-slate-100 text-slate-900 font-bold border-b border-slate-300">
                        <tr>
                          <th className="p-2 border-l">نوع السلاح</th>
                          <th className="p-2 border-l">الرقم التسلسلي</th>
                          <th className="p-2 border-l">حجم الذخيرة</th>
                          <th className="p-2 border-l">المخازن / خطوط النار</th>
                          <th className="p-2 border-l">تاريخ الصرف</th>
                          <th className="p-2 border-l">الحالة الفنية</th>
                          <th className="p-2">الملاحظات الفنية</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-slate-200">
                        {personnel.logs.armament.map((a) => (
                          <tr key={a.id}>
                            <td className="p-2 border-l font-bold text-slate-900">{a.weaponType}</td>
                            <td className="p-2 border-l font-mono font-bold text-emerald-800">{a.weaponSerial}</td>
                            <td className="p-2 border-l font-mono">{a.ammoQty} طلقة</td>
                            <td className="p-2 border-l font-mono">{Number(a.firelinesCount) || 0} مخزن</td>
                            <td className="p-2 border-l font-mono text-slate-800">{a.issueDate}</td>
                            <td className="p-2 border-l font-bold text-slate-800">{a.condition}</td>
                            <td className="p-2 text-slate-600 text-[11px]">{a.technicalNotes || '-'}</td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  )}
                </div>
              )}

              {/* 4. SECTION: SUPPLIES & DISPATCHED GEAR LOG (سجل المهمات المنصرفة والمعدات الميدانية) */}
              {selectedSections.supply && (
                <div className="border border-slate-300 rounded-2xl p-4 space-y-3 print:break-inside-avoid">
                  <h4 className="text-xs font-black text-slate-900 border-b border-slate-300 pb-2 flex items-center justify-between">
                    <div className="flex items-center space-x-1.5 space-x-reverse">
                      <Package className="w-4 h-4 text-emerald-700" />
                      <span>رابعاً: سجل المهمات المنصرفة والتجهيزات والمعدات العسكرية الميدانية</span>
                    </div>
                    <span className="text-[10px] font-bold text-slate-500">إجمالي المواد: ({personnel.logs.supply?.length || 0})</span>
                  </h4>

                  {(!personnel.logs.supply || personnel.logs.supply.length === 0) ? (
                    <p className="text-xs text-slate-500 font-bold py-2 text-center">لا توجد سجلات صرف مهمات عسكرية أو تجهيزات ميدانية مضافة.</p>
                  ) : (
                    <table className="w-full text-right text-xs border border-slate-300">
                      <thead className="bg-slate-100 text-slate-900 font-bold border-b border-slate-300">
                        <tr>
                          <th className="p-2 border-l">نوع المهمة / المادة</th>
                          <th className="p-2 border-l">اسم التجهيز</th>
                          <th className="p-2 border-l">الكمية</th>
                          <th className="p-2 border-l">تاريخ الصرف</th>
                          <th className="p-2 border-l">الحالة عند التسليم</th>
                          <th className="p-2">المُسلِّم / ملاحظات</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-slate-200">
                        {personnel.logs.supply.map((s) => (
                          <tr key={s.id}>
                            <td className="p-2 border-l font-bold text-slate-900">{s.itemType}</td>
                            <td className="p-2 border-l font-bold text-emerald-800">{s.itemName}</td>
                            <td className="p-2 border-l font-mono font-bold text-center">{s.quantity}</td>
                            <td className="p-2 border-l font-mono">{s.issueDate}</td>
                            <td className="p-2 border-l font-bold text-slate-700">{s.condition}</td>
                            <td className="p-2 text-slate-600 text-[11px]">{s.issuedBy} {s.notes ? `(${s.notes})` : ''}</td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  )}
                </div>
              )}

              {/* 5. SECTION: ATTENDANCE, ABSENCE & DESERTION LOG (سجل التحضير والحضور والغياب والفرار والإجازات) */}
              {selectedSections.attendance && (
                <div className="border border-slate-300 rounded-2xl p-4 space-y-3 print:break-inside-avoid">
                  <h4 className="text-xs font-black text-slate-900 border-b border-slate-300 pb-2 flex items-center justify-between">
                    <div className="flex items-center space-x-1.5 space-x-reverse">
                      <Clock className="w-4 h-4 text-emerald-700" />
                      <span>خامساً: سجل التحضير والحضور والغياب والفرار والإجازات والتمام</span>
                    </div>
                    <span className="text-[10px] font-bold text-slate-500">إجمالي الحالات: ({personnel.logs.attendance?.length || 0})</span>
                  </h4>

                  {(!personnel.logs.attendance || personnel.logs.attendance.length === 0) ? (
                    <p className="text-xs text-slate-500 font-bold py-2 text-center">لا توجد قيود تمام أو إجازات أو غياب مدونة سابقاً.</p>
                  ) : (
                    <table className="w-full text-right text-xs border border-slate-300">
                      <thead className="bg-slate-100 text-slate-900 font-bold border-b border-slate-300">
                        <tr>
                          <th className="p-2 border-l">التاريخ</th>
                          <th className="p-2 border-l">حالة التتمام</th>
                          <th className="p-2 border-l">المدة (أيام)</th>
                          <th className="p-2 border-l">تاريخ البداية والنهاية</th>
                          <th className="p-2 border-l">أسباب وملاحظات التمام</th>
                          <th className="p-2 border-l">المعتمد</th>
                          <th className="p-2">التصديق الحيوي للوجه</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-slate-200">
                        {personnel.logs.attendance.map((att) => (
                          <tr key={att.id}>
                            <td className="p-2 border-l font-mono text-slate-900">{att.date}</td>
                            <td className={`p-2 border-l font-black ${
                              att.type === 'فرار' || att.type === 'غياب'
                                ? 'text-red-700'
                                : att.type === 'حضور'
                                ? 'text-emerald-700'
                                : 'text-amber-700'
                            }`}>
                              {att.type}
                            </td>
                            <td className="p-2 border-l font-mono text-center font-bold">{att.durationDays || 1}</td>
                            <td className="p-2 border-l font-mono text-[11px] text-slate-700">
                              {att.startDate} {att.endDate ? `إلى ${att.endDate}` : ''}
                            </td>
                            <td className="p-2 border-l text-slate-800">{att.reason || att.notes || '-'}</td>
                            <td className="p-2 border-l text-slate-700">{att.approvedBy || '-'}</td>
                            <td className="p-2 text-xs font-bold text-slate-700">
                              {att.faceVerified ? '📸 مؤكد حيويًا' : 'عادي'}
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  )}
                </div>
              )}

              {/* 6. SECTION: MEDICAL LOG (السجل الطبي والعيادات والوصفات) */}
              {selectedSections.medical && (
                <div className="border border-slate-300 rounded-2xl p-4 space-y-3 print:break-inside-avoid">
                  <h4 className="text-xs font-black text-slate-900 border-b border-slate-300 pb-2 flex items-center justify-between">
                    <div className="flex items-center space-x-1.5 space-x-reverse">
                      <HeartPulse className="w-4 h-4 text-emerald-700" />
                      <span>سادساً: السجل الطبي والعيادات العسكرية والوصفات والعمليات</span>
                    </div>
                    <span className="text-[10px] font-bold text-slate-500">إجمالي الحالات: ({personnel.logs.medical?.length || 0})</span>
                  </h4>

                  {(!personnel.logs.medical || personnel.logs.medical.length === 0) ? (
                    <p className="text-xs text-slate-500 font-bold py-2 text-center">لا توجد زيارات طبية أو إجازات مرضية مسجلة للفرد.</p>
                  ) : (
                    <table className="w-full text-right text-xs border border-slate-300">
                      <thead className="bg-slate-100 text-slate-900 font-bold border-b border-slate-300">
                        <tr>
                          <th className="p-2 border-l">التاريخ</th>
                          <th className="p-2 border-l">التشخيص الطبي</th>
                          <th className="p-2 border-l">المستشفى / العيادة</th>
                          <th className="p-2 border-l">الطبيب المعالج</th>
                          <th className="p-2 border-l">الراحة المرضية</th>
                          <th className="p-2">الأدوية والوصفات العلاجية المنصرفة</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-slate-200">
                        {personnel.logs.medical.map((med) => (
                          <tr key={med.id}>
                            <td className="p-2 border-l font-mono text-slate-900">{med.date}</td>
                            <td className="p-2 border-l font-bold text-slate-900">{med.diagnosis}</td>
                            <td className="p-2 border-l text-slate-800">{med.hospital}</td>
                            <td className="p-2 border-l text-slate-700">{med.doctor}</td>
                            <td className="p-2 border-l font-bold text-red-700">{med.sickLeaveDays} أيام</td>
                            <td className="p-2 text-slate-700 text-[11px]">
                              {med.medications && med.medications.length > 0
                                ? med.medications.map(m => `${m.name} (${m.dose})`).join(' ، ')
                                : med.prescriptionDetails || '-'}
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  )}
                </div>
              )}

              {/* 7. SECTION: FINANCIAL LOG (السجل المالي والرواتب والبدلات) */}
              {selectedSections.financial && (() => {
                const finLogs = StorageService.getSyncedPersonnelFinancialLogs(personnel);
                return (
                  <div className="border border-slate-300 rounded-2xl p-4 space-y-3 print:break-inside-avoid">
                    <h4 className="text-xs font-black text-slate-900 border-b border-slate-300 pb-2 flex items-center justify-between">
                      <div className="flex items-center space-x-1.5 space-x-reverse">
                        <DollarSign className="w-4 h-4 text-emerald-700" />
                        <span>سابعاً: السجل المالي والرواتب والبدلات والاستقطاعات والسلف والمساعدات المالية</span>
                      </div>
                      <span className="text-[10px] font-bold text-slate-500">إجمالي المعاملات: ({finLogs.length})</span>
                    </h4>

                    {finLogs.length === 0 ? (
                      <p className="text-xs text-slate-500 font-bold py-2 text-center">لا توجد حركات سداد أو سلف أو مساعدات مالية مضافة لسجل الفرد.</p>
                    ) : (
                      <table className="w-full text-right text-xs border border-slate-300">
                        <thead className="bg-slate-100 text-slate-900 font-bold border-b border-slate-300">
                          <tr>
                            <th className="p-2 border-l">التاريخ</th>
                            <th className="p-2 border-l">نوع المعاملة المالية</th>
                            <th className="p-2 border-l">المبلغ المعتمد</th>
                            <th className="p-2 border-l">رقم السند المالي</th>
                            <th className="p-2 border-l">حالة الخصم والمسير</th>
                            <th className="p-2 border-l">أسباب المعاملة والبيان</th>
                            <th className="p-2">المصادقة والتنفيذ</th>
                          </tr>
                        </thead>
                        <tbody className="divide-y divide-slate-200">
                          {finLogs.map((fin) => {
                            const isAdvance = fin.grantType === 'سلفة مالية' || fin.type === 'سلفة' || fin.type === 'سلفة مالية' || fin.isDeductedFromSalary;
                            const isAid = fin.grantType === 'مساعدة مالية' || fin.type === 'مساعدة مالية';
                            return (
                              <tr key={fin.id} className={isAdvance ? 'bg-amber-50/50' : isAid ? 'bg-emerald-50/50' : ''}>
                                <td className="p-2 border-l font-mono text-slate-900">{fin.date || fin.transactionDate}</td>
                                <td className="p-2 border-l font-bold">
                                  {isAdvance ? (
                                    <span className="text-amber-900 font-black">سلفة مالية ⚠️</span>
                                  ) : isAid ? (
                                    <span className="text-emerald-900 font-black">مساعدة مالية 🎁</span>
                                  ) : (
                                    <span className="text-slate-800">{fin.type}</span>
                                  )}
                                </td>
                                <td className="p-2 border-l font-mono font-black text-slate-900">{(fin.amount || 0).toLocaleString()} ريال</td>
                                <td className="p-2 border-l font-mono text-[11px] text-slate-700">{fin.voucherNumber || '-'}</td>
                                <td className="p-2 border-l text-[11px]">
                                  {isAdvance ? (
                                    <span className="text-amber-800 font-bold">مستقطعة (مسير {fin.monthYear || '-'})</span>
                                  ) : isAid ? (
                                    <span className="text-emerald-800 font-bold">غير مستردة (بدون خصم)</span>
                                  ) : (
                                    <span className="text-slate-600">معتمد</span>
                                  )}
                                </td>
                                <td className="p-2 border-l text-slate-800 text-[11px]">{fin.reason}</td>
                                <td className="p-2 font-mono text-slate-600 text-[10px]">{fin.approvedBy || 'الإدارة المالية'}</td>
                              </tr>
                            );
                          })}
                        </tbody>
                      </table>
                    )}
                  </div>
                );
              })()}

              {/* 8. SECTION: SECURITY & INVESTIGATION LOG (السجل الأمني والمخالفات) */}
              {selectedSections.security && (
                <div className="border border-slate-300 rounded-2xl p-4 space-y-3 print:break-inside-avoid">
                  <h4 className="text-xs font-black text-slate-900 border-b border-slate-300 pb-2 flex items-center justify-between">
                    <div className="flex items-center space-x-1.5 space-x-reverse">
                      <AlertTriangle className="w-4 h-4 text-emerald-700" />
                      <span>ثامناً: السجل الأمني والاستخباراتي والمخالفات والجزاءات العسكرية</span>
                    </div>
                    <span className="text-[10px] font-bold text-slate-500">إجمالي القيود: ({personnel.logs.security?.length || 0})</span>
                  </h4>

                  {(!personnel.logs.security || personnel.logs.security.length === 0) ? (
                    <p className="text-xs text-slate-500 font-bold py-2 text-center">السجل الأمني ناصع. لا توجد قضايا أو مخالفات استخباراتية مسجلة.</p>
                  ) : (
                    <table className="w-full text-right text-xs border border-slate-300">
                      <thead className="bg-slate-100 text-slate-900 font-bold border-b border-slate-300">
                        <tr>
                          <th className="p-2 border-l">التاريخ</th>
                          <th className="p-2 border-l">نوع المخالفة / القضية</th>
                          <th className="p-2 border-l">تفاصيل التحقيق</th>
                          <th className="p-2 border-l">درجة الخطورة</th>
                          <th className="p-2 border-l">العقوبة والجزاء الإداري</th>
                          <th className="p-2">حالة القيد الأمني</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-slate-200">
                        {personnel.logs.security.map((sec) => (
                          <tr key={sec.id}>
                            <td className="p-2 border-l font-mono text-slate-900">{sec.date}</td>
                            <td className="p-2 border-l font-bold text-red-800">{sec.violation}</td>
                            <td className="p-2 border-l text-slate-800">{sec.investigationDetails}</td>
                            <td className="p-2 border-l font-bold text-slate-900">{sec.warningLevel}</td>
                            <td className="p-2 border-l font-bold text-slate-900">{sec.penalty}</td>
                            <td className="p-2 font-bold text-slate-700">{sec.status}</td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  )}
                </div>
              )}

              {/* 9. SECTION: TRAINING COURSES LOG (سجل الدورات والتأهيل الميداني) */}
              {selectedSections.training && (
                <div className="border border-slate-300 rounded-2xl p-4 space-y-3 print:break-inside-avoid">
                  <h4 className="text-xs font-black text-slate-900 border-b border-slate-300 pb-2 flex items-center justify-between">
                    <div className="flex items-center space-x-1.5 space-x-reverse">
                      <Award className="w-4 h-4 text-emerald-700" />
                      <span>تاسعاً: سجل الدورات التدريبية والتأهيل القيادي والميداني</span>
                    </div>
                    <span className="text-[10px] font-bold text-slate-500">إجمالي الدورات: ({personnel.logs.training?.length || 0})</span>
                  </h4>

                  {(!personnel.logs.training || personnel.logs.training.length === 0) ? (
                    <p className="text-xs text-slate-500 font-bold py-2 text-center">لا توجد دورات تدريبية مسجلة سابقاً.</p>
                  ) : (
                    <table className="w-full text-right text-xs border border-slate-300">
                      <thead className="bg-slate-100 text-slate-900 font-bold border-b border-slate-300">
                        <tr>
                          <th className="p-2 border-l">اسم الدورة</th>
                          <th className="p-2 border-l">نوع الدورة</th>
                          <th className="p-2 border-l">مقر ومقدم الدورة</th>
                          <th className="p-2 border-l">الفترة الزمنية</th>
                          <th className="p-2 border-l">التقدير النهائي</th>
                          <th className="p-2">الشهادات والتقييم</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-slate-200">
                        {personnel.logs.training.map((trn) => (
                          <tr key={trn.id}>
                            <td className="p-2 border-l font-bold text-slate-900">{trn.courseName}</td>
                            <td className="p-2 border-l text-slate-800">{trn.courseType}</td>
                            <td className="p-2 border-l text-slate-800">{trn.provider}</td>
                            <td className="p-2 border-l font-mono text-[11px] text-slate-700">
                              {trn.startDate} إلى {trn.endDate} ({trn.durationWeeks} أسابيع)
                            </td>
                            <td className="p-2 border-l font-bold text-emerald-800">{trn.grade}</td>
                            <td className="p-2 text-slate-600 text-[11px]">{trn.evaluation || trn.certificates || '-'}</td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  )}
                </div>
              )}

              {/* EMPTY SELECTION NOTICE */}
              {!Object.values(selectedSections).some(Boolean) && (
                <div className="bg-amber-50 border-2 border-amber-300 text-amber-900 rounded-2xl p-6 text-center font-bold text-xs my-4">
                  ⚠️ لم يتم تحديد أي سجل للطباعة! يرجى اختيار سجل واحد على الأقل من القائمة أعلاه (مثل: السجل الطبي، أو السجل المالي).
                </div>
              )}

              {/* OFFICIAL SIGNATURES AND SEALS BLOCK */}
              <div className="pt-8 border-t-2 border-slate-900 grid grid-cols-3 gap-6 text-center text-xs font-bold text-slate-900 signature-block print:break-inside-avoid">
                <div className="space-y-2">
                  {officer1Title.trim() !== '' && (
                    <p className="font-black text-slate-900">{officer1Title}</p>
                  )}
                  <p className="font-bold text-slate-800 text-xs">{officer1Name || '....................'}</p>
                  <p className="text-[10px] text-slate-400 font-mono pt-2">التوقيع: ....................</p>
                </div>
                <div className="space-y-2">
                  {officer2Title.trim() !== '' && (
                    <p className="font-black text-slate-900">{officer2Title}</p>
                  )}
                  <p className="font-bold text-slate-800 text-xs">{officer2Name || '....................'}</p>
                  <p className="text-[10px] text-slate-400 font-mono pt-2">المصادقة والختم: ....................</p>
                </div>
                <div className="space-y-2">
                  {officer3Title.trim() !== '' && (
                    <p className="font-black text-slate-900">{officer3Title}</p>
                  )}
                  <p className="font-bold text-slate-800 text-xs">{officer3Name || '....................'}</p>
                  <p className="text-[10px] text-slate-400 font-mono pt-2">التوقيع والخاتم الرسمي: ....................</p>
                </div>
              </div>

            </div>
          ) : (
            /* MULTIPLE RECORDS BRANCH-SPECIFIC OFFICIAL REPORT SHEET */
            <div className="space-y-6">
              
              {/* Branch Header & Classification Banner */}
              <div className="border-b-2 border-slate-900 pb-3 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
                <div className="space-y-1">
                  <div className="flex items-center space-x-2 space-x-reverse">
                    <span className="text-xs font-black px-2.5 py-0.5 rounded-md bg-slate-900 text-white font-['Tajawal']">
                      {activeReportType === 'security' ? '🛡️ فرع الاستخبارات والأمن العسكري' :
                       activeReportType === 'medical' ? '🏥 إدارة الخدمات الطبية العسكرية' :
                       activeReportType === 'armament' ? '🎯 فرع التسليح والذخائر والعهد القتالية' :
                       activeReportType === 'training' ? '🎓 إدارة التدريب والدورات العسكرية' :
                       activeReportType === 'absences' ? '📋 فرع السجلات والتمام والغياب' :
                       activeReportType === 'financial' ? '💰 الإدارة المالية ومسيرات الرواتب' :
                       activeReportType === 'readiness' ? '⚡ فرع العمليات والجاهزية القتالية' :
                       activeReportType === 'daily' ? '📊 قيادة الفرقة - حصر التمام اليومي' :
                       '📑 إدارة القوى البشرية وشؤون الأفراد'}
                    </span>
                    <h3 className="text-base sm:text-lg font-black text-slate-900 font-['Tajawal']">
                      {reportTitle || 'التقرير العسكري المعتمد'}
                    </h3>
                  </div>
                  <p className="text-[11px] text-slate-600 font-bold">
                    كشف رسمي معتمد ومستخرج من المنظومة العسكرية المركزية • {currentAccountName}
                  </p>
                </div>

                <div className="text-left text-xs font-mono space-y-0.5 dir-ltr shrink-0">
                  <div className="text-right">إجمالي السجلات: <strong className="font-bold text-slate-900">{reportData?.length || 0} فرد</strong></div>
                  <div className="text-right">تاريخ الاستخراج: <strong className="font-bold text-slate-900">{new Date().toISOString().split('T')[0]}</strong></div>
                  <div className="text-right text-[10px] text-rose-700 font-black">درجة السرية: سري للغاية وللاستعمال الرسمي</div>
                </div>
              </div>

              {/* Branch Statistics KPI Summary Badges */}
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5 text-xs font-bold print:break-inside-avoid">
                {activeReportType === 'security' && (
                  <>
                    <div className="bg-rose-50 border border-rose-200 p-2.5 rounded-xl text-center">
                      <span className="text-[10px] text-rose-700 block">إجمالي قيود المخالفات</span>
                      <span className="text-base font-black text-rose-950 font-mono">
                        {reportData?.reduce((acc, p) => acc + (p.logs?.security?.length || 1), 0)}
                      </span>
                    </div>
                    <div className="bg-amber-50 border border-amber-200 p-2.5 rounded-xl text-center">
                      <span className="text-[10px] text-amber-700 block">قيد التحقيق والتحري</span>
                      <span className="text-base font-black text-amber-950 font-mono">
                        {reportData?.reduce((acc, p) => acc + (p.logs?.security?.filter(s => s.status === 'قيد التحقيق').length || 0), 0)}
                      </span>
                    </div>
                    <div className="bg-emerald-50 border border-emerald-200 p-2.5 rounded-xl text-center">
                      <span className="text-[10px] text-emerald-700 block">تم البت / قضاء عسكري</span>
                      <span className="text-base font-black text-emerald-950 font-mono">
                        {reportData?.reduce((acc, p) => acc + (p.logs?.security?.filter(s => s.status !== 'قيد التحقيق').length || 0), 0)}
                      </span>
                    </div>
                    <div className="bg-slate-50 border border-slate-300 p-2.5 rounded-xl text-center">
                      <span className="text-[10px] text-slate-700 block">أوامر التوقيف والاحتجاز</span>
                      <span className="text-base font-black text-slate-950 font-mono">
                        {reportData?.reduce((acc, p) => acc + (p.logs?.security?.filter(s => s.detentionOrder && s.detentionOrder.trim() !== '').length || (p.currentStatus === 'موقوف' ? 1 : 0)), 0)}
                      </span>
                    </div>
                  </>
                )}

                {activeReportType === 'medical' && (
                  <>
                    <div className="bg-pink-50 border border-pink-200 p-2.5 rounded-xl text-center">
                      <span className="text-[10px] text-pink-700 block">إجمالي الحالات الطبية</span>
                      <span className="text-base font-black text-pink-950 font-mono">
                        {reportData?.reduce((acc, p) => acc + (p.logs?.medical?.length || 1), 0)}
                      </span>
                    </div>
                    <div className="bg-rose-50 border border-rose-200 p-2.5 rounded-xl text-center">
                      <span className="text-[10px] text-rose-700 block">المنومين في المستشفيات</span>
                      <span className="text-base font-black text-rose-950 font-mono">
                        {reportData?.filter(p => p.currentStatus === 'مستشفى' || p.currentStatus === 'جريح').length}
                      </span>
                    </div>
                    <div className="bg-amber-50 border border-amber-200 p-2.5 rounded-xl text-center">
                      <span className="text-[10px] text-amber-700 block">إجمالي أيام الإجازات المرضية</span>
                      <span className="text-base font-black text-amber-950 font-mono">
                        {reportData?.reduce((acc, p) => acc + (p.logs?.medical?.reduce((mAcc, m) => mAcc + (m.sickLeaveDays || 0), 0) || 0), 0)} يوم
                      </span>
                    </div>
                    <div className="bg-emerald-50 border border-emerald-200 p-2.5 rounded-xl text-center">
                      <span className="text-[10px] text-emerald-700 block">تعافي وعودة للخدمة</span>
                      <span className="text-base font-black text-emerald-950 font-mono">
                        {reportData?.filter(p => p.currentStatus === 'متواجد' || p.currentStatus === 'في الميدان').length}
                      </span>
                    </div>
                  </>
                )}

                {activeReportType === 'armament' && (
                  <>
                    <div className="bg-amber-50 border border-amber-200 p-2.5 rounded-xl text-center">
                      <span className="text-[10px] text-amber-700 block">إجمالي الأفراد المسلّحين</span>
                      <span className="text-base font-black text-amber-950 font-mono">
                        {armamentTotals.armedCount} فرد
                      </span>
                    </div>
                    <div className="bg-slate-50 border border-slate-300 p-2.5 rounded-xl text-center">
                      <span className="text-[10px] text-slate-700 block">إجمالي قطع الأسلحة المنصرفة</span>
                      <span className="text-base font-black text-slate-950 font-mono">
                        {armamentTotals.weaponsCount} قطعة
                      </span>
                    </div>
                    <div className="bg-emerald-50 border border-emerald-200 p-2.5 rounded-xl text-center">
                      <span className="text-[10px] text-emerald-700 block">مجموع الذخيرة المصروفة</span>
                      <span className="text-base font-black text-emerald-950 font-mono">
                        {armamentTotals.ammoQuantity.toLocaleString()} طلقة
                      </span>
                    </div>
                    <div className="bg-blue-50 border border-blue-200 p-2.5 rounded-xl text-center">
                      <span className="text-[10px] text-blue-700 block">مجموع الخزائن / المخازن المنصرفة</span>
                      <span className="text-base font-black text-blue-950 font-mono">
                        {armamentTotals.magazinesCount} مخزن
                      </span>
                    </div>
                  </>
                )}

                {activeReportType === 'training' && (
                  <>
                    <div className="bg-purple-50 border border-purple-200 p-2.5 rounded-xl text-center">
                      <span className="text-[10px] text-purple-700 block">إجمالي المتدربين</span>
                      <span className="text-base font-black text-purple-950 font-mono">{reportData?.length}</span>
                    </div>
                    <div className="bg-emerald-50 border border-emerald-200 p-2.5 rounded-xl text-center">
                      <span className="text-[10px] text-emerald-700 block">دورات منتهية بنجاح</span>
                      <span className="text-base font-black text-emerald-950 font-mono">
                        {reportData?.reduce((acc, p) => acc + (p.logs?.training?.filter(t => t.grade === 'ممتاز' || t.grade === 'جيد جداً').length || 0), 0)}
                      </span>
                    </div>
                    <div className="bg-blue-50 border border-blue-200 p-2.5 rounded-xl text-center">
                      <span className="text-[10px] text-blue-700 block">دورات تخصصية وميدانية</span>
                      <span className="text-base font-black text-blue-950 font-mono">
                        {reportData?.reduce((acc, p) => acc + (p.logs?.training?.length || 1), 0)}
                      </span>
                    </div>
                    <div className="bg-amber-50 border border-amber-200 p-2.5 rounded-xl text-center">
                      <span className="text-[10px] text-amber-700 block">دورات خارجية وبعثات</span>
                      <span className="text-base font-black text-amber-950 font-mono">
                        {reportData?.filter(p => p.currentStatus === 'دورة تدريبية خارجية').length}
                      </span>
                    </div>
                  </>
                )}

                {activeReportType === 'absences' && (
                  <>
                    <div className="bg-amber-50 border border-amber-200 p-2.5 rounded-xl text-center">
                      <span className="text-[10px] text-amber-700 block">إجازات وأذونات رسمية</span>
                      <span className="text-base font-black text-amber-950 font-mono">
                        {reportData?.filter(p => p.currentStatus === 'إجازة' || p.currentStatus === 'إذن').length}
                      </span>
                    </div>
                    <div className="bg-rose-50 border border-rose-200 p-2.5 rounded-xl text-center">
                      <span className="text-[10px] text-rose-700 block">حالات غياب بدون إذن</span>
                      <span className="text-base font-black text-rose-950 font-mono">
                        {reportData?.filter(p => p.currentStatus === 'غياب').length}
                      </span>
                    </div>
                    <div className="bg-red-50 border border-red-300 p-2.5 rounded-xl text-center">
                      <span className="text-[10px] text-red-800 block">حالات فرار مسجلة</span>
                      <span className="text-base font-black text-red-950 font-mono">
                        {reportData?.filter(p => p.currentStatus === 'فرار').length}
                      </span>
                    </div>
                    <div className="bg-slate-50 border border-slate-300 p-2.5 rounded-xl text-center">
                      <span className="text-[10px] text-slate-700 block">أفراد موقوفون</span>
                      <span className="text-base font-black text-slate-950 font-mono">
                        {reportData?.filter(p => p.currentStatus === 'موقوف').length}
                      </span>
                    </div>
                  </>
                )}

                {activeReportType === 'financial' && (
                  <>
                    <div className="bg-teal-50 border border-teal-200 p-2.5 rounded-xl text-center">
                      <span className="text-[10px] text-teal-700 block">إجمالي السجلات المالية</span>
                      <span className="text-base font-black text-teal-950 font-mono">{reportData?.length}</span>
                    </div>
                    <div className="bg-emerald-50 border border-emerald-200 p-2.5 rounded-xl text-center">
                      <span className="text-[10px] text-emerald-700 block">مجموع الرواتب والمستحقات</span>
                      <span className="text-base font-black text-emerald-950 font-mono">
                        {reportData?.reduce((acc, p) => acc + (p.logs?.financial?.filter(f => f.type !== 'استقطاع').reduce((fAcc, f) => fAcc + (f.amount || 0), 0) || 0), 0).toLocaleString()} ريال
                      </span>
                    </div>
                    <div className="bg-rose-50 border border-rose-200 p-2.5 rounded-xl text-center">
                      <span className="text-[10px] text-rose-700 block">مجموع الاستقطاعات</span>
                      <span className="text-base font-black text-rose-950 font-mono">
                        {reportData?.reduce((acc, p) => acc + (p.logs?.financial?.filter(f => f.type === 'استقطاع').reduce((fAcc, f) => fAcc + (f.amount || 0), 0) || 0), 0).toLocaleString()} ريال
                      </span>
                    </div>
                    <div className="bg-slate-50 border border-slate-300 p-2.5 rounded-xl text-center">
                      <span className="text-[10px] text-slate-700 block">صافي المبالغ المصروفة</span>
                      <span className="text-base font-black text-slate-950 font-mono">
                        {(
                          reportData?.reduce((acc, p) => acc + (p.logs?.financial?.filter(f => f.type !== 'استقطاع').reduce((fAcc, f) => fAcc + (f.amount || 0), 0) || 0), 0) -
                          reportData?.reduce((acc, p) => acc + (p.logs?.financial?.filter(f => f.type === 'استقطاع').reduce((fAcc, f) => fAcc + (f.amount || 0), 0) || 0), 0)
                        ).toLocaleString()} ريال
                      </span>
                    </div>
                  </>
                )}

                {activeReportType === 'readiness' && (
                  <>
                    <div className="bg-emerald-50 border border-emerald-200 p-2.5 rounded-xl text-center">
                      <span className="text-[10px] text-emerald-700 block">جاهزية قتالية كاملة 100%</span>
                      <span className="text-base font-black text-emerald-950 font-mono">
                        {reportData?.filter(p => !p.combatReadiness || p.combatReadiness.includes('100') || p.combatReadiness.includes('جاهز')).length}
                      </span>
                    </div>
                    <div className="bg-blue-50 border border-blue-200 p-2.5 rounded-xl text-center">
                      <span className="text-[10px] text-blue-700 block">في الميدان ومتواجدون</span>
                      <span className="text-base font-black text-blue-950 font-mono">
                        {reportData?.filter(p => p.currentStatus === 'في الميدان' || p.currentStatus === 'متواجد').length}
                      </span>
                    </div>
                    <div className="bg-amber-50 border border-amber-200 p-2.5 rounded-xl text-center">
                      <span className="text-[10px] text-amber-700 block">مأموريات وانتداب</span>
                      <span className="text-base font-black text-amber-950 font-mono">
                        {reportData?.filter(p => p.currentStatus === 'مأمورية' || p.currentStatus === 'منتدب').length}
                      </span>
                    </div>
                    <div className="bg-slate-50 border border-slate-300 p-2.5 rounded-xl text-center">
                      <span className="text-[10px] text-slate-700 block">إجمالي القوة المحصورة</span>
                      <span className="text-base font-black text-slate-950 font-mono">{reportData?.length}</span>
                    </div>
                  </>
                )}

                {activeReportType === 'daily' && (
                  <>
                    <div className="bg-emerald-50 border border-emerald-200 p-2.5 rounded-xl text-center">
                      <span className="text-[10px] text-emerald-700 block">متواجدون بالتمام</span>
                      <span className="text-base font-black text-emerald-950 font-mono">
                        {reportData?.filter(p => p.currentStatus === 'متواجد' || p.currentStatus === 'في الميدان').length}
                      </span>
                    </div>
                    <div className="bg-amber-50 border border-amber-200 p-2.5 rounded-xl text-center">
                      <span className="text-[10px] text-amber-700 block">إجازات وأذونات</span>
                      <span className="text-base font-black text-amber-950 font-mono">
                        {reportData?.filter(p => p.currentStatus === 'إجازة' || p.currentStatus === 'إذن').length}
                      </span>
                    </div>
                    <div className="bg-rose-50 border border-rose-200 p-2.5 rounded-xl text-center">
                      <span className="text-[10px] text-rose-700 block">غياب وفرار ومستشفى</span>
                      <span className="text-base font-black text-rose-950 font-mono">
                        {reportData?.filter(p => ['غياب', 'فرار', 'مستشفى', 'موقوف'].includes(p.currentStatus)).length}
                      </span>
                    </div>
                    <div className="bg-slate-50 border border-slate-300 p-2.5 rounded-xl text-center">
                      <span className="text-[10px] text-slate-700 block">إجمالي القوة</span>
                      <span className="text-base font-black text-slate-950 font-mono">{reportData?.length}</span>
                    </div>
                  </>
                )}
              </div>

              {/* Branch Detailed Printable Table */}
              <div className="overflow-x-auto">
                <table className="w-full text-right text-xs border border-slate-900 print:text-[10px] print:border-black">
                  <thead className="bg-slate-200 text-slate-900 font-black border-b-2 border-slate-900 print:bg-slate-100 print:border-black">
                    {activeReportType === 'security' ? (
                      <tr>
                        <th className="p-2 border-l border-slate-900 text-center w-8">#</th>
                        <th className="p-2 border-l border-slate-900">الرقم الوظيفي</th>
                        <th className="p-2 border-l border-slate-900">الاسم الرباعي</th>
                        <th className="p-2 border-l border-slate-900">الرتبة</th>
                        <th className="p-2 border-l border-slate-900">الوحدة والكتيبة</th>
                        <th className="p-2 border-l border-slate-900">نوع المخالفة</th>
                        <th className="p-2 border-l border-slate-900">درجة الخطورة</th>
                        <th className="p-2 border-l border-slate-900">ملخص التحقيق والواقعة</th>
                        <th className="p-2 border-l border-slate-900">العقوبة / الإجراء المقترح</th>
                        <th className="p-2 border-l border-slate-900">أمر التوقيف والاحتجاز</th>
                        <th className="p-2 border-l border-slate-900">جهة التحقيق</th>
                        <th className="p-2 border-l border-slate-900">حالة القضية</th>
                        <th className="p-2">تاريخ المخالفة</th>
                      </tr>
                    ) : activeReportType === 'medical' ? (
                      <tr>
                        <th className="p-2 border-l border-slate-900 text-center w-8">#</th>
                        <th className="p-2 border-l border-slate-900">الرقم الوظيفي</th>
                        <th className="p-2 border-l border-slate-900">الاسم الرباعي</th>
                        <th className="p-2 border-l border-slate-900">الرتبة</th>
                        <th className="p-2 border-l border-slate-900">الوحدة</th>
                        <th className="p-2 border-l border-slate-900">الحالة الراهنة</th>
                        <th className="p-2 border-l border-slate-900">التشخيص الطبي</th>
                        <th className="p-2 border-l border-slate-900">المستشفى / العيادة</th>
                        <th className="p-2 border-l border-slate-900">الطبيب المعالج</th>
                        <th className="p-2 border-l border-slate-900">أيام الإجازة</th>
                        <th className="p-2 border-l border-slate-900">التنويم والعمليات</th>
                        <th className="p-2 border-l border-slate-900">التوصيات الطبية</th>
                        <th className="p-2">تاريخ الكشف</th>
                      </tr>
                    ) : activeReportType === 'armament' ? (
                      <tr>
                        <th className="p-2 border-l border-slate-900 text-center w-8">#</th>
                        <th className="p-2 border-l border-slate-900">الرقم الوظيفي</th>
                        <th className="p-2 border-l border-slate-900">الاسم الرباعي</th>
                        <th className="p-2 border-l border-slate-900">الرتبة</th>
                        <th className="p-2 border-l border-slate-900">الوحدة والكتيبة</th>
                        <th className="p-2 border-l border-slate-900">نوع السلاح المسند</th>
                        <th className="p-2 border-l border-slate-900">الرقم التسلسلي S/N</th>
                        <th className="p-2 border-l border-slate-900">حالة العهدة</th>
                        <th className="p-2 border-l border-slate-900">الحالة الفنية</th>
                        <th className="p-2 border-l border-slate-900">عدد الخزائن</th>
                        <th className="p-2 border-l border-slate-900">كمية الذخيرة</th>
                        <th className="p-2 border-l border-slate-900">تاريخ الصرف</th>
                        <th className="p-2">ملاحظات فنية</th>
                      </tr>
                    ) : activeReportType === 'training' ? (
                      <tr>
                        <th className="p-2 border-l border-slate-900 text-center w-8">#</th>
                        <th className="p-2 border-l border-slate-900">الرقم الوظيفي</th>
                        <th className="p-2 border-l border-slate-900">الاسم الرباعي</th>
                        <th className="p-2 border-l border-slate-900">الرتبة</th>
                        <th className="p-2 border-l border-slate-900">الوحدة والكتيبة</th>
                        <th className="p-2 border-l border-slate-900">اسم الدورة</th>
                        <th className="p-2 border-l border-slate-900">نوع الدورة</th>
                        <th className="p-2 border-l border-slate-900">معهد / جهة التدريب</th>
                        <th className="p-2 border-l border-slate-900">الفترة الزمنية</th>
                        <th className="p-2 border-l border-slate-900">المدة بالأسابيع</th>
                        <th className="p-2 border-l border-slate-900">التقدير والنتيجة</th>
                        <th className="p-2 border-l border-slate-900">التقييم والشهادة</th>
                        <th className="p-2">الضابط المشرف</th>
                      </tr>
                    ) : activeReportType === 'absences' ? (
                      <tr>
                        <th className="p-2 border-l border-slate-900 text-center w-8">#</th>
                        <th className="p-2 border-l border-slate-900">الرقم الوظيفي</th>
                        <th className="p-2 border-l border-slate-900">الاسم الرباعي</th>
                        <th className="p-2 border-l border-slate-900">الرتبة</th>
                        <th className="p-2 border-l border-slate-900">الوحدة والكتيبة</th>
                        <th className="p-2 border-l border-slate-900">نوع الحالة</th>
                        <th className="p-2 border-l border-slate-900">سبب الغياب / الإجازة</th>
                        <th className="p-2 border-l border-slate-900">تاريخ البدء</th>
                        <th className="p-2 border-l border-slate-900">تاريخ الانتهاء</th>
                        <th className="p-2 border-l border-slate-900">المدة بالأيام</th>
                        <th className="p-2 border-l border-slate-900">جهة الاعتماد</th>
                        <th className="p-2 border-l border-slate-900">حالة السلاح</th>
                        <th className="p-2">ملاحظات</th>
                      </tr>
                    ) : activeReportType === 'financial' ? (
                      <tr>
                        <th className="p-2 border-l border-slate-900 text-center w-8">#</th>
                        <th className="p-2 border-l border-slate-900">الرقم الوظيفي</th>
                        <th className="p-2 border-l border-slate-900">الاسم الرباعي</th>
                        <th className="p-2 border-l border-slate-900">الرتبة</th>
                        <th className="p-2 border-l border-slate-900">الوحدة</th>
                        <th className="p-2 border-l border-slate-900">نوع المعاملة</th>
                        <th className="p-2 border-l border-slate-900">المبلغ (ريال)</th>
                        <th className="p-2 border-l border-slate-900">السبب والغرض</th>
                        <th className="p-2 border-l border-slate-900">تاريخ المعاملة</th>
                        <th className="p-2 border-l border-slate-900">الجهة المعتمدة</th>
                        <th className="p-2">ملاحظات</th>
                      </tr>
                    ) : activeReportType === 'readiness' ? (
                      <tr>
                        <th className="p-2 border-l border-slate-900 text-center w-8">#</th>
                        <th className="p-2 border-l border-slate-900">الرقم الوظيفي</th>
                        <th className="p-2 border-l border-slate-900">الاسم الرباعي</th>
                        <th className="p-2 border-l border-slate-900">الرتبة</th>
                        <th className="p-2 border-l border-slate-900">الوحدة والكتيبة</th>
                        <th className="p-2 border-l border-slate-900">الحالة الراهنة</th>
                        <th className="p-2 border-l border-slate-900">الجاهزية القتالية</th>
                        <th className="p-2 border-l border-slate-900">فصيلة الدم</th>
                        <th className="p-2 border-l border-slate-900">اللياقة الطبية</th>
                        <th className="p-2 border-l border-slate-900">السلاح المسند</th>
                        <th className="p-2 border-l border-slate-900">الوظيفة العسكرية</th>
                        <th className="p-2">رقم الهاتف</th>
                      </tr>
                    ) : activeReportType === 'daily' ? (
                      <tr>
                        <th className="p-2 border-l border-slate-900 text-center w-8">#</th>
                        <th className="p-2 border-l border-slate-900">الرقم الوظيفي</th>
                        <th className="p-2 border-l border-slate-900">الاسم الرباعي</th>
                        <th className="p-2 border-l border-slate-900">الرتبة</th>
                        <th className="p-2 border-l border-slate-900">الوحدة والكتيبة</th>
                        <th className="p-2 border-l border-slate-900">حالة التمام اليومي</th>
                        <th className="p-2 border-l border-slate-900">جهة الانتداب / المأمورية</th>
                        <th className="p-2 border-l border-slate-900">الدورة التدريبية</th>
                        <th className="p-2 border-l border-slate-900">تاريخ آخر تحديث</th>
                        <th className="p-2">رقم التواصل</th>
                      </tr>
                    ) : (
                      <tr>
                        <th className="p-2 border-l border-slate-900 text-center w-8">#</th>
                        <th className="p-2 border-l border-slate-900">الرقم الوظيفي</th>
                        <th className="p-2 border-l border-slate-900">الاسم الرباعي</th>
                        <th className="p-2 border-l border-slate-900">الرتبة</th>
                        <th className="p-2 border-l border-slate-900">الرقم الوطني</th>
                        <th className="p-2 border-l border-slate-900">الوحدة والكتيبة</th>
                        <th className="p-2 border-l border-slate-900">الوظيفة العسكرية</th>
                        <th className="p-2 border-l border-slate-900">تاريخ الالتحاق</th>
                        <th className="p-2 border-l border-slate-900">الحالة الحالية</th>
                        <th className="p-2">رقم الهاتف</th>
                      </tr>
                    )}
                  </thead>
                  <tbody className="divide-y divide-slate-300 print:divide-slate-400">
                    {reportData?.map((p, idx) => {
                      if (activeReportType === 'security') {
                        const secLogs = p.logs?.security || [];
                        const sec = secLogs[0];
                        return (
                          <tr key={p.militaryId} className="hover:bg-slate-50 print:break-inside-avoid">
                            <td className="p-2 border-l border-slate-900 font-mono text-center">{idx + 1}</td>
                            <td className="p-2 border-l border-slate-900 font-mono font-bold text-slate-900">{p.militaryId}</td>
                            <td className="p-2 border-l border-slate-900 font-bold text-slate-900">{p.fullName}</td>
                            <td className="p-2 border-l border-slate-900 font-bold text-slate-800">{p.rank}</td>
                            <td className="p-2 border-l border-slate-900 text-slate-700">{p.unit} ({p.battalion})</td>
                            <td className="p-2 border-l border-slate-900 font-bold text-rose-800">{sec?.violation || 'مخالفة أمنية عامة'}</td>
                            <td className="p-2 border-l border-slate-900 font-bold">
                              <span className="px-1.5 py-0.5 rounded text-[10px] bg-rose-100 text-rose-900 border border-rose-300">
                                {sec?.warningLevel || 'متوسط'}
                              </span>
                            </td>
                            <td className="p-2 border-l border-slate-900 text-slate-700 text-[11px] leading-relaxed max-w-xs">{sec?.investigationDetails || '-'}</td>
                            <td className="p-2 border-l border-slate-900 font-bold text-slate-900">{sec?.penalty || '-'}</td>
                            <td className="p-2 border-l border-slate-900 font-mono text-rose-800 font-bold">{sec?.detentionOrder || (p.currentStatus === 'موقوف' ? 'أمر توقيف نافذ' : 'لا يوجد')}</td>
                            <td className="p-2 border-l border-slate-900 text-slate-700">{sec?.authority || 'فرع الاستخبارات العسكرية'}</td>
                            <td className="p-2 border-l border-slate-900 font-bold text-slate-800">{sec?.status || (p.currentStatus === 'موقوف' ? 'موقوف قيد التحقيق' : 'قيد التحقيق')}</td>
                            <td className="p-2 font-mono text-slate-600 text-[11px]">{sec?.date || '-'}</td>
                          </tr>
                        );
                      }

                      if (activeReportType === 'medical') {
                        const med = p.logs?.medical?.[0];
                        return (
                          <tr key={p.militaryId} className="hover:bg-slate-50 print:break-inside-avoid">
                            <td className="p-2 border-l border-slate-900 font-mono text-center">{idx + 1}</td>
                            <td className="p-2 border-l border-slate-900 font-mono font-bold text-slate-900">{p.militaryId}</td>
                            <td className="p-2 border-l border-slate-900 font-bold text-slate-900">{p.fullName}</td>
                            <td className="p-2 border-l border-slate-900 font-bold text-slate-800">{p.rank}</td>
                            <td className="p-2 border-l border-slate-900 text-slate-700">{p.unit}</td>
                            <td className="p-2 border-l border-slate-900 font-bold text-pink-800">{p.currentStatus}</td>
                            <td className="p-2 border-l border-slate-900 font-bold text-slate-900">{med?.diagnosis || 'سليم معافى'}</td>
                            <td className="p-2 border-l border-slate-900 text-slate-700">{med?.hospital || 'المستشفى العسكري'}</td>
                            <td className="p-2 border-l border-slate-900 text-slate-700">{med?.doctor || '-'}</td>
                            <td className="p-2 border-l border-slate-900 font-mono font-bold text-center text-pink-800">{med?.sickLeaveDays || 0} يوم</td>
                            <td className="p-2 border-l border-slate-900 text-slate-700 text-[11px]">{med?.surgicalOperations || med?.injuryDetails || '-'}</td>
                            <td className="p-2 border-l border-slate-900 text-slate-700 text-[11px] leading-relaxed max-w-xs">{med?.recommendations || med?.notes || '-'}</td>
                            <td className="p-2 font-mono text-slate-600 text-[11px]">{med?.date || '-'}</td>
                          </tr>
                        );
                      }

                      if (activeReportType === 'armament') {
                        const row = armamentRows[idx] || resolveArmamentRow(p);
                        return (
                          <tr key={p.militaryId} className="hover:bg-slate-50 print:break-inside-avoid">
                            <td className="p-2 border-l border-slate-900 font-mono text-center">{idx + 1}</td>
                            <td className="p-2 border-l border-slate-900 font-mono font-bold text-slate-900">{p.militaryId}</td>
                            <td className="p-2 border-l border-slate-900 font-bold text-slate-900">{p.fullName}</td>
                            <td className="p-2 border-l border-slate-900 font-bold text-slate-800">{p.rank}</td>
                            <td className="p-2 border-l border-slate-900 text-slate-700">{p.unit} ({p.battalion || '-'})</td>
                            <td className="p-2 border-l border-slate-900 font-bold text-slate-900">{row.weaponType}</td>
                            <td className="p-2 border-l border-slate-900 font-mono font-bold text-amber-900">{row.weaponSerial}</td>
                            <td className="p-2 border-l border-slate-900 font-bold text-slate-800">{row.status}</td>
                            <td className="p-2 border-l border-slate-900 text-slate-800">{row.condition}</td>
                            <td className="p-2 border-l border-slate-900 font-mono text-center font-bold text-slate-900">{row.firelinesCount}</td>
                            <td className="p-2 border-l border-slate-900 font-mono font-bold text-emerald-800">{row.ammoQty.toLocaleString()} طلقة</td>
                            <td className="p-2 border-l border-slate-900 font-mono text-slate-600 text-[11px]">{row.issueDate}</td>
                            <td className="p-2 text-slate-600 text-[11px]">{row.technicalNotes}</td>
                          </tr>
                        );
                      }

                      if (activeReportType === 'training') {
                        const trn = p.logs?.training?.[0];
                        return (
                          <tr key={p.militaryId} className="hover:bg-slate-50 print:break-inside-avoid">
                            <td className="p-2 border-l border-slate-900 font-mono text-center">{idx + 1}</td>
                            <td className="p-2 border-l border-slate-900 font-mono font-bold text-slate-900">{p.militaryId}</td>
                            <td className="p-2 border-l border-slate-900 font-bold text-slate-900">{p.fullName}</td>
                            <td className="p-2 border-l border-slate-900 font-bold text-slate-800">{p.rank}</td>
                            <td className="p-2 border-l border-slate-900 text-slate-700">{p.unit}</td>
                            <td className="p-2 border-l border-slate-900 font-bold text-purple-950">{trn?.courseName || p.trainingCourseType || 'تدريب تخصصي'}</td>
                            <td className="p-2 border-l border-slate-900 text-slate-800">{trn?.courseType || '-'}</td>
                            <td className="p-2 border-l border-slate-900 text-slate-800">{trn?.provider || 'معهد تدريب القوات'}</td>
                            <td className="p-2 border-l border-slate-900 font-mono text-[11px] text-slate-700">{trn?.startDate ? `${trn.startDate} إلى ${trn.endDate}` : '-'}</td>
                            <td className="p-2 border-l border-slate-900 font-mono text-center font-bold text-slate-900">{trn?.durationWeeks || '-'} أسابيع</td>
                            <td className="p-2 border-l border-slate-900 font-bold text-emerald-800">{trn?.grade || '-'}</td>
                            <td className="p-2 border-l border-slate-900 text-slate-700 text-[11px]">{trn?.evaluation || trn?.certificates || '-'}</td>
                            <td className="p-2 text-slate-700 text-[11px]">{trn?.supervisorOfficer || '-'}</td>
                          </tr>
                        );
                      }

                      if (activeReportType === 'absences') {
                        const att = p.logs?.attendance?.[0];
                        return (
                          <tr key={p.militaryId} className="hover:bg-slate-50 print:break-inside-avoid">
                            <td className="p-2 border-l border-slate-900 font-mono text-center">{idx + 1}</td>
                            <td className="p-2 border-l border-slate-900 font-mono font-bold text-slate-900">{p.militaryId}</td>
                            <td className="p-2 border-l border-slate-900 font-bold text-slate-900">{p.fullName}</td>
                            <td className="p-2 border-l border-slate-900 font-bold text-slate-800">{p.rank}</td>
                            <td className="p-2 border-l border-slate-900 text-slate-700">{p.unit} ({p.battalion})</td>
                            <td className="p-2 border-l border-slate-900 font-bold">
                              <span className={`px-2 py-0.5 rounded text-[10px] ${
                                p.currentStatus === 'فرار' ? 'bg-red-100 text-red-900 font-black' :
                                p.currentStatus === 'غياب' ? 'bg-rose-100 text-rose-900 font-black' :
                                'bg-amber-100 text-amber-900'
                              }`}>
                                {p.currentStatus}
                              </span>
                            </td>
                            <td className="p-2 border-l border-slate-900 text-slate-700 text-[11px] leading-relaxed max-w-xs">{att?.reason || '-'}</td>
                            <td className="p-2 border-l border-slate-900 font-mono text-slate-700 text-[11px]">{att?.startDate || '-'}</td>
                            <td className="p-2 border-l border-slate-900 font-mono text-slate-700 text-[11px]">{att?.endDate || '-'}</td>
                            <td className="p-2 border-l border-slate-900 font-mono font-bold text-center text-rose-900">{att?.durationDays || '-'} يوم</td>
                            <td className="p-2 border-l border-slate-900 text-slate-700">{att?.approvedBy || '-'}</td>
                            <td className="p-2 border-l border-slate-900 text-slate-700 text-[11px]">{att?.withWeapon ? '⚠️ غادر بالسلاح' : 'بدون سلاح'}</td>
                            <td className="p-2 text-slate-600 text-[11px]">{att?.notes || '-'}</td>
                          </tr>
                        );
                      }

                      if (activeReportType === 'financial') {
                        const syncedLogs = StorageService.getSyncedPersonnelFinancialLogs(p);
                        const fin = syncedLogs[0];
                        const totalAmt = syncedLogs.reduce((acc, f) => acc + (f.amount || 0), 0);
                        const isAdvance = fin?.grantType === 'سلفة مالية' || fin?.type === 'سلفة' || fin?.type === 'سلفة مالية' || fin?.isDeductedFromSalary;
                        const isAid = fin?.grantType === 'مساعدة مالية' || fin?.type === 'مساعدة مالية';
                        return (
                          <tr key={p.militaryId} className={`hover:bg-slate-50 print:break-inside-avoid ${isAdvance ? 'bg-amber-50/40' : isAid ? 'bg-emerald-50/40' : ''}`}>
                            <td className="p-2 border-l border-slate-900 font-mono text-center">{idx + 1}</td>
                            <td className="p-2 border-l border-slate-900 font-mono font-bold text-slate-900">{p.militaryId}</td>
                            <td className="p-2 border-l border-slate-900 font-bold text-slate-900">{p.fullName}</td>
                            <td className="p-2 border-l border-slate-900 font-bold text-slate-800">{p.rank}</td>
                            <td className="p-2 border-l border-slate-900 text-slate-700">{p.unit}</td>
                            <td className="p-2 border-l border-slate-900 font-bold">
                              {isAdvance ? (
                                <span className="text-amber-900 font-black">سلفة ({fin?.voucherNumber || 'مسجلة'})</span>
                              ) : isAid ? (
                                <span className="text-emerald-900 font-black">مساعدة ({fin?.voucherNumber || 'مسجلة'})</span>
                              ) : (
                                <span className="text-teal-900">{fin?.type || 'راتب أساسي'}</span>
                              )}
                            </td>
                            <td className="p-2 border-l border-slate-900 font-mono font-black text-emerald-800">{totalAmt.toLocaleString()} ريال</td>
                            <td className="p-2 border-l border-slate-900 text-slate-700 text-[11px]">{fin?.reason || '-'}</td>
                            <td className="p-2 border-l border-slate-900 font-mono text-slate-600 text-[11px]">{fin?.transactionDate || fin?.date || '-'}</td>
                            <td className="p-2 border-l border-slate-900 text-slate-700">{fin?.approvedBy || 'الإدارة المالية'}</td>
                            <td className="p-2 text-slate-600 text-[11px]">{fin?.notes || '-'}</td>
                          </tr>
                        );
                      }

                      if (activeReportType === 'readiness') {
                        return (
                          <tr key={p.militaryId} className="hover:bg-slate-50 print:break-inside-avoid">
                            <td className="p-2 border-l border-slate-900 font-mono text-center">{idx + 1}</td>
                            <td className="p-2 border-l border-slate-900 font-mono font-bold text-slate-900">{p.militaryId}</td>
                            <td className="p-2 border-l border-slate-900 font-bold text-slate-900">{p.fullName}</td>
                            <td className="p-2 border-l border-slate-900 font-bold text-slate-800">{p.rank}</td>
                            <td className="p-2 border-l border-slate-900 text-slate-700">{p.unit} ({p.battalion})</td>
                            <td className="p-2 border-l border-slate-900 font-bold text-emerald-800">{p.currentStatus}</td>
                            <td className="p-2 border-l border-slate-900 font-bold text-emerald-900">{p.combatReadiness || '100% جاهز للقتال'}</td>
                            <td className="p-2 border-l border-slate-900 font-mono font-bold text-rose-800 text-center">{p.bloodType || 'غير مسجلة'}</td>
                            <td className="p-2 border-l border-slate-900 text-slate-800 text-center">{p.medicalFitness || 'لائق أ'}</td>
                            <td className="p-2 border-l border-slate-900 font-bold text-slate-900">{p.assignedWeapon || p.logs?.armament?.[0]?.weaponType || 'غير مسند'}</td>
                            <td className="p-2 border-l border-slate-900 text-slate-700">{p.jobTitle || 'غير محدد'}</td>
                            <td className="p-2 font-mono text-slate-700">{p.phone}</td>
                          </tr>
                        );
                      }

                      if (activeReportType === 'daily') {
                        return (
                          <tr key={p.militaryId} className="hover:bg-slate-50 print:break-inside-avoid">
                            <td className="p-2 border-l border-slate-900 font-mono text-center">{idx + 1}</td>
                            <td className="p-2 border-l border-slate-900 font-mono font-bold text-slate-900">{p.militaryId}</td>
                            <td className="p-2 border-l border-slate-900 font-bold text-slate-900">{p.fullName}</td>
                            <td className="p-2 border-l border-slate-900 font-bold text-slate-800">{p.rank}</td>
                            <td className="p-2 border-l border-slate-900 text-slate-700">{p.unit} ({p.battalion})</td>
                            <td className="p-2 border-l border-slate-900 font-bold text-slate-900">{p.currentStatus}</td>
                            <td className="p-2 border-l border-slate-900 text-purple-900 font-bold">{p.secondedUnit || '-'}</td>
                            <td className="p-2 border-l border-slate-900 text-indigo-900 font-bold">{p.trainingCourseType || '-'}</td>
                            <td className="p-2 border-l border-slate-900 font-mono text-slate-600 text-[11px]">{p.lastStatusChangeDate || '-'}</td>
                            <td className="p-2 font-mono text-slate-700">{p.phone}</td>
                          </tr>
                        );
                      }

                      // Default comprehensive
                      return (
                        <tr key={p.militaryId} className="hover:bg-slate-50 print:break-inside-avoid">
                          <td className="p-2 border-l border-slate-900 font-mono text-center">{idx + 1}</td>
                          <td className="p-2 border-l border-slate-900 font-mono font-bold text-slate-900">{p.militaryId}</td>
                          <td className="p-2 border-l border-slate-900 font-bold text-slate-900">{p.fullName}</td>
                          <td className="p-2 border-l border-slate-900 font-bold text-slate-800">{p.rank}</td>
                          <td className="p-2 border-l border-slate-900 font-mono text-slate-700">{p.nationalId}</td>
                          <td className="p-2 border-l border-slate-900 text-slate-700">{p.unit} ({p.battalion})</td>
                          <td className="p-2 border-l border-slate-900 text-slate-700">{p.jobTitle || 'غير محدد'}</td>
                          <td className="p-2 border-l border-slate-900 font-mono text-slate-600 text-[11px]">{p.enlistmentDate || '-'}</td>
                          <td className="p-2 border-l border-slate-900 font-bold text-emerald-800">{p.currentStatus}</td>
                          <td className="p-2 font-mono text-slate-700">{p.phone}</td>
                        </tr>
                      );
                    })}
                  </tbody>

                  {/* Summary Totals Table Footer for Armament & Financial */}
                  {activeReportType === 'armament' && (
                    <tfoot className="bg-slate-100 font-black border-t-2 border-slate-900 text-slate-900">
                      <tr>
                        <td colSpan={5} className="p-2.5 border-l border-slate-900 text-left font-black">
                          المجموع الإجمالي لفرع التسليح:
                        </td>
                        <td colSpan={4} className="p-2.5 border-l border-slate-900 font-bold">
                          إجمالي الأسلحة المنصرفة: {armamentTotals.weaponsCount} قطعة ({armamentTotals.armedCount} فرد مسلح)
                        </td>
                        <td className="p-2.5 border-l border-slate-900 font-mono text-center font-black text-sm">
                          {armamentTotals.magazinesCount}
                        </td>
                        <td className="p-2.5 border-l border-slate-900 font-mono text-emerald-900 font-black text-sm">
                          {armamentTotals.ammoQuantity.toLocaleString()} طلقة
                        </td>
                        <td colSpan={2} className="p-2.5 font-bold text-slate-600 text-[11px]">
                          مطابق للسجلات الرسمية
                        </td>
                      </tr>
                    </tfoot>
                  )}

                  {activeReportType === 'financial' && (
                    <tfoot className="bg-slate-100 font-black border-t-2 border-slate-900 text-slate-900">
                      <tr>
                        <td colSpan={6} className="p-2.5 border-l border-slate-900 text-left font-black">
                          المجاميع الإجمالية للمسير المالي:
                        </td>
                        <td className="p-2.5 border-l border-slate-900 font-mono text-emerald-900">
                          {(
                            reportData?.reduce((acc, p) => acc + (p.logs?.financial?.filter(f => f.type !== 'استقطاع').reduce((fAcc, f) => fAcc + (f.amount || 0), 0) || 0), 0) -
                            reportData?.reduce((acc, p) => acc + (p.logs?.financial?.filter(f => f.type === 'استقطاع').reduce((fAcc, f) => fAcc + (f.amount || 0), 0) || 0), 0)
                          ).toLocaleString()} ريال
                        </td>
                        <td colSpan={4} className="p-2.5 font-bold text-slate-600 text-[11px]">
                          صافي إجمالي المبالغ المعتمدة للصرف
                        </td>
                      </tr>
                    </tfoot>
                  )}
                </table>
              </div>

              {/* OFFICIAL SIGNATURES AND SEALS BLOCK */}
              <div className="pt-8 border-t-2 border-slate-900 grid grid-cols-3 gap-6 text-center text-xs font-bold text-slate-900 signature-block print:break-inside-avoid">
                <div className="space-y-2">
                  <p className="font-black text-slate-900">{officer1Title || branchDefaults.t1}</p>
                  <p className="font-bold text-slate-800 text-xs">{officer1Name || '....................'}</p>
                  <p className="text-[10px] text-slate-400 font-mono pt-2">التوقيع: ....................</p>
                </div>
                <div className="space-y-2">
                  <p className="font-black text-slate-900">{officer2Title || branchDefaults.t2}</p>
                  <p className="font-bold text-slate-800 text-xs">{officer2Name || '....................'}</p>
                  <p className="text-[10px] text-slate-400 font-mono pt-2">المصادقة والختم: ....................</p>
                </div>
                <div className="space-y-2">
                  <p className="font-black text-slate-900">{officer3Title || branchDefaults.t3}</p>
                  <p className="font-bold text-slate-800 text-xs">{officer3Name || '....................'}</p>
                  <p className="text-[10px] text-slate-400 font-mono pt-2">التوقيع والخاتم الرسمي: ....................</p>
                </div>
              </div>

              {/* Official Seal and Verification Note */}
              <div className="pt-4 text-center text-[10px] text-slate-500 font-bold border-t border-slate-200 flex items-center justify-between print:break-inside-avoid">
                <span>وثيقة عسكرية رسمية معتمدة • يحظر تداولها لغير المعنيين</span>
                <span className="font-mono">معرف التقرير: OFF-REP-{Math.floor(100000 + Math.random() * 900000)}</span>
                <span>نظام إدارة القوى البشرية العسكري © 2026</span>
              </div>

            </div>
          )}

        </div>

        </div>

        {/* Floating Sticky Bottom Bar for Quick Return & Print */}
        <div className="sticky bottom-0 z-30 bg-slate-950 text-white p-3.5 rounded-b-3xl border-t-2 border-emerald-500/80 shadow-2xl flex items-center justify-between gap-3 print:hidden no-print backdrop-blur-md shrink-0">
          <div className="flex items-center space-x-2 space-x-reverse text-xs text-slate-300 font-medium">
            <Printer className="w-4 h-4 text-emerald-400" />
            <span className="font-bold hidden sm:inline text-amber-300 font-['Tajawal']">معاينة وتخصيص طباعة الملف الموحد</span>
          </div>

          <div className="flex items-center space-x-2 space-x-reverse flex-wrap gap-1.5">
            <button
              type="button"
              onClick={onClose}
              className="bg-slate-800 hover:bg-slate-700 text-amber-300 hover:text-white border border-amber-500/50 font-extrabold px-3.5 py-2 rounded-xl text-xs transition-all shadow-md flex items-center space-x-1.5 space-x-reverse cursor-pointer"
              title="العودة للقائمة السابقة"
            >
              <ArrowRight className="w-4 h-4 text-amber-400" />
              <span>العودة للقائمة السابقة ↩️</span>
            </button>

            <button
              type="button"
              onClick={handleShareOrSave}
              disabled={isPrinting}
              className="bg-sky-700 hover:bg-sky-600 active:scale-95 text-white font-extrabold px-3.5 py-2 rounded-xl text-xs transition-all shadow-md cursor-pointer flex items-center space-x-1.5 space-x-reverse disabled:opacity-50"
              title="مشاركة أو حفظ المستند كملف مستقل (متوافق مع أندرويد وويندوز)"
            >
              {isPrinting ? <Loader2 className="w-4 h-4 animate-spin" /> : <Share2 className="w-4 h-4" />}
              <span>مشاركة / حفظ PDF 📄</span>
            </button>

            <button
              type="button"
              onClick={handlePrint}
              disabled={isPrinting}
              className="bg-emerald-600 hover:bg-emerald-500 active:scale-95 text-white font-extrabold px-4 sm:px-5 py-2 rounded-xl text-xs transition-all shadow-md cursor-pointer flex items-center space-x-1.5 space-x-reverse disabled:opacity-50"
            >
              {isPrinting ? <Loader2 className="w-4 h-4 animate-spin" /> : <Printer className="w-4 h-4" />}
              <span>طباعة المستند 🖨️</span>
            </button>
          </div>
        </div>

      </div>

    </div>,
    document.body
  );
};

