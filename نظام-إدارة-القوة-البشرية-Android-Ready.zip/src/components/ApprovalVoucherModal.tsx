import React, { useRef } from 'react';
import { createPortal } from 'react-dom';
import { QRCodeSVG } from 'qrcode.react';
import { PersonnelRecord } from '../types';
import {
  Printer,
  ShieldCheck,
  X,
  User,
  FileText,
  Crosshair,
  QrCode,
  ExternalLink,
  Share2,
  CheckCircle2
} from 'lucide-react';
import { getCurrentHeaderInfo } from '../lib/headerUtils';
import { PersonnelAvatar } from './PersonnelAvatar';
import {
  preparePrintableDocument,
  executeUnifiedPrint,
  shareOrSavePrintableDocument
} from '../lib/unifiedPrintService';

export interface WeaponCustodyDetail {
  weaponType: string;
  weaponSerial: string;
  magazinesCount: number;
  ammoCount: number;
  notes?: string;
  isCustom?: boolean;
}

export interface VoucherData {
  id: string;
  type: 'leave' | 'permission' | 'medical' | 'training' | 'weapon_leave' | string;
  title: string;
  personnel: PersonnelRecord;
  startDate?: string;
  endDate?: string;
  duration?: string | number;
  details?: string;
  approvedBy?: string;
  department?: string;
  timestamp: string;
  referenceNumber: string;
  additionalInfo?: { label: string; value: string }[];
  weaponDetails?: {
    primaryWeapon?: WeaponCustodyDetail;
    additionalWeapons?: WeaponCustodyDetail[];
    custodyNotes?: string;
    totalAmmo?: number;
    totalMagazines?: number;
  };
}

interface ApprovalVoucherModalProps {
  isOpen: boolean;
  onClose: () => void;
  voucherData: VoucherData | null;
}

export const ApprovalVoucherModal: React.FC<ApprovalVoucherModalProps> = ({
  isOpen,
  onClose,
  voucherData
}) => {
  const printRef = useRef<HTMLDivElement>(null);
  const [isDocumentReady, setIsDocumentReady] = React.useState(false);

  // Prepare document resources (fonts, images, barcodes) for flawless print on Web, Android & Windows
  React.useEffect(() => {
    if (!isOpen || !voucherData) return;
    setIsDocumentReady(false);
    let isCancelled = false;

    preparePrintableDocument(printRef.current).then(() => {
      if (!isCancelled) {
        setIsDocumentReady(true);
      }
    });

    return () => {
      isCancelled = true;
    };
  }, [isOpen, voucherData]);

  // Keyboard shortcut support (Escape to close, Ctrl+P to print) & body print isolation
  React.useEffect(() => {
    if (!isOpen) return;

    document.body.classList.add('is-printing-modal');
    document.body.setAttribute('data-printing-modal', 'true');

    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        onClose();
      } else if ((e.ctrlKey || e.metaKey) && e.key === 'p') {
        e.preventDefault();
        handlePrint();
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => {
      document.body.classList.remove('is-printing-modal');
      document.body.removeAttribute('data-printing-modal');
      window.removeEventListener('keydown', handleKeyDown);
    };
  }, [isOpen, onClose]);

  if (!isOpen || !voucherData) return null;

  const { personnel } = voucherData;

  const handlePrint = async () => {
    await executeUnifiedPrint(printRef.current, {
      documentTitle: `${voucherData.title} - ${voucherData.referenceNumber}`,
      orientation: 'portrait'
    });
  };

  const handleSharePdf = async () => {
    await shareOrSavePrintableDocument(printRef.current, {
      title: voucherData.title,
      filename: `سند_${voucherData.referenceNumber}_${voucherData.personnel.fullName.replace(/\s+/g, '_')}.html`,
      orientation: 'portrait'
    });
  };

  // Generate simple deterministic lines for SVG barcode rendering
  const generateBarcodeBars = (code: string) => {
    const bars = [];
    let x = 10;
    for (let i = 0; i < code.length; i++) {
      const charCode = code.charCodeAt(i);
      const width1 = (charCode % 3) + 1;
      const width2 = ((charCode * 2) % 3) + 1;
      bars.push(<rect key={`b1-${i}`} x={x} y="4" width={width1} height="32" fill="#0f172a" />);
      x += width1 + 2;
      bars.push(<rect key={`b2-${i}`} x={x} y="4" width={width2} height="32" fill="#0f172a" />);
      x += width2 + 3;
    }
    return { bars, totalWidth: x + 10 };
  };

  const barcodeData = generateBarcodeBars(voucherData.referenceNumber);

  // Construct structured text payload for QR Code scan
  const weaponSummary = voucherData.weaponDetails
    ? `\nسلاح أساسي: ${voucherData.weaponDetails.primaryWeapon?.weaponType || '---'} (S/N: ${voucherData.weaponDetails.primaryWeapon?.weaponSerial || 'بدون'})` +
      (voucherData.weaponDetails.additionalWeapons && voucherData.weaponDetails.additionalWeapons.length > 0
        ? `\nأسلحة إضافية: ${voucherData.weaponDetails.additionalWeapons.map(w => `${w.weaponType} (${w.weaponSerial || 'بدون'})`).join(', ')}`
        : '') +
      `\nإجمالي الذخيرة: ${voucherData.weaponDetails.totalAmmo || 0} طلقة | ${voucherData.weaponDetails.totalMagazines || 0} مخازن`
    : 'بدون اصطحاب سلاح';

  const qrPayloadText = `
سند وتصريح خروج عسكري معتمد
-----------------------------------
الرقم المرجعي: ${voucherData.referenceNumber}
نوع السند: ${voucherData.title}
الاسم: ${personnel.rank} / ${personnel.fullName}
الرقم العسكري: ${personnel.militaryId}
الهوية / السجل المدني: ${personnel.nationalId || '---'}
الوحدة: ${personnel.unit} ${personnel.battalion ? `- ${personnel.battalion}` : ''}
المسمى الوظيفي: ${personnel.jobTitle || 'عسكري'}
تاريخ المغادرة: ${voucherData.startDate || '---'}
تاريخ العودة: ${voucherData.endDate || '---'}
المدة المقررة: ${voucherData.duration || '---'}
الجهة المصادقة: ${voucherData.department || 'فرع الإدارة والعمليات'}
ضابط الاعتماد: ${voucherData.approvedBy || 'النظام العسكري الموحد'}
${weaponSummary}
قيد السند: ${voucherData.timestamp}
حالة التوثيق: سند معتمد رسمياً ومسجلة بالنظام الإلكتروني
`.trim();

  const modalContent = (
    <div className="fixed inset-0 z-[99999] bg-slate-950/90 backdrop-blur-md flex items-center justify-center p-2 sm:p-4 overflow-hidden printable-modal-overlay print:p-0 print:bg-white print:static print:block">
      <div className="relative bg-white border-2 border-slate-700 rounded-3xl max-w-4xl w-full max-h-[96vh] h-full flex flex-col shadow-2xl overflow-hidden printable-modal-card print:max-h-none print:h-auto print:border-none print:shadow-none print:rounded-none print:max-w-none print:w-full print:p-0 print:bg-white print:text-black">
        
        {/* Top Control Bar (Always visible at top of modal, Hidden during Print) */}
        <div className="shrink-0 z-30 bg-slate-950 text-white px-4 sm:px-6 py-3.5 flex flex-wrap items-center justify-between gap-3 border-b-2 border-amber-500/80 shadow-xl print:hidden no-print">
          <div className="flex items-center space-x-3 space-x-reverse">
            <div className="p-2.5 bg-rose-700 rounded-2xl text-white shadow-md animate-pulse">
              <Crosshair className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center space-x-2 space-x-reverse">
                <h2 className="text-sm sm:text-base font-black font-['Tajawal'] text-white">سند مصادقة وتصريح مرور عسكري معتمد</h2>
                <span className="bg-emerald-500/20 text-emerald-300 border border-emerald-500/50 text-[11px] font-bold px-2.5 py-0.5 rounded-md font-mono">
                  {voucherData.referenceNumber}
                </span>
              </div>
              <p className="text-[11px] text-slate-300">جاهز للطباعة الورقية الفورية أو الحفظ بصيغة A4 مع الباركود والختم</p>
            </div>
          </div>

          <div className="flex items-center space-x-2.5 space-x-reverse">
            {/* Document readiness indicator */}
            <div className={`hidden sm:flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-bold border transition-colors ${
              isDocumentReady
                ? 'bg-emerald-950/60 text-emerald-300 border-emerald-500/40'
                : 'bg-amber-950/60 text-amber-300 border-amber-500/40 animate-pulse'
            }`}>
              <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
              <span>{isDocumentReady ? 'المستند جاهز للطباعة' : 'جاري تجهيز الخطوط...'}</span>
            </div>

            {/* PRIMARY INSTANT PRINT COMMAND BUTTON */}
            <button
              type="button"
              onClick={handlePrint}
              className="bg-emerald-600 hover:bg-emerald-500 active:scale-95 text-white font-black px-4 sm:px-5 py-2.5 rounded-xl flex items-center space-x-2 space-x-reverse text-xs sm:text-sm transition-all shadow-xl ring-2 ring-emerald-400 cursor-pointer"
              title="أمر الطباعة الفورية المباشرة (Ctrl+P)"
            >
              <Printer className="w-4 h-4 sm:w-5 sm:h-5 text-white animate-pulse" />
              <span>أمر الطباعة الفورية 🖨️</span>
            </button>

            {/* UNIFIED SHARE / SAVE PDF BUTTON */}
            <button
              type="button"
              onClick={handleSharePdf}
              className="bg-sky-600 hover:bg-sky-500 active:scale-95 text-white font-bold px-3.5 py-2.5 rounded-xl flex items-center space-x-1.5 space-x-reverse text-xs transition-all shadow-md cursor-pointer"
              title="مشاركة أو حفظ السند بصيغة PDF / تقرير معتمد لكافة الأجهزة"
            >
              <Share2 className="w-4 h-4" />
              <span className="hidden sm:inline">مشاركة / حفظ PDF 📄</span>
              <span className="sm:hidden">حفظ PDF</span>
            </button>

            {/* CLOSE BUTTON */}
            <button
              type="button"
              onClick={onClose}
              className="p-2.5 text-slate-300 hover:text-white hover:bg-slate-800 rounded-xl transition-colors cursor-pointer border border-slate-700"
              title="إغلاق المعاينة"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* In-Document Quick Print Action Banner */}
        <div className="no-print shrink-0 bg-gradient-to-r from-amber-500/15 via-emerald-500/15 to-sky-500/15 border-b border-slate-200 px-5 py-2 flex items-center justify-between text-xs text-slate-800 font-bold">
          <div className="flex items-center space-x-2 space-x-reverse">
            <span className="flex h-2.5 w-2.5 relative">
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
              <span className="relative inline-flex rounded-full h-2.5 w-2.5 bg-emerald-500"></span>
            </span>
            <span>نموذج A4 رسمي معتمد إلكترونياً – متوافق مع كافة أنظمة ويندوز وأندرويد</span>
          </div>
          <div className="flex items-center gap-3">
            <button
              type="button"
              onClick={handleSharePdf}
              className="text-sky-800 hover:text-sky-950 font-black flex items-center space-x-1 space-x-reverse underline underline-offset-4 cursor-pointer text-[11px]"
            >
              <Share2 className="w-3.5 h-3.5" />
              <span>مشاركة / حفظ</span>
            </button>
            <button
              type="button"
              onClick={handlePrint}
              className="text-emerald-800 hover:text-emerald-950 font-black flex items-center space-x-1 space-x-reverse underline underline-offset-4 cursor-pointer text-[11px]"
            >
              <Printer className="w-3.5 h-3.5" />
              <span>طباعة سريعة (Ctrl+P)</span>
            </button>
          </div>
        </div>

        {/* Scrollable Container for Document Content */}
        <div className="flex-1 overflow-y-auto p-3 sm:p-5 bg-slate-100/90 print:overflow-visible print:p-0 print:bg-white">
          {/* Printable Document Container with Compact A4 Layout */}
          <div
            ref={printRef}
            id="approval-voucher-printable"
            data-printable-content="true"
            className="bg-white border-2 border-slate-900 rounded-xl p-4 sm:p-6 space-y-3 text-right font-['Tajawal'] dir-rtl shadow-md print:shadow-none print:p-3 print:text-black print:border-2 print:border-slate-900 print:bg-white print:rounded-none"
          >
          
          {/* Official Military Header */}
          {(() => {
            const headerInfo = getCurrentHeaderInfo(personnel.unit);
            return (
              <div className="border-b-2 border-slate-900 pb-2.5 flex items-center justify-between gap-2 text-slate-900 print:border-slate-900">
                {/* Right: Military Hierarchy */}
                <div className="text-right space-y-0.5 shrink-0">
                  <p className="text-[11px] font-black text-slate-900">{headerInfo.forceName}</p>
                  <p className="text-[10px] font-black text-slate-800">{headerInfo.divisionName}</p>
                  <p className="text-xs font-black text-rose-950 print:text-black">{headerInfo.unitName}</p>
                </div>

                {/* Center: Official Seal / Emblem */}
                <div className="text-center space-y-0.5 px-2">
                  <div className="w-12 h-12 mx-auto bg-slate-900 text-amber-400 rounded-xl flex items-center justify-center font-black border-2 border-amber-500 shadow-xs print:bg-slate-900 print:text-amber-400 print:border-slate-800 shrink-0">
                    <ShieldCheck className="w-8 h-8 text-amber-400" />
                  </div>
                  <span className="text-[9px] font-black text-slate-900 block tracking-tight">
                    سند ومصادقة إلكترونية رسمية
                  </span>
                </div>

                {/* Left: Metadata & Reference Number */}
                <div className="text-left space-y-0.5 font-mono text-[10px] dir-ltr shrink-0">
                  <p className="font-bold text-slate-900">REF: <span className="text-rose-900 font-black print:text-black">{voucherData.referenceNumber}</span></p>
                  <p className="font-bold text-slate-800">DATE: {voucherData.timestamp.split(' ')[0]}</p>
                  <p className="text-[10px] text-slate-600">TIME: {voucherData.timestamp.split(' ')[1] || '12:00'}</p>
                  <div className="pt-0.5">
                    <span className="inline-block bg-rose-100 text-rose-950 border border-rose-300 font-black px-1.5 py-0.5 rounded text-[9px] print:bg-slate-100 print:text-black print:border-black">
                      {voucherData.weaponDetails ? 'تصريح مرور وسلاح معتمد' : 'معتمد رسمي برقم موحد'}
                    </span>
                  </div>
                </div>
              </div>
            );
          })()}

          {/* Document Title Banner */}
          <div className="bg-slate-900 text-white p-2.5 rounded-xl flex items-center justify-between gap-2 print:bg-slate-100 print:text-black print:border print:border-slate-900">
            <div className="flex items-center space-x-2 space-x-reverse">
              <div className="w-8 h-8 bg-rose-700 text-white rounded-lg flex items-center justify-center font-bold shrink-0 print:bg-slate-800">
                <Crosshair className="w-5 h-5 text-white" />
              </div>
              <div>
                <span className="text-[9px] text-amber-300 font-black block print:text-slate-800">
                  وثيقة عسكرية رسمية - تصريح مرور واصطحاب العهدة
                </span>
                <h1 className="text-sm font-black text-white print:text-black">{voucherData.title}</h1>
              </div>
            </div>
            <div className="text-left font-mono text-[11px] bg-slate-800 px-3 py-1 rounded-lg border border-slate-700 print:bg-white print:border-slate-800 shrink-0">
              <span className="text-slate-400 block text-[8px] print:text-slate-700">رقم السند/التصريح:</span>
              <span className="text-amber-300 font-black text-xs print:text-black">{voucherData.id}</span>
            </div>
          </div>

          {/* SECTION 1: Target Personnel Military Card */}
          <div className="bg-slate-50 border border-slate-300 rounded-xl p-2.5 space-y-2 print:bg-white print:border-slate-800">
            <h3 className="text-[11px] font-black text-slate-900 border-b border-slate-300 pb-1 flex items-center space-x-1.5 space-x-reverse print:border-slate-800">
              <User className="w-3.5 h-3.5 text-rose-800" />
              <span>أولاً: بطاقة بيانات الفرد العسكرية والحامل للعهدة والتصريح</span>
            </h3>

            <div className="flex items-center gap-2.5">
              <PersonnelAvatar
                photoUrl={personnel.photoUrl}
                fullName={personnel.fullName}
                rank={personnel.rank}
                militaryId={personnel.militaryId}
                size="lg"
                shape="rounded"
                className="shrink-0 print:border-slate-800"
              />

              <div className="grid grid-cols-2 sm:grid-cols-3 gap-1.5 w-full text-[11px]">
                <div className="bg-white p-1.5 rounded-lg border border-slate-300 print:border-slate-800">
                  <span className="text-[9px] text-slate-500 font-bold block print:text-slate-700">الاسم الرباعي الكامل:</span>
                  <span className="font-black text-slate-900">{personnel.fullName}</span>
                </div>

                <div className="bg-white p-1.5 rounded-lg border border-slate-300 print:border-slate-800">
                  <span className="text-[9px] text-slate-500 font-bold block print:text-slate-700">الرتبة العسكرية:</span>
                  <span className="font-black text-rose-950 print:text-black">{personnel.rank}</span>
                </div>

                <div className="bg-white p-1.5 rounded-lg border border-slate-300 print:border-slate-800">
                  <span className="text-[9px] text-slate-500 font-bold block print:text-slate-700">الرقم العسكري:</span>
                  <span className="font-mono font-black text-slate-900">{personnel.militaryId}</span>
                </div>

                <div className="bg-white p-1.5 rounded-lg border border-slate-300 print:border-slate-800">
                  <span className="text-[9px] text-slate-500 font-bold block print:text-slate-700">الوحدة والكتيبة:</span>
                  <span className="font-bold text-slate-900">{personnel.unit} {personnel.battalion ? `- ${personnel.battalion}` : ''}</span>
                </div>

                <div className="bg-white p-1.5 rounded-lg border border-slate-300 print:border-slate-800">
                  <span className="text-[9px] text-slate-500 font-bold block print:text-slate-700">المسمى الوظيفي:</span>
                  <span className="font-bold text-slate-900">{personnel.jobTitle || 'عسكري'}</span>
                </div>

                <div className="bg-white p-1.5 rounded-lg border border-slate-300 print:border-slate-800">
                  <span className="text-[9px] text-slate-500 font-bold block print:text-slate-700">السجل المدني / الهوية:</span>
                  <span className="font-mono font-bold text-slate-900">{personnel.nationalId || '---'}</span>
                </div>
              </div>
            </div>
          </div>

          {/* SECTION 2: Action & Movement Details */}
          <div className="bg-white border border-slate-300 rounded-xl p-2.5 space-y-2 print:border-slate-800">
            <h3 className="text-[11px] font-black text-slate-900 border-b border-slate-300 pb-1 flex items-center space-x-1.5 space-x-reverse print:border-slate-800">
              <FileText className="w-3.5 h-3.5 text-emerald-800" />
              <span>ثانياً: بيانات وتفاصيل الحركة وخط السير والمصادقة الإدارية</span>
            </h3>

            <div className="grid grid-cols-2 sm:grid-cols-4 gap-1.5 text-[11px]">
              <div className="bg-slate-50 p-1.5 rounded-lg border border-slate-300 print:bg-white print:border-slate-800">
                <span className="text-[9px] text-slate-500 font-bold block print:text-slate-700">نوع الإجراء والتصنيف:</span>
                <span className="font-black text-slate-900">{voucherData.title}</span>
              </div>

              {voucherData.startDate && (
                <div className="bg-slate-50 p-1.5 rounded-lg border border-slate-300 print:bg-white print:border-slate-800">
                  <span className="text-[9px] text-slate-500 font-bold block print:text-slate-700">تاريخ المغادرة / البدء:</span>
                  <span className="font-mono font-bold text-slate-900">{voucherData.startDate}</span>
                </div>
              )}

              {voucherData.endDate && (
                <div className="bg-slate-50 p-1.5 rounded-lg border border-slate-300 print:bg-white print:border-slate-800">
                  <span className="text-[9px] text-slate-500 font-bold block print:text-slate-700">تاريخ العودة / الانتهاء:</span>
                  <span className="font-mono font-bold text-slate-900">{voucherData.endDate}</span>
                </div>
              )}

              {voucherData.duration && (
                <div className="bg-slate-50 p-1.5 rounded-lg border border-slate-300 print:bg-white print:border-slate-800">
                  <span className="text-[9px] text-slate-500 font-bold block print:text-slate-700">المدة المقررة:</span>
                  <span className="font-bold text-slate-900">{voucherData.duration}</span>
                </div>
              )}
            </div>

            {voucherData.details && (
              <div className="bg-amber-50/80 border border-amber-300 p-2 rounded-lg text-[10px] text-amber-950 print:bg-white print:border-slate-800 print:text-black">
                <span className="font-bold block mb-0.5">خط السير والوجهة الميدانية / البيان الرسمي:</span>
                <p className="font-medium text-slate-900 leading-tight print:text-black">{voucherData.details}</p>
              </div>
            )}
          </div>

          {/* SECTION 3: Detailed Weapon & Ammunition Custody Schedule */}
          {voucherData.weaponDetails && (
            <div className="bg-rose-50/80 border border-rose-300 rounded-xl p-2.5 space-y-2 print:bg-white print:border-slate-800">
              <div className="flex items-center justify-between border-b border-rose-300 pb-1 print:border-slate-800">
                <h3 className="text-[11px] font-black text-rose-950 flex items-center space-x-1.5 space-x-reverse print:text-black">
                  <Crosshair className="w-3.5 h-3.5 text-rose-800 print:text-black" />
                  <span>ثالثاً: جدول حصر عهدة الأسلحة والذخائر والعتاد المصرح باصطحابه</span>
                </h3>
                <span className="text-[9px] font-black bg-rose-200 text-rose-950 px-2 py-0.5 rounded-full border border-rose-400 print:bg-slate-100 print:text-black print:border-black">
                  تصريح مرور سلاح معتمد
                </span>
              </div>

              <div className="overflow-x-auto">
                <table className="w-full text-right text-[10px] border-collapse border border-slate-800 print:border-black">
                  <thead>
                    <tr className="bg-slate-900 text-white font-black print:bg-slate-200 print:text-black print:border-b print:border-black">
                      <th className="p-1 border border-slate-700 print:border-black text-center w-6">#</th>
                      <th className="p-1 border border-slate-700 print:border-black">نوع السلاح / العتاد العسكري</th>
                      <th className="p-1 border border-slate-700 print:border-black text-center">الرقم التسلسلي (S/N)</th>
                      <th className="p-1 border border-slate-700 print:border-black text-center">عدد الخزائن</th>
                      <th className="p-1 border border-slate-700 print:border-black text-center">كمية الذخيرة (طلقة)</th>
                      <th className="p-1 border border-slate-700 print:border-black">حالة العهدة</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-300 text-slate-900 font-medium print:divide-slate-800">
                    {voucherData.weaponDetails.primaryWeapon && (
                      <tr className="bg-white">
                        <td className="p-1 border border-slate-300 print:border-black font-bold text-center">1</td>
                        <td className="p-1 border border-slate-300 print:border-black font-black text-rose-950 print:text-black">
                          {voucherData.weaponDetails.primaryWeapon.weaponType}
                        </td>
                        <td className="p-1 border border-slate-300 print:border-black font-mono font-bold text-center text-rose-900 print:text-black">
                          {voucherData.weaponDetails.primaryWeapon.weaponSerial || 'بدون رقم'}
                        </td>
                        <td className="p-1 border border-slate-300 print:border-black text-center font-bold">
                          {voucherData.weaponDetails.primaryWeapon.magazinesCount}
                        </td>
                        <td className="p-1 border border-slate-300 print:border-black text-center font-bold">
                          {voucherData.weaponDetails.primaryWeapon.ammoCount}
                        </td>
                        <td className="p-1 border border-slate-300 print:border-black text-slate-800 text-[9px]">
                          {voucherData.weaponDetails.primaryWeapon.notes || 'سلاح شخصي أساسي'}
                        </td>
                      </tr>
                    )}

                    {voucherData.weaponDetails.additionalWeapons?.map((w, idx) => (
                      <tr key={idx} className="bg-white">
                        <td className="p-1 border border-slate-300 print:border-black font-bold text-center">
                          {(voucherData.weaponDetails?.primaryWeapon ? 2 : 1) + idx}
                        </td>
                        <td className="p-1 border border-slate-300 print:border-black font-bold text-slate-900">
                          {w.weaponType}
                        </td>
                        <td className="p-1 border border-slate-300 print:border-black font-mono font-bold text-center text-rose-900 print:text-black">
                          {w.weaponSerial || 'غير مسجل'}
                        </td>
                        <td className="p-1 border border-slate-300 print:border-black text-center font-bold">
                          {w.magazinesCount}
                        </td>
                        <td className="p-1 border border-slate-300 print:border-black text-center font-bold">
                          {w.ammoCount}
                        </td>
                        <td className="p-1 border border-slate-300 print:border-black text-slate-800 text-[9px]">
                          {w.notes || 'سلاح إضافي / عتاد مخصص'}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                  <tfoot>
                    <tr className="bg-slate-100 text-slate-950 font-black border-t border-slate-900 print:bg-slate-200 print:border-black">
                      <td colSpan={3} className="p-1 border border-slate-300 print:border-black text-left pl-2 font-bold">
                        الإجمالي الكلي:
                      </td>
                      <td className="p-1 border border-slate-300 print:border-black text-center font-black">
                        {voucherData.weaponDetails.totalMagazines ?? 0} مخازن
                      </td>
                      <td className="p-1 border border-slate-300 print:border-black text-center font-black">
                        {voucherData.weaponDetails.totalAmmo ?? 0} طلقة
                      </td>
                      <td className="p-1 border border-slate-300 print:border-black text-[9px] font-bold text-slate-800">
                        {1 + (voucherData.weaponDetails.additionalWeapons?.length || 0)} قطع سلاح معتمدة
                      </td>
                    </tr>
                  </tfoot>
                </table>
              </div>

              <div className="p-1.5 bg-rose-100/90 rounded-lg border border-rose-300 text-[9px] text-rose-950 leading-tight font-bold print:bg-slate-100 print:text-black print:border-slate-800">
                🚨 <strong>تنبيه أمني مشدد:</strong> يُمنع تسليم السلاح أو إعارته لأي جهة. يلزم إبراز التصريح عند نقاط السيطرة والتفتيش.
              </div>
            </div>
          )}

          {/* SECTION 4: Digital Verification, Scannable QR Code & Barcode */}
          <div className="bg-slate-900 text-white p-3 rounded-xl space-y-2 print:bg-white print:text-black print:border print:border-slate-900">
            <div className="flex flex-row items-center justify-between gap-3">
              
              {/* Process Metadata */}
              <div className="space-y-0.5 text-[10px] text-right w-1/2">
                <div className="flex items-center space-x-1.5 space-x-reverse text-amber-300 font-bold print:text-black">
                  <ShieldCheck className="w-3.5 h-3.5" />
                  <span>الاعتماد الإلكتروني والتشفير العسكري</span>
                </div>
                <div className="text-[9.5px] text-slate-300 space-y-0.5 font-mono print:text-black">
                  <p>تاريخ والقيد: <strong className="text-white print:text-black">{voucherData.timestamp}</strong></p>
                  <p>الفرع المصادق: <strong className="text-white print:text-black">{voucherData.department || 'فرع الإدارة والعمليات'}</strong></p>
                  <p>ضابط الاعتماد: <strong className="text-white print:text-black">{voucherData.approvedBy || 'النظام العسكري الموحد'}</strong></p>
                  <p>الرمز المرجعي: <strong className="text-amber-300 print:text-black">{voucherData.referenceNumber}</strong></p>
                </div>
              </div>

              {/* Scannable Real QR Code & SVG Barcode */}
              <div className="flex items-center space-x-3 space-x-reverse bg-white p-2 rounded-lg border border-slate-700 text-slate-900 shrink-0 print:border-slate-800">
                {/* SVG Barcode */}
                <div className="text-center">
                  <svg width={barcodeData.totalWidth} height="32" className="mx-auto">
                    {barcodeData.bars}
                  </svg>
                  <span className="font-mono text-[8px] font-black tracking-widest text-slate-900 block mt-0.5">
                    *{voucherData.referenceNumber}*
                  </span>
                </div>

                {/* Real Scannable QRCodeSVG */}
                <div className="border-r border-slate-300 pr-2.5 text-center flex flex-col items-center">
                  <div className="p-1 bg-white rounded border border-slate-300">
                    <QRCodeSVG
                      value={qrPayloadText}
                      size={64}
                      level="M"
                      includeMargin={false}
                    />
                  </div>
                  <span className="text-[7.5px] font-black text-slate-900 block mt-0.5">رمز التحقق الميداني (QR)</span>
                </div>
              </div>

            </div>
          </div>

          {/* SECTION 5: Official 4-Column Signatures & Official Stamp (guaranteed no break) */}
          <div className="signature-block break-inside-avoid print:break-inside-avoid page-break-inside-avoid pt-1.5 border-t-2 border-slate-900 space-y-2">
            <h4 className="text-[10px] font-black text-slate-900 text-center uppercase tracking-wider">
              المصادقة والتواقيع الرسمية للوحدة العسكرية والاعتماد النهائي
            </h4>

            <div className="grid grid-cols-4 gap-2 text-center text-[10px]">
              {/* Box 1: Personnel Holder Signature */}
              <div className="bg-slate-50 border border-slate-300 p-2 rounded-lg space-y-2 print:bg-white print:border-slate-800">
                <div>
                  <p className="font-black text-slate-900 text-[10px]">المستلم / الفرد المصرح له</p>
                  <p className="text-[8px] text-slate-500 font-bold block">(إقرار باستلام السلاح)</p>
                </div>
                <div className="text-[9px] font-bold text-slate-800 truncate">
                  {personnel.rank} / {personnel.fullName}
                </div>
                <div className="border-b border-dashed border-slate-400 w-full mx-auto"></div>
                <p className="text-[8px] font-bold text-slate-500">التوقيع / البصمة: ..........</p>
              </div>

              {/* Box 2: Armament Officer Signature */}
              <div className="bg-slate-50 border border-slate-300 p-2 rounded-lg space-y-2 print:bg-white print:border-slate-800">
                <div>
                  <p className="font-black text-slate-900 text-[10px]">ركن التسليح والذخائر</p>
                  <p className="text-[8px] text-slate-500 font-bold block">(تدقيق تسليم السلاح)</p>
                </div>
                <div className="text-[9px] font-bold text-slate-800">
                  مسؤول التسليح والذخيرة
                </div>
                <div className="border-b border-dashed border-slate-400 w-full mx-auto"></div>
                <p className="text-[8px] font-bold text-slate-500">التوقيع: ..........</p>
              </div>

              {/* Box 3: Approving Officer Signature */}
              <div className="bg-slate-50 border border-slate-300 p-2 rounded-lg space-y-2 print:bg-white print:border-slate-800">
                <div>
                  <p className="font-black text-slate-900 text-[10px]">ضابط الإدارة والعمليات</p>
                  <p className="text-[8px] text-slate-500 font-bold block">(مصادقة الخروج والمسار)</p>
                </div>
                <div className="text-[9px] font-bold text-slate-800 truncate">
                  {voucherData.approvedBy || 'ضابط العمليات الميدانية'}
                </div>
                <div className="border-b border-dashed border-slate-400 w-full mx-auto"></div>
                <p className="text-[8px] font-bold text-slate-500">التوقيع: ..........</p>
              </div>

              {/* Box 4: Brigade Commander & Official Stamp */}
              <div className="bg-slate-50 border-2 border-slate-800 p-2 rounded-lg space-y-1 text-center print:bg-white print:border-slate-900">
                <p className="font-black text-slate-900 text-[10px]">اعتماد قائد اللواء / القيادة</p>
                <div className="w-12 h-12 mx-auto rounded-full border border-dashed border-rose-900 flex items-center justify-center text-[7px] font-black text-rose-950 rotate-6 print:border-black print:text-black">
                  [ الختم العسكري ]
                </div>
                <p className="text-[8px] font-black text-slate-900">التوقيع والختم: ..........</p>
              </div>
            </div>
          </div>

          <div className="text-center text-[8.5px] text-slate-500 pt-0.5 border-t border-slate-300 print:text-black">
            هذا السند وثيقة عسكرية رسمية صادرة إلكترونياً وتعتمد لدى نقاط السيطرة والتفتيش بدون كشط أو تعديل يدوي.
          </div>

        </div>
        </div>

        {/* Pinned Bottom Action Bar (Always visible at bottom of modal) */}
        <div className="shrink-0 z-30 bg-slate-950 text-white px-4 sm:px-6 py-3 border-t-2 border-slate-800 shadow-2xl flex flex-wrap items-center justify-between gap-3 backdrop-blur-md print:hidden no-print">
          <div className="flex items-center space-x-2 space-x-reverse text-xs">
            <span className="font-bold text-slate-300">السند:</span>
            <span className="text-amber-400 font-extrabold truncate max-w-[200px] sm:max-w-xs">{voucherData.title}</span>
            <span className="hidden sm:inline text-slate-500">•</span>
            <span className="hidden sm:inline font-mono text-[11px] text-emerald-400 font-bold">{voucherData.referenceNumber}</span>
          </div>

          <div className="flex items-center space-x-2.5 space-x-reverse">
            <button
              type="button"
              onClick={handlePrint}
              className="bg-emerald-600 hover:bg-emerald-500 active:scale-95 text-white font-black px-6 py-2.5 rounded-xl flex items-center space-x-2 space-x-reverse text-xs sm:text-sm transition-all shadow-xl ring-2 ring-emerald-400 cursor-pointer"
            >
              <Printer className="w-4 h-4 sm:w-5 sm:h-5 text-white animate-pulse" />
              <span>🖨️ أمر الطباعة الفورية للسند (A4)</span>
            </button>

            <button
              type="button"
              onClick={handleSharePdf}
              className="bg-sky-600 hover:bg-sky-500 active:scale-95 text-white font-bold px-4 py-2.5 rounded-xl flex items-center space-x-1.5 space-x-reverse text-xs transition-all shadow-md cursor-pointer"
              title="مشاركة أو حفظ السند بصيغة PDF / تقرير معتمد"
            >
              <Share2 className="w-4 h-4" />
              <span>مشاركة / حفظ PDF 📄</span>
            </button>

            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2.5 bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white rounded-xl text-xs font-bold transition-colors cursor-pointer border border-slate-700"
            >
              إغلاق
            </button>
          </div>
        </div>

        {/* Floating Instant Print Quick-Action Button for instant access */}
        <div className="fixed bottom-16 left-6 z-[100000] no-print print:hidden">
          <button
            type="button"
            onClick={handlePrint}
            className="bg-emerald-600 hover:bg-emerald-500 text-white font-black px-4 py-2.5 rounded-2xl shadow-2xl flex items-center space-x-2 space-x-reverse text-xs border-2 border-emerald-300 ring-4 ring-emerald-500/30 cursor-pointer hover:scale-105 active:scale-95 transition-all"
            title="طباعة فورية مباشرة"
          >
            <Printer className="w-4 h-4 text-white animate-bounce" />
            <span>طباعة فورية (Ctrl+P)</span>
          </button>
        </div>
      </div>
    </div>
  );

  return createPortal(modalContent, document.body);
};
