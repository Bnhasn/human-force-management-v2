import React, { useState, useMemo, useRef, useEffect } from 'react';
import { createPortal } from 'react-dom';
import { getCurrentHeaderInfo } from '../lib/headerUtils';
import {
  Printer,
  X,
  Shield,
  AlertTriangle,
  CheckCircle2,
  Package,
  Layers,
  Users,
  FileText,
  Clock,
  Flame,
  ArrowRight,
  Filter,
  Check,
  Scale,
  Crosshair,
  Building2,
  Calendar,
  RotateCcw,
  Plus,
  Trash2,
  UserCheck,
  ChevronDown,
  ChevronUp,
  Share2
} from 'lucide-react';
import {
  preparePrintableDocument,
  executeUnifiedPrint,
  shareOrSavePrintableDocument
} from '../lib/unifiedPrintService';
import { PersonnelRecord } from '../types';
import {
  ArmoryInventoryItem,
  ArmoryWeaponPiece,
  ArmoryIntakeRecord,
  ArmoryIssueOrder,
  WeaponTypeConfig,
  AmmoTypeConfig
} from '../data/armamentData';
import { TARGET_SPECIFIED_WEAPONS } from './ArmamentBranchWorkspace';

export interface SignatoryOfficer {
  id: string;
  title: string;
  name: string;
}

export const DEFAULT_ARMAMENT_SIGNATORIES: SignatoryOfficer[] = [
  { id: 'sig-1', title: 'رئيس فرع التسليح والعتاد', name: 'عقيد ركن / أحمد منصور الشمري' },
  { id: 'sig-2', title: 'ضابط مستودعات الذخائر المركزية', name: 'مقدم / سالم عبد الله القحطاني' },
  { id: 'sig-3', title: 'قائد التشكيل - يعتمد', name: 'لواء ركن / قائد التشكيل العسكري' }
];

export type ArmamentReportType =
  | 'stock'
  | 'ammo_issues'
  | 'balance_per_item'
  | 'low_stock'
  | 'movement'
  | 'personnel';

interface ArmamentReportPrintModalProps {
  isOpen: boolean;
  onClose: () => void;
  initialReportType?: ArmamentReportType;
  currentAccountName?: string;
  inventory: ArmoryInventoryItem[];
  weapons: ArmoryWeaponPiece[];
  intakes: ArmoryIntakeRecord[];
  issues: ArmoryIssueOrder[];
  personnel: PersonnelRecord[];
  weaponTypes: WeaponTypeConfig[];
  ammoTypes: AmmoTypeConfig[];
}

export const ArmamentReportPrintModal: React.FC<ArmamentReportPrintModalProps> = ({
  isOpen,
  onClose,
  initialReportType = 'ammo_issues',
  currentAccountName = 'قيادة الفرقة الثالثة',
  inventory,
  weapons,
  intakes,
  issues,
  personnel,
  weaponTypes,
  ammoTypes
}) => {
  const [activeReportType, setActiveReportType] = useState<ArmamentReportType>(initialReportType);

  // Unit, Battalion and Item Filtering
  const [selectedUnit, setSelectedUnit] = useState<string>('الكل');
  const [selectedBattalion, setSelectedBattalion] = useState<string>('الكل');
  const [selectedItemName, setSelectedItemName] = useState<string>('الكل');
  const [selectedAmmoType, setSelectedAmmoType] = useState<string>('الكل');
  const [showArmedOnly, setShowArmedOnly] = useState<boolean>(true);

  // Dynamic & Persistent Officer Signatures State
  const [signatories, setSignatories] = useState<SignatoryOfficer[]>(() => {
    try {
      const saved = localStorage.getItem('military_armament_report_signatories');
      if (saved) {
        const parsed = JSON.parse(saved);
        if (Array.isArray(parsed) && parsed.length > 0) return parsed;
      }
    } catch (e) {}
    return DEFAULT_ARMAMENT_SIGNATORIES;
  });

  const [showSignatoryManager, setShowSignatoryManager] = useState<boolean>(true);
  const [saveSuccessNotice, setSaveSuccessNotice] = useState<string | null>(null);

  const handleAddSignatory = () => {
    const newOfficer: SignatoryOfficer = {
      id: `sig-${Date.now()}`,
      title: 'صفة / منصب الضابط',
      name: ''
    };
    setSignatories((prev) => [...prev, newOfficer]);
  };

  const handleRemoveSignatory = (id: string) => {
    if (signatories.length <= 1) return;
    setSignatories((prev) => prev.filter((s) => s.id !== id));
  };

  const handleUpdateSignatory = (id: string, field: 'name' | 'title', value: string) => {
    setSignatories((prev) =>
      prev.map((s) => (s.id === id ? { ...s, [field]: value } : s))
    );
  };

  const handleSaveSignatoriesDefault = () => {
    try {
      localStorage.setItem('military_armament_report_signatories', JSON.stringify(signatories));
      setSaveSuccessNotice('تم حفظ أسماء وصفات الضباط كنموذج ثابت للتقارير بنجاح! ✓');
      setTimeout(() => setSaveSuccessNotice(null), 3500);
    } catch (e) {}
  };

  const handleResetSignatories = () => {
    setSignatories(DEFAULT_ARMAMENT_SIGNATORIES);
    try {
      localStorage.removeItem('military_armament_report_signatories');
      setSaveSuccessNotice('تمت استعادة الأسماء والصفات الافتراضية');
      setTimeout(() => setSaveSuccessNotice(null), 3000);
    } catch (e) {}
  };

  // Compute distinct units
  const uniqueUnits = useMemo(() => {
    const set = new Set<string>();
    personnel.forEach((p) => {
      if (p.unit && p.unit.trim()) set.add(p.unit.trim());
    });
    issues.forEach((iss) => {
      if (iss.unit && iss.unit.trim()) set.add(iss.unit.trim());
    });
    weapons.forEach((w) => {
      if (w.currentHolderUnit && w.currentHolderUnit.trim()) set.add(w.currentHolderUnit.trim());
    });
    return Array.from(set).sort();
  }, [personnel, issues, weapons]);

  // Compute distinct battalions
  const uniqueBattalions = useMemo(() => {
    const set = new Set<string>();
    personnel.forEach((p) => {
      if (selectedUnit === 'الكل' || (p.unit && p.unit.trim() === selectedUnit)) {
        if (p.battalion && p.battalion.trim()) set.add(p.battalion.trim());
      }
    });
    return Array.from(set).sort();
  }, [personnel, selectedUnit]);

  // Compute distinct ammo types from issues, inventory and config
  const uniqueAmmoTypes = useMemo(() => {
    const set = new Set<string>();
    ammoTypes.forEach((a) => {
      if (a.name) set.add(a.name);
    });
    issues.forEach((iss) => {
      if (iss.ammoType) set.add(iss.ammoType);
    });
    inventory
      .filter((inv) => inv.itemType === 'ammo')
      .forEach((inv) => set.add(inv.name));
    return Array.from(set).sort();
  }, [ammoTypes, issues, inventory]);

  // Filter issues according to selectedUnit, selectedBattalion, and selectedAmmoType
  const filteredIssues = useMemo(() => {
    return issues.filter((iss) => {
      const person = personnel.find((p) => p.militaryId === iss.recipientMilitaryId);
      const issUnit = (iss.unit || person?.unit || '').trim();
      const issBattalion = (person?.battalion || '').trim();

      const unitMatch =
        selectedUnit === 'الكل' ||
        issUnit === selectedUnit ||
        issUnit.includes(selectedUnit);

      const battalionMatch =
        selectedBattalion === 'الكل' ||
        issBattalion === selectedBattalion ||
        issUnit.includes(selectedBattalion);

      const ammoMatch =
        selectedAmmoType === 'الكل' ||
        iss.ammoType === selectedAmmoType ||
        iss.ammoType.includes(selectedAmmoType);

      return unitMatch && battalionMatch && ammoMatch;
    });
  }, [issues, personnel, selectedUnit, selectedBattalion, selectedAmmoType]);

  // Total sum of dispensed ammunition
  const totalDispensedAmmo = useMemo(() => {
    return filteredIssues.reduce((sum, iss) => sum + (Number(iss.issuedAmmoQty) || 0), 0);
  }, [filteredIssues]);

  // Filter armed personnel by unit & battalion, showing ONLY actual user-entered weapons (No mock fallbacks!)
  const armedPersonnelList = useMemo(() => {
    const defaultSampleSerials = new Set([
      'WPN-SIG-99120', 'WPN-HK-416-08', 'WPN-M4-88410', 'WPN-GLOCK-7711',
      'WPN-SIG-10492', 'WPN-M16-3392', 'WPN-BROWNING-0092', 'WPN-AK47-0912',
      'WPN-SNIPER-ACCURACY-019', 'WPN-G3-55910', 'WPN-MP5-99201', 'WPN-G3-11029',
      'WPN-GLOCK-00911', 'SN-78921'
    ]);

    const mapped = personnel
      .filter((p) => {
        const unitMatch = selectedUnit === 'الكل' || (p.unit && p.unit.trim() === selectedUnit);
        const battalionMatch = selectedBattalion === 'الكل' || (p.battalion && p.battalion.trim() === selectedBattalion);
        return unitMatch && battalionMatch;
      })
      .map((p) => {
        // 1. Authoritative check: Active issue order with a real weapon piece
        const assignedIssue = issues.find(
          (iss) => (iss.recipientMilitaryId === p.militaryId || iss.recipientName === p.fullName) &&
                   iss.status === 'نشط' &&
                   iss.weaponSerial &&
                   iss.weaponSerial.trim() !== '' &&
                   iss.weaponSerial !== '-' &&
                   iss.weaponSerial !== 'ذخيرة فقط' &&
                   !defaultSampleSerials.has(iss.weaponSerial.trim())
        );

        // 2. Authoritative check: Armory tracked weapon piece assigned to this individual
        const assignedPiece = weapons.find(
          (w) => w.currentHolderMilitaryId === p.militaryId &&
                 w.status === 'منصرف للفرد' &&
                 w.serialNumber &&
                 w.serialNumber.trim() !== '' &&
                 !defaultSampleSerials.has(w.serialNumber.trim())
        );

        // 3. Check real armament logs on personnel (excluding mock items)
        const realArmLog = p.logs?.armament?.find(
          (a) => !a.returnDate &&
                 a.status !== 'مورد' &&
                 a.status !== 'في المخزن' &&
                 a.weaponSerial &&
                 a.weaponSerial.trim() !== '' &&
                 a.weaponSerial !== '-' &&
                 a.weaponSerial !== 'ذخيرة فقط' &&
                 !defaultSampleSerials.has(a.weaponSerial.trim())
        );

        // 4. Check direct armament on personnel if valid
        const directArm = p.armament &&
          p.armament.serialNumber &&
          p.armament.serialNumber.trim() !== '' &&
          p.armament.serialNumber !== '-' &&
          !defaultSampleSerials.has(p.armament.serialNumber.trim())
            ? p.armament
            : undefined;

        const hasWeapon = !!(assignedIssue || assignedPiece || realArmLog || directArm);

        let weaponType = '-';
        let weaponSerial = '-';
        let ammoCount = 0;
        let magsCount = 0;
        let hasVest = false;
        let hasHelmet = false;

        if (assignedIssue) {
          weaponType = assignedIssue.weaponType || 'سلاح آلي';
          weaponSerial = assignedIssue.weaponSerial || '-';
          ammoCount = Number(assignedIssue.issuedAmmoQty) || 0;
          magsCount = Number((assignedIssue as any).magazinesCount) || (ammoCount > 0 ? Math.ceil(ammoCount / 30) : 0);
          hasVest = true;
          hasHelmet = true;
        } else if (realArmLog) {
          weaponType = realArmLog.weaponType;
          weaponSerial = realArmLog.weaponSerial;
          ammoCount = Number(realArmLog.ammoQty) || 0;
          magsCount = Number(realArmLog.firelinesCount) || (ammoCount > 0 ? Math.ceil(ammoCount / 30) : 0);
          hasVest = true;
          hasHelmet = true;
        } else if (assignedPiece) {
          weaponType = assignedPiece.weaponType;
          weaponSerial = assignedPiece.serialNumber;
          ammoCount = Number(p.logs?.armament?.[0]?.ammoQty) || Number(p.armament?.ammoQty) || 0;
          magsCount = Number(p.logs?.armament?.[0]?.firelinesCount) || Number(p.armament?.magazinesCount) || (ammoCount > 0 ? Math.ceil(ammoCount / 30) : 0);
          hasVest = true;
          hasHelmet = true;
        } else if (directArm) {
          weaponType = directArm.weaponType || directArm.name || '-';
          weaponSerial = directArm.serialNumber || directArm.weaponSerial || '-';
          ammoCount = Number(directArm.ammoQty) || Number(directArm.ammoCount) || 0;
          magsCount = Number(directArm.magazinesCount) || (ammoCount > 0 ? Math.ceil(ammoCount / 30) : 0);
          hasVest = directArm.vest ?? false;
          hasHelmet = directArm.helmet ?? false;
        }

        return {
          id: p.id,
          militaryId: p.militaryId,
          name: p.fullName,
          rank: p.rank,
          unit: p.unit,
          battalion: p.battalion,
          hasWeapon,
          weaponType: hasWeapon ? weaponType : 'غير مسلّح (-)',
          weaponSerial: hasWeapon ? weaponSerial : '-',
          ammoCount: hasWeapon ? ammoCount : 0,
          magsCount: hasWeapon ? magsCount : 0,
          hasVest: hasWeapon ? hasVest : false,
          hasHelmet: hasWeapon ? hasHelmet : false,
          status: p.currentStatus || (p as any).status || 'متواجد'
        };
      });

    // If showArmedOnly is true (default), filter strictly to personnel with active real custody
    if (showArmedOnly) {
      return mapped.filter((p) => p.hasWeapon);
    }
    return mapped;
  }, [personnel, issues, weapons, selectedUnit, selectedBattalion, showArmedOnly]);

  // Aggregate totals for armed personnel list
  const personnelTotals = useMemo(() => {
    const armedPersonnel = armedPersonnelList.filter((p) => p.hasWeapon);
    const armedCount = armedPersonnel.length;
    const totalWeapons = armedCount;
    const totalMags = armedPersonnelList.reduce((sum, p) => sum + (Number(p.magsCount) || 0), 0);
    const totalAmmo = armedPersonnelList.reduce((sum, p) => sum + (Number(p.ammoCount) || 0), 0);
    return { armedCount, totalWeapons, totalMags, totalAmmo };
  }, [armedPersonnelList]);

  // Compute comprehensive inward/dispensed stock balance per item strictly from REAL user-entered data
  const itemStockBalances = useMemo(() => {
    const list: Array<{
      id: string;
      name: string;
      itemType: 'سلاح' | 'ذخيرة';
      category: string;
      caliber: string;
      totalReceived: number; // الرصيد الوارد إلى المخازن
      issuedQty: number;     // الرصيد المنصرف
      availableQty: number;  // الرصيد الحالي بالمخزن
      maintenanceQty: number;
      unitMeasure: string;
      consumptionRate: number;
    }> = [];

    // Collect distinct item names actually entered by the user
    const trackedItemsMap = new Map<string, {
      name: string;
      itemType: 'سلاح' | 'ذخيرة';
      category: string;
      caliber: string;
      unitMeasure: string;
    }>();

    // 1. From real inventory
    inventory.forEach((inv) => {
      const key = inv.name.trim().toLowerCase();
      if (!trackedItemsMap.has(key)) {
        trackedItemsMap.set(key, {
          name: inv.name,
          itemType: inv.itemType === 'ammo' ? 'ذخيرة' : 'سلاح',
          category: inv.category || (inv.itemType === 'ammo' ? 'ذخائر حية' : 'أسلحة ومعدات'),
          caliber: inv.caliber || '-',
          unitMeasure: inv.itemType === 'ammo' ? 'طلقة' : 'قطعة'
        });
      }
    });

    // 2. From real tracked weapon pieces
    weapons.forEach((w) => {
      const key = w.weaponType.trim().toLowerCase();
      if (!trackedItemsMap.has(key)) {
        trackedItemsMap.set(key, {
          name: w.weaponType,
          itemType: 'سلاح',
          category: 'أسلحة مسجلة',
          caliber: w.caliber || '-',
          unitMeasure: 'قطعة'
        });
      }
    });

    // 3. From real intakes
    intakes.forEach((intk) => {
      const key = intk.name.trim().toLowerCase();
      if (!trackedItemsMap.has(key)) {
        trackedItemsMap.set(key, {
          name: intk.name,
          itemType: intk.itemType === 'ammo' ? 'ذخيرة' : 'سلاح',
          category: intk.itemType === 'ammo' ? 'ذخائر حية' : 'أسلحة واردة',
          caliber: intk.caliber || '-',
          unitMeasure: intk.itemType === 'ammo' ? 'طلقة' : 'قطعة'
        });
      }
    });

    // 4. From real issues
    issues.forEach((iss) => {
      if (iss.weaponType) {
        const key = iss.weaponType.trim().toLowerCase();
        if (!trackedItemsMap.has(key)) {
          trackedItemsMap.set(key, {
            name: iss.weaponType,
            itemType: 'سلاح',
            category: 'أسلحة منصرفة',
            caliber: '-',
            unitMeasure: 'قطعة'
          });
        }
      }
      if (iss.ammoType) {
        const key = iss.ammoType.trim().toLowerCase();
        if (!trackedItemsMap.has(key)) {
          trackedItemsMap.set(key, {
            name: iss.ammoType,
            itemType: 'ذخيرة',
            category: 'ذخائر منصرفة',
            caliber: iss.ammoCaliber || '-',
            unitMeasure: 'طلقة'
          });
        }
      }
    });

    // Calculate real totals for each item actually entered
    let index = 1;
    trackedItemsMap.forEach((meta, itemKey) => {
      const matchingInv = inventory.filter((inv) => inv.name.trim().toLowerCase() === itemKey);
      const invTotalReceived = matchingInv.reduce((sum, item) => sum + (Number(item.totalReceived) || 0), 0);
      const invIssued = matchingInv.reduce((sum, item) => sum + (Number(item.issuedQty) || 0), 0);
      const invAvailable = matchingInv.reduce((sum, item) => sum + (Number(item.availableQty) || 0), 0);
      const invMaintenance = matchingInv.reduce((sum, item) => sum + (Number(item.inMaintenanceQty) || 0), 0);

      const matchingIntakes = intakes.filter((intk) => intk.name.trim().toLowerCase() === itemKey);
      const intakesTotal = matchingIntakes.reduce((sum, item) => sum + (Number(item.quantity) || 0), 0);

      const matchingIssues = issues.filter((iss) => {
        const matchesName =
          (meta.itemType === 'سلاح' && iss.weaponType?.trim().toLowerCase() === itemKey) ||
          (meta.itemType === 'ذخيرة' && iss.ammoType?.trim().toLowerCase() === itemKey);
        if (!matchesName) return false;
        if (selectedUnit === 'الكل') return true;
        const person = personnel.find((p) => p.militaryId === iss.recipientMilitaryId);
        return iss.unit === selectedUnit || person?.unit === selectedUnit;
      });
      const issuesQty = meta.itemType === 'ذخيرة'
        ? matchingIssues.reduce((sum, iss) => sum + (Number(iss.issuedAmmoQty) || 0), 0)
        : matchingIssues.filter((iss) => iss.weaponSerial && iss.weaponSerial !== 'ذخيرة فقط').length;

      const matchingPieces = weapons.filter((w) => w.weaponType.trim().toLowerCase() === itemKey);
      const piecesTotal = matchingPieces.length;
      const piecesIssued = matchingPieces.filter((p) => {
        if (p.status !== 'منصرف للفرد') return false;
        if (selectedUnit === 'الكل') return true;
        return p.currentHolderUnit === selectedUnit;
      }).length;
      const piecesMaintenance = matchingPieces.filter(
        (p) => p.technicalCondition === 'تحتاج صيانة' || p.technicalCondition === 'معطوبة' || p.status === 'في الصيانة'
      ).length;

      // Real balance strictly calculated from user-entered records
      const totalReceived = Math.max(invTotalReceived, intakesTotal, piecesTotal);
      const issuedQty = Math.max(invIssued, issuesQty, piecesIssued);
      const availableQty = invAvailable > 0 ? invAvailable : Math.max(0, totalReceived - issuedQty);
      const maintenanceQty = Math.max(invMaintenance, piecesMaintenance);
      const consumptionRate = totalReceived > 0 ? Math.round((issuedQty / totalReceived) * 100) : 0;

      list.push({
        id: `real-item-${index++}`,
        name: meta.name,
        itemType: meta.itemType,
        category: meta.category,
        caliber: meta.caliber,
        totalReceived,
        issuedQty,
        availableQty,
        maintenanceQty,
        unitMeasure: meta.unitMeasure,
        consumptionRate
      });
    });

    if (selectedItemName !== 'الكل') {
      return list.filter((item) => item.name === selectedItemName || item.name.includes(selectedItemName));
    }

    return list;
  }, [inventory, weapons, intakes, issues, personnel, selectedUnit, selectedItemName]);

  // Totals for Item Stock Balances
  const totalStockReceived = useMemo(() => itemStockBalances.reduce((acc, i) => acc + i.totalReceived, 0), [itemStockBalances]);
  const totalStockIssued = useMemo(() => itemStockBalances.reduce((acc, i) => acc + i.issuedQty, 0), [itemStockBalances]);
  const totalStockAvailable = useMemo(() => itemStockBalances.reduce((acc, i) => acc + i.availableQty, 0), [itemStockBalances]);

  // All distinct item names strictly from user-entered records
  const allItemNames = useMemo(() => {
    const set = new Set<string>();
    inventory.forEach((inv) => set.add(inv.name));
    weapons.forEach((w) => set.add(w.weaponType));
    intakes.forEach((intk) => set.add(intk.name));
    issues.forEach((iss) => {
      if (iss.weaponType) set.add(iss.weaponType);
      if (iss.ammoType) set.add(iss.ammoType);
    });
    return Array.from(set).sort();
  }, [inventory, weapons, intakes, issues]);

  const reportDate = new Date().toLocaleDateString('ar-EG', {
    weekday: 'long',
    year: 'numeric',
    month: 'long',
    day: 'numeric'
  });

  const reportSerial = `REP-ARM-${Math.floor(100000 + Math.random() * 900000)}`;

  const printableRef = useRef<HTMLDivElement>(null);
  const [isDocumentReady, setIsDocumentReady] = useState(false);

  useEffect(() => {
    if (!isOpen) return;
    setIsDocumentReady(false);
    let isCancelled = false;

    preparePrintableDocument(printableRef.current).then(() => {
      if (!isCancelled) {
        setIsDocumentReady(true);
      }
    });

    return () => {
      isCancelled = true;
    };
  }, [isOpen, activeReportType, selectedUnit, selectedBattalion, selectedItemName, selectedAmmoType, showArmedOnly, signatories]);

  if (!isOpen) return null;

  const getReportNameArabic = () => {
    switch (activeReportType) {
      case 'ammo_issues': return 'كشف_صرف_الذخيرة';
      case 'balance_per_item': return 'رصيد_الوارد_والمنصرف';
      case 'stock': return 'المخزون_الكلي';
      case 'low_stock': return 'المخزون_وشيك_النفاد';
      case 'movement': return 'حركة_المستودع';
      case 'personnel': return 'عهد_التسليح_للأفراد';
      default: return 'تقرير_التسليح';
    }
  };

  const isLandscapeReport = activeReportType === 'balance_per_item' || activeReportType === 'ammo_issues' || activeReportType === 'stock';

  const handlePrint = async () => {
    await executeUnifiedPrint(printableRef.current, {
      documentTitle: `${getReportNameArabic()}_${selectedUnit}_${new Date().toISOString().slice(0, 10)}`,
      orientation: isLandscapeReport ? 'landscape' : 'portrait'
    });
  };

  const handleSharePdf = async () => {
    await shareOrSavePrintableDocument(printableRef.current, {
      title: `تقرير تسليح - ${getReportNameArabic()}`,
      filename: `${getReportNameArabic()}_${selectedUnit}.html`,
      orientation: isLandscapeReport ? 'landscape' : 'portrait'
    });
  };

  const handleResetFilters = () => {
    setSelectedUnit('الكل');
    setSelectedBattalion('الكل');
    setSelectedItemName('الكل');
    setSelectedAmmoType('الكل');
  };

  return createPortal(
    <div className="fixed inset-0 z-[100] flex flex-col items-center justify-center p-2 sm:p-4 bg-slate-950/90 backdrop-blur-md overflow-hidden print:p-0 print:bg-white print:static printable-modal-overlay">
      {/* Container */}
      <div className="bg-white text-slate-900 border border-slate-300 rounded-3xl max-w-6xl w-full shadow-2xl relative my-2 sm:my-4 max-h-[96vh] flex flex-col overflow-hidden print:max-h-none print:border-none print:shadow-none print:p-0 print:m-0 print:w-full printable-modal-card">
        
        {/* Modal Sticky Toolbar */}
        <div className="sticky top-0 z-30 bg-slate-900 text-white p-3.5 sm:p-4 rounded-t-3xl border-b-2 border-amber-500/80 shadow-md flex flex-wrap items-center justify-between gap-3 print:hidden no-print shrink-0">
          <div className="flex items-center space-x-2 space-x-reverse font-bold text-amber-300">
            <Printer className="w-5 h-5 text-amber-400" />
            <span className="text-sm sm:text-base font-['Tajawal'] font-black">
              مركز تقارير وطباعة فرع التسليح والذخائر
            </span>
          </div>

          {/* Report Type Selector Tabs */}
          <div className="flex flex-wrap items-center gap-1.5 bg-slate-800 p-1.5 rounded-2xl border border-slate-700 text-xs">
            <button
              onClick={() => setActiveReportType('ammo_issues')}
              className={`px-3 py-1.5 rounded-xl font-bold transition-all cursor-pointer flex items-center space-x-1 space-x-reverse ${
                activeReportType === 'ammo_issues'
                  ? 'bg-amber-600 text-white shadow-xs'
                  : 'text-slate-300 hover:text-white hover:bg-slate-700'
              }`}
            >
              <Crosshair className="w-3.5 h-3.5 text-amber-300" />
              <span>🎯 كشف صرف الذخيرة</span>
            </button>

            <button
              onClick={() => setActiveReportType('balance_per_item')}
              className={`px-3 py-1.5 rounded-xl font-bold transition-all cursor-pointer flex items-center space-x-1 space-x-reverse ${
                activeReportType === 'balance_per_item'
                  ? 'bg-emerald-700 text-white shadow-xs'
                  : 'text-slate-300 hover:text-white hover:bg-slate-700'
              }`}
            >
              <Scale className="w-3.5 h-3.5 text-emerald-300" />
              <span>⚖️ رصيد الوارد والمنصرف</span>
            </button>

            <button
              onClick={() => setActiveReportType('stock')}
              className={`px-3 py-1.5 rounded-xl font-bold transition-all cursor-pointer ${
                activeReportType === 'stock'
                  ? 'bg-blue-700 text-white shadow-xs'
                  : 'text-slate-300 hover:text-white hover:bg-slate-700'
              }`}
            >
              📦 المخزون الكلي
            </button>

            <button
              onClick={() => setActiveReportType('low_stock')}
              className={`px-3 py-1.5 rounded-xl font-bold transition-all cursor-pointer ${
                activeReportType === 'low_stock'
                  ? 'bg-rose-700 text-white shadow-xs'
                  : 'text-slate-300 hover:text-white hover:bg-slate-700'
              }`}
            >
              ⚠️ وشيكة النفاد
            </button>

            <button
              onClick={() => setActiveReportType('movement')}
              className={`px-3 py-1.5 rounded-xl font-bold transition-all cursor-pointer ${
                activeReportType === 'movement'
                  ? 'bg-purple-700 text-white shadow-xs'
                  : 'text-slate-300 hover:text-white hover:bg-slate-700'
              }`}
            >
              🔄 حركة المستودع
            </button>

            <button
              onClick={() => setActiveReportType('personnel')}
              className={`px-3 py-1.5 rounded-xl font-bold transition-all cursor-pointer ${
                activeReportType === 'personnel'
                  ? 'bg-indigo-700 text-white shadow-xs'
                  : 'text-slate-300 hover:text-white hover:bg-slate-700'
              }`}
            >
              🎖️ عهد الأفراد
            </button>
          </div>

          {/* Action buttons */}
          <div className="flex items-center space-x-2 space-x-reverse flex-wrap gap-1.5">
            {/* Document readiness indicator */}
            <div className={`hidden sm:flex items-center gap-1.5 px-3 py-1 rounded-xl text-xs font-bold border transition-colors ${
              isDocumentReady
                ? 'bg-emerald-950/60 text-emerald-300 border-emerald-500/40'
                : 'bg-amber-950/60 text-amber-300 border-amber-500/40 animate-pulse'
            }`}>
              <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
              <span>{isDocumentReady ? 'التقرير جاهز للطباعة' : 'جاري تجهيز الخطوط...'}</span>
            </div>

            <button
              onClick={handlePrint}
              className="bg-amber-600 hover:bg-amber-700 text-white font-extrabold px-3.5 py-1.5 rounded-xl text-xs transition-all shadow-md flex items-center space-x-1.5 space-x-reverse cursor-pointer"
            >
              <Printer className="w-4 h-4" />
              <span>أمر الطباعة 🖨️</span>
            </button>

            <button
              type="button"
              onClick={handleSharePdf}
              className="bg-sky-600 hover:bg-sky-500 active:scale-95 text-white font-bold px-3 py-1.5 rounded-xl text-xs transition-all shadow-md flex items-center space-x-1.5 space-x-reverse cursor-pointer"
              title="مشاركة أو حفظ التقرير بصيغة PDF / تقرير معتمد"
            >
              <Share2 className="w-4 h-4" />
              <span>مشاركة / حفظ PDF 📄</span>
            </button>

            <button
              type="button"
              onClick={onClose}
              className="bg-slate-800 hover:bg-slate-700 text-amber-300 hover:text-white border border-amber-500/50 font-extrabold px-3 py-1.5 rounded-xl text-xs transition-all flex items-center space-x-1.5 space-x-reverse cursor-pointer"
            >
              <ArrowRight className="w-4 h-4 text-amber-400" />
              <span>إغلاق ↩️</span>
            </button>

            <button
              onClick={onClose}
              className="w-8 h-8 flex items-center justify-center text-slate-300 hover:text-white bg-slate-800 hover:bg-slate-700 rounded-xl cursor-pointer border border-slate-700"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Scrollable Body */}
        <div className="overflow-y-auto p-4 sm:p-6 md:p-8 flex-1 space-y-5">

          {/* Dynamic Filter Toolbar (Hidden on Print) */}
          <div className="bg-slate-50 border-2 border-slate-300 rounded-2xl p-4 print:hidden shadow-xs space-y-3 font-['Cairo',sans-serif]">
            <div className="flex items-center justify-between border-b border-slate-200 pb-2.5">
              <div className="flex items-center space-x-2 space-x-reverse text-slate-900 font-black text-xs">
                <Filter className="w-4 h-4 text-amber-600 shrink-0" />
                <span>تصفية وتخصيص بيانات التقرير حسب الوحدة والكتيبة والأصناف:</span>
              </div>
              <button
                type="button"
                onClick={handleResetFilters}
                className="text-[11px] font-bold text-slate-600 hover:text-rose-700 flex items-center space-x-1 space-x-reverse cursor-pointer"
              >
                <RotateCcw className="w-3 h-3" />
                <span>إعادة ضبط التصفية</span>
              </button>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-3 text-xs">
              {/* Unit Filter */}
              <div>
                <label className="block text-[11px] font-bold text-slate-700 mb-1">الوحدة العسكرية:</label>
                <select
                  value={selectedUnit}
                  onChange={(e) => {
                    setSelectedUnit(e.target.value);
                    setSelectedBattalion('الكل');
                  }}
                  className="w-full bg-white border border-slate-300 rounded-xl px-2.5 py-1.5 text-xs font-bold text-slate-900 focus:outline-none focus:border-amber-600"
                >
                  <option value="الكل">🏢 جميع الوحدات العسكرية</option>
                  {uniqueUnits.map((u) => (
                    <option key={u} value={u}>{u}</option>
                  ))}
                </select>
              </div>

              {/* Battalion Filter */}
              <div>
                <label className="block text-[11px] font-bold text-slate-700 mb-1">الكتيبة / السرية:</label>
                <select
                  value={selectedBattalion}
                  onChange={(e) => setSelectedBattalion(e.target.value)}
                  className="w-full bg-white border border-slate-300 rounded-xl px-2.5 py-1.5 text-xs font-bold text-slate-900 focus:outline-none focus:border-amber-600"
                >
                  <option value="الكل">🛡️ جميع الكتائب</option>
                  {uniqueBattalions.map((b) => (
                    <option key={b} value={b}>{b}</option>
                  ))}
                </select>
              </div>

              {/* Item Filter (for Balance Per Item Report) */}
              <div>
                <label className="block text-[11px] font-bold text-slate-700 mb-1">تحديد نوع السلاح أو الصنف:</label>
                <select
                  value={selectedItemName}
                  onChange={(e) => setSelectedItemName(e.target.value)}
                  className="w-full bg-white border border-slate-300 rounded-xl px-2.5 py-1.5 text-xs font-bold text-slate-900 focus:outline-none focus:border-amber-600"
                >
                  <option value="الكل">⚖️ جميع الأصناف والأسلحة والذخائر</option>
                  {allItemNames.map((itm) => (
                    <option key={itm} value={itm}>{itm}</option>
                  ))}
                </select>
              </div>

              {/* Ammo Filter (for Ammo Issues Report) */}
              <div>
                <label className="block text-[11px] font-bold text-slate-700 mb-1">نوع الذخيرة المنصرفة:</label>
                <select
                  value={selectedAmmoType}
                  onChange={(e) => setSelectedAmmoType(e.target.value)}
                  className="w-full bg-white border border-slate-300 rounded-xl px-2.5 py-1.5 text-xs font-bold text-slate-900 focus:outline-none focus:border-amber-600"
                >
                  <option value="الكل">🎯 جميع أنواع الذخائر</option>
                  {uniqueAmmoTypes.map((a) => (
                    <option key={a} value={a}>{a}</option>
                  ))}
                </select>
              </div>
            </div>

            {/* Armed Personnel Filter Toggle (Active for personnel report) */}
            {activeReportType === 'personnel' && (
              <div className="pt-2.5 border-t border-slate-200 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-2">
                <label className="flex items-center space-x-2 space-x-reverse cursor-pointer text-xs font-bold text-slate-800 bg-amber-100/70 border border-amber-300 px-3 py-1.5 rounded-xl hover:bg-amber-100 transition-colors">
                  <input
                    type="checkbox"
                    checked={showArmedOnly}
                    onChange={(e) => setShowArmedOnly(e.target.checked)}
                    className="rounded text-amber-600 focus:ring-amber-500 w-4 h-4 cursor-pointer"
                  />
                  <span>عرض الأفراد المسلحين فقط (حذف أي بيانات افتراضية لغير المسلحين)</span>
                </label>
                <span className="text-[11px] text-slate-600 font-bold">
                  {showArmedOnly
                    ? `🛡️ يتم عرض الأفراد الذين لديهم عهدة سلاح مسجلة فعلياً (${armedPersonnelList.length} فرد)`
                    : `📋 يتم عرض كافة أفراد القوة (${armedPersonnelList.length} فرد)`}
                </span>
              </div>
            )}
          </div>

          {/* OFFICER SIGNATURES CUSTOMIZER PANEL (Hidden on Print) */}
          <div className="bg-white border-2 border-amber-300 rounded-2xl p-4 print:hidden shadow-xs space-y-3 font-['Cairo',sans-serif]">
            <div className="flex items-center justify-between border-b border-amber-100 pb-2.5">
              <div className="flex items-center space-x-2 space-x-reverse text-slate-900 font-black text-xs">
                <UserCheck className="w-4 h-4 text-amber-600 shrink-0" />
                <span>إضافة وتخصيص أسماء الضباط وصفاتهم في أسفل التقرير ({signatories.length} توقيعات معتمدة):</span>
              </div>
              
              <div className="flex items-center space-x-2 space-x-reverse">
                {saveSuccessNotice && (
                  <span className="text-[11px] font-bold text-emerald-700 bg-emerald-50 border border-emerald-300 px-2.5 py-0.5 rounded-lg animate-fade-in">
                    {saveSuccessNotice}
                  </span>
                )}
                <button
                  type="button"
                  onClick={() => setShowSignatoryManager(!showSignatoryManager)}
                  className="text-xs font-bold text-amber-900 hover:text-amber-950 flex items-center space-x-1 space-x-reverse bg-amber-50 hover:bg-amber-100 border border-amber-300 px-3 py-1 rounded-xl transition-all cursor-pointer"
                >
                  <span>{showSignatoryManager ? 'طي لوحة التوقيعات' : 'تعديل وإضافة الضباط ✍️'}</span>
                  {showSignatoryManager ? <ChevronUp className="w-3.5 h-3.5" /> : <ChevronDown className="w-3.5 h-3.5" />}
                </button>
              </div>
            </div>

            {showSignatoryManager && (
              <div className="space-y-3 pt-1">
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
                  {signatories.map((officer, index) => (
                    <div
                      key={officer.id}
                      className="bg-slate-50 border border-slate-200 hover:border-amber-400 rounded-xl p-3 space-y-2 relative transition-all"
                    >
                      <div className="flex items-center justify-between text-[11px] font-black text-slate-700 border-b border-slate-200 pb-1.5">
                        <span className="flex items-center space-x-1.5 space-x-reverse">
                          <span className="w-5 h-5 rounded-full bg-amber-200 text-amber-900 flex items-center justify-center text-[10px] font-black">
                            {index + 1}
                          </span>
                          <span>الضابط الموقع #{index + 1}</span>
                        </span>
                        {signatories.length > 1 && (
                          <button
                            type="button"
                            onClick={() => handleRemoveSignatory(officer.id)}
                            className="text-rose-600 hover:text-rose-800 p-1 rounded-md hover:bg-rose-50 transition-colors cursor-pointer"
                            title="حذف هذا التوقيع من أسفل التقرير"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        )}
                      </div>

                      <div>
                        <label className="block text-[10px] font-bold text-slate-600 mb-1">
                          الصفة / المسمى الوظيفي:
                        </label>
                        <input
                          type="text"
                          value={officer.title}
                          onChange={(e) => handleUpdateSignatory(officer.id, 'title', e.target.value)}
                          placeholder="مثال: رئيس فرع التسليح / ضابط المستودع / قائد اللواء"
                          className="w-full bg-white border border-slate-300 rounded-lg px-2.5 py-1 text-xs font-bold text-slate-900 focus:outline-none focus:border-amber-600"
                        />
                      </div>

                      <div>
                        <label className="block text-[10px] font-bold text-slate-600 mb-1">
                          الرتبة والاسم الكامل:
                        </label>
                        <input
                          type="text"
                          list="officers-suggest-list"
                          value={officer.name}
                          onChange={(e) => handleUpdateSignatory(officer.id, 'name', e.target.value)}
                          placeholder="مثال: عقيد ركن / فلان بن فلان"
                          className="w-full bg-white border border-slate-300 rounded-lg px-2.5 py-1 text-xs font-extrabold text-slate-900 focus:outline-none focus:border-amber-600"
                        />
                      </div>
                    </div>
                  ))}
                </div>

                {/* Suggestion list for registered officers */}
                <datalist id="officers-suggest-list">
                  {personnel.map((p) => (
                    <option key={p.militaryId} value={`${p.rank} / ${p.fullName}`} />
                  ))}
                </datalist>

                {/* Control Buttons */}
                <div className="flex flex-wrap items-center justify-between gap-2 pt-2 border-t border-slate-200 text-xs">
                  <button
                    type="button"
                    onClick={handleAddSignatory}
                    className="bg-amber-600 hover:bg-amber-700 text-white font-extrabold px-3.5 py-1.5 rounded-xl transition-all shadow-xs flex items-center space-x-1.5 space-x-reverse cursor-pointer"
                  >
                    <Plus className="w-3.5 h-3.5" />
                    <span>إضافة ضابط موقع إضافي ➕</span>
                  </button>

                  <div className="flex items-center space-x-2 space-x-reverse">
                    <button
                      type="button"
                      onClick={handleSaveSignatoriesDefault}
                      className="bg-slate-900 hover:bg-slate-800 text-amber-300 hover:text-white font-bold px-3 py-1.5 rounded-xl transition-all flex items-center space-x-1 space-x-reverse cursor-pointer shadow-xs"
                      title="حفظ هذه الأسماء والصفات كنموذج ثابت للتقارير القادمة"
                    >
                      <Check className="w-3.5 h-3.5" />
                      <span>حفظ كأسماء افتراضية للتقارير 💾</span>
                    </button>

                    <button
                      type="button"
                      onClick={handleResetSignatories}
                      className="text-slate-500 hover:text-rose-700 font-bold px-2.5 py-1.5 rounded-xl text-[11px] transition-all flex items-center space-x-1 space-x-reverse cursor-pointer"
                    >
                      <RotateCcw className="w-3 h-3" />
                      <span>استعادة النموذج الافتراضي</span>
                    </button>
                  </div>
                </div>
              </div>
            )}
          </div>

          {/* PRINTABLE OFFICIAL REPORT DOCUMENT */}
          <div
            ref={printableRef}
            id="armament-printable-report"
            data-printable-content="true"
            className="space-y-6 text-right font-['Cairo',sans-serif]"
          >
            
            {/* Official Military Letterhead / Header */}
            {(() => {
              const headerInfo = getCurrentHeaderInfo(currentAccountName);
              return (
                <div className="flex items-center justify-between border-b-2 border-slate-900 pb-5">
                  <div>
                    <h1 className="text-xl font-black text-slate-900 font-['Tajawal']">{headerInfo.forceName}</h1>
                    <h2 className="text-sm font-black text-slate-800">{headerInfo.divisionName}</h2>
                    <p className="text-xs font-bold text-amber-900">{headerInfo.unitName}</p>
                  </div>

                  <div className="text-center">
                    <div className="w-16 h-16 border-2 border-slate-900 rounded-full flex items-center justify-center mx-auto bg-slate-50 font-black text-[10px] text-slate-900 text-center leading-tight">
                      قيادة التسليح<br/>والذخائر
                    </div>
                    <span className="text-[10px] text-rose-800 font-black block mt-1 tracking-wider uppercase">
                      سري للغاية ومحمي
                    </span>
                  </div>

                  <div className="text-left text-xs font-mono space-y-0.5">
                    <div>رقم القيد التفتيشي: <strong className="text-slate-900">{reportSerial}</strong></div>
                    <div>تاريخ التقرير: <strong>{reportDate}</strong></div>
                    <div>نوع المستند: <strong className="text-amber-700">تقرير تسليح رسمي معتمد</strong></div>
                  </div>
                </div>
              );
            })()}

            {/* Report Title & Selected Scope Header */}
            <div className="bg-slate-100 border-y border-slate-300 py-3 px-4 flex flex-col md:flex-row md:items-center justify-between gap-2 rounded-xl">
              <div>
                <h2 className="text-lg font-black text-slate-900 font-['Tajawal']">
                  {activeReportType === 'ammo_issues' && '🎯 تقرير كشف أوامر صرف الذخائر والأسلحة للأفراد'}
                  {activeReportType === 'balance_per_item' && '⚖️ تقرير حركة الأرصدة (الوارد والمنصرف والمتوفر) لكل صنف'}
                  {activeReportType === 'stock' && '📋 تقرير رصيد المخزون الكلي وجاهزية الأسلحة والذخائر'}
                  {activeReportType === 'low_stock' && '⚠️ تقرير الأصناف وشيكة النفاد وبيان العجز والتنبيهات'}
                  {activeReportType === 'movement' && '🔄 تقرير حركة الوارد والصادر وتوريد العهد بالمستودع'}
                  {activeReportType === 'personnel' && '🎖️ تقرير كشف التسليح والجاهزية النارية القتالية للأفراد'}
                </h2>
                <div className="text-xs text-slate-700 font-bold mt-1 flex flex-wrap items-center gap-x-4 gap-y-1">
                  <span>
                    الوحدة المستهدفة:{' '}
                    <strong className="text-amber-900 font-black">
                      {selectedUnit === 'الكل' ? 'كافة الوحدات والتشكيلات' : selectedUnit}
                    </strong>
                  </span>
                  <span>
                    الكتيبة:{' '}
                    <strong className="text-slate-900 font-black">
                      {selectedBattalion === 'الكل' ? 'كافة الكتائب' : selectedBattalion}
                    </strong>
                  </span>
                  {activeReportType === 'balance_per_item' && selectedItemName !== 'الكل' && (
                    <span>
                      الصنف المحدد: <strong className="text-emerald-900">{selectedItemName}</strong>
                    </span>
                  )}
                  {activeReportType === 'ammo_issues' && selectedAmmoType !== 'الكل' && (
                    <span>
                      نوع الذخيرة: <strong className="text-amber-900">{selectedAmmoType}</strong>
                    </span>
                  )}
                </div>
              </div>

              <div className="text-left shrink-0">
                <span className="text-xs font-mono font-bold bg-slate-900 text-white px-3 py-1 rounded-lg">
                  {currentAccountName}
                </span>
              </div>
            </div>

            {/* KPI Badges */}
            <div className="grid grid-cols-2 md:grid-cols-4 gap-3 text-center text-xs">
              {activeReportType === 'personnel' ? (
                <>
                  <div className="bg-amber-50/70 border border-amber-300 p-3 rounded-xl">
                    <span className="text-amber-900 font-bold block text-[11px]">إجمالي الأفراد المسلحين</span>
                    <span className="text-lg font-black text-amber-950 font-mono">
                      {personnelTotals.armedCount} فرد
                    </span>
                  </div>

                  <div className="bg-slate-50 border border-slate-300 p-3 rounded-xl">
                    <span className="text-slate-600 font-bold block text-[11px]">إجمالي قطع الأسلحة المنصرفة</span>
                    <span className="text-lg font-black text-slate-900 font-mono">
                      {personnelTotals.totalWeapons} قطعة
                    </span>
                  </div>

                  <div className="bg-blue-50/70 border border-blue-300 p-3 rounded-xl">
                    <span className="text-blue-900 font-bold block text-[11px]">مجموع المخازن المنصرفة</span>
                    <span className="text-lg font-black text-blue-950 font-mono">
                      {personnelTotals.totalMags} مخزن
                    </span>
                  </div>

                  <div className="bg-emerald-50/70 border border-emerald-300 p-3 rounded-xl">
                    <span className="text-emerald-900 font-bold block text-[11px]">مجموع الذخيرة المصروفة</span>
                    <span className="text-lg font-black text-emerald-950 font-mono">
                      {personnelTotals.totalAmmo.toLocaleString('ar-EG')} طلقة
                    </span>
                  </div>
                </>
              ) : (
                <>
                  <div className="bg-amber-50/70 border border-amber-300 p-3 rounded-xl">
                    <span className="text-amber-900 font-bold block text-[11px]">مجموع الذخيرة المنصرفة</span>
                    <span className="text-lg font-black text-amber-950 font-mono">
                      {totalDispensedAmmo.toLocaleString('ar-EG')} طلقة
                    </span>
                  </div>

                  <div className="bg-slate-50 border border-slate-300 p-3 rounded-xl">
                    <span className="text-slate-600 font-bold block text-[11px]">أوامر الصرف المنفذة</span>
                    <span className="text-lg font-black text-slate-900 font-mono">
                      {filteredIssues.length} أوامر
                    </span>
                  </div>

                  <div className="bg-emerald-50/70 border border-emerald-300 p-3 rounded-xl">
                    <span className="text-emerald-900 font-bold block text-[11px]">إجمالي الوارد إلى المخازن</span>
                    <span className="text-lg font-black text-emerald-950 font-mono">
                      {totalStockReceived.toLocaleString('ar-EG')}
                    </span>
                  </div>

                  <div className="bg-blue-50/70 border border-blue-300 p-3 rounded-xl">
                    <span className="text-blue-900 font-bold block text-[11px]">المتوفر حالياً بالمستودع</span>
                    <span className="text-lg font-black text-blue-950 font-mono">
                      {totalStockAvailable.toLocaleString('ar-EG')}
                    </span>
                  </div>
                </>
              )}
            </div>

            {/* REPORT VIEW: AMMUNITION & WEAPONS DISPENSE ORDERS REPORT */}
            {activeReportType === 'ammo_issues' && (
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <h3 className="font-extrabold text-slate-900 text-sm font-['Tajawal'] border-r-4 border-amber-600 pr-2">
                    كشف أوامر صرف الذخائر والأسلحة للأفراد العسكريين (الوحدة: {selectedUnit} • الكتيبة: {selectedBattalion})
                  </h3>
                  <span className="text-xs font-mono font-bold text-slate-600">
                    عدد الأوامر: {filteredIssues.length}
                  </span>
                </div>

                <div className="overflow-x-auto border border-slate-300 rounded-xl shadow-2xs">
                  <table className="w-full text-xs text-right border-collapse">
                    <thead>
                      <tr className="bg-slate-200 text-slate-900 font-black border-b border-slate-300 text-center">
                        <th className="p-2.5 border-l border-slate-300 w-10">#</th>
                        <th className="p-2.5 border-l border-slate-300 text-right">الرقم الوظيفي</th>
                        <th className="p-2.5 border-l border-slate-300 text-right">الاسم والرتبة</th>
                        <th className="p-2.5 border-l border-slate-300 text-right">الوحدة والكتيبة</th>
                        <th className="p-2.5 border-l border-slate-300 text-right">نوع الذخيرة المنصرفة</th>
                        <th className="p-2.5 border-l border-slate-300 text-center font-bold">الكمية المنصرفة</th>
                        <th className="p-2.5 border-l border-slate-300 text-right">السلاح والرقم التسلسلي</th>
                        <th className="p-2.5 border-l border-slate-300 text-center">تاريخ الصرف</th>
                        <th className="p-2.5 border-l border-slate-300 text-right">جهة أمر الصرف</th>
                        <th className="p-2.5 text-center">توقيع المستلم</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-200">
                      {filteredIssues.length === 0 ? (
                        <tr>
                          <td colSpan={10} className="p-6 text-center text-slate-500 font-bold bg-white">
                            لا توجد أوامر صرف ذخيرة مسجلة مطابقة لمعايير التصفية المحددة.
                          </td>
                        </tr>
                      ) : (
                        filteredIssues.map((iss, idx) => {
                          const person = personnel.find((p) => p.militaryId === iss.recipientMilitaryId);
                          const unitDisplay = iss.unit || person?.unit || 'غير محدد';
                          const battalionDisplay = person?.battalion ? ` • ${person.battalion}` : '';

                          return (
                            <tr key={iss.id || idx} className={idx % 2 === 0 ? 'bg-white' : 'bg-slate-50/80'}>
                              <td className="p-2.5 border-l border-slate-200 text-center font-mono font-bold text-slate-700">
                                {idx + 1}
                              </td>
                              <td className="p-2.5 border-l border-slate-200 font-mono font-black text-rose-950">
                                {iss.recipientMilitaryId}
                              </td>
                              <td className="p-2.5 border-l border-slate-200 font-black text-slate-900">
                                {iss.recipientRank} / {iss.recipientName}
                              </td>
                              <td className="p-2.5 border-l border-slate-200 font-bold text-slate-800">
                                {unitDisplay}{battalionDisplay}
                              </td>
                              <td className="p-2.5 border-l border-slate-200 font-extrabold text-amber-950">
                                {iss.ammoType} {iss.ammoCaliber ? `(${iss.ammoCaliber})` : ''}
                              </td>
                              <td className="p-2.5 border-l border-slate-200 text-center font-mono font-black text-amber-900 bg-amber-50/50">
                                {iss.issuedAmmoQty} طلقة
                              </td>
                              <td className="p-2.5 border-l border-slate-200 font-bold text-slate-800">
                                {iss.weaponType}{' '}
                                {iss.weaponSerial ? (
                                  <span className="font-mono text-rose-900 text-[11px] block">
                                    [S/N: {iss.weaponSerial}]
                                  </span>
                                ) : (
                                  ''
                                )}
                              </td>
                              <td className="p-2.5 border-l border-slate-200 text-center font-mono font-bold text-slate-700">
                                {iss.date}
                              </td>
                              <td className="p-2.5 border-l border-slate-200 font-bold text-slate-800">
                                {iss.orderReference || 'أمر تسليح قيادي'}
                              </td>
                              <td className="p-2.5 text-center text-slate-400 font-mono text-[10px]">
                                ........................
                              </td>
                            </tr>
                          );
                        })
                      )}
                    </tbody>
                    {/* CRITICAL: MANDATORY TOTALS ROW AT BOTTOM OF REPORT */}
                    <tfoot>
                      <tr className="bg-amber-100 text-amber-950 font-black border-t-2 border-slate-900 text-xs">
                        <td colSpan={5} className="p-3 text-right font-black text-sm">
                          المجموع الإجمالي لكمية الذخيرة المنصرفة (الوحدة: {selectedUnit === 'الكل' ? 'كافة الوحدات' : selectedUnit}):
                        </td>
                        <td className="p-3 text-center font-mono font-black text-base text-rose-900 bg-amber-200/80 border-x-2 border-slate-900">
                          {totalDispensedAmmo.toLocaleString('ar-EG')} طلقة
                        </td>
                        <td colSpan={4} className="p-3 text-left font-mono text-[11px] text-slate-700">
                          إجمالي الأوامر المعتمدة: ({filteredIssues.length} أمر صرف رسمي)
                        </td>
                      </tr>
                    </tfoot>
                  </table>
                </div>

                {/* Summary Statement Box */}
                <div className="bg-gradient-to-r from-amber-50 to-orange-50 border-2 border-amber-300 rounded-2xl p-4 text-xs space-y-2">
                  <div className="font-black text-amber-950 text-sm flex items-center space-x-2 space-x-reverse">
                    <Crosshair className="w-4 h-4 text-amber-700" />
                    <span>خلاصة كشف صرف الذخيرة والاعتماد:</span>
                  </div>
                  <p className="text-slate-800 leading-relaxed font-bold">
                    يشهد فرع التسليح والذخائر بأنه قد تم صرف وتسليم كمية إجمالية قدرها{' '}
                    <strong className="text-rose-900 text-sm font-black underline font-mono">
                      {totalDispensedAmmo.toLocaleString('ar-EG')} طلقة
                    </strong>{' '}
                    من الذخائر بموجب ({filteredIssues.length}) أمر صرف رسمي معتمد، لصالح منسوبي{' '}
                    <strong className="text-slate-900">({selectedUnit === 'الكل' ? 'كافة الوحدات والتشكيلات' : selectedUnit})</strong>،
                    وتم تسجيلها رسمياً بالعهد الشخصية وسجلات المستودع.
                  </p>
                </div>
              </div>
            )}

            {/* REPORT VIEW: BALANCE PER ITEM (INWARD VS DISPENSED BALANCE FOR EACH WEAPON & AMMO) */}
            {activeReportType === 'balance_per_item' && (
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <h3 className="font-extrabold text-slate-900 text-sm font-['Tajawal'] border-r-4 border-emerald-600 pr-2">
                    تقرير حركة الأرصدة: الرصيد الوارد إلى المخازن والرصيد المنصرف والرصيد المتبقي لكل نوع سلاح أو ذخيرة
                  </h3>
                  <span className="text-xs font-mono font-bold text-slate-600">
                    عدد الأصناف: {itemStockBalances.length}
                  </span>
                </div>

                <div className="overflow-x-auto border border-slate-300 rounded-xl shadow-2xs">
                  <table className="w-full text-xs text-right border-collapse">
                    <thead>
                      <tr className="bg-slate-200 text-slate-900 font-black border-b border-slate-300 text-center">
                        <th className="p-2.5 border-l border-slate-300 w-10">#</th>
                        <th className="p-2.5 border-l border-slate-300 text-right">اسم الصنف (السلاح / الذخيرة)</th>
                        <th className="p-2.5 border-l border-slate-300 text-center">النوع</th>
                        <th className="p-2.5 border-l border-slate-300 text-right">العيار والتصنيف</th>
                        <th className="p-2.5 border-l border-slate-300 text-center font-bold bg-emerald-100/70 text-emerald-950">
                          الرصيد الوارد إلى المخازن
                        </th>
                        <th className="p-2.5 border-l border-slate-300 text-center font-bold bg-amber-100/70 text-amber-950">
                          الرصيد المنصرف
                        </th>
                        <th className="p-2.5 border-l border-slate-300 text-center font-bold bg-blue-100/70 text-blue-950">
                          الرصيد المتوفر بالمخزن
                        </th>
                        <th className="p-2.5 border-l border-slate-300 text-center font-bold">نسبة المنصرف</th>
                        <th className="p-2.5 text-center">الموقف والجاهزية</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-200">
                      {itemStockBalances.length === 0 ? (
                        <tr>
                          <td colSpan={9} className="p-8 text-center text-slate-500 font-bold bg-white">
                            لا توجد أصناف أسلحة أو ذخائر مسجلة بالمخزن حالياً. تظهر في هذا التقرير فقط البيانات والأصناف التي تقوم بإدخالها.
                          </td>
                        </tr>
                      ) : (
                        itemStockBalances.map((itm, idx) => (
                        <tr key={itm.id} className={idx % 2 === 0 ? 'bg-white' : 'bg-slate-50/80'}>
                          <td className="p-2.5 border-l border-slate-200 text-center font-mono font-bold text-slate-700">
                            {idx + 1}
                          </td>
                          <td className="p-2.5 border-l border-slate-200 font-black text-slate-900">
                            {itm.name}
                          </td>
                          <td className="p-2.5 border-l border-slate-200 text-center">
                            <span
                              className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                                itm.itemType === 'سلاح'
                                  ? 'bg-blue-100 text-blue-900 border border-blue-300'
                                  : 'bg-amber-100 text-amber-900 border border-amber-300'
                              }`}
                            >
                              {itm.itemType}
                            </span>
                          </td>
                          <td className="p-2.5 border-l border-slate-200 font-bold text-slate-700">
                            {itm.category} • <span className="font-mono text-slate-800">{itm.caliber}</span>
                          </td>
                          <td className="p-2.5 border-l border-slate-200 text-center font-mono font-black text-emerald-900 bg-emerald-50/50">
                            {itm.totalReceived.toLocaleString('ar-EG')} {itm.unitMeasure}
                          </td>
                          <td className="p-2.5 border-l border-slate-200 text-center font-mono font-black text-amber-900 bg-amber-50/50">
                            {itm.issuedQty.toLocaleString('ar-EG')} {itm.unitMeasure}
                          </td>
                          <td className="p-2.5 border-l border-slate-200 text-center font-mono font-black text-blue-900 bg-blue-50/50">
                            {itm.availableQty.toLocaleString('ar-EG')} {itm.unitMeasure}
                          </td>
                          <td className="p-2.5 border-l border-slate-200 text-center font-mono font-bold">
                            %{itm.consumptionRate}
                          </td>
                          <td className="p-2.5 text-center font-bold">
                            {itm.availableQty <= 10 ? (
                              <span className="bg-rose-100 text-rose-800 border border-rose-300 px-2 py-0.5 rounded text-[10px]">
                                منخفض / تزويد عاجل
                              </span>
                            ) : (
                              <span className="bg-emerald-100 text-emerald-800 border border-emerald-300 px-2 py-0.5 rounded text-[10px]">
                                جاهزية ممتازة ✓
                              </span>
                            )}
                          </td>
                        </tr>
                      )))}
                    </tbody>
                    {/* Totals Row */}
                    <tfoot>
                      <tr className="bg-slate-200 text-slate-900 font-black border-t-2 border-slate-900 text-xs text-center">
                        <td colSpan={4} className="p-3 text-right font-black text-sm">
                          إجمالي الأرصدة الكلية (الوارد والمنصرف والمتوفر):
                        </td>
                        <td className="p-3 font-mono font-black text-emerald-950 text-sm bg-emerald-100/90 border-x border-slate-300">
                          {totalStockReceived.toLocaleString('ar-EG')}
                        </td>
                        <td className="p-3 font-mono font-black text-amber-950 text-sm bg-amber-100/90 border-x border-slate-300">
                          {totalStockIssued.toLocaleString('ar-EG')}
                        </td>
                        <td className="p-3 font-mono font-black text-blue-950 text-sm bg-blue-100/90 border-x border-slate-300">
                          {totalStockAvailable.toLocaleString('ar-EG')}
                        </td>
                        <td colSpan={2} className="p-3 text-center text-slate-700 font-bold text-[11px]">
                          مطابق للسجلات التفتيشية
                        </td>
                      </tr>
                    </tfoot>
                  </table>
                </div>
              </div>
            )}

            {/* REPORT VIEW: FULL INVENTORY (STOCK) */}
            {activeReportType === 'stock' && (
              <div className="space-y-4">
                <h3 className="font-extrabold text-slate-900 text-sm font-['Tajawal'] border-r-4 border-amber-600 pr-2">
                  جدول رصيد الأسلحة والذخائر المحددة بالأمر العسكري (12 صنف رئيسي + الأصناف المضافة)
                </h3>
                
                <div className="overflow-x-auto border border-slate-300 rounded-xl">
                  <table className="w-full text-xs text-right border-collapse">
                    <thead>
                      <tr className="bg-slate-200 text-slate-900 font-black border-b border-slate-300 text-center">
                        <th className="p-2.5 border-l border-slate-300 w-10">#</th>
                        <th className="p-2.5 border-l border-slate-300 text-right">اسم الصنف / قطعة السلاح</th>
                        <th className="p-2.5 border-l border-slate-300 text-right">التصنيف العسكري</th>
                        <th className="p-2.5 border-l border-slate-300 text-right">العيار / الذخيرة</th>
                        <th className="p-2.5 border-l border-slate-300 text-center">الرصيد الوارد الإجمالي</th>
                        <th className="p-2.5 border-l border-slate-300 text-center">المتوفر بالمخزن</th>
                        <th className="p-2.5 border-l border-slate-300 text-center">المنصرف للميدان</th>
                        <th className="p-2.5 border-l border-slate-300 text-center">تحت الصيانة</th>
                        <th className="p-2.5 text-center">الحالة الفنية</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-200">
                      {itemStockBalances.filter((i) => i.itemType === 'سلاح').length === 0 ? (
                        <tr>
                          <td colSpan={9} className="p-8 text-center text-slate-500 font-bold bg-white">
                            لا توجد أسلحة مسجلة بالمخزن حالياً. تظهر في هذا التقرير فقط الأسلحة التي تقوم بإدخالها.
                          </td>
                        </tr>
                      ) : (
                        itemStockBalances.filter((i) => i.itemType === 'سلاح').map((item, idx) => (
                        <tr key={item.name} className={idx % 2 === 0 ? 'bg-white' : 'bg-slate-50/70'}>
                          <td className="p-2.5 border-l border-slate-200 text-center font-mono font-bold">{idx + 1}</td>
                          <td className="p-2.5 border-l border-slate-200 font-black text-slate-900">
                            {item.name}
                          </td>
                          <td className="p-2.5 border-l border-slate-200 text-slate-700 font-bold">{item.category}</td>
                          <td className="p-2.5 border-l border-slate-200 font-mono text-slate-800">{item.caliber}</td>
                          <td className="p-2.5 border-l border-slate-200 text-center font-mono font-extrabold text-slate-900">{item.totalReceived}</td>
                          <td className="p-2.5 border-l border-slate-200 text-center font-mono font-extrabold text-emerald-700">{item.availableQty}</td>
                          <td className="p-2.5 border-l border-slate-200 text-center font-mono font-bold text-blue-700">{item.issuedQty}</td>
                          <td className="p-2.5 border-l border-slate-200 text-center font-mono font-bold text-amber-700">{item.maintenanceQty}</td>
                          <td className="p-2.5 text-center font-bold">
                            {item.availableQty > 10 ? (
                              <span className="text-emerald-800 bg-emerald-100 border border-emerald-300 px-2 py-0.5 rounded-md text-[10px]">جاهزية ممتازة</span>
                            ) : (
                              <span className="text-rose-800 bg-rose-100 border border-rose-300 px-2 py-0.5 rounded-md text-[10px]">ينصح بالتزويد</span>
                            )}
                          </td>
                        </tr>
                      )))}
                    </tbody>
                  </table>
                </div>
              </div>
            )}

            {/* REPORT VIEW: LOW STOCK */}
            {activeReportType === 'low_stock' && (
              <div className="space-y-4">
                <h3 className="font-extrabold text-rose-950 text-sm font-['Tajawal'] border-r-4 border-rose-700 pr-2">
                  بيان حصر الأصناف والذخائر وشيكة النفاد ومستويات العجز الفني
                </h3>

                <div className="overflow-x-auto border border-slate-300 rounded-xl">
                  <table className="w-full text-xs text-right border-collapse">
                    <thead>
                      <tr className="bg-rose-100 text-rose-950 font-black border-b border-rose-300">
                        <th className="p-2.5 border-l border-rose-200 text-center">#</th>
                        <th className="p-2.5 border-l border-rose-200">اسم الصنف والتسليح</th>
                        <th className="p-2.5 border-l border-rose-200">العيار</th>
                        <th className="p-2.5 border-l border-rose-200 text-center">المتوفر حالياً</th>
                        <th className="p-2.5 border-l border-rose-200 text-center">حد الأمان والتنبيه</th>
                        <th className="p-2.5 text-center">التوصية والإجراء المطلوب</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-200">
                      {itemStockBalances.filter((i) => i.availableQty <= 15).map((item, idx) => (
                        <tr key={item.name} className="bg-white">
                          <td className="p-2.5 border-l border-slate-200 text-center font-mono font-bold">{idx + 1}</td>
                          <td className="p-2.5 border-l border-slate-200 font-bold text-slate-900">{item.name}</td>
                          <td className="p-2.5 border-l border-slate-200 font-mono">{item.caliber}</td>
                          <td className="p-2.5 border-l border-slate-200 text-center font-mono font-black text-rose-700">{item.availableQty}</td>
                          <td className="p-2.5 border-l border-slate-200 text-center font-mono font-bold text-slate-700">15</td>
                          <td className="p-2.5 text-center font-bold text-rose-900 bg-rose-50/50">
                            رفع طلب تزويد عاجل من الهيئة العامة للتسليح
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            )}

            {/* REPORT VIEW: MOVEMENT LOG */}
            {activeReportType === 'movement' && (
              <div className="space-y-4">
                <h3 className="font-extrabold text-slate-900 text-sm font-['Tajawal'] border-r-4 border-slate-900 pr-2">
                  بيان حركة الواردات والمستلمات بالمخزن وأوامر الصرف الرسمية
                </h3>

                <div className="overflow-x-auto border border-slate-300 rounded-xl">
                  <table className="w-full text-xs text-right border-collapse">
                    <thead>
                      <tr className="bg-slate-200 text-slate-900 font-black border-b border-slate-300">
                        <th className="p-2.5 border-l border-slate-300 text-center">التاريخ</th>
                        <th className="p-2.5 border-l border-slate-300 text-center">نوع الحركة</th>
                        <th className="p-2.5 border-l border-slate-300">اسم الصنف / السلاح</th>
                        <th className="p-2.5 border-l border-slate-300">الرقم التسلسلي / الدفعة</th>
                        <th className="p-2.5 border-l border-slate-300 text-center">الكمية</th>
                        <th className="p-2.5 border-l border-slate-300">المستلم / الجهة الموردة</th>
                        <th className="p-2.5 text-center">الضابط المسؤول والمعتمد</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-200">
                      {filteredIssues.map((iss) => (
                        <tr key={iss.id} className="bg-white">
                          <td className="p-2.5 border-l border-slate-200 text-center font-mono font-bold text-slate-700">{iss.date}</td>
                          <td className="p-2.5 border-l border-slate-200 text-center">
                            <span className="bg-blue-100 text-blue-900 font-bold px-2 py-0.5 rounded-md text-[10px]">صرف عهدة</span>
                          </td>
                          <td className="p-2.5 border-l border-slate-200 font-bold text-slate-900">{iss.weaponType}</td>
                          <td className="p-2.5 border-l border-slate-200 font-mono font-bold text-amber-900">{iss.weaponSerial || iss.orderNumber}</td>
                          <td className="p-2.5 border-l border-slate-200 text-center font-mono font-black">{iss.issuedAmmoQty} طلقة</td>
                          <td className="p-2.5 border-l border-slate-200 font-bold">{iss.recipientRank} / {iss.recipientName} ({iss.unit})</td>
                          <td className="p-2.5 text-center font-bold text-slate-800">{iss.responsibleOfficer}</td>
                        </tr>
                      ))}
                      {intakes.map((intk) => (
                        <tr key={intk.id} className="bg-emerald-50/50">
                          <td className="p-2.5 border-l border-slate-200 text-center font-mono font-bold text-slate-700">{intk.date}</td>
                          <td className="p-2.5 border-l border-slate-200 text-center">
                            <span className="bg-emerald-100 text-emerald-900 font-bold px-2 py-0.5 rounded-md text-[10px]">استلام توريد</span>
                          </td>
                          <td className="p-2.5 border-l border-slate-200 font-bold text-slate-900">{intk.name}</td>
                          <td className="p-2.5 border-l border-slate-200 font-mono text-slate-700">{intk.batchNumber}</td>
                          <td className="p-2.5 border-l border-slate-200 text-center font-mono font-black text-emerald-800">+{intk.quantity} قطعة</td>
                          <td className="p-2.5 border-l border-slate-200 font-bold text-slate-700">{intk.source}</td>
                          <td className="p-2.5 text-center font-bold text-slate-800">{intk.receivedBy}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            )}

            {/* REPORT VIEW: PERSONNEL READINESS */}
            {activeReportType === 'personnel' && (
              <div className="space-y-4">
                <h3 className="font-extrabold text-slate-900 text-sm font-['Tajawal'] border-r-4 border-emerald-700 pr-2">
                  كشف تسليح الأفراد والعهد الشخصية المسجلة بالتسليح (الوحدة: {selectedUnit} • الكتيبة: {selectedBattalion})
                </h3>

                <div className="overflow-x-auto border border-slate-300 rounded-xl">
                  <table className="w-full text-xs text-right border-collapse">
                    <thead>
                      <tr className="bg-slate-200 text-slate-900 font-black border-b border-slate-300">
                        <th className="p-2.5 border-l border-slate-300 text-center">الرقم العسكري</th>
                        <th className="p-2.5 border-l border-slate-300">اسم الفرد</th>
                        <th className="p-2.5 border-l border-slate-300">الرتبة والوحدة</th>
                        <th className="p-2.5 border-l border-slate-300">السلاح المسلم</th>
                        <th className="p-2.5 border-l border-slate-300">الرقم التسلسلي</th>
                        <th className="p-2.5 border-l border-slate-300 text-center">الذخيرة والمخازن</th>
                        <th className="p-2.5 border-l border-slate-300 text-center">الجعبة والخوذة</th>
                        <th className="p-2.5 text-center">حالة الفرد</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-200">
                      {armedPersonnelList.length === 0 ? (
                        <tr>
                          <td colSpan={8} className="p-8 text-center text-slate-500 font-bold bg-white">
                            لا توجد عهد أسلحة مسجلة للأفراد مطابقة لمعايير البحث الحالية. تظهر في هذا الكشف فقط الأسلحة والعهد التي تقوم بإدخالها فعلياً.
                          </td>
                        </tr>
                      ) : (
                        armedPersonnelList.map((p) => (
                        <tr key={p.id} className="bg-white hover:bg-slate-50">
                          <td className="p-2.5 border-l border-slate-200 text-center font-mono font-bold text-slate-900">{p.militaryId}</td>
                          <td className="p-2.5 border-l border-slate-200 font-black text-slate-900">{p.name}</td>
                          <td className="p-2.5 border-l border-slate-200 font-bold text-slate-700">{p.rank} • {p.unit}</td>
                          <td className="p-2.5 border-l border-slate-200 font-bold text-amber-900">{p.weaponType}</td>
                          <td className="p-2.5 border-l border-slate-200 font-mono font-bold text-slate-800">{p.weaponSerial}</td>
                          <td className="p-2.5 border-l border-slate-200 text-center font-mono font-bold">
                            {p.ammoCount} طلقة ({p.magsCount} مخزن)
                          </td>
                          <td className="p-2.5 border-l border-slate-200 text-center font-bold text-[11px]">
                            {p.hasVest ? 'جعبة ✅' : '❌'} | {p.hasHelmet ? 'خوذة ✅' : '❌'}
                          </td>
                          <td className="p-2.5 text-center font-bold">
                            <span
                              className={`px-2 py-0.5 rounded-md text-[10px] ${
                                (p.status as string) === 'فرار بالسلاح'
                                  ? 'bg-rose-100 text-rose-900 border border-rose-400 font-black'
                                  : p.status === 'في الميدان'
                                  ? 'bg-blue-100 text-blue-900 border border-blue-300'
                                  : 'bg-emerald-100 text-emerald-900 border border-emerald-300'
                              }`}
                            >
                              {p.status}
                            </span>
                          </td>
                        </tr>
                      )))}
                    </tbody>
                    <tfoot>
                      <tr className="bg-slate-100 text-slate-950 font-black border-t-2 border-slate-900 text-xs">
                        <td colSpan={3} className="p-3 text-right font-black text-sm">
                          المجموع الإجمالي لفرع التسليح (كشف عهد الأفراد):
                        </td>
                        <td colSpan={2} className="p-3 font-bold text-amber-950">
                          إجمالي الأسلحة المنصرفة: {personnelTotals.totalWeapons} قطعة ({personnelTotals.armedCount} فرد مسلح)
                        </td>
                        <td className="p-3 text-center font-mono font-black text-emerald-900 bg-amber-50/80 border-x border-slate-300">
                          {personnelTotals.totalAmmo.toLocaleString('ar-EG')} طلقة ({personnelTotals.totalMags} مخزن)
                        </td>
                        <td colSpan={2} className="p-3 text-left font-mono text-[11px] text-slate-600">
                          مطابق للسجلات الرسمية
                        </td>
                      </tr>
                    </tfoot>
                  </table>
                </div>
              </div>
            )}

            {/* Official Military Signatures Block */}
            <div
              className={`grid gap-6 text-xs font-bold text-slate-900 pt-8 border-t-2 border-slate-900 text-center signature-block ${
                signatories.length === 1
                  ? 'grid-cols-1 max-w-xs mx-auto'
                  : signatories.length === 2
                  ? 'grid-cols-2 max-w-xl mx-auto'
                  : signatories.length === 4
                  ? 'grid-cols-2 sm:grid-cols-4'
                  : signatories.length >= 5
                  ? 'grid-cols-2 sm:grid-cols-3 md:grid-cols-5'
                  : 'grid-cols-3'
              }`}
            >
              {signatories.map((officer) => (
                <div key={officer.id} className="space-y-2">
                  {officer.title.trim() !== '' && (
                    <p className="font-black text-xs sm:text-sm text-slate-900">{officer.title}</p>
                  )}
                  <p className="text-slate-800 font-extrabold text-xs">
                    {officer.name.trim() !== '' ? officer.name : '................................'}
                  </p>
                  <p className="text-slate-400 text-[10px] pt-2">التوقيع والختم: ................................</p>
                </div>
              ))}
            </div>

            {/* Verification Footer */}
            <div className="text-center pt-4 border-t border-slate-200 text-[10px] text-slate-500 font-mono">
              نظام الإدارة العسكرية لفرع التسليح • هذا المستند معتمد ومقيد بقاعدة البيانات رسمياً • كود التوثيق: {reportSerial}
            </div>

          </div>

        </div>

        {/* Floating Sticky Bottom Bar for Quick Return & Print */}
        <div className="sticky bottom-0 z-30 bg-slate-950 text-white p-3.5 rounded-b-3xl border-t-2 border-amber-500/80 shadow-2xl flex items-center justify-between gap-3 print:hidden no-print backdrop-blur-md shrink-0">
          <div className="flex items-center space-x-2 space-x-reverse text-xs text-slate-300 font-medium">
            <Printer className="w-4 h-4 text-amber-400" />
            <span className="font-bold hidden sm:inline text-amber-300 font-['Tajawal']">
              تقرير فرع التسليح والعتاد • الوحدة: {selectedUnit}
            </span>
          </div>

          <div className="flex items-center space-x-2 space-x-reverse">
            <button
              type="button"
              onClick={handlePrint}
              className="bg-amber-600 hover:bg-amber-700 active:scale-95 text-white font-extrabold px-5 py-2 rounded-xl text-xs transition-all shadow-md cursor-pointer flex items-center space-x-1.5 space-x-reverse"
            >
              <Printer className="w-4 h-4" />
              <span>أمر الطباعة 🖨️</span>
            </button>

            <button
              type="button"
              onClick={handleSharePdf}
              className="bg-sky-600 hover:bg-sky-500 active:scale-95 text-white font-bold px-4 py-2 rounded-xl text-xs transition-all shadow-md flex items-center space-x-1.5 space-x-reverse cursor-pointer"
              title="مشاركة أو حفظ التقرير بصيغة PDF / تقرير معتمد"
            >
              <Share2 className="w-4 h-4" />
              <span>مشاركة / حفظ PDF 📄</span>
            </button>

            <button
              type="button"
              onClick={onClose}
              className="bg-slate-800 hover:bg-slate-700 text-amber-300 hover:text-white border border-amber-500/50 font-extrabold px-4 py-2 rounded-xl text-xs transition-all shadow-md flex items-center space-x-1.5 space-x-reverse cursor-pointer"
            >
              <ArrowRight className="w-4 h-4 text-amber-400" />
              <span>العودة للقائمة السابقة ↩️</span>
            </button>
          </div>
        </div>

      </div>
    </div>,
    document.body
  );
};
