<div align="center">
<img width="1200" height="475" alt="GHBanner" src="https://ai.google.dev/static/site-assets/images/share-ais-513315318.png" />
</div>

# Run and deploy your AI Studio app

This contains everything you need to run your app locally.

View your app in AI Studio: https://ai.studio/apps/b1dfd52f-22d9-4efb-b8d8-010b54cf94a4

## Run Locally

**Prerequisites:**  Node.js


1. Install dependencies:
   `npm install`
2. Set the `GEMINI_API_KEY` in [.env.local](.env.local) to your Gemini API key
3. Run the app:
   `npm run dev`


## Local-only update notes
- Firestore/Firebase synchronization is disabled; records are intended to remain in this device's local IndexedDB/LocalStorage.
- Startup now waits for local database hydration before mounting the app to reduce empty-screen/empty-record startup races.
- Report export now generates a PDF file; Excel import/export remains based on the existing XLSX implementation.
- Keep regular JSON backups. Browser/PWA local storage is tied to the same app origin and installed-app profile; opening a different origin/profile may show a separate local dataset.
