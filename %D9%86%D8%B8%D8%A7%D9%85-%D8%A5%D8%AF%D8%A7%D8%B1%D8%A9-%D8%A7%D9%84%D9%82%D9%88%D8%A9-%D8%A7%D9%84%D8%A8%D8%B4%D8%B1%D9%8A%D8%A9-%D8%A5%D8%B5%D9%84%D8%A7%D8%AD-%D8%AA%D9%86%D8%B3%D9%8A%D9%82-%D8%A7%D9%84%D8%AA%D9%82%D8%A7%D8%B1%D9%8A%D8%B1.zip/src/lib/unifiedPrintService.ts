import { Printer } from '@capgo/capacitor-printer';

/**
 * Unified Print & Document Preparation Service
 * Designed specifically for multi-environment compatibility:
 * - Web browsers & Google AI Studio Preview
 * - Android (Capacitor / Android WebView)
 * - Windows (Electron / WebView2 / PWA)
 *
 * Guarantees that:
 * 1. Document content, fonts, and images are fully decoded and rendered before printing begins.
 * 2. Report content is never cleared or unmounted prematurely.
 * 3. Fallbacks (Share Sheet, Standalone Document Export) are provided if the platform's WebView disables window.print().
 */

export interface UnifiedPrintOptions {
  element: HTMLElement | null;
  documentTitle?: string;
  orientation?: 'portrait' | 'landscape';
  onBeforePrint?: () => void;
  onAfterPrint?: () => void;
}

export interface UnifiedPrintResult {
  success: boolean;
  method: 'native_print' | 'share_document' | 'file_export' | 'fallback';
  message?: string;
  error?: any;
}

/**
 * Prepares the DOM element for printing:
 * Waits for Arabic web fonts, all image elements, and QR code canvases to be fully decoded.
 */
export async function preparePrintableDocument(target: HTMLElement | null): Promise<boolean> {
  if (!target) return false;

  try {
    // 1. Wait for document fonts to load completely
    if (document.fonts && typeof document.fonts.ready?.then === 'function') {
      try {
        await document.fonts.ready;
      } catch (fontErr) {
        console.warn('[PrintService] Font ready check warning:', fontErr);
      }
    }

    // 2. Wait for all <img> tags inside target to finish decoding
    const images = Array.from(target.querySelectorAll('img'));
    if (images.length > 0) {
      await Promise.all(
        images.map((img) => {
          if (img.complete && img.naturalWidth > 0) return Promise.resolve();
          return new Promise<void>((resolve) => {
            if (typeof img.decode === 'function') {
              img.decode().then(() => resolve()).catch(() => resolve());
            } else {
              img.onload = () => resolve();
              img.onerror = () => resolve();
            }
            // Absolute safety timeout of 1200ms per image to prevent hanging
            setTimeout(resolve, 1200);
          });
        })
      );
    }

    // 3. Small frame pause for CSS reflow and QR code canvases to flush
    await new Promise((r) => requestAnimationFrame(() => setTimeout(r, 60)));

    return true;
  } catch (err) {
    console.warn('[PrintService] Error during document preparation:', err);
    return true; // continue anyway
  }
}

/**
 * Executes unified printing with automatic platform detection and safe cleanup.
 * Supports both executeUnifiedPrint({ element, ... }) and executeUnifiedPrint(element, { ... }).
 */
export async function executeUnifiedPrint(
  targetOrOptions: HTMLElement | null | UnifiedPrintOptions,
  secondaryOptions?: Omit<UnifiedPrintOptions, 'element'>
): Promise<UnifiedPrintResult> {
  let element: HTMLElement | null = null;
  let documentTitle = 'تقرير عسكري رسمي';
  let orientation: 'portrait' | 'landscape' = 'portrait';
  let onBeforePrint: (() => void) | undefined;
  let onAfterPrint: (() => void) | undefined;

  if (targetOrOptions && 'nodeType' in targetOrOptions) {
    element = targetOrOptions as HTMLElement;
    if (secondaryOptions) {
      documentTitle = secondaryOptions.documentTitle || documentTitle;
      orientation = secondaryOptions.orientation || orientation;
      onBeforePrint = secondaryOptions.onBeforePrint;
      onAfterPrint = secondaryOptions.onAfterPrint;
    }
  } else if (targetOrOptions && typeof targetOrOptions === 'object') {
    const opts = targetOrOptions as UnifiedPrintOptions;
    element = opts.element;
    documentTitle = opts.documentTitle || documentTitle;
    orientation = opts.orientation || orientation;
    onBeforePrint = opts.onBeforePrint;
    onAfterPrint = opts.onAfterPrint;
  }

  if (!element) {
    return {
      success: false,
      method: 'fallback',
      message: 'لم يتم العثور على محتوى المستند المراد طباعته.'
    };
  }

  await preparePrintableDocument(element);
  try {
    onBeforePrint?.();
    // Use the same standalone HTML document for Android and desktop. This avoids
    // printing the app's full screen/root (which can produce a blank preview).
    const printed = await shareOrSavePrintableDocument(element, {
      title: documentTitle,
      orientation
    });
    return {
      success: printed,
      method: printed ? 'native_print' : 'fallback',
      message: printed
        ? 'تم إرسال المستند إلى نافذة الطباعة. اختر الطابعة أو حفظ بصيغة PDF.'
        : 'تعذرت الطباعة مباشرة. حاول مرة أخرى أو استخدم خيار مشاركة/حفظ المستند.',
    };
  } catch (error) {
    console.error('[PrintService] Print failed:', error);
    return {
      success: false,
      method: 'fallback',
      message: 'تعذرت الطباعة. يرجى إعادة المحاولة.',
      error
    };
  } finally {
    try {
      onAfterPrint?.();
    } catch (callbackError) {
      console.warn('[PrintService] onAfterPrint error:', callbackError);
    }
  }
}

/**
 * Builds a standalone, self-contained HTML document with all inline styles and fonts,
 * and shares it (Android share sheet with native print options) or downloads it.
 */
export async function shareOrSavePrintableDocument(
  element: HTMLElement | null,
  titleOrOptions: string | { title?: string; filename?: string; orientation?: 'portrait' | 'landscape' },
  orientationParam: 'portrait' | 'landscape' = 'portrait'
): Promise<boolean> {
  if (!element) return false;

  try {
    let documentTitle = 'وثيقة عسكرية رسمية';
    let fileName = '';
    let orientation: 'portrait' | 'landscape' = orientationParam;

    if (typeof titleOrOptions === 'string') {
      documentTitle = titleOrOptions;
      const cleanTitle = documentTitle.replace(/[/\\?%*:|"<>]/g, '_');
      fileName = `${cleanTitle}.html`;
    } else if (titleOrOptions && typeof titleOrOptions === 'object') {
      if (titleOrOptions.title) documentTitle = titleOrOptions.title;
      if (titleOrOptions.orientation) orientation = titleOrOptions.orientation;
      if (titleOrOptions.filename) {
        fileName = titleOrOptions.filename;
      } else {
        fileName = `${documentTitle.replace(/[/\\?%*:|"<>]/g, '_')}.html`;
      }
    }

    const cleanTitle = documentTitle.replace(/[/\\?%*:|"<>]/g, '_');
    if (!fileName) fileName = `${cleanTitle}.html`;

    // Clone element to sanitize for standalone document
    const clone = element.cloneNode(true) as HTMLElement;

    // Remove no-print and interactive action buttons inside the clone
    const removeSelectors = ['.no-print', '.print\\:hidden', '[data-no-print]', 'button', 'input', 'select'];
    removeSelectors.forEach((sel) => {
      clone.querySelectorAll(sel).forEach((el) => el.remove());
    });

    const isLandscape = orientation === 'landscape';

    // Copy the application's compiled CSS into the standalone print document.
    // The old implementation relied on Tailwind CDN, which may not load inside
    // Android/Windows native print WebViews before the print dialog is opened.
    const embeddedAppStyles = Array.from(document.styleSheets).map((sheet) => {
      try {
        return Array.from(sheet.cssRules).map((rule) => rule.cssText).join('\\n');
      } catch (styleError) {
        // Cross-origin stylesheets cannot be read; retain a link fallback below.
        return '';
      }
    }).filter(Boolean).join('\\n');

    const externalStyleLinks = Array.from(document.querySelectorAll('link[rel="stylesheet"]'))
      .map((link) => {
        const href = (link as HTMLLinkElement).href;
        try {
          const url = new URL(href, document.baseURI);
          return url.origin === window.location.origin ? `<link rel="stylesheet" href="${url.href}">` : '';
        } catch {
          return '';
        }
      }).filter(Boolean).join('\\n');

    const standaloneHtml = `<!DOCTYPE html>
<html dir="rtl" lang="ar">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>${cleanTitle}</title>
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Cairo:wght@400;600;700;800;900&family=Tajawal:wght@400;500;700;800;900&display=swap" rel="stylesheet">
  ${externalStyleLinks}
  <style id="embedded-application-styles">
    ${embeddedAppStyles}
  </style>
  <style id="standalone-print-base">
    * { box-sizing: border-box; -webkit-print-color-adjust: exact !important; print-color-adjust: exact !important; }
    body {
      background: #ffffff;
      color: #0f172a;
      font-family: 'Cairo', 'Tajawal', system-ui, -apple-system, sans-serif;
      margin: 0;
      padding: 16px;
      direction: rtl;
    }
    @page {
      size: A4 ${isLandscape ? 'landscape' : 'portrait'};
      margin: 8mm;
    }
    @media print {
      body { padding: 0; }
      .standalone-toolbar { display: none !important; }
      table { page-break-inside: auto; }
      tr { page-break-inside: avoid; page-break-after: auto; }
      thead { display: table-header-group; }
      tfoot { display: table-row-group; }
    }
    table { width: 100%; border-collapse: collapse; }
    th, td { border: 1px solid #cbd5e1; padding: 6px 8px; }
    th { background-color: #f1f5f9; font-weight: 800; }
  </style>
</head>
<body>
  <!-- Print Control Banner for Standalone View -->
  <div class="standalone-toolbar mb-6 p-4 bg-slate-900 text-white rounded-2xl flex flex-wrap items-center justify-between gap-3 shadow-xl border-2 border-emerald-500">
    <div>
      <div class="font-black text-sm text-amber-300">🖨️ وثيقة رسمية جاهزة للطباعة والحفظ (A4)</div>
      <div class="text-xs text-slate-300">${cleanTitle} • تم إعداد المستند بدقة عالية</div>
    </div>
    <div class="flex items-center gap-2">
      <button onclick="window.print()" class="bg-emerald-600 hover:bg-emerald-500 text-white font-black px-5 py-2.5 rounded-xl text-xs cursor-pointer shadow-lg active:scale-95 transition-all">
        طباعة المستند الآن 🖨️
      </button>
      <button onclick="window.close()" class="bg-slate-800 hover:bg-slate-700 text-slate-300 font-bold px-3 py-2.5 rounded-xl text-xs cursor-pointer">
        إغلاق
      </button>
    </div>
  </div>

  <div class="max-w-[1100px] mx-auto bg-white">
    ${clone.innerHTML}
  </div>

  <script>
    // Auto-trigger print prompt on load in desktop viewers
    window.onload = function() {
      if (window.location.search.includes('autoprint=true')) {
        setTimeout(function() { window.print(); }, 500);
      }
    };
  </script>
</body>
</html>`;

    // Prefer the native print framework in Capacitor and the isolated iframe
    // print flow on desktop/web. Both receive a complete HTML document, not the
    // app root, which prevents the blank-preview issue seen in WebViews.
    try {
      await Printer.printHtml({ name: cleanTitle, html: standaloneHtml });
      return true;
    } catch (nativePrintError) {
      console.warn('[PrintService] Printer plugin unavailable; using share/download fallback:', nativePrintError);
    }

    const blob = new Blob([standaloneHtml], { type: 'text/html;charset=utf-8;' });
    const isMobile = /Android|iPhone|iPad|iPod|Mobile/i.test(navigator.userAgent);

    // If on Mobile / Android, use Web Share API to send the file to Android Print Service / Google Drive / PDF reader
    if (isMobile && typeof navigator.share === 'function') {
      try {
        const file = new File([blob], fileName, { type: 'text/html' });
        if (typeof navigator.canShare === 'function' && navigator.canShare({ files: [file] })) {
          await navigator.share({
            files: [file],
            title: cleanTitle,
            text: `وثيقة طباعة رسمية: ${cleanTitle}`
          });
          return true;
        }
      } catch (shareErr: any) {
        if (shareErr.name === 'AbortError') return true;
        console.warn('Share document failed, falling back to download:', shareErr);
      }
    }

    // Desktop / Windows fallback: download the standalone file
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = fileName;
    document.body.appendChild(a);
    a.click();
    setTimeout(() => {
      if (document.body.contains(a)) document.body.removeChild(a);
      URL.revokeObjectURL(url);
    }, 4000);

    return true;
  } catch (err) {
    console.error('[PrintService] Failed to share or save standalone document:', err);
    return false;
  }
}
