import { executeUnifiedPrintFromButton } from '../lib/unifiedPrintService';
import React, { useState } from 'react';
import {
  ArrowRight,
  Shield,
  Activity,
  DollarSign,
  Lock,
  Crosshair,
  Award,
  Paperclip,
  Clock,
  Plus,
  FileText,
  Printer,
  Calendar,
  CheckCircle2,
  AlertCircle,
  Building,
  Upload,
  UserCheck,
  Package,
  Trash2,
  Scan,
  ShieldCheck,
  ArrowRightLeft,
  Camera,
  Edit3,
  Check,
  GraduationCap,
  Gift,
  AlertTriangle
} from 'lucide-react';
import { FaceVerificationModal, FaceVerificationResult } from './FaceVerificationModal';
import { ApprovalVoucherModal, VoucherData } from './ApprovalVoucherModal';
import { StatusChangeModal } from './StatusChangeModal';
import { ImageUploadPicker } from './ImageUploadPicker';
import { PersonnelAvatar } from './PersonnelAvatar';
import {
  PersonnelRecord,
  DepartmentRole,
  PersonnelStatus,
  MovementLog,
  AttendanceLog,
  MedicalLog,
  FinancialLog,
  SecurityLog,
  ArmamentLog,
  TrainingLog,
  PersonnelAttachment,
  SupplyLog
} from '../types';
import { StorageService } from '../lib/storage';
import { compressImageFile, compressBase64Image } from '../lib/imageUtils';
import {
  getPersonnelCustodies,
  getPersonnelChronologicalDispenses,
  getStatusBadgeConfig
} from '../lib/personnelUtils';

interface PersonnelProfileViewProps {
  personnel: PersonnelRecord;
  onBack: () => void;
  onRefresh: () => void;
  currentRole: DepartmentRole;
  onPrintProfile: (p: PersonnelRecord) => void;
  onEditPersonnel?: (p: PersonnelRecord) => void;
  onDeletePersonnel?: (militaryId: string, name: string) => void;
}

export const PersonnelProfileView: React.FC<PersonnelProfileViewProps> = ({
  personnel,
  onBack,
  onRefresh,
  currentRole,
  onPrintProfile,
  onEditPersonnel,
  onDeletePersonnel
}) => {
  const [activeTab, setActiveTab] = useState<
    'custody' | 'chronologicalDispenses' | 'movement' | 'attendance' | 'medical' | 'financial' | 'security' | 'armament' | 'supply' | 'training' | 'attachments'
  >('custody');

  // Modal forms states for adding new log items
  const [showAddModal, setShowAddModal] = useState(false);
  const [showPhotoModal, setShowPhotoModal] = useState(false);
  const [tempPhotoUrl, setTempPhotoUrl] = useState(personnel.photoUrl);
  const [successToast, setSuccessToast] = useState<string | null>(null);

  // Quick form states
  const [formType, setFormType] = useState<string>('');
  const [formText1, setFormText1] = useState('');
  const [formText2, setFormText2] = useState('');
  const [formText3, setFormText3] = useState('');
  const [formNum1, setFormNum1] = useState<number>(0);
  const [formDate1, setFormDate1] = useState(new Date().toISOString().split('T')[0]);

  // Dedicated Security modal states
  const [secViolation, setSecViolation] = useState('');
  const [secDetails, setSecDetails] = useState('');
  const [secPenalty, setSecPenalty] = useState('إنذار مسلكي رسمي');
  const [secWarningLevel, setSecWarningLevel] = useState<'منخفض' | 'متوسط' | 'عالي' | 'حرج'>('عالي');
  const [secStatus, setSecStatus] = useState<'قيد التحقيق' | 'تم البت' | 'محال للنيابة العسكرية' | 'منتهي'>('تم البت');
  const [secDetain, setSecDetain] = useState(false);
  const [secFileUrl, setSecFileUrl] = useState('');
  const [secFileName, setSecFileName] = useState('');
  const [attFileUrl, setAttFileUrl] = useState('');
  const [attFileName, setAttFileName] = useState('');
  const [dispensesFilterQuery, setDispensesFilterQuery] = useState('');
  const [previewImageModal, setPreviewImageModal] = useState<string | null>(null);
  const [showFaceVerificationModal, setShowFaceVerificationModal] = useState(false);
  const [lastFaceVerification, setLastFaceVerification] = useState<FaceVerificationResult | null>(null);

  // Approval Voucher Modal state & handlers
  const [showVoucherModal, setShowVoucherModal] = useState<boolean>(false);
  const [voucherData, setVoucherData] = useState<VoucherData | null>(null);
  const [showStatusChangeModal, setShowStatusChangeModal] = useState<boolean>(false);

  // Dedicated Financial Advance & Grant Modal states
  const [showGrantModal, setShowGrantModal] = useState<boolean>(false);
  const [grantType, setGrantType] = useState<'سلفة مالية' | 'مساعدة مالية'>('سلفة مالية');
  const [grantAmount, setGrantAmount] = useState<number>(1000);
  const [grantDate, setGrantDate] = useState<string>(new Date().toISOString().split('T')[0]);
  const [grantMonth, setGrantMonth] = useState<string>(new Date().toISOString().slice(0, 7));
  const [grantReason, setGrantReason] = useState<string>('');
  const [grantNotes, setGrantNotes] = useState<string>('معتمد للصرف وفق الضوابط والتعليمات المالية');
  const [grantOfficer, setGrantOfficer] = useState<string>('القيادة المالية');
  const [grantSubmitting, setGrantSubmitting] = useState<boolean>(false);

  const printAttendanceVoucher = (att: AttendanceLog) => {
    const refNum = `ATT-${att.id.slice(-6)}-${Math.floor(1000 + Math.random() * 9000)}`;
    const fromDate = att.startDate || att.date;
    const toDate = att.endDate || 'سارية حتى الآن';
    const voucher: VoucherData = {
      id: `VCH-${att.id}`,
      type: att.type === 'إجازة' ? 'leave' : 'permission',
      title: `سند توثيق واعتماد فترة حالة (${att.type})`,
      personnel,
      startDate: fromDate,
      endDate: toDate,
      duration: `${att.durationDays} يوم`,
      details: att.reason || `تقييد حالة (${att.type}) من تاريخ [${fromDate}] إلى تاريخ [${toDate}] (${att.durationDays} يوم)`,
      approvedBy: att.approvedBy || currentRole,
      department: currentRole,
      timestamp: `${att.date} 09:00:00`,
      referenceNumber: refNum,
      additionalInfo: [
        { label: 'حالة التمام والجاهزية', value: att.type },
        { label: 'من تاريخ', value: fromDate },
        { label: 'إلى تاريخ', value: toDate },
        { label: 'المدة المقيدة', value: `${att.durationDays} يوم` },
        { label: 'الضابط / الجهة المصادقة', value: att.approvedBy || currentRole },
        { label: 'الملاحظات الإدارية', value: att.notes || 'موثقة ومقيدة بملف الفرد الإلكتروني' }
      ]
    };
    setVoucherData(voucher);
    setShowVoucherModal(true);
  };

  const printMedicalVoucher = (med: MedicalLog) => {
    const refNum = `MED-${med.id.slice(-6)}-${Math.floor(1000 + Math.random() * 9000)}`;
    const voucher: VoucherData = {
      id: `VCH-${med.id}`,
      type: 'medical',
      title: med.sickLeaveDays > 0 ? 'سند منح إجازة مرضية وتوثيق طبي' : 'سند مصادقة وتقرير طبي معتمد',
      personnel,
      startDate: med.date,
      endDate: med.recoveryEndDate || 'حسب التقرير الطبي',
      duration: med.sickLeaveDays > 0 ? `${med.sickLeaveDays} أيام` : 'تقييم طبي',
      details: `التشخيص الطبي: ${med.diagnosis} | المستشفى: ${med.hospital} | الطبيب: ${med.doctor}`,
      approvedBy: med.doctor || 'طبيب الفرع الطبي',
      department: 'الخدمات الطبية العسكرية',
      timestamp: `${med.date} 10:00:00`,
      referenceNumber: refNum,
      additionalInfo: [
        { label: 'المستشفى المعالج', value: med.hospital },
        { label: 'الطبيب المعالج', value: med.doctor },
        { label: 'مدة الإجازة المرضية', value: `${med.sickLeaveDays} أيام` },
        { label: 'وصف العلاج', value: med.prescriptionDetails || 'علاج وتأهيل طبي' }
      ]
    };
    setVoucherData(voucher);
    setShowVoucherModal(true);
  };

  const printTrainingVoucher = (trn: TrainingLog) => {
    const refNum = `TRN-${trn.id.slice(-6)}-${Math.floor(1000 + Math.random() * 9000)}`;
    const voucher: VoucherData = {
      id: `VCH-${trn.id}`,
      type: 'training',
      title: 'سند اعتماد وتسجيل دورة تدريبية تخصصية',
      personnel,
      startDate: trn.startDate || new Date().toISOString().split('T')[0],
      endDate: trn.endDate || 'حسب البرنامج التدريبي',
      duration: 'دورة تأهيلية تخصصية',
      details: `اسم الدورة: ${trn.courseName} | الجهة: ${trn.provider} | التقييم: ${trn.evaluation}`,
      approvedBy: trn.provider || 'فرع التدريب والعمليات',
      department: 'التدريب والعمليات',
      timestamp: `${trn.startDate || new Date().toISOString().split('T')[0]} 08:30:00`,
      referenceNumber: refNum,
      additionalInfo: [
        { label: 'تقدير الدورة', value: trn.grade || 'معتمد' },
        { label: 'الشهادة الممنوحة', value: trn.certificates || 'شهادة دورة رسمية' }
      ]
    };
    setVoucherData(voucher);
    setShowVoucherModal(true);
  };

  const printFinancialVoucher = (fin: FinancialLog) => {
    const isAdvance = fin.grantType === 'سلفة مالية' || fin.type === 'سلفة' || fin.type === 'سلفة مالية' || fin.isDeductedFromSalary;
    const isAid = fin.grantType === 'مساعدة مالية' || fin.type === 'مساعدة مالية';
    const refNum = fin.voucherNumber || `FIN-${isAdvance ? 'LOAN' : 'GRANT'}-${fin.id.slice(-6)}-${Math.floor(1000 + Math.random() * 9000)}`;
    const voucher: VoucherData = {
      id: `VCH-${fin.id}`,
      type: isAdvance ? 'financial_advance' : (isAid ? 'financial_grant' : 'financial'),
      title: isAdvance ? 'سند صرف سلفة مالية واحتساب خصم مسير' : (isAid ? 'سند منح مساعدة مالية رسمية (غير مستردة)' : `سند قيد مالي معتمد (${fin.type})`),
      personnel,
      timestamp: `${fin.transactionDate || fin.date || new Date().toISOString().split('T')[0]} 10:00:00`,
      referenceNumber: refNum,
      department: 'الإدارة والقيادة المالية',
      approvedBy: fin.approvedBy || currentRole || 'القيادة المالية',
      details: `${fin.grantType || fin.type}: ${fin.reason} بمبلغ (${(fin.amount || 0).toLocaleString('ar-SA')} ر.س)`,
      additionalInfo: [
        { label: 'نوع المعاملة المالية', value: fin.grantType || fin.type },
        { label: 'المبلغ المعتمد للصرف', value: `${(fin.amount || 0).toLocaleString('ar-SA')} ريال سعودي` },
        { label: 'تاريخ الصرف والمنح', value: fin.date || fin.transactionDate },
        { label: 'شهر المسير المالي', value: fin.monthYear || (fin.date ? fin.date.slice(0, 7) : '-') },
        {
          label: 'حالة الخصم من المرتب',
          value: isAdvance
            ? `⚠️ سلفة مستقطعة من مرتب شهر (${fin.monthYear || (fin.date ? fin.date.slice(0, 7) : '-')})`
            : (isAid ? '✅ مساعدة مالية غير مستردة (لا تُخصم من المرتب)' : 'معاملة مالية مقيدة')
        },
        { label: 'المبرر والسبب الرسمي', value: fin.reason },
        { label: 'الضابط / الجهة المعتمدة', value: fin.approvedBy || currentRole || 'القيادة المالية' },
        { label: 'الملاحظات والتوجيهات', value: fin.notes || 'معتمد ومقيد رسمياً بملف الفرد الإلكتروني' }
      ]
    };
    setVoucherData(voucher);
    setShowVoucherModal(true);
  };

  const handleGrantSubmitInProfile = (e: React.FormEvent) => {
    e.preventDefault();
    if (grantAmount <= 0) {
      alert('يرجى إدخال مبلغ مالي صحيح أكبر من الصفر!');
      return;
    }
    setGrantSubmitting(true);
    try {
      const res = StorageService.grantFinancialAidOrAdvance({
        militaryId: personnel.militaryId,
        grantType,
        amount: grantAmount,
        monthYear: grantMonth || grantDate.slice(0, 7),
        date: grantDate,
        reason: grantReason.trim() || (grantType === 'سلفة مالية' ? 'طلب سلفة مالية مؤقتة على المرتب' : 'مساعدة وإعانة مالية استثنائية'),
        notes: grantNotes.trim() || 'معتمد ومقيد بملف الفرد الإلكتروني',
        actingUser: grantOfficer || currentRole || 'القيادة المالية',
        actingDept: 'الإدارة المالية'
      });

      if (res.success && res.record) {
        setShowGrantModal(false);
        setGrantReason('');
        setGrantNotes('معتمد للصرف وفق الضوابط والتعليمات المالية');
        setSuccessToast(res.message);
        onRefresh();

        // Immediately open official military voucher for viewing and printing
        const isAdvance = res.record.grantType === 'سلفة مالية';
        const voucher: VoucherData = {
          id: res.record.id,
          type: isAdvance ? 'financial_advance' : 'financial_grant',
          title: isAdvance ? 'سند صرف سلفة مالية واحتساب خصم مسير' : 'سند منح مساعدة مالية رسمية (غير مستردة)',
          personnel,
          timestamp: res.record.createdAt || new Date().toISOString(),
          referenceNumber: res.record.voucherNumber,
          department: 'الإدارة المالية',
          approvedBy: res.record.approvedBy || currentRole || 'القيادة المالية',
          details: `${res.record.grantType}: ${res.record.reason} بمبلغ (${res.record.amount.toLocaleString('ar-SA')} ر.س)`,
          additionalInfo: [
            { label: 'نوع المعاملة المالية', value: res.record.grantType },
            { label: 'المبلغ المعتمد للصرف', value: `${res.record.amount.toLocaleString('ar-SA')} ريال سعودي` },
            { label: 'شهر المسير المالي', value: res.record.monthYear },
            { label: 'تاريخ الصرف والمنح', value: res.record.date },
            {
              label: 'حالة الخصم من المرتب',
              value: isAdvance
                ? `⚠️ سلفة مستقطعة من مرتب شهر (${res.record.monthYear})`
                : '✅ مساعدة مالية غير مستردة (لا تُخصم من المرتب)'
            },
            { label: 'المبرر والسبب الرسمي', value: res.record.reason },
            { label: 'الملاحظات والتوجيهات', value: res.record.notes || 'معتمد ومقيد بملف الفرد' }
          ]
        };
        setVoucherData(voucher);
        setShowVoucherModal(true);
      } else {
        alert(res.message || 'تعذر استكمال العملية');
      }
    } catch (err: any) {
      alert(`حدث خطأ: ${err.message || 'تعذر منح العملية المالية'}`);
    } finally {
      setGrantSubmitting(false);
    }
  };

  const handleFaceVerified = (result: FaceVerificationResult) => {
    setLastFaceVerification(result);
    StorageService.logAction(
      currentRole,
      'الاستخبارات والأمن',
      'فحص واختبار مسح الوجه المباشر',
      personnel.militaryId,
      personnel.fullName,
      `تم إجراء فحص مسح الوجه المباشر للفرد (${personnel.rank} / ${personnel.fullName}) بنسبة مطابقة حيومية ${result.matchScore}% وتوقيع رقمي معتمد.`,
      personnel.militaryId,
      personnel.fullName
    );
    if (onRefresh) onRefresh();
  };

  // Extract Custody list & Chronological dispenses list
  const custodiesList = getPersonnelCustodies(personnel);
  const chronologicalDispensesList = getPersonnelChronologicalDispenses(personnel);

  const filteredDispenses = chronologicalDispensesList.filter((d) => {
    const q = dispensesFilterQuery.toLowerCase().trim();
    if (!q) return true;
    return (
      String(d.itemName || '').toLowerCase().includes(q) ||
      String(d.branch || '').toLowerCase().includes(q) ||
      String(d.dispenseType || '').toLowerCase().includes(q) ||
      String(d.orderNumber || '').toLowerCase().includes(q) ||
      String(d.details || '').toLowerCase().includes(q)
    );
  });

  const handleAddLogSubmit = (e: React.FormEvent) => {
    e.preventDefault();

    if (activeTab === 'movement') {
      StorageService.addMovementLog(
        personnel.militaryId,
        {
          date: formDate1,
          type: (formType as any) || 'أمر إداري',
          details: formText1,
          issuingAuthority: formText2 || currentRole,
          effectiveDate: formDate1
        },
        'المستخدم الحالي',
        currentRole
      );
    } else if (activeTab === 'attendance') {
      StorageService.updateStatus(
        personnel.militaryId,
        (formType as any) || 'إجازة',
        formText1,
        'المستخدم الحالي',
        currentRole
      );
    } else if (activeTab === 'medical') {
      StorageService.addMedicalLog(
        personnel.militaryId,
        {
          date: formDate1,
          diagnosis: formText1,
          hospital: formText2 || 'المستشفى العسكري المركزي',
          doctor: formText3 || 'طبيب عسكري معتمد',
          sickLeaveDays: formNum1 || 3,
          medications: [
            {
              id: `med-med-${Date.now()}`,
              name: 'علاج وصرف صيدلاني عسكري',
              dose: 'حسب إرشادات الطبيب المعالج',
              dateDispensed: formDate1,
              prescribedBy: formText3 || 'طبيب عسكري'
            }
          ]
        },
        'المستخدم الحالي',
        currentRole,
        formType === 'تنويم مستشفى'
      );
    } else if (activeTab === 'financial') {
      StorageService.addFinancialLog(
        personnel.militaryId,
        {
          date: formDate1,
          type: (formType as any) || 'مكافأة',
          amount: formNum1 || 1000,
          reason: formText1,
          transactionDate: formDate1
        },
        'المستخدم الحالي',
        currentRole
      );
    } else if (activeTab === 'security') {
      const violationTitle = secViolation.trim() || formText1.trim() || 'مخالفة ضوابط مسلكية وتمام';
      const detailsText = secDetails.trim() || formText2.trim() || (secFileName ? `مرفق محضر/وثيقة أمنية: ${secFileName}` : 'تم توثيق المحضر الانضباطي والتحقيق الأمني الرسمي');
      const penaltyText = secPenalty.trim() || formText3.trim() || 'إنذار مسلكي رسمي';

      StorageService.addSecurityLog(
        personnel.militaryId,
        {
          date: formDate1,
          violation: violationTitle,
          investigationDetails: detailsText,
          penalty: penaltyText,
          warningLevel: secWarningLevel,
          authority: currentRole,
          status: secStatus
        },
        'المستخدم الحالي',
        currentRole,
        secDetain
      );

      if (secFileUrl) {
        StorageService.addAttachment(
          personnel.militaryId,
          {
            title: secFileName || 'وثيقة ومحضر استخباراتي وأمني',
            category: 'وثيقة أمنية',
            fileType: secFileUrl.startsWith('data:image') ? 'image' : 'pdf',
            uploadDate: formDate1,
            fileSize: '1.5 MB',
            fileUrl: secFileUrl,
            uploadedBy: currentRole,
            notes: violationTitle
          },
          'فرع الاستخبارات والأمن العسكري',
          currentRole
        );
      }
    } else if (activeTab === 'armament') {
      StorageService.addArmamentLog(
        personnel.militaryId,
        {
          weaponSerial: formText1 || `WPN-${Math.floor(Math.random() * 90000)}`,
          weaponType: formText2 || 'بندقية M4A1 5.56mm',
          issueDate: formDate1,
          ammoQty: formNum1 || 90,
          firelinesCount: 3,
          ammoHistory: [
            {
              id: `ah-${Date.now()}`,
              type: 'صرف',
              quantity: formNum1 || 90,
              date: formDate1,
              reason: 'صرف حزمة تسليح معتمدة',
              issuedBy: currentRole
            }
          ],
          condition: 'ممتازة',
          technicalNotes: formText3 || 'فحص أمان فني ناجح'
        },
        'المستخدم الحالي',
        currentRole
      );
    } else if (activeTab === 'training') {
      StorageService.addTrainingLog(
        personnel.militaryId,
        {
          courseName: formText1,
          courseType: 'تخصصي',
          provider: formText2 || 'معهد القوات المسلحة',
          startDate: formDate1,
          endDate: formDate1,
          durationWeeks: formNum1 || 4,
          grade: 'ممتاز',
          evaluation: formText3 || 'تقييم عالي الأداء',
          certificates: 'شهادة اجتياز دورة معتمدة'
        },
        'المستخدم الحالي',
        currentRole
      );
    } else if (activeTab === 'supply') {
      StorageService.addSupplyLog(
        personnel.militaryId,
        {
          itemType: (formType as any) || 'بدلة عسكرية',
          itemName: formText1 || 'بدلة تمويه ومهمات عسكرية رسمية',
          quantity: formNum1 || 1,
          issueDate: formDate1,
          condition: 'جديد',
          issuedBy: currentRole,
          serialNumber: formText2 || `EQP-${Math.floor(1000 + Math.random() * 9000)}`,
          notes: formText3 || 'صرف وتوثيق بسجل الفرد العسكري'
        },
        'المستخدم الحالي',
        currentRole
      );
    } else if (activeTab === 'attachments') {
      const isImage = attFileUrl.startsWith('data:image') || attFileName.match(/\.(jpg|jpeg|png|webp|gif)$/i);
      StorageService.addAttachment(
        personnel.militaryId,
        {
          title: formText1 || attFileName || 'مستند عسكري رسمي',
          category: (formType as any) || (isImage ? 'صورة/فيديو' : 'قرار إداري'),
          fileType: isImage ? 'image' : 'pdf',
          uploadDate: formDate1,
          fileSize: '1.2 MB',
          fileUrl: attFileUrl || undefined,
          uploadedBy: currentRole,
          notes: formText2 || undefined
        },
        'المستخدم الحالي',
        currentRole
      );
    }

    setShowAddModal(false);
    setFormText1('');
    setFormText2('');
    setFormText3('');
    setFormNum1(0);
    setSecViolation('');
    setSecDetails('');
    setSecPenalty('إنذار مسلكي رسمي');
    setSecFileUrl('');
    setSecFileName('');
    setAttFileUrl('');
    setAttFileName('');
    setSecDetain(false);
    onRefresh();
  };

  // Safe logs container with defensive fallbacks and synchronized financial grants/advances
  const syncedFinancialLogs = StorageService.getSyncedPersonnelFinancialLogs(personnel);
  const safeLogs = {
    movement: Array.isArray(personnel.logs?.movement) ? personnel.logs.movement : [],
    attendance: Array.isArray(personnel.logs?.attendance) ? personnel.logs.attendance : [],
    medical: Array.isArray(personnel.logs?.medical) ? personnel.logs.medical : [],
    financial: syncedFinancialLogs,
    security: Array.isArray(personnel.logs?.security) ? personnel.logs.security : [],
    armament: Array.isArray(personnel.logs?.armament) ? personnel.logs.armament : [],
    supply: Array.isArray(personnel.logs?.supply) ? personnel.logs.supply : [],
    training: Array.isArray(personnel.logs?.training) ? personnel.logs.training : [],
    attachments: Array.isArray(personnel.logs?.attachments)
      ? personnel.logs.attachments
      : Array.isArray(personnel.attachments)
      ? personnel.attachments
      : []
  };

  // Calculate totals for financial summary
  const totalFinancialSpent = safeLogs.financial.reduce((sum, item) => sum + (item.amount || 0), 0);
  const totalAdvancesAmount = safeLogs.financial
    .filter((f) => f.grantType === 'سلفة مالية' || f.type === 'سلفة' || f.type === 'سلفة مالية' || f.isDeductedFromSalary)
    .reduce((sum, item) => sum + (item.amount || 0), 0);
  const totalGrantsAmount = safeLogs.financial
    .filter((f) => f.grantType === 'مساعدة مالية' || f.type === 'مساعدة مالية')
    .reduce((sum, item) => sum + (item.amount || 0), 0);

  return (
    <div className="space-y-6 pb-12">
      
      {/* Top Navigation & Action Controls */}
      <div className="flex items-center justify-between bg-white border border-slate-200 rounded-2xl p-4 shadow-sm">
        <button
          onClick={onBack}
          className="flex items-center space-x-2 space-x-reverse bg-slate-100 hover:bg-slate-200 text-slate-800 px-4 py-2 rounded-xl text-xs font-bold transition-all border border-slate-300"
        >
          <ArrowRight className="w-4 h-4 text-emerald-700" />
          <span>العودة لقائمة القوة البشرية</span>
        </button>

        <div className="flex items-center space-x-2 space-x-reverse">
          <button
            onClick={() => setShowFaceVerificationModal(true)}
            className="flex items-center space-x-2 space-x-reverse bg-gradient-to-r from-slate-900 to-slate-800 hover:from-slate-800 hover:to-slate-700 text-emerald-400 border border-emerald-500/50 px-4 py-2 rounded-xl text-xs font-black transition-all shadow-md cursor-pointer"
            title="مسح وجه الفرد بالكاميرا للتحقق من هوية الملف الإلكتروني"
          >
            <Scan className="w-4 h-4 text-emerald-400 animate-pulse" />
            <span>مسح الوجه واختبار الهوية 📸</span>
          </button>

          {onEditPersonnel && (
            <button
              onClick={() => onEditPersonnel(personnel)}
              className="flex items-center space-x-2 space-x-reverse bg-indigo-700 hover:bg-indigo-800 text-white px-4 py-2 rounded-xl text-xs font-extrabold transition-all shadow-md cursor-pointer"
              title="تعديل وتحديث بيانات الفرد بالكامل"
            >
              <Edit3 className="w-4 h-4 text-indigo-200" />
              <span>تعديل بيانات الفرد ✏️</span>
            </button>
          )}

          <button
            onClick={() => onPrintProfile(personnel)}
            className="flex items-center space-x-2 space-x-reverse bg-emerald-700 hover:bg-emerald-800 text-white px-4 py-2 rounded-xl text-xs font-extrabold transition-all shadow-md cursor-pointer"
          >
            <Printer className="w-4 h-4" />
            <span>طباعة الملف الشامل (PDF)</span>
          </button>

          {onDeletePersonnel && (
            <button
              onClick={() => onDeletePersonnel(personnel.militaryId, personnel.fullName)}
              className="flex items-center space-x-1.5 space-x-reverse bg-rose-50 hover:bg-rose-600 text-rose-700 hover:text-white border border-rose-300 px-3.5 py-2 rounded-xl text-xs font-bold transition-all cursor-pointer"
              title="نقل الملف لسلة المحذوفات (احتفاظ لمدة 30 يوم)"
            >
              <Trash2 className="w-4 h-4" />
              <span>نقل لسلة المحذوفات</span>
            </button>
          )}
        </div>
      </div>

      {/* Success Toast Notice */}
      {successToast && (
        <div className="bg-emerald-800 text-emerald-100 px-4 py-3 rounded-2xl flex items-center justify-between shadow-lg border border-emerald-600 animate-in fade-in slide-in-from-top-2 duration-200">
          <div className="flex items-center space-x-2 space-x-reverse font-bold text-sm">
            <Check className="w-5 h-5 text-emerald-300" />
            <span>{successToast}</span>
          </div>
          <button
            onClick={() => setSuccessToast(null)}
            className="text-emerald-200 hover:text-white text-xs font-bold px-2 py-1 bg-emerald-900/60 rounded-lg cursor-pointer"
          >
            إغلاق
          </button>
        </div>
      )}

      {/* Main Personnel Military Badge Header */}
      <div className="bg-white border border-slate-200 rounded-2xl p-6 shadow-sm relative overflow-hidden">
        <div className="flex flex-col md:flex-row items-center justify-between gap-6 relative z-10">
          
          <div className="flex flex-col md:flex-row items-center md:items-start space-y-4 md:space-y-0 md:space-x-5 md:space-x-reverse text-center md:text-right">
            {/* Interactive Photo Avatar with Camera trigger */}
            <div
              className="relative group cursor-pointer shrink-0"
              onClick={() => {
                setTempPhotoUrl(personnel.photoUrl);
                setShowPhotoModal(true);
              }}
              title="انقر لتغيير أو تصوير أو حذف الصورة الشخصية للفرد"
            >
              <PersonnelAvatar
                photoUrl={personnel.photoUrl}
                fullName={personnel.fullName}
                rank={personnel.rank}
                militaryId={personnel.militaryId}
                size="2xl"
                shape="rounded"
                className="border-2 border-emerald-600 shadow-md transition-transform group-hover:scale-105"
              />
              <div className="absolute inset-0 bg-slate-950/60 rounded-2xl opacity-0 group-hover:opacity-100 transition-opacity flex flex-col items-center justify-center text-white text-[11px] font-bold p-1 text-center backdrop-blur-xs">
                <Camera className="w-6 h-6 mb-1 text-emerald-400" />
                <span>تعديل الصورة 📸</span>
              </div>
              <div className="absolute -bottom-1 -right-1 bg-emerald-700 text-white p-1.5 rounded-xl shadow-md border-2 border-white">
                <Camera className="w-3.5 h-3.5" />
              </div>
            </div>

            <div className="space-y-1.5">
              <div className="flex items-center justify-center md:justify-start space-x-2 space-x-reverse">
                <span className="bg-emerald-100 text-emerald-800 border border-emerald-300 text-xs font-extrabold px-3 py-0.5 rounded-md">
                  {personnel.rank}
                </span>
                <span className="text-xs font-mono bg-slate-100 text-slate-800 border border-slate-300 px-2.5 py-0.5 rounded-md font-bold">
                  الرقم الوظيفي: {personnel.militaryId}
                </span>
              </div>

              <h2 className="text-2xl md:text-3xl font-bold text-slate-900 font-['Tajawal']">
                {personnel.fullName}
              </h2>

              <p className="text-xs text-slate-600 font-medium">
                {personnel.unit} • {personnel.battalion} • {personnel.company}
              </p>

              <div className="flex flex-wrap items-center justify-center md:justify-start gap-2 pt-1 text-[11px] text-slate-500 font-medium">
                <span>الرقم الوطني: <strong className="text-slate-900">{personnel.nationalId}</strong></span>
                <span>•</span>
                <span>فصيلة الدم: <strong className="text-rose-700 font-mono font-bold">{personnel.bloodType}</strong></span>
                <span>•</span>
                <span>الهاتف: <strong className="text-slate-900">{personnel.phone}</strong></span>
                <span>•</span>
                <span>الوظيفة: <strong className="text-slate-900">{personnel.jobTitle}</strong></span>
              </div>

              {/* Family & Guarantor Intelligence Card */}
              <div className="mt-2 pt-2 border-t border-slate-100 grid grid-cols-1 sm:grid-cols-3 gap-2 text-right text-[11px] bg-slate-50/80 p-2.5 rounded-xl border border-slate-200/80">
                <div>
                  <span className="text-slate-500 font-bold block">اسم الأم:</span>
                  <span className="font-extrabold text-slate-900">{personnel.motherName || 'غير مسجل'}</span>
                </div>
                <div>
                  <span className="text-slate-500 font-bold block">اسم الضمين (الكفيل):</span>
                  <span className="font-extrabold text-indigo-900">{personnel.guarantorName || 'غير مسجل'}</span>
                </div>
                <div>
                  <span className="text-slate-500 font-bold block">أقرب القرباء وهاتفه:</span>
                  <span className="font-extrabold text-slate-900">
                    {personnel.relativeName || 'غير مسجل'} {personnel.relativePhone ? `(${personnel.relativePhone})` : ''}
                  </span>
                </div>
              </div>
            </div>
          </div>

          {/* Current Status Badge Box */}
          <div className="bg-slate-50 border border-slate-200 rounded-2xl p-4 text-center min-w-[220px]">
            <span className="text-[11px] text-slate-500 font-bold block mb-1">حالة الجاهزية الحالية بالفرد</span>
            <div className="flex items-center justify-center space-x-1.5 space-x-reverse">
              <span
                className={`inline-block text-sm font-black px-4 py-1.5 rounded-xl border font-['Tajawal'] ${
                  ['متواجد', 'في الميدان'].includes(personnel.currentStatus)
                    ? 'bg-emerald-100 text-emerald-800 border-emerald-300'
                    : ['إجازة', 'إذن', 'مأمورية'].includes(personnel.currentStatus)
                    ? 'bg-amber-100 text-amber-800 border-amber-300'
                    : personnel.currentStatus === 'منتدب'
                    ? 'bg-purple-100 text-purple-900 border-purple-300'
                    : personnel.currentStatus === 'فرار بالسلاح'
                    ? 'bg-rose-950 text-rose-100 border-rose-900 font-black animate-pulse'
                    : ['مستشفى'].includes(personnel.currentStatus)
                    ? 'bg-pink-100 text-pink-800 border-pink-300'
                    : 'bg-rose-100 text-rose-800 border-rose-300'
                }`}
              >
                {personnel.currentStatus}
              </span>
            </div>

            {/* Current Status Dates & Duration */}
            <div className="mt-2 pt-1.5 border-t border-slate-200/80 text-right space-y-0.5">
              <div className="text-[10px] text-slate-600 flex items-center justify-between">
                <span>سارية من تاريخ:</span>
                <span className="font-mono font-bold text-slate-900 bg-white px-1.5 py-0.5 rounded border border-slate-200">
                  {personnel.lastStatusChangeDate || personnel.enlistmentDate || 'مسجل'}
                </span>
              </div>
              {(() => {
                const startDateStr = personnel.lastStatusChangeDate || personnel.enlistmentDate;
                if (!startDateStr) return null;
                const diff = Math.ceil((new Date().getTime() - new Date(startDateStr).getTime()) / (1000 * 60 * 60 * 24));
                const days = diff > 0 ? diff : 1;
                return (
                  <div className="text-[10px] text-emerald-800 font-bold flex items-center justify-between">
                    <span>المدة حتى الآن:</span>
                    <span className="font-mono bg-emerald-50 text-emerald-900 px-1.5 py-0.5 rounded border border-emerald-200">
                      {days} يوم
                    </span>
                  </div>
                );
              })()}
            </div>

            {/* Previous Status Info */}
            {(() => {
              const previousRecord = (personnel.logs?.attendance || []).find((a) => a.endDate && a.endDate !== a.startDate);
              if (!previousRecord) return null;
              return (
                <div className="mt-2 p-2 bg-slate-100/90 border border-slate-200 rounded-xl text-[10px] text-slate-700 text-right space-y-0.5">
                  <div className="font-bold text-slate-500">الحالة السابقة المقيدة:</div>
                  <div className="font-extrabold text-slate-900 flex items-center justify-between">
                    <span>{previousRecord.type}</span>
                    <span className="font-mono text-[9px] text-slate-500 font-normal">
                      ({previousRecord.durationDays} يوم)
                    </span>
                  </div>
                  <div className="text-[9px] font-mono text-slate-500 pt-0.5">
                    من {previousRecord.startDate || previousRecord.date} ← إلى {previousRecord.endDate}
                  </div>
                </div>
              );
            })()}

            {personnel.currentStatus === 'منتدب' && (
              <div className="mt-2 p-2 bg-purple-50/90 border border-purple-200 rounded-xl space-y-1 text-right">
                <div className="text-[11px] text-purple-950 font-black flex items-center space-x-1 space-x-reverse">
                  <Building className="w-3.5 h-3.5 text-purple-700 shrink-0" />
                  <span>الوحدة المنتدب إليها:</span>
                </div>
                <div className="text-xs font-black text-purple-900 pr-2">
                  {personnel.secondedUnit || 'لم يتم تحديد الوحدة'}
                </div>
              </div>
            )}

            {(personnel.currentStatus === 'دورة تدريبية داخلية' || personnel.currentStatus === 'دورة تدريبية خارجية') && (
              <div className="mt-2 p-2 bg-indigo-50/90 border border-indigo-200 rounded-xl space-y-1 text-right">
                <div className="text-[11px] text-indigo-950 font-black flex items-center space-x-1 space-x-reverse">
                  <GraduationCap className="w-3.5 h-3.5 text-indigo-700 shrink-0" />
                  <span>نوع ومسمى الدورة التدريبية:</span>
                </div>
                <div className="text-xs font-black text-indigo-900 pr-2">
                  {personnel.trainingCourseType || 'لم يتم تحديد مسمى الدورة'}
                </div>
              </div>
            )}

            <div className="mt-3 pt-2 border-t border-slate-200 flex flex-col gap-1.5">
              <button
                type="button"
                onClick={() => setShowStatusChangeModal(true)}
                className="w-full py-1.5 px-3 bg-emerald-700 hover:bg-emerald-800 text-white rounded-xl text-xs font-black transition-all shadow-xs flex items-center justify-center space-x-1.5 space-x-reverse cursor-pointer"
              >
                <ArrowRightLeft className="w-3.5 h-3.5" />
                <span>تعديل/تغيير الحالة القتالية ⚡</span>
              </button>
            </div>

            {/* Weapon Custody Status Box */}
            {(() => {
              const activeWeapon = StorageService.getActiveWeaponForPersonnel(personnel);
              const lastReturned = (personnel.logs?.armament || []).find((a) => a.returnDate || a.status === 'مورد');

              return (
                <div className="mt-3 p-3 bg-white border border-slate-200 rounded-2xl text-right transition-all shadow-xs">
                  <div className="text-[10px] text-slate-500 font-extrabold flex items-center justify-between mb-1.5">
                    <span className="flex items-center space-x-1 space-x-reverse">
                      <Crosshair className="w-3.5 h-3.5 text-slate-600" />
                      <span>حالة عهدة السلاح:</span>
                    </span>
                    {activeWeapon ? (
                      <span className="bg-emerald-100 text-emerald-800 border border-emerald-300 px-2 py-0.5 rounded-full font-black text-[10px] flex items-center space-x-1 space-x-reverse">
                        <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse"></span>
                        <span>السلاح بحوزته 🟢</span>
                      </span>
                    ) : lastReturned ? (
                      <span className="bg-blue-100 text-blue-900 border border-blue-300 px-2 py-0.5 rounded-full font-black text-[10px] flex items-center space-x-1 space-x-reverse">
                        <span>📦 مورد في التسليح</span>
                      </span>
                    ) : (
                      <span className="bg-slate-100 text-slate-600 border border-slate-300 px-2 py-0.5 rounded-full font-bold text-[10px]">
                        غير مسلّح
                      </span>
                    )}
                  </div>

                  {activeWeapon ? (
                    <div className="bg-emerald-50/80 border border-emerald-200 rounded-xl p-2.5 space-y-1 text-emerald-950">
                      <div className="flex items-center justify-between">
                        <span className="font-extrabold text-xs text-emerald-900">{activeWeapon.weaponType}</span>
                        <span className="font-mono font-bold text-[11px] text-emerald-800 bg-white px-1.5 py-0.5 rounded border border-emerald-200">
                          {activeWeapon.weaponSerial}
                        </span>
                      </div>
                      <div className="flex items-center justify-between text-[10px] text-emerald-800 pt-1 border-t border-emerald-200/60 font-medium">
                        <span>الذخيرة: <strong className="font-mono text-amber-800">{activeWeapon.ammoQty || 0} طلقة</strong></span>
                        <span>تاريخ الصرف: <strong className="font-mono">{activeWeapon.issueDate}</strong></span>
                      </div>
                      <div className="text-[10px] text-emerald-700 font-bold">
                        ✓ السلاح مقيد رسمياً في عهدة الفرد
                      </div>
                    </div>
                  ) : lastReturned ? (
                    <div className="bg-blue-50/80 border border-blue-200 rounded-xl p-2.5 space-y-1 text-blue-950">
                      <div className="flex items-center justify-between">
                        <span className="font-extrabold text-xs text-blue-900">{lastReturned.weaponType}</span>
                        <span className="font-mono font-bold text-[11px] text-blue-800 bg-white px-1.5 py-0.5 rounded border border-blue-200">
                          {lastReturned.weaponSerial}
                        </span>
                      </div>
                      <div className="flex items-center justify-between text-[10px] text-blue-800 pt-1 border-t border-blue-200/60 font-medium">
                        <span>تاريخ التوريد: <strong className="font-mono">{lastReturned.returnDate || 'مورد'}</strong></span>
                        <span>السند: <strong className="font-mono">{lastReturned.turnInReceiptNumber || 'معتمد'}</strong></span>
                      </div>
                      <div className="text-[10px] text-blue-700 font-bold">
                        ✓ تم توريد السلاح وإخلاء العهدة وإعادته لمستودع التسليح
                      </div>
                    </div>
                  ) : (
                    <div className="text-slate-400 text-[11px] text-center py-1">
                      لا توجد عهدة سلاح مسجلة باسم الفرد حالياً
                    </div>
                  )}
                </div>
              );
            })()}

            <span className="text-[10px] text-slate-500 font-medium block mt-2">
              تاريخ آخر تحديث: {personnel.lastStatusChangeDate || personnel.enlistmentDate || 'مسجل'}
            </span>
          </div>

        </div>
      </div>

      {/* Electronic Log Subtabs Navigation */}
      <div className="bg-white border border-slate-200 rounded-2xl p-2 shadow-sm overflow-x-auto">
        <div className="flex items-center space-x-1 space-x-reverse min-w-max text-xs font-bold">
          
          <button
            onClick={() => setActiveTab('custody')}
            className={`flex items-center space-x-1.5 space-x-reverse px-4 py-2.5 rounded-xl transition-all ${
              activeTab === 'custody'
                ? 'bg-indigo-800 text-white shadow-md font-extrabold'
                : 'bg-indigo-50 text-indigo-900 border border-indigo-200 hover:bg-indigo-100'
            }`}
          >
            <Package className="w-4 h-4 text-amber-400" />
            <span>لوحة العهد الحالية ({custodiesList.length})</span>
          </button>

          <button
            onClick={() => setActiveTab('chronologicalDispenses')}
            className={`flex items-center space-x-1.5 space-x-reverse px-4 py-2.5 rounded-xl transition-all ${
              activeTab === 'chronologicalDispenses'
                ? 'bg-slate-900 text-white shadow-md font-extrabold'
                : 'bg-slate-100 text-slate-800 border border-slate-200 hover:bg-slate-200'
            }`}
          >
            <Clock className="w-4 h-4 text-emerald-400" />
            <span>سجل الصرف الزمني الشامل ({chronologicalDispensesList.length})</span>
          </button>

          <span className="h-6 w-px bg-slate-300 mx-1"></span>

          <button
            onClick={() => setActiveTab('movement')}
            className={`flex items-center space-x-1.5 space-x-reverse px-4 py-2.5 rounded-xl transition-all ${
              activeTab === 'movement'
                ? 'bg-emerald-700 text-white shadow-xs'
                : 'text-slate-600 hover:bg-slate-100 hover:text-slate-900'
            }`}
          >
            <Clock className="w-4 h-4" />
            <span>1. سجل الحركة ({safeLogs.movement.length})</span>
          </button>

          <button
            onClick={() => setActiveTab('attendance')}
            className={`flex items-center space-x-1.5 space-x-reverse px-4 py-2.5 rounded-xl transition-all ${
              activeTab === 'attendance'
                ? 'bg-emerald-700 text-white shadow-xs'
                : 'text-slate-600 hover:bg-slate-100 hover:text-slate-900'
            }`}
          >
            <UserCheck className="w-4 h-4" />
            <span>2. سجل الحضور والانضباط ({safeLogs.attendance.length})</span>
          </button>

          <button
            onClick={() => setActiveTab('medical')}
            className={`flex items-center space-x-1.5 space-x-reverse px-4 py-2.5 rounded-xl transition-all ${
              activeTab === 'medical'
                ? 'bg-emerald-700 text-white shadow-xs'
                : 'text-slate-600 hover:bg-slate-100 hover:text-slate-900'
            }`}
          >
            <Activity className="w-4 h-4" />
            <span>3. السجل الطبي ({safeLogs.medical.length})</span>
          </button>

          <button
            onClick={() => setActiveTab('financial')}
            className={`flex items-center space-x-1.5 space-x-reverse px-4 py-2.5 rounded-xl transition-all ${
              activeTab === 'financial'
                ? 'bg-emerald-700 text-white shadow-xs'
                : 'text-slate-600 hover:bg-slate-100 hover:text-slate-900'
            }`}
          >
            <DollarSign className="w-4 h-4" />
            <span>4. السجل المالي ({safeLogs.financial.length})</span>
          </button>

          <button
            onClick={() => setActiveTab('security')}
            className={`flex items-center space-x-1.5 space-x-reverse px-4 py-2.5 rounded-xl transition-all ${
              activeTab === 'security'
                ? 'bg-emerald-700 text-white shadow-xs'
                : 'text-slate-600 hover:bg-slate-100 hover:text-slate-900'
            }`}
          >
            <Lock className="w-4 h-4" />
            <span>5. السجل الأمني ({safeLogs.security.length})</span>
          </button>

          <button
            onClick={() => setActiveTab('armament')}
            className={`flex items-center space-x-1.5 space-x-reverse px-4 py-2.5 rounded-xl transition-all ${
              activeTab === 'armament'
                ? 'bg-emerald-700 text-white shadow-xs'
                : 'text-slate-600 hover:bg-slate-100 hover:text-slate-900'
            }`}
          >
            <Crosshair className="w-4 h-4" />
            <span>6. سجل التسليح ({safeLogs.armament.length})</span>
          </button>

          <button
            onClick={() => setActiveTab('supply')}
            className={`flex items-center space-x-1.5 space-x-reverse px-4 py-2.5 rounded-xl transition-all ${
              activeTab === 'supply'
                ? 'bg-emerald-700 text-white shadow-xs'
                : 'text-slate-600 hover:bg-slate-100 hover:text-slate-900'
            }`}
          >
            <Package className="w-4 h-4" />
            <span>7. المهمات والبدلات العسكرية ({safeLogs.supply.length})</span>
          </button>

          <button
            onClick={() => setActiveTab('training')}
            className={`flex items-center space-x-1.5 space-x-reverse px-4 py-2.5 rounded-xl transition-all ${
              activeTab === 'training'
                ? 'bg-emerald-700 text-white shadow-xs'
                : 'text-slate-600 hover:bg-slate-100 hover:text-slate-900'
            }`}
          >
            <Award className="w-4 h-4" />
            <span>8. سجل الدورات والتدريب ({safeLogs.training.length})</span>
          </button>

          <button
            onClick={() => setActiveTab('attachments')}
            className={`flex items-center space-x-1.5 space-x-reverse px-4 py-2.5 rounded-xl transition-all ${
              activeTab === 'attachments'
                ? 'bg-emerald-700 text-white shadow-xs'
                : 'text-slate-600 hover:bg-slate-100 hover:text-slate-900'
            }`}
          >
            <Paperclip className="w-4 h-4" />
            <span>9. مرفقات الفرد ({safeLogs.attachments.length})</span>
          </button>

        </div>
      </div>

      {/* Subtab Content Area */}
      <div className="bg-white border border-slate-200 rounded-2xl p-6 shadow-sm space-y-6">
        
        {/* Subtab Top Controls */}
        <div className="flex items-center justify-between pb-4 border-b border-slate-200">
          <div>
            <h3 className="text-lg font-bold text-slate-900 font-['Tajawal']">
              {activeTab === 'custody' && 'لوحة العهد الشخصية الحالية المصروفة للفرد'}
              {activeTab === 'chronologicalDispenses' && 'سجل عمليات الصرف الزمني الشامل (تسليح • تموين • طبي)'}
              {activeTab === 'movement' && 'سجل الحركة والتنقلات والترقيات'}
              {activeTab === 'attendance' && 'سجل الحضور والغياب والإجازات والفرار'}
              {activeTab === 'medical' && 'السجل الطبي والأدوية المصروفة والعمليات'}
              {activeTab === 'financial' && 'السجل المالي والرواتب والبدلات والمكافآت'}
              {activeTab === 'security' && 'السجل الأمني والمخالفات والتحقيقات والقرارات المتخذة'}
              {activeTab === 'armament' && 'سجل التسليح الشخصي وصرف واسترجاع الذخيرة'}
              {activeTab === 'supply' && 'سجل المهمات والبدلات العسكرية وعهد التموين المصروفة'}
              {activeTab === 'training' && 'سجل التدريب والدورات والتقييم والشهادات'}
              {activeTab === 'attachments' && 'المستندات والمرفقات والقرارات المرفوعة'}
            </h3>
            <p className="text-xs text-slate-500 mt-0.5 font-medium">
              جميع المدخلات موثقة وتحدث آلياً بالتكامل مع الفروع والإدارات المختصة
            </p>
          </div>

          {activeTab !== 'custody' && activeTab !== 'chronologicalDispenses' && (
            <button
              onClick={() => {
                setFormType('');
                setFormText1('');
                setFormText2('');
                setFormText3('');
                setFormNum1(0);
                setShowAddModal(true);
              }}
              className="flex items-center space-x-1.5 space-x-reverse bg-emerald-700 hover:bg-emerald-800 text-white px-3.5 py-2 rounded-xl text-xs font-bold transition-all shadow-sm"
            >
              <Plus className="w-4 h-4" />
              <span>إضافة قيد بالسجل</span>
            </button>
          )}
        </div>

        {/* TAB 0.1: CUSTODY DASHBOARD */}
        {activeTab === 'custody' && (
          <div className="space-y-6">
            {/* Overview Stats Bar */}
            <div className="grid grid-cols-1 sm:grid-cols-4 gap-4">
              <div className="p-4 bg-indigo-50 border border-indigo-200 rounded-2xl">
                <span className="text-[11px] font-bold text-indigo-700 block">إجمالي العهد المقيدة</span>
                <span className="text-2xl font-black text-indigo-950 font-mono mt-1 block">
                  {custodiesList.length}
                </span>
                <span className="text-[10px] text-indigo-600 font-medium mt-1 block">
                  أسلحة، ذخائر، مهمات، ومستلزمات
                </span>
              </div>

              <div className="p-4 bg-amber-50 border border-amber-200 rounded-2xl">
                <span className="text-[11px] font-bold text-amber-800 block">عهد التسليح والذخيرة</span>
                <span className="text-2xl font-black text-amber-950 font-mono mt-1 block">
                  {custodiesList.filter((c) => c.category === 'تسليح').length}
                </span>
                <span className="text-[10px] text-amber-700 font-medium mt-1 block">قطع تسليح معتمدة</span>
              </div>

              <div className="p-4 bg-emerald-50 border border-emerald-200 rounded-2xl">
                <span className="text-[11px] font-bold text-emerald-800 block">مهمات التموين والبدلات</span>
                <span className="text-2xl font-black text-emerald-950 font-mono mt-1 block">
                  {custodiesList.filter((c) => c.category === 'تموين وإمداد').length}
                </span>
                <span className="text-[10px] text-emerald-700 font-medium mt-1 block">تجهيزات وبدلات عسكرية</span>
              </div>

              <div className="p-4 bg-purple-50 border border-purple-200 rounded-2xl">
                <span className="text-[11px] font-bold text-purple-800 block">أدوية ومستلزمات طبية</span>
                <span className="text-2xl font-black text-purple-950 font-mono mt-1 block">
                  {custodiesList.filter((c) => c.category === 'طبية').length}
                </span>
                <span className="text-[10px] text-purple-700 font-medium mt-1 block">وصفات طبية مصروفة</span>
              </div>
            </div>

            {/* Custody Items Grid / Cards */}
            {custodiesList.length === 0 ? (
              <div className="text-center py-12 bg-slate-50 border border-dashed border-slate-300 rounded-2xl text-slate-500 text-xs font-bold">
                لا توجد أي عهدة مقيدة حالياً بذمة هذا الفرد.
              </div>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {custodiesList.map((item) => (
                  <div
                    key={item.id}
                    className="p-4 bg-white border border-slate-200 hover:border-slate-300 rounded-2xl shadow-2xs space-y-3 relative overflow-hidden"
                  >
                    <div className="flex items-center justify-between border-b border-slate-100 pb-2.5">
                      <div className="flex items-center space-x-2 space-x-reverse">
                        <span className="w-2.5 h-2.5 rounded-full bg-emerald-600"></span>
                        <span className="font-extrabold text-sm text-slate-900 font-['Tajawal']">
                          {item.itemName}
                        </span>
                      </div>

                      <span
                        className={`text-[10px] font-bold px-2.5 py-0.5 rounded-lg border ${
                          item.category === 'تسليح'
                            ? 'bg-amber-100 text-amber-900 border-amber-300'
                            : item.category === 'تموين وإمداد'
                            ? 'bg-emerald-100 text-emerald-900 border-emerald-300'
                            : 'bg-purple-100 text-purple-900 border-purple-300'
                        }`}
                      >
                        {item.category}
                      </span>
                    </div>

                    <div className="grid grid-cols-2 gap-2 text-xs">
                      <div>
                        <span className="text-slate-400 text-[10px] block">الرقم التسلسلي / الكود:</span>
                        <span className="font-mono font-bold text-slate-800">{item.serialOrCode || '-'}</span>
                      </div>

                      <div>
                        <span className="text-slate-400 text-[10px] block">الكمية المصروفة:</span>
                        <span className="font-bold text-slate-900">{item.quantity}</span>
                      </div>

                      <div>
                        <span className="text-slate-400 text-[10px] block">تاريخ الصرف:</span>
                        <span className="font-mono text-slate-700">{item.issueDate}</span>
                      </div>

                      <div>
                        <span className="text-slate-400 text-[10px] block">الحالة الفنية:</span>
                        <span className="font-bold text-emerald-800">{item.condition}</span>
                      </div>

                      <div>
                        <span className="text-slate-400 text-[10px] block">رقم أمر الصرف:</span>
                        <span className="font-mono text-xs font-bold text-indigo-900">{item.orderNumber}</span>
                      </div>

                      <div>
                        <span className="text-slate-400 text-[10px] block">جهة الصرف:</span>
                        <span className="font-bold text-slate-800">{item.issuingBranch}</span>
                      </div>
                    </div>

                    {item.notes && (
                      <p className="text-[11px] text-slate-500 bg-slate-50 p-2 rounded-xl border border-slate-100 font-medium">
                        ملاحظات: {item.notes}
                      </p>
                    )}
                  </div>
                ))}
              </div>
            )}
          </div>
        )}

        {/* TAB 0.2: CHRONOLOGICAL DISPENSES */}
        {activeTab === 'chronologicalDispenses' && (
          <div className="space-y-4">
            {/* Search Filter for Dispenses */}
            <div className="flex flex-col sm:flex-row items-center justify-between gap-3 bg-slate-50 p-3 rounded-2xl border border-slate-200">
              <input
                type="text"
                value={dispensesFilterQuery}
                onChange={(e) => setDispensesFilterQuery(e.target.value)}
                placeholder="تصفية الصرفيات بالاسم، نوع المادة، الفرع، أمر الصرف..."
                className="w-full sm:w-80 bg-white border border-slate-300 rounded-xl px-3 py-2 text-xs focus:outline-none focus:border-emerald-600"
              />

              <button
                onClick={(e) => void executeUnifiedPrintFromButton(e.currentTarget, 'سجل الصرف الزمني')} 
                className="flex items-center space-x-1.5 space-x-reverse bg-slate-900 hover:bg-slate-800 text-white px-3.5 py-2 rounded-xl text-xs font-bold transition-all shrink-0"
              >
                <Printer className="w-4 h-4 text-emerald-400" />
                <span>طباعة سجل الصرف الزمني</span>
              </button>
            </div>

            {/* Timeline Table */}
            {filteredDispenses.length === 0 ? (
              <div className="text-center py-12 text-slate-500 text-xs font-bold">
                لا توجد سجلات صرف مسجلة تطابق التصفية.
              </div>
            ) : (
              <div className="overflow-x-auto border border-slate-200 rounded-2xl">
                <table className="w-full text-right text-xs">
                  <thead className="bg-slate-900 text-white text-[11px] font-bold">
                    <tr>
                      <th className="p-3">التاريخ</th>
                      <th className="p-3">الفرع المختص</th>
                      <th className="p-3">نوع الصرف</th>
                      <th className="p-3">المادة / العتاد</th>
                      <th className="p-3">تفاصيل المادة</th>
                      <th className="p-3">الكمية</th>
                      <th className="p-3">رقم أمر الصرف</th>
                      <th className="p-3">المسؤول عن الصرف</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-200 font-medium text-slate-800">
                    {filteredDispenses.map((d) => (
                      <tr key={d.id} className="hover:bg-slate-50 transition-colors">
                        <td className="p-3 font-mono font-bold text-slate-900 whitespace-nowrap">{d.date}</td>
                        <td className="p-3">
                          <span
                            className={`px-2.5 py-0.5 rounded-lg font-bold text-[10px] border ${
                              d.branch === 'فرع التسليح'
                                ? 'bg-amber-100 text-amber-900 border-amber-300'
                                : d.branch === 'فرع التموين والإمداد'
                                ? 'bg-emerald-100 text-emerald-900 border-emerald-300'
                                : 'bg-purple-100 text-purple-900 border-purple-300'
                            }`}
                          >
                            {d.branch}
                          </span>
                        </td>
                        <td className="p-3 font-bold text-slate-900">{d.dispenseType}</td>
                        <td className="p-3 font-black text-emerald-950 font-['Tajawal']">{d.itemName}</td>
                        <td className="p-3 text-slate-600 text-[11px]">{d.details}</td>
                        <td className="p-3 font-mono font-bold text-slate-900">{d.quantity}</td>
                        <td className="p-3 font-mono font-bold text-indigo-900">{d.orderNumber}</td>
                        <td className="p-3 text-slate-700">{d.issuedBy}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </div>
        )}

        {/* 1. MOVEMENT LOG TAB */}
        {activeTab === 'movement' && (
          <div className="space-y-4">
            {personnel.logs.movement.length === 0 ? (
              <div className="text-center py-12 text-slate-500 text-xs">
                لا توجد سجلات حركة مسجلة لهذا الفرد حتى الآن.
              </div>
            ) : (
              <div className="space-y-3">
                {personnel.logs.movement.map((m) => (
                  <div
                    key={m.id}
                    className="p-4 bg-slate-50 border border-slate-200 rounded-xl flex items-start justify-between gap-4 text-xs"
                  >
                    <div className="space-y-1">
                      <div className="flex items-center space-x-2 space-x-reverse">
                        <span className="font-extrabold text-emerald-800 bg-emerald-100 border border-emerald-300 px-2.5 py-0.5 rounded">
                          {m.type}
                        </span>
                        <span className="text-slate-500 text-[11px] font-medium">تاريخ القرار: {m.date}</span>
                      </div>
                      <p className="text-slate-900 font-bold pt-1">{m.details}</p>
                      <p className="text-slate-500 text-[11px] font-medium">الجهة المصدرة: {m.issuingAuthority}</p>
                    </div>

                    <span className="text-[11px] bg-white border border-slate-300 px-2.5 py-1 rounded text-slate-800 font-mono font-bold shadow-2xs">
                      ساري من: {m.effectiveDate}
                    </span>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}

        {/* 2. ATTENDANCE & STATUS HISTORY TAB */}
        {activeTab === 'attendance' && (
          <div className="space-y-5">
            {/* Top Card: Active Current Status Overview */}
            {(() => {
              const currentStart = personnel.lastStatusChangeDate || personnel.enlistmentDate || new Date().toISOString().split('T')[0];
              const todayStr = new Date().toISOString().split('T')[0];
              let elapsedDays = 1;
              if (currentStart && todayStr) {
                const diff = Math.ceil((new Date(todayStr).getTime() - new Date(currentStart).getTime()) / (1000 * 60 * 60 * 24));
                elapsedDays = diff > 0 ? diff : 1;
              }

              return (
                <div className="bg-gradient-to-r from-slate-900 via-slate-800 to-slate-900 text-white p-5 rounded-2xl shadow-md border-2 border-emerald-500/50 flex flex-col md:flex-row items-center justify-between gap-4">
                  <div className="space-y-1.5 text-right w-full md:w-auto">
                    <div className="flex items-center space-x-2 space-x-reverse">
                      <span className="text-[11px] text-emerald-300 font-bold bg-emerald-950/80 px-2.5 py-0.5 rounded-full border border-emerald-500/40">
                        الحالة العسكرية السارية حالياً ⚡
                      </span>
                      <span className="w-2.5 h-2.5 rounded-full bg-emerald-400 animate-pulse"></span>
                    </div>
                    <div className="flex items-center space-x-3 space-x-reverse pt-1">
                      <span className="text-xl font-black font-['Tajawal'] text-amber-300">
                        {personnel.currentStatus}
                      </span>
                      <span className="text-xs text-slate-300 font-medium">
                        (مقيدة في تمام القوة اليومية)
                      </span>
                    </div>
                    <div className="flex flex-wrap items-center gap-3 pt-1 text-xs text-slate-200">
                      <div className="flex items-center space-x-1.5 space-x-reverse bg-slate-800/80 px-3 py-1 rounded-xl border border-slate-700">
                        <span className="text-slate-400">سارية من تاريخ:</span>
                        <strong className="font-mono text-emerald-300 text-sm">{currentStart}</strong>
                      </div>
                      <div className="flex items-center space-x-1.5 space-x-reverse bg-slate-800/80 px-3 py-1 rounded-xl border border-slate-700">
                        <span className="text-slate-400">إلى:</span>
                        <strong className="text-white text-xs">تاريخ اليوم (مستمرة)</strong>
                      </div>
                      <div className="flex items-center space-x-1.5 space-x-reverse bg-emerald-900/60 text-emerald-200 px-3 py-1 rounded-xl border border-emerald-600/50">
                        <span>المدة المنقضية:</span>
                        <strong className="font-mono font-black text-sm text-emerald-300">{elapsedDays} يوم</strong>
                      </div>
                    </div>

                    {['غياب', 'فرار', 'فرار بالسلاح'].includes(personnel.currentStatus) && (
                      <div className="flex items-center space-x-2 space-x-reverse bg-red-950/90 text-red-200 border border-red-500/50 px-3 py-1.5 rounded-xl text-xs mt-2">
                        <span className="w-2 h-2 rounded-full bg-red-400 animate-ping"></span>
                        <strong className="font-bold">استقطاع مالي يومي ساري بنظام المرتبات:</strong>
                        <span>
                          يتم خصم أجر الغياب اليومي تلقائياً (المدة المحتسبة: {elapsedDays} يوم) ومستمر يومياً حتى تحديث الحالة.
                        </span>
                      </div>
                    )}
                  </div>

                  <div className="shrink-0 w-full md:w-auto text-left">
                    <button
                      type="button"
                      onClick={() => setShowStatusChangeModal(true)}
                      className="w-full md:w-auto px-5 py-2.5 bg-emerald-600 hover:bg-emerald-500 text-white rounded-xl text-xs font-black transition-all shadow-md flex items-center justify-center space-x-2 space-x-reverse cursor-pointer"
                    >
                      <ArrowRightLeft className="w-4 h-4" />
                      <span>تحديث/تغيير الحالة القتالية والانضباطية ⚡</span>
                    </button>
                  </div>
                </div>
              );
            })()}

            {/* Historical Status Periods Timeline Header */}
            <div className="flex items-center justify-between border-b border-slate-200 pb-2.5 pt-2">
              <div className="flex items-center space-x-2 space-x-reverse">
                <Clock className="w-4 h-4 text-emerald-700" />
                <h4 className="font-extrabold text-slate-900 text-sm font-['Tajawal']">
                  سجل حركات وفترات الحالات والتمام الميداني (من تاريخ ← إلى تاريخ)
                </h4>
                <span className="bg-slate-100 text-slate-700 border border-slate-200 px-2 py-0.5 rounded-full text-[11px] font-bold">
                  {personnel.logs.attendance.length} فترة مسجلة
                </span>
              </div>
              <p className="text-[11px] text-slate-500 font-medium hidden sm:block">
                توثيق رسمي وتلقائي لكافة الفترات السابقة من تاريخ التعيين وحتى التغيير
              </p>
            </div>

            {/* Historical Periods List */}
            {personnel.logs.attendance.length === 0 ? (
              <div className="text-center py-12 text-slate-500 text-xs bg-slate-50 border border-dashed border-slate-200 rounded-2xl">
                لا توجد حركات انضباط أو فترات سابقة مسجلة لهذا الفرد حتى الآن.
              </div>
            ) : (
              <div className="space-y-3">
                {personnel.logs.attendance.map((att, idx) => {
                  const fromDate = att.startDate || att.date;
                  const toDate = att.endDate;
                  const isCompleted = Boolean(toDate && toDate !== fromDate);
                  const isDeserter = att.type === 'فرار' || att.type === 'فرار بالسلاح';
                  const isLeave = att.type === 'إجازة' || att.type === 'إذن';

                  return (
                    <div
                      key={att.id || idx}
                      className={`p-4 rounded-2xl border transition-all text-xs space-y-2.5 shadow-2xs ${
                        att.type === 'فرار بالسلاح'
                          ? 'bg-rose-950/10 border-rose-500 text-rose-950'
                          : isDeserter
                          ? 'bg-rose-50/90 border-rose-300 text-rose-950'
                          : isLeave
                          ? 'bg-amber-50/90 border-amber-300 text-amber-950'
                          : att.type === 'منتدب'
                          ? 'bg-purple-50/90 border-purple-300 text-purple-950'
                          : att.type === 'مأمورية'
                          ? 'bg-sky-50/90 border-sky-300 text-sky-950'
                          : ['دورة تدريبية داخلية', 'دورة تدريبية خارجية'].includes(att.type)
                          ? 'bg-indigo-50/90 border-indigo-300 text-indigo-950'
                          : ['متواجد', 'في الميدان', 'حضور'].includes(att.type)
                          ? 'bg-emerald-50/90 border-emerald-300 text-emerald-950'
                          : 'bg-white border-slate-200 text-slate-900'
                      }`}
                    >
                      {/* Top Row: Status Name, Date Range Pill, Duration, Tag */}
                      <div className="flex flex-wrap items-center justify-between gap-2 border-b border-black/5 pb-2.5">
                        <div className="flex flex-wrap items-center space-x-2 space-x-reverse gap-y-1">
                          <span
                            className={`font-black text-xs px-3 py-1 rounded-xl border shadow-2xs ${
                              att.type === 'فرار بالسلاح'
                                ? 'bg-rose-950 text-rose-100 border-rose-800'
                                : isDeserter
                                ? 'bg-rose-700 text-white border-rose-800'
                                : isLeave
                                ? 'bg-amber-700 text-white border-amber-800'
                                : att.type === 'منتدب'
                                ? 'bg-purple-700 text-white border-purple-800'
                                : att.type === 'مأمورية'
                                ? 'bg-sky-700 text-white border-sky-800'
                                : ['متواجد', 'في الميدان', 'حضور'].includes(att.type)
                                ? 'bg-emerald-700 text-white border-emerald-800'
                                : 'bg-slate-800 text-white border-slate-900'
                            }`}
                          >
                            {att.type}
                          </span>

                          {/* From Date -> To Date Badge */}
                          <div className="flex items-center space-x-1.5 space-x-reverse font-mono text-xs bg-white border border-slate-200 px-3 py-1 rounded-xl shadow-2xs text-slate-800">
                            <span className="text-slate-400 font-medium">من تاريخ:</span>
                            <span className="font-extrabold text-slate-900">{fromDate}</span>
                            <span className="text-slate-400 px-0.5">←</span>
                            <span className="text-slate-400 font-medium">إلى تاريخ:</span>
                            <span className={`font-extrabold ${toDate ? 'text-slate-900' : 'text-emerald-700'}`}>
                              {toDate || 'سارية حتى الآن'}
                            </span>
                          </div>

                          {/* Duration Badge */}
                          <span className="px-2.5 py-1 rounded-xl bg-slate-900 text-white font-mono font-bold text-xs shadow-2xs">
                            المدة: {att.durationDays} يوم
                          </span>
                        </div>

                        {/* Completion Status Tag */}
                        <div className="flex items-center space-x-2 space-x-reverse">
                          {isCompleted ? (
                            <span className="text-[10px] font-bold text-blue-900 bg-blue-100 border border-blue-300 px-2 py-0.5 rounded-lg flex items-center space-x-1 space-x-reverse">
                              <span>✓ فترة مكتملة ومقيدة</span>
                            </span>
                          ) : (
                            <span className="text-[10px] font-black text-emerald-900 bg-emerald-100 border border-emerald-300 px-2.5 py-0.5 rounded-lg flex items-center space-x-1 space-x-reverse">
                              <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse"></span>
                              <span>🟢 حالة نشطة وسارية</span>
                            </span>
                          )}

                          <button
                            type="button"
                            onClick={() => printAttendanceVoucher(att)}
                            className="bg-slate-800 hover:bg-slate-900 text-white font-bold px-2.5 py-1 rounded-lg text-[10px] flex items-center space-x-1 space-x-reverse transition-all shadow-2xs cursor-pointer"
                            title="طباعة سند الاعتماد الميداني"
                          >
                            <Printer className="w-3 h-3" />
                            <span>السند 🖨️</span>
                          </button>
                        </div>
                      </div>

                      {/* Details & Notes */}
                      <div className="space-y-1 text-right">
                        <p className="font-extrabold text-slate-900 text-xs leading-relaxed">
                          {att.reason}
                        </p>
                        {att.notes && (
                          <p className="text-[11px] text-slate-600 font-medium">
                            ملاحظات: {att.notes}
                          </p>
                        )}
                        <div className="flex flex-wrap items-center gap-3 text-[10px] text-slate-500 pt-1 font-medium">
                          <span>المعتمد: <strong className="text-slate-700">{att.approvedBy || 'القيادة'}</strong></span>
                          <span>•</span>
                          <span>تاريخ التوثيق: <strong className="font-mono text-slate-700">{att.date}</strong></span>
                          {att.leaveType && (
                            <>
                              <span>•</span>
                              <span>نوع الإجازة/الإذن: <strong className="text-amber-800">{att.leaveType}</strong></span>
                            </>
                          )}
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </div>
        )}

        {/* 3. MEDICAL LOG TAB */}
        {activeTab === 'medical' && (
          <div className="space-y-4">
            {personnel.logs.medical.length === 0 ? (
              <div className="text-center py-12 text-slate-500 text-xs">
                السجل الطبي نظيف - لا توجد إصابات أو إجازات مرضية مسجلة.
              </div>
            ) : (
              <div className="space-y-4">
                {personnel.logs.medical.map((med) => (
                  <div key={med.id} className="p-4 bg-slate-50 border border-slate-200 rounded-xl space-y-3 text-xs">
                    <div className="flex items-center justify-between border-b border-slate-200 pb-2">
                      <div className="flex items-center space-x-2 space-x-reverse">
                        <Activity className="w-4 h-4 text-pink-600" />
                        <span className="font-bold text-slate-900 text-sm">{med.diagnosis}</span>
                      </div>
                      <div className="flex items-center space-x-2 space-x-reverse">
                        <span className="text-slate-500 text-[11px] font-medium">{med.date}</span>
                        <button
                          onClick={() => printMedicalVoucher(med)}
                          className="bg-teal-700 hover:bg-teal-800 text-white font-bold px-2.5 py-1 rounded-lg text-[10px] flex items-center space-x-1 space-x-reverse transition-all shadow-2xs cursor-pointer"
                          title="طباعة سند اعتماد التقرير الطبي والعودة العلاجية"
                        >
                          <Printer className="w-3 h-3" />
                          <span>السند 🖨️</span>
                        </button>
                      </div>
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-3 gap-2 text-slate-700 text-[11px]">
                      <div>المستشفى: <strong className="text-slate-900">{med.hospital}</strong></div>
                      <div>الطبيب المعالج: <strong className="text-slate-900">{med.doctor}</strong></div>
                      <div>الإجازة المرضية: <strong className="text-pink-700">{med.sickLeaveDays} أيام</strong></div>
                    </div>

                    {med.injuryDetails && (
                      <div className="p-2 bg-white border border-slate-200 rounded text-slate-700">
                        تفاصيل الإصابة: {med.injuryDetails}
                      </div>
                    )}

                    {med.surgicalOperations && (
                      <div className="p-2 bg-pink-50 border border-pink-200 rounded text-pink-800 font-bold">
                        العمليات الجراحية: {med.surgicalOperations}
                      </div>
                    )}

                    {/* Dispensed Medications List */}
                    {med.medications && med.medications.length > 0 && (
                      <div className="pt-2 border-t border-slate-200 space-y-1.5">
                        <span className="text-[11px] font-bold text-emerald-800 block">الأدوية والعلاجات المصروفة:</span>
                        <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                          {med.medications.map((m) => (
                            <div key={m.id} className="p-2 bg-white border border-slate-200 rounded flex justify-between items-center text-[11px]">
                              <div>
                                <div className="font-bold text-slate-800">{m.name}</div>
                                <div className="text-slate-500 text-[10px]">{m.dose}</div>
                              </div>
                              <span className="text-slate-500 font-mono text-[10px]">{m.dateDispensed}</span>
                            </div>
                          ))}
                        </div>
                      </div>
                    )}

                  </div>
                ))}
              </div>
            )}
          </div>
        )}

        {/* 4. FINANCIAL LOG TAB */}
        {activeTab === 'financial' && (
          <div className="space-y-4">
            {/* Top Financial Dashboard & Fast Actions */}
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
              <div className="p-4 bg-teal-50 border border-teal-200 rounded-2xl flex flex-col justify-between">
                <span className="text-[11px] font-bold text-teal-800">إجمالي المبالغ المصروفة طوال الخدمة:</span>
                <span className="text-xl font-black text-teal-900 font-mono mt-1">
                  {totalFinancialSpent.toLocaleString('ar-SA')} ر.س
                </span>
                <span className="text-[10px] text-teal-700 mt-1">شامل الرواتب والبدلات والمكافآت</span>
              </div>

              <div className="p-4 bg-amber-50 border border-amber-200 rounded-2xl flex flex-col justify-between">
                <div className="flex items-center justify-between">
                  <span className="text-[11px] font-bold text-amber-900">إجمالي السلف المالية المقيدة:</span>
                  <span className="text-[10px] bg-amber-200/80 text-amber-900 px-2 py-0.5 rounded font-black">
                    مستقطعة
                  </span>
                </div>
                <span className="text-xl font-black text-amber-950 font-mono mt-1">
                  {totalAdvancesAmount.toLocaleString('ar-SA')} ر.س
                </span>
                <span className="text-[10px] text-amber-800 mt-1">تُخصم تلقائياً من مسيرات الرواتب</span>
              </div>

              <div className="p-4 bg-emerald-50 border border-emerald-200 rounded-2xl flex flex-col justify-between">
                <div className="flex items-center justify-between">
                  <span className="text-[11px] font-bold text-emerald-900">إجمالي المساعدات المالية:</span>
                  <span className="text-[10px] bg-emerald-200/80 text-emerald-900 px-2 py-0.5 rounded font-black">
                    غير مستردة
                  </span>
                </div>
                <span className="text-xl font-black text-emerald-950 font-mono mt-1">
                  {totalGrantsAmount.toLocaleString('ar-SA')} ر.س
                </span>
                <span className="text-[10px] text-emerald-800 mt-1">إعانات رسمية بدون أي استقطاع</span>
              </div>
            </div>

            {/* Quick Actions Bar for Grants & Advances */}
            <div className="p-3 bg-gradient-to-l from-slate-900 via-slate-800 to-slate-900 rounded-2xl border border-slate-700 flex flex-wrap items-center justify-between gap-3 shadow-md">
              <div className="text-white text-xs">
                <span className="font-bold block text-emerald-400">إجراءات الصرف والتقييد المالي المباشر بالفرد</span>
                <span className="text-[10px] text-slate-300">
                  يمكنك منح سلفة مالية (مستقطعة) أو مساعدة مالية (غير مستردة) مباشرة مع تسجيلها فورياً بملف الفرد وإصدار السند الرسمي
                </span>
              </div>

              <div className="flex items-center space-x-2 space-x-reverse">
                <button
                  type="button"
                  onClick={() => {
                    setGrantType('سلفة مالية');
                    setGrantAmount(1000);
                    setGrantReason('طلب سلفة مالية مؤقتة على المرتب');
                    setShowGrantModal(true);
                  }}
                  className="bg-amber-500 hover:bg-amber-600 text-slate-950 font-black px-3.5 py-2 rounded-xl text-xs flex items-center space-x-1.5 space-x-reverse transition-all shadow-sm cursor-pointer"
                >
                  <AlertTriangle className="w-4 h-4 text-slate-950" />
                  <span>صرف سلفة مالية (مستقطعة) ⚠️</span>
                </button>

                <button
                  type="button"
                  onClick={() => {
                    setGrantType('مساعدة مالية');
                    setGrantAmount(1500);
                    setGrantReason('مساعدة وإعانة مالية استثنائية');
                    setShowGrantModal(true);
                  }}
                  className="bg-emerald-600 hover:bg-emerald-700 text-white font-black px-3.5 py-2 rounded-xl text-xs flex items-center space-x-1.5 space-x-reverse transition-all shadow-sm cursor-pointer"
                >
                  <Gift className="w-4 h-4 text-emerald-200" />
                  <span>منح مساعدة مالية (غير مستردة) 🎁</span>
                </button>
              </div>
            </div>

            {safeLogs.financial.length === 0 ? (
              <div className="text-center py-12 text-slate-500 text-xs bg-slate-50 rounded-2xl border border-slate-200">
                لا توجد عمليات مالية أو سلف أو مساعدات مسجلة في ملف هذا الفرد.
              </div>
            ) : (
              <div className="space-y-3">
                {safeLogs.financial.map((fin) => {
                  const isAdvance = fin.grantType === 'سلفة مالية' || fin.type === 'سلفة' || fin.type === 'سلفة مالية' || fin.isDeductedFromSalary;
                  const isAid = fin.grantType === 'مساعدة مالية' || fin.type === 'مساعدة مالية';
                  const isDeduction = fin.type === 'استقطاع';

                  return (
                    <div
                      key={fin.id}
                      className={`p-4 rounded-2xl border transition-all text-xs space-y-2.5 shadow-2xs ${
                        isAdvance
                          ? 'bg-amber-50/70 border-amber-300'
                          : isAid
                          ? 'bg-emerald-50/70 border-emerald-300'
                          : isDeduction
                          ? 'bg-rose-50/70 border-rose-300'
                          : 'bg-slate-50 border-slate-200'
                      }`}
                    >
                      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-slate-200/80 pb-2">
                        <div className="flex flex-wrap items-center gap-2">
                          <span
                            className={`font-black px-2.5 py-0.5 rounded-md text-[11px] ${
                              isAdvance
                                ? 'bg-amber-200 text-amber-950 border border-amber-400'
                                : isAid
                                ? 'bg-emerald-200 text-emerald-950 border border-emerald-400'
                                : isDeduction
                                ? 'bg-rose-200 text-rose-950 border border-rose-400'
                                : 'bg-slate-200 text-slate-900 border border-slate-300'
                            }`}
                          >
                            {isAdvance ? 'سلفة مالية (مستقطعة) ⚠️' : isAid ? 'مساعدة مالية (غير مستردة) 🎁' : fin.type}
                          </span>

                          {fin.voucherNumber && (
                            <span className="font-mono text-[10px] bg-white px-2 py-0.5 rounded border border-slate-300 font-bold text-slate-800">
                              سند: {fin.voucherNumber}
                            </span>
                          )}

                          {isAdvance && (
                            <span className="text-[10px] text-amber-900 font-bold bg-amber-100/80 px-2 py-0.5 rounded border border-amber-300">
                              مستقطعة من مرتب شهر: {fin.monthYear || fin.date?.slice(0, 7) || '-'}
                            </span>
                          )}

                          {isAid && (
                            <span className="text-[10px] text-emerald-900 font-bold bg-emerald-100/80 px-2 py-0.5 rounded border border-emerald-300">
                              إعانة رسمية غير مستردة (بدون خصم)
                            </span>
                          )}
                        </div>

                        <div className="flex items-center space-x-3 space-x-reverse self-end sm:self-auto">
                          <span
                            className={`text-base font-black font-mono ${
                              isDeduction || isAdvance ? 'text-amber-900' : 'text-emerald-900'
                            }`}
                          >
                            {isDeduction ? '-' : '+'}{(fin.amount || 0).toLocaleString('ar-SA')} ر.س
                          </span>

                          <button
                            type="button"
                            onClick={() => printFinancialVoucher(fin)}
                            className="bg-slate-900 hover:bg-slate-800 text-white font-bold px-2.5 py-1 rounded-lg text-[10px] flex items-center space-x-1 space-x-reverse transition-all shadow-2xs cursor-pointer"
                            title="عرض وطباعة السند المالي الرسمي المعتمد"
                          >
                            <Printer className="w-3 h-3 text-emerald-400" />
                            <span>السند الرسمي 🖨️</span>
                          </button>
                        </div>
                      </div>

                      <div className="text-slate-800 font-medium">
                        <span className="font-bold text-slate-900">البيان والسبب: </span>
                        <span>{fin.reason}</span>
                      </div>

                      {fin.notes && (
                        <div className="text-slate-600 text-[11px] bg-white/70 p-2 rounded-xl border border-slate-200">
                          <span className="font-bold text-slate-700">الملاحظات والتوجيهات: </span>
                          <span>{fin.notes}</span>
                        </div>
                      )}

                      <div className="flex flex-wrap items-center justify-between text-[10px] text-slate-500 pt-1 border-t border-slate-200/60">
                        <span>تاريخ الصرف والقيد: <strong className="font-mono text-slate-700">{fin.date || fin.transactionDate}</strong></span>
                        <span>الجهة المعتمدة: <strong className="text-slate-700">{fin.approvedBy || 'الإدارة المالية'}</strong></span>
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </div>
        )}

        {/* 5. SECURITY LOG TAB */}
        {activeTab === 'security' && (
          <div className="space-y-4">
            {personnel.logs.security.length === 0 ? (
              <div className="text-center py-12 text-slate-500 text-xs">
                السجل الأمني نظيف تماماً - لا توجد قيود أو عقوبات.
              </div>
            ) : (
              <div className="space-y-3">
                {personnel.logs.security.map((sec) => (
                  <div key={sec.id} className="p-4 bg-slate-50 border border-slate-200 rounded-xl space-y-2 text-xs">
                    <div className="flex items-center justify-between border-b border-slate-200 pb-2">
                      <div className="flex items-center space-x-2 space-x-reverse">
                        <Lock className="w-4 h-4 text-rose-700" />
                        <span className="font-bold text-rose-900 text-sm">{sec.violation}</span>
                      </div>
                      <div className="flex items-center space-x-2 space-x-reverse">
                        <span className="text-rose-800 font-bold bg-rose-100 border border-rose-300 px-2 py-0.5 rounded text-[10px]">
                          خطورة: {sec.warningLevel}
                        </span>
                        <button
                          type="button"
                          onClick={() => {
                            if (confirm(`هل أنت تأكد من رغبتك في حذف القيد الأمني (${sec.violation})؟`)) {
                              StorageService.deleteSecurityLog(personnel.militaryId, sec.id, 'المستخدم الحالي', currentRole);
                              onRefresh();
                            }
                          }}
                          className="text-slate-400 hover:text-rose-600 transition-colors p-1 cursor-pointer"
                          title="حذف القيد الأمني"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </div>

                    <p className="text-slate-700">{sec.investigationDetails}</p>
                    <div className="flex flex-wrap items-center justify-between gap-2 text-[11px] text-slate-600 pt-1 border-t border-slate-200 font-medium">
                      <span>العقوبة: <strong className="text-slate-900">{sec.penalty}</strong></span>
                      <span>الحالة: <strong className="text-emerald-800">{sec.status}</strong></span>
                      {sec.date && <span>تاريخ القيد: <strong className="text-slate-700">{sec.date}</strong></span>}
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}

        {/* 6. ARMAMENT LOG TAB */}
        {activeTab === 'armament' && (
          <div className="space-y-4">
            {personnel.logs.armament.length === 0 ? (
              <div className="text-center py-12 text-slate-500 text-xs">
                لا يوجد سلاح مسند لهذا الفرد حالياً.
              </div>
            ) : (
              <div className="space-y-4">
                {personnel.logs.armament.map((arm) => {
                  const isInCustody = !arm.returnDate && arm.status !== 'مورد' && arm.status !== 'في المخزن' && arm.weaponSerial !== 'ذخيرة فقط';
                  const isReturned = arm.returnDate || arm.status === 'مورد';

                  return (
                    <div
                      key={arm.id}
                      className={`p-4 rounded-2xl space-y-3 text-xs border transition-all ${
                        isInCustody
                          ? 'bg-emerald-50/50 border-emerald-300 shadow-xs'
                          : 'bg-slate-50 border-slate-200'
                      }`}
                    >
                      <div className="flex flex-wrap items-center justify-between border-b border-slate-200 pb-2.5 gap-2">
                        <div>
                          <div className="flex items-center space-x-2 space-x-reverse">
                            <span className="text-sm font-black text-slate-900">{arm.weaponType}</span>
                            {isInCustody ? (
                              <span className="bg-emerald-100 text-emerald-800 border border-emerald-300 px-2 py-0.5 rounded-full font-black text-[10px] flex items-center space-x-1 space-x-reverse">
                                <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse"></span>
                                <span>السلاح بحوزة الفرد حالياً 🟢</span>
                              </span>
                            ) : isReturned ? (
                              <span className="bg-blue-100 text-blue-900 border border-blue-300 px-2 py-0.5 rounded-full font-black text-[10px]">
                                📦 مورد في التسليح (تم الإرجاع للمخزن)
                              </span>
                            ) : (
                              <span className="bg-slate-100 text-slate-700 border border-slate-300 px-2 py-0.5 rounded-full font-bold text-[10px]">
                                قيد تسليحي
                              </span>
                            )}
                          </div>
                          <span className="text-slate-500 text-[11px] font-mono block mt-0.5">
                            الرقم التسلسلي (S/N): <strong className={isInCustody ? 'text-emerald-900 font-bold' : 'text-slate-800'}>{arm.weaponSerial}</strong>
                          </span>
                        </div>

                        <div className="flex items-center space-x-2 space-x-reverse">
                          <span className="bg-white text-slate-700 border border-slate-200 px-2.5 py-1 rounded-lg text-[11px] font-bold">
                            حالة السلاح: {arm.condition}
                          </span>
                        </div>
                      </div>

                      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-[11px] text-slate-700 bg-white/70 p-2.5 rounded-xl border border-slate-200/80">
                        <div>
                          <span className="text-[10px] text-slate-400 block font-bold">الذخيرة الحية:</span>
                          <strong className="text-amber-800 font-mono text-xs font-bold">{arm.ammoQty} طلقة</strong>
                        </div>
                        <div>
                          <span className="text-[10px] text-slate-400 block font-bold">خطوط النار / الخزائن:</span>
                          <strong className="text-slate-900 font-mono">{arm.firelinesCount} خزائن</strong>
                        </div>
                        <div>
                          <span className="text-[10px] text-slate-400 block font-bold">تاريخ الصرف:</span>
                          <strong className="text-slate-900 font-mono">{arm.issueDate}</strong>
                        </div>
                        <div>
                          <span className="text-[10px] text-slate-400 block font-bold">تاريخ التوريد:</span>
                          <strong className={isReturned ? 'text-blue-800 font-mono font-bold' : 'text-slate-400'}>
                            {arm.returnDate || 'بحوزته حالياً'}
                          </strong>
                        </div>
                      </div>

                      {arm.turnInReceiptNumber && (
                        <div className="bg-blue-50 border border-blue-200 rounded-xl p-2.5 text-[11px] text-blue-900 space-y-1 font-medium">
                          <div className="flex flex-wrap items-center justify-between gap-2">
                            <span>سند التوريد الرسمي: <strong className="font-mono font-bold text-blue-950">{arm.turnInReceiptNumber}</strong></span>
                            <span>✓ تم استلام السلاح بمخازن التسليح وإخلاء العهدة</span>
                          </div>
                          {(arm.turnInOfficer || arm.turnInTime) && (
                            <div className="flex flex-wrap items-center gap-3 text-[10px] text-blue-800 pt-0.5 border-t border-blue-200/60">
                              {arm.turnInOfficer && <span>ضابط التسليح المستلم: <strong>{arm.turnInOfficer}</strong></span>}
                              {arm.turnInTime && <span>وقت التوريد: <strong className="font-mono">{arm.turnInTime}</strong></span>}
                              {arm.turnInDate && <span>بتاريخ: <strong className="font-mono">{arm.turnInDate}</strong></span>}
                            </div>
                          )}
                        </div>
                      )}

                      {arm.reissueReceiptNumber && (
                        <div className="bg-emerald-50 border border-emerald-300 rounded-xl p-2.5 text-[11px] text-emerald-950 space-y-1 font-medium">
                          <div className="flex flex-wrap items-center justify-between gap-2">
                            <span>سند إعادة الصرف من المخازن: <strong className="font-mono font-bold text-emerald-900">{arm.reissueReceiptNumber}</strong></span>
                            <span className="bg-emerald-200/70 text-emerald-900 px-2 py-0.5 rounded-md font-extrabold text-[10px]">
                              {arm.reissueProcedures || 'إعادة صرف من المستودع'}
                            </span>
                          </div>
                          <div className="flex flex-wrap items-center gap-3 text-[10px] text-emerald-800 pt-0.5 border-t border-emerald-200/60">
                            {arm.reissueOfficer && <span>ضابط التسليح المسلم: <strong>{arm.reissueOfficer}</strong></span>}
                            {arm.reissueDate && <span>تاريخ الإعادة: <strong className="font-mono">{arm.reissueDate}</strong></span>}
                            {arm.reissueTime && <span>الوقت: <strong className="font-mono">{arm.reissueTime}</strong></span>}
                            <span>المخازن: <strong>{arm.firelinesCount}</strong></span>
                            <span>الذخيرة: <strong>{arm.ammoQty} طلقة</strong></span>
                          </div>
                        </div>
                      )}

                      {arm.technicalNotes && (
                        <p className="text-slate-600 text-[11px]">ملاحظات فنية: {arm.technicalNotes}</p>
                      )}
                    </div>
                  );
                })}
              </div>
            )}
          </div>
        )}

        {/* 7. SUPPLY & LOGISTICS TAB (المهمات والبدلات العسكرية) */}
        {activeTab === 'supply' && (
          <div className="space-y-4">
            {(!personnel.logs.supply || personnel.logs.supply.length === 0) ? (
              <div className="text-center py-12 text-slate-500 text-xs">
                لا توجد مهمات أو بدلات مقيدة باسم هذا الفرد حالياً.
              </div>
            ) : (
              <div className="space-y-3">
                {personnel.logs.supply.map((sup) => (
                  <div key={sup.id} className="p-4 bg-slate-50 border border-slate-200 rounded-xl space-y-3 text-xs">
                    <div className="flex items-center justify-between border-b border-slate-200 pb-2">
                      <div className="flex items-center space-x-2 space-x-reverse">
                        <Package className="w-4 h-4 text-indigo-700" />
                        <div>
                          <span className="font-bold text-indigo-950 text-sm block">{sup.itemName}</span>
                          <span className="text-[10px] text-slate-500 font-semibold">{sup.itemType}</span>
                        </div>
                      </div>
                      <div className="flex items-center space-x-2 space-x-reverse">
                        <span className="bg-indigo-100 text-indigo-900 border border-indigo-200 px-2.5 py-1 rounded text-[11px] font-bold">
                          الكمية: {sup.quantity}
                        </span>
                        <span className="bg-emerald-100 text-emerald-800 border border-emerald-200 px-2.5 py-1 rounded text-[11px] font-bold">
                          {sup.condition}
                        </span>
                      </div>
                    </div>

                    <div className="grid grid-cols-2 sm:grid-cols-3 gap-3 text-[11px] text-slate-700 font-medium">
                      <div>تاريخ الصرف: <strong className="text-slate-900 font-mono">{sup.issueDate}</strong></div>
                      <div>جهة الصرف: <strong className="text-indigo-800">{sup.issuedBy}</strong></div>
                      {sup.serialNumber && (
                        <div>الرقم التسلسلي / العهدة: <strong className="text-slate-900 font-mono">{sup.serialNumber}</strong></div>
                      )}
                    </div>

                    {sup.notes && (
                      <p className="text-slate-600 text-[11px] pt-1 border-t border-slate-200">
                        ملاحظات الصرف والتعليمات: {sup.notes}
                      </p>
                    )}
                  </div>
                ))}
              </div>
            )}
          </div>
        )}

        {/* 7. TRAINING & COURSES TAB */}
        {activeTab === 'training' && (
          <div className="space-y-4">
            {personnel.logs.training.length === 0 ? (
              <div className="text-center py-12 text-slate-500 text-xs">
                لا توجد دورات مسجلة حتى الآن.
              </div>
            ) : (
              <div className="space-y-3">
                {personnel.logs.training.map((trn) => (
                  <div key={trn.id} className="p-4 bg-slate-50 border border-slate-200 rounded-xl space-y-2 text-xs">
                    <div className="flex items-center justify-between">
                      <span className="text-sm font-bold text-slate-900">{trn.courseName}</span>
                      <div className="flex items-center space-x-2 space-x-reverse">
                        <span className="bg-purple-100 text-purple-900 border border-purple-300 px-2 py-0.5 rounded text-[11px] font-bold">
                          التقدير: {trn.grade}
                        </span>
                        <button
                          onClick={() => printTrainingVoucher(trn)}
                          className="bg-purple-700 hover:bg-purple-800 text-white font-bold px-2.5 py-1 rounded-lg text-[10px] flex items-center space-x-1 space-x-reverse transition-all shadow-2xs cursor-pointer"
                          title="طباعة سند اعتماد وتوثيق الدورة التدريبية"
                        >
                          <Printer className="w-3 h-3" />
                          <span>السند 🖨️</span>
                        </button>
                      </div>
                    </div>
                    <p className="text-slate-700 text-[11px]">{trn.evaluation}</p>
                    <div className="text-slate-500 text-[10px] flex justify-between pt-1 border-t border-slate-200 font-medium">
                      <span>الجهة: {trn.provider}</span>
                      <span>الشهادة: {trn.certificates}</span>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}

        {/* 8. ATTACHMENTS TAB */}
        {activeTab === 'attachments' && (
          <div className="space-y-4">
            <div className="flex items-center justify-between bg-slate-50 p-3 rounded-xl border border-slate-200">
              <span className="text-xs font-bold text-slate-800">
                المستندات، الصور والملفات الموثقة بالفرد ({ (personnel.logs?.attachments || personnel.attachments || []).length })
              </span>

              {/* Direct File & Image Upload button in Personnel Profile */}
              <label className="cursor-pointer bg-emerald-700 hover:bg-emerald-800 text-white text-xs font-bold px-3.5 py-1.5 rounded-xl flex items-center space-x-1.5 space-x-reverse transition-all shadow-xs">
                <Upload className="w-3.5 h-3.5" />
                <span>إرفاق وثيقة / صورة جديدة</span>
                <input
                  type="file"
                  accept="image/*,application/pdf,.doc,.docx"
                  className="hidden"
                  onChange={async (e) => {
                    const file = e.target.files?.[0];
                    if (file) {
                      try {
                        const compressedUrl = await compressImageFile(file);
                        StorageService.addAttachment(
                          personnel.militaryId,
                          {
                            title: file.name,
                            category: file.type.startsWith('image') ? 'صورة/فيديو' : 'مستند شخصي',
                            fileType: file.type.startsWith('image') ? 'image' : 'pdf',
                            uploadDate: new Date().toISOString().split('T')[0],
                            fileSize: `${(file.size / (1024 * 1024)).toFixed(1)} MB`,
                            fileUrl: compressedUrl,
                            uploadedBy: 'مدير النظام'
                          },
                          'مدير النظام',
                          currentRole
                        );
                        onRefresh();
                      } catch (err) {
                        console.error('Failed to upload attachment:', err);
                      }
                    }
                  }}
                />
              </label>
            </div>

            {(personnel.logs?.attachments || personnel.attachments || []).length === 0 ? (
              <div className="text-center py-12 text-slate-500 text-xs">
                لا توجد وثائق أو مرفقات إلكترونية مرفوعة حتى الآن.
              </div>
            ) : (
              <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-3">
                {(personnel.logs?.attachments || personnel.attachments || []).map((attch) => {
                  const isImage = attch.fileUrl && (
                    attch.fileUrl.startsWith('data:image') ||
                    attch.fileType === 'image' ||
                    attch.fileUrl.startsWith('blob:') ||
                    attch.fileUrl.match(/\.(jpeg|jpg|gif|png|webp|svg)$/i)
                  );

                  return (
                    <div key={attch.id} className="p-3 bg-slate-50 border border-slate-200 rounded-xl space-y-2 text-xs">
                      <div className="flex items-center justify-between">
                        <div className="flex items-center space-x-2 space-x-reverse overflow-hidden">
                          <FileText className="w-5 h-5 text-emerald-700 shrink-0" />
                          <div className="truncate">
                            <div className="font-bold text-slate-900 truncate">{attch.title}</div>
                            <div className="text-slate-500 text-[10px]">{attch.category} • {attch.fileSize}</div>
                          </div>
                        </div>
                        <span className="text-[10px] text-emerald-800 bg-emerald-100 border border-emerald-300 px-1.5 py-0.5 rounded font-bold shrink-0">
                          مستند موثق
                        </span>
                      </div>

                      {/* Image Preview if Base64 or Image URL or image type */}
                      {isImage && attch.fileUrl && (
                        <div className="mt-2 relative group cursor-pointer" onClick={() => setPreviewImageModal(attch.fileUrl!)}>
                          <img
                            src={attch.fileUrl}
                            alt={attch.title}
                            className="w-full h-32 object-cover rounded-lg border border-slate-300 shadow-2xs group-hover:opacity-90 transition-opacity"
                          />
                          <div className="absolute inset-0 bg-slate-900/40 opacity-0 group-hover:opacity-100 flex items-center justify-center text-white text-[10px] font-bold rounded-lg transition-opacity">
                            انقر التوسيع والعرض
                          </div>
                        </div>
                      )}

                      {attch.notes && (
                        <p className="text-[10px] text-slate-600 bg-white p-2 rounded border border-slate-200">
                          ملاحظة: {attch.notes}
                        </p>
                      )}

                      <div className="flex items-center justify-between text-[10px] text-slate-500 pt-1 border-t border-slate-200 font-medium">
                        <span>تاريخ الرفع: {attch.uploadDate}</span>
                        <div className="flex items-center space-x-2 space-x-reverse">
                          {attch.fileUrl && (
                            <a
                              href={attch.fileUrl}
                              download={attch.title}
                              target="_blank"
                              rel="noreferrer"
                              className="text-emerald-700 hover:underline font-bold"
                            >
                              معاينة / تنزيل
                            </a>
                          )}
                          <button
                            type="button"
                            onClick={() => {
                              if (confirm('هل أنت متأكد من حذف هذا المرفق النهائي؟')) {
                                StorageService.deleteAttachment(
                                  personnel.militaryId,
                                  attch.id,
                                  'مدير النظام',
                                  currentRole
                                );
                                onRefresh();
                              }
                            }}
                            className="text-rose-600 hover:text-rose-800 font-bold cursor-pointer"
                            title="حذف المرفق"
                          >
                            حذف
                          </button>
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </div>
        )}

      </div>

      {/* Add Log Modal */}
      {showAddModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs">
          <div className="bg-white border border-slate-200 rounded-2xl p-6 max-w-lg w-full space-y-4 shadow-xl max-h-[90vh] overflow-y-auto">
            <h3 className="text-base font-bold text-slate-900 font-['Tajawal'] border-b border-slate-200 pb-3">
              إضافة قيد جديد إلى {activeTab === 'security' ? 'السجل الأمني والمخالفات' : activeTab}
            </h3>

            {activeTab === 'security' ? (
              <form onSubmit={handleAddLogSubmit} className="space-y-3.5 text-right text-xs">
                <div className="p-3 bg-rose-50 border border-rose-200 rounded-xl text-rose-900 font-bold">
                  <span>الفرد المستهدف: </span>
                  <span className="text-slate-900">{personnel.rank} / {personnel.fullName} (رقم عسكري: {personnel.militaryId})</span>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                  <div>
                    <label className="block text-slate-700 font-bold mb-1">تاريخ الواقعة / القرار *</label>
                    <input
                      type="date"
                      required
                      value={formDate1}
                      onChange={(e) => setFormDate1(e.target.value)}
                      className="w-full bg-slate-50 border border-slate-300 rounded-xl px-3 py-2 text-slate-900 font-bold focus:outline-none focus:bg-white focus:border-rose-600"
                    />
                  </div>

                  <div>
                    <label className="block text-slate-700 font-bold mb-1">درجة الخطورة *</label>
                    <select
                      value={secWarningLevel}
                      onChange={(e) => setSecWarningLevel(e.target.value as any)}
                      className="w-full bg-slate-50 border border-slate-300 rounded-xl px-3 py-2 text-slate-900 font-bold focus:outline-none focus:bg-white focus:border-rose-600"
                    >
                      <option value="منخفض">منخفض - تنبيه مسلكي</option>
                      <option value="متوسط">متوسط - مخالفة تعليمات</option>
                      <option value="عالي">عالي - قيد أمني/انضباطي</option>
                      <option value="حرج">حرج - قضايا جسيمة/توقيف</option>
                    </select>
                  </div>
                </div>

                <div>
                  <label className="block text-slate-700 font-bold mb-1">عنوان / نص المخالفة الانضباطية *</label>
                  <input
                    type="text"
                    required
                    value={secViolation}
                    onChange={(e) => setSecViolation(e.target.value)}
                    placeholder="أدخل عنوان أو موضوع المخالفة..."
                    className="w-full bg-slate-50 border border-slate-300 rounded-xl px-3 py-2 text-slate-900 font-bold focus:outline-none focus:bg-white focus:border-rose-600"
                  />
                </div>

                <div>
                  <label className="block text-slate-700 font-bold mb-1">العقوبة / القرار الصادر *</label>
                  <input
                    type="text"
                    required
                    value={secPenalty}
                    onChange={(e) => setSecPenalty(e.target.value)}
                    placeholder="أدخل نص العقوبة..."
                    className="w-full bg-slate-50 border border-slate-300 rounded-xl px-3 py-2 text-slate-900 font-bold focus:outline-none focus:bg-white focus:border-rose-600"
                  />
                  <div className="flex flex-wrap gap-1 mt-1 text-[10px]">
                    {['إنذار مسلكي رسمي', 'حجز تحفظي وتوقيف', 'خصم 3 أيام من الراتب', 'لفت نظر انضباطي', 'إحالة للمحكمة العسكرية'].map((preset) => (
                      <button
                        key={preset}
                        type="button"
                        onClick={() => setSecPenalty(preset)}
                        className="bg-slate-100 hover:bg-rose-100 text-slate-700 hover:text-rose-900 border border-slate-200 px-2 py-0.5 rounded font-bold transition-all cursor-pointer"
                      >
                        {preset}
                      </button>
                    ))}
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                  <div>
                    <label className="block text-slate-700 font-bold mb-1">حالة القرار الانضباطي *</label>
                    <select
                      value={secStatus}
                      onChange={(e) => setSecStatus(e.target.value as any)}
                      className="w-full bg-slate-50 border border-slate-300 rounded-xl px-3 py-2 text-slate-900 font-bold focus:outline-none focus:bg-white focus:border-rose-600"
                    >
                      <option value="قيد التحقيق">قيد التحقيق والاستجواب</option>
                      <option value="تم البت">تم البت وصدور القرار</option>
                      <option value="محال للنيابة العسكرية">محال للنيابة العسكرية</option>
                      <option value="منتهي">منتهي / حفظ الملف</option>
                    </select>
                  </div>

                  <div className="flex items-center pt-4">
                    <label className="flex items-center space-x-2 space-x-reverse cursor-pointer font-bold text-slate-800 text-xs">
                      <input
                        type="checkbox"
                        checked={secDetain}
                        onChange={(e) => setSecDetain(e.target.checked)}
                        className="w-4 h-4 text-rose-700 rounded border-slate-300 focus:ring-rose-500"
                      />
                      <span>توقيف الفرد آلياً (تعديل الحالة لموقوف)</span>
                    </label>
                  </div>
                </div>

                <div>
                  <label className="block text-slate-700 font-bold mb-1">تفاصيل المحضر والتحقيق الانضباطي</label>
                  <textarea
                    rows={2}
                    value={secDetails}
                    onChange={(e) => setSecDetails(e.target.value)}
                    placeholder="تفاصيل المحضر والاستجواب..."
                    className="w-full bg-slate-50 border border-slate-300 rounded-xl p-2.5 text-slate-800 focus:outline-none focus:bg-white focus:border-rose-600"
                  ></textarea>
                </div>

                {/* File Attachment Upload */}
                <div className="bg-rose-50/70 border border-rose-200 p-3 rounded-xl space-y-2">
                  <label className="block text-rose-900 font-bold flex items-center space-x-1.5 space-x-reverse">
                    <Paperclip className="w-4 h-4 text-rose-700" />
                    <span>إرفاق صورة أو وثيقة محضر استخباراتي وأمني:</span>
                  </label>
                  <div className="flex items-center gap-2">
                    <label className="cursor-pointer bg-white border border-rose-300 hover:bg-rose-100 text-rose-900 px-3 py-1.5 rounded-xl flex items-center space-x-2 space-x-reverse font-bold text-xs shadow-xs transition-all">
                      <Upload className="w-3.5 h-3.5 text-rose-700" />
                      <span>اختر صورة/ملف</span>
                      <input
                        type="file"
                        accept="image/*,application/pdf,.doc,.docx"
                        className="hidden"
                        onChange={(e) => {
                          const file = e.target.files?.[0];
                          if (file) {
                            setSecFileName(file.name);
                            const reader = new FileReader();
                            reader.onload = (ev) => {
                              setSecFileUrl(ev.target?.result as string);
                            };
                            reader.readAsDataURL(file);
                          }
                        }}
                      />
                    </label>
                    {secFileName && (
                      <span className="text-xs text-slate-800 font-bold truncate max-w-[180px] bg-white px-2 py-1 rounded border border-rose-200">
                        {secFileName}
                      </span>
                    )}
                  </div>
                  {secFileUrl && secFileUrl.startsWith('data:image') && (
                    <img src={secFileUrl} alt="معاينة المرفق" className="w-24 h-16 object-cover rounded-lg border border-rose-300 mt-1" />
                  )}
                </div>

                <div className="flex items-center justify-end space-x-2 space-x-reverse pt-4 border-t border-slate-100">
                  <button
                    type="button"
                    onClick={() => setShowAddModal(false)}
                    className="px-4 py-2 bg-slate-100 text-slate-700 hover:bg-slate-200 rounded-xl font-bold transition-colors cursor-pointer"
                  >
                    إلغاء
                  </button>
                  <button
                    type="submit"
                    className="px-5 py-2 bg-rose-700 hover:bg-rose-800 text-white rounded-xl font-bold shadow-sm transition-colors cursor-pointer flex items-center space-x-1.5 space-x-reverse"
                  >
                    <Lock className="w-4 h-4" />
                    <span>اعتماد وتقييد المخالفة</span>
                  </button>
                </div>
              </form>
            ) : (
              <form onSubmit={handleAddLogSubmit} className="space-y-3 text-right text-xs">
                <div>
                  <label className="block text-slate-700 font-bold mb-1">تاريخ العملية / القرار</label>
                  <input
                    type="date"
                    value={formDate1}
                    onChange={(e) => setFormDate1(e.target.value)}
                    className="w-full bg-slate-50 border border-slate-300 rounded-xl px-3 py-2 text-slate-800 focus:outline-none focus:bg-white focus:border-emerald-600"
                  />
                </div>

                <div>
                  <label className="block text-slate-700 font-bold mb-1">البيان الأساسي / العنوان *</label>
                  <input
                    type="text"
                    required
                    value={formText1}
                    onChange={(e) => setFormText1(e.target.value)}
                    placeholder="أدخل التفاصيل الرئيسية..."
                    className="w-full bg-slate-50 border border-slate-300 rounded-xl px-3 py-2 text-slate-800 focus:outline-none focus:bg-white focus:border-emerald-600"
                  />
                </div>

                <div>
                  <label className="block text-slate-700 font-bold mb-1">الجهة المصدرة / المستشفى / الملاحظة</label>
                  <input
                    type="text"
                    value={formText2}
                    onChange={(e) => setFormText2(e.target.value)}
                    placeholder="الجهة أو المصدر..."
                    className="w-full bg-slate-50 border border-slate-300 rounded-xl px-3 py-2 text-slate-800 focus:outline-none focus:bg-white focus:border-emerald-600"
                  />
                </div>

                {activeTab === 'financial' && (
                  <div>
                    <label className="block text-slate-700 font-bold mb-1">نوع المعاملة المالية *</label>
                    <select
                      value={formType || 'سلفة مالية'}
                      onChange={(e) => setFormType(e.target.value)}
                      className="w-full bg-slate-50 border border-slate-300 rounded-xl px-3 py-2 text-slate-800 font-bold focus:outline-none focus:bg-white focus:border-emerald-600"
                    >
                      <option value="سلفة مالية">سلفة مالية (مستقطعة من المرتب)</option>
                      <option value="مساعدة مالية">مساعدة مالية رسمية (غير مستردة)</option>
                      <option value="مكافأة">مكافأة</option>
                      <option value="حافز">حافز</option>
                      <option value="بدل">بدل</option>
                      <option value="راتب">راتب</option>
                      <option value="استقطاع">استقطاع</option>
                    </select>
                  </div>
                )}

                {(activeTab === 'financial' || activeTab === 'medical' || activeTab === 'armament') && (
                  <div>
                    <label className="block text-slate-700 font-bold mb-1">المبلغ / الأيام / كمية الذخيرة</label>
                    <input
                      type="number"
                      value={formNum1}
                      onChange={(e) => setFormNum1(Number(e.target.value))}
                      className="w-full bg-slate-50 border border-slate-300 rounded-xl px-3 py-2 text-slate-800 font-mono focus:outline-none focus:bg-white focus:border-emerald-600"
                    />
                  </div>
                )}

                {activeTab === 'attachments' && (
                  <div className="bg-emerald-50/60 border border-emerald-200 p-3 rounded-xl space-y-2">
                    <label className="block text-emerald-900 font-bold flex items-center space-x-1.5 space-x-reverse">
                      <Paperclip className="w-4 h-4 text-emerald-700" />
                      <span>إرفاق صورة أو وثيقة إلكترونية *</span>
                    </label>
                    <div className="flex items-center gap-2">
                      <label className="cursor-pointer bg-white border border-emerald-300 hover:bg-emerald-100 text-emerald-900 px-3 py-1.5 rounded-xl flex items-center space-x-2 space-x-reverse font-bold text-xs shadow-xs transition-all">
                        <Upload className="w-3.5 h-3.5 text-emerald-700" />
                        <span>اختر صورة/وثيقة</span>
                        <input
                          type="file"
                          accept="image/*,application/pdf,.doc,.docx"
                          className="hidden"
                          onChange={async (e) => {
                            const file = e.target.files?.[0];
                            if (file) {
                              setAttFileName(file.name);
                              try {
                                const compressedUrl = await compressImageFile(file);
                                setAttFileUrl(compressedUrl);
                              } catch (err) {
                                console.error('Failed to compress attachment:', err);
                              }
                            }
                          }}
                        />
                      </label>
                      {attFileName && (
                        <span className="text-xs text-slate-800 font-bold truncate max-w-[180px] bg-white px-2 py-1 rounded border border-emerald-200">
                          {attFileName}
                        </span>
                      )}
                    </div>
                    {attFileUrl && attFileUrl.startsWith('data:image') && (
                      <img src={attFileUrl} alt="معاينة المرفق" className="w-24 h-16 object-cover rounded-lg border border-emerald-300 mt-1" />
                    )}
                  </div>
                )}

                <div className="flex items-center justify-end space-x-2 space-x-reverse pt-4 border-t border-slate-100">
                  <button
                    type="button"
                    onClick={() => setShowAddModal(false)}
                    className="px-4 py-2 bg-slate-100 text-slate-700 hover:bg-slate-200 rounded-xl font-bold transition-colors cursor-pointer"
                  >
                    إلغاء
                  </button>
                  <button
                    type="submit"
                    className="px-5 py-2 bg-emerald-700 hover:bg-emerald-800 text-white rounded-xl font-bold shadow-sm transition-colors cursor-pointer"
                  >
                    حفظ القيد
                  </button>
                </div>
              </form>
            )}
          </div>
        </div>
      )}

      {/* Fullscreen Image Preview Lightbox Modal */}
      {previewImageModal && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-md cursor-pointer"
          onClick={() => setPreviewImageModal(null)}
        >
          <div className="relative max-w-4xl max-h-[90vh] bg-slate-900 border border-slate-700 rounded-2xl overflow-hidden shadow-2xl p-2" onClick={(e) => e.stopPropagation()}>
            <button
              onClick={() => setPreviewImageModal(null)}
              className="absolute top-3 right-3 z-10 bg-slate-800/90 hover:bg-rose-600 text-white w-8 h-8 rounded-full flex items-center justify-center font-bold text-sm shadow-md transition-all"
            >
              ✕
            </button>
            <img
              src={previewImageModal}
              alt="معاينة الوثيقة المرفقة"
              className="max-w-full max-h-[85vh] object-contain rounded-xl mx-auto"
            />
          </div>
        </div>
      )}

      {/* Face Verification Camera Scan Modal */}
      <FaceVerificationModal
        isOpen={showFaceVerificationModal}
        onClose={() => setShowFaceVerificationModal(false)}
        onVerified={handleFaceVerified}
        targetPersonnel={personnel}
        taskTitle={`مسح وجه الفرد واختبار الهوية بالمباشر (${personnel.rank} / ${personnel.fullName})`}
        sensitiveTaskType="identity_check"
      />

      {/* Approval Voucher Modal */}
      <ApprovalVoucherModal
        isOpen={showVoucherModal}
        onClose={() => setShowVoucherModal(false)}
        voucherData={voucherData}
      />

      {/* Dedicated Financial Advance / Aid Granting Modal */}
      {showGrantModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-xs animate-in fade-in duration-200">
          <div className="bg-white rounded-3xl border border-slate-200 shadow-2xl w-full max-w-lg overflow-hidden flex flex-col max-h-[90vh]">
            <div className="p-5 bg-gradient-to-l from-slate-900 via-slate-800 to-slate-900 text-white flex items-center justify-between border-b border-slate-700">
              <div className="flex items-center space-x-3 space-x-reverse">
                <div className={`p-2.5 rounded-2xl border ${
                  grantType === 'سلفة مالية'
                    ? 'bg-amber-500/20 border-amber-400/40 text-amber-400'
                    : 'bg-emerald-500/20 border-emerald-400/40 text-emerald-400'
                }`}>
                  {grantType === 'سلفة مالية' ? <AlertTriangle className="w-6 h-6" /> : <Gift className="w-6 h-6" />}
                </div>
                <div>
                  <h3 className="text-base font-black font-['Tajawal'] text-white">
                    {grantType === 'سلفة مالية' ? 'صرف سلفة مالية على المرتب' : 'منح مساعدة مالية رسمية (غير مستردة)'}
                  </h3>
                  <p className="text-xs text-slate-300">
                    تقييد العملية مباشرة في ملف: {personnel.rank} / {personnel.fullName} ({personnel.militaryId})
                  </p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setShowGrantModal(false)}
                className="text-slate-400 hover:text-white bg-slate-800 hover:bg-slate-700 p-2 rounded-xl text-xs font-bold transition-all cursor-pointer"
              >
                ✕
              </button>
            </div>

            <form onSubmit={handleGrantSubmitInProfile} className="p-6 space-y-4 overflow-y-auto text-xs text-right">
              {/* Type Switcher */}
              <div className="grid grid-cols-2 gap-2 p-1.5 bg-slate-100 rounded-2xl border border-slate-200">
                <button
                  type="button"
                  onClick={() => {
                    setGrantType('سلفة مالية');
                    if (!grantReason || grantReason.includes('مساعدة')) {
                      setGrantReason('طلب سلفة مالية مؤقتة على المرتب');
                    }
                  }}
                  className={`py-2 px-3 rounded-xl font-black text-xs transition-all flex items-center justify-center space-x-1.5 space-x-reverse cursor-pointer ${
                    grantType === 'سلفة مالية'
                      ? 'bg-amber-500 text-slate-950 shadow-sm'
                      : 'text-slate-700 hover:text-slate-950'
                  }`}
                >
                  <AlertTriangle className="w-3.5 h-3.5" />
                  <span>سلفة مالية (مستقطعة)</span>
                </button>
                <button
                  type="button"
                  onClick={() => {
                    setGrantType('مساعدة مالية');
                    if (!grantReason || grantReason.includes('سلفة')) {
                      setGrantReason('مساعدة وإعانة مالية استثنائية');
                    }
                  }}
                  className={`py-2 px-3 rounded-xl font-black text-xs transition-all flex items-center justify-center space-x-1.5 space-x-reverse cursor-pointer ${
                    grantType === 'مساعدة مالية'
                      ? 'bg-emerald-600 text-white shadow-sm'
                      : 'text-slate-700 hover:text-slate-950'
                  }`}
                >
                  <Gift className="w-3.5 h-3.5" />
                  <span>مساعدة مالية (غير مستردة)</span>
                </button>
              </div>

              {/* Notice Box */}
              <div className={`p-3 rounded-2xl border leading-relaxed text-[11px] ${
                grantType === 'سلفة مالية'
                  ? 'bg-amber-50 border-amber-200 text-amber-950'
                  : 'bg-emerald-50 border-emerald-200 text-emerald-950'
              }`}>
                {grantType === 'سلفة مالية' ? (
                  <span>
                    ⚠️ <strong>تنبيه السلفة المالية:</strong> سيتم تقييد هذه السلفة فورياً في ملف الفرد، واحتسابها تلقائياً كاستقطاع وخصم من مسير مرتب الشهر المحدد وتحديث صافي مرتبه، وتوليد سند صرف رسمي برقم وسند مرجعي.
                  </span>
                ) : (
                  <span>
                    🎁 <strong>مساعدة مالية غير مستردة:</strong> تُصرف كإعانة ومكرمة استثنائية للفرد دون أي استقطاع أو مساس بمرتبه الشهري، ويتم تثبيتها بملفه الإلكتروني مع إصدار سند الصرف المعتمد.
                  </span>
                )}
              </div>

              {/* Amount and Month */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-slate-700 font-bold mb-1">المبلغ المالي المعتمد (ريال) *</label>
                  <input
                    type="number"
                    required
                    min="1"
                    value={grantAmount}
                    onChange={(e) => setGrantAmount(Math.max(0, Number(e.target.value)))}
                    className="w-full bg-slate-50 border border-slate-300 rounded-xl px-3 py-2 text-slate-900 font-bold font-mono focus:outline-none focus:bg-white focus:border-emerald-600"
                  />
                </div>

                <div>
                  <label className="block text-slate-700 font-bold mb-1">
                    {grantType === 'سلفة مالية' ? 'شهر الخصم والاستقطاع *' : 'شهر المسير المرجعي *'}
                  </label>
                  <input
                    type="month"
                    required
                    value={grantMonth}
                    onChange={(e) => setGrantMonth(e.target.value)}
                    className="w-full bg-slate-50 border border-slate-300 rounded-xl px-3 py-2 text-slate-900 font-bold font-mono focus:outline-none focus:bg-white focus:border-emerald-600"
                  />
                </div>
              </div>

              {/* Date and Approver */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-slate-700 font-bold mb-1">تاريخ المعاملة والصرف *</label>
                  <input
                    type="date"
                    required
                    value={grantDate}
                    onChange={(e) => setGrantDate(e.target.value)}
                    className="w-full bg-slate-50 border border-slate-300 rounded-xl px-3 py-2 text-slate-900 font-bold focus:outline-none focus:bg-white focus:border-emerald-600"
                  />
                </div>

                <div>
                  <label className="block text-slate-700 font-bold mb-1">الضابط أو الجهة المصادقة *</label>
                  <input
                    type="text"
                    required
                    value={grantOfficer}
                    onChange={(e) => setGrantOfficer(e.target.value)}
                    className="w-full bg-slate-50 border border-slate-300 rounded-xl px-3 py-2 text-slate-900 font-bold focus:outline-none focus:bg-white focus:border-emerald-600"
                  />
                </div>
              </div>

              {/* Reason */}
              <div>
                <label className="block text-slate-700 font-bold mb-1">سبب ومن مبرر الصرف *</label>
                <input
                  type="text"
                  required
                  value={grantReason}
                  onChange={(e) => setGrantReason(e.target.value)}
                  placeholder={grantType === 'سلفة مالية' ? 'مثال: طلب سلفة عائلية طارئة على الراتب...' : 'مثال: مكرمة ومساعدة علاجية استثنائية...'}
                  className="w-full bg-slate-50 border border-slate-300 rounded-xl px-3 py-2 text-slate-900 font-bold focus:outline-none focus:bg-white focus:border-emerald-600"
                />
              </div>

              {/* Notes */}
              <div>
                <label className="block text-slate-700 font-bold mb-1">الملاحظات والتوجيهات المالية</label>
                <textarea
                  rows={2}
                  value={grantNotes}
                  onChange={(e) => setGrantNotes(e.target.value)}
                  className="w-full bg-slate-50 border border-slate-300 rounded-xl px-3 py-2 text-slate-900 font-medium focus:outline-none focus:bg-white focus:border-emerald-600"
                />
              </div>

              <div className="pt-3 border-t border-slate-200 flex items-center justify-end space-x-2 space-x-reverse">
                <button
                  type="button"
                  onClick={() => setShowGrantModal(false)}
                  className="px-4 py-2.5 rounded-xl border border-slate-300 text-slate-700 font-bold hover:bg-slate-100 transition-all cursor-pointer"
                >
                  إلغاء
                </button>
                <button
                  type="submit"
                  disabled={grantSubmitting}
                  className={`px-6 py-2.5 rounded-xl font-black shadow-md transition-all flex items-center space-x-1.5 space-x-reverse cursor-pointer ${
                    grantType === 'سلفة مالية'
                      ? 'bg-amber-500 hover:bg-amber-600 text-slate-950'
                      : 'bg-emerald-700 hover:bg-emerald-800 text-white'
                  }`}
                >
                  <Check className="w-4 h-4" />
                  <span>{grantSubmitting ? 'جاري المعالجة...' : 'تأكيد الصرف وتوثيقه بملف الفرد 💾'}</span>
                </button>
              </div>
            </form>
          </div>
        </div>
      )}


      {/* Status Change & Discipline Tracking Modal */}
      <StatusChangeModal
        isOpen={showStatusChangeModal}
        onClose={() => setShowStatusChangeModal(false)}
        personnel={personnel}
        onConfirm={(militaryId, newStatus, extraDetails) => {
          StorageService.updateStatus(
            militaryId,
            newStatus,
            extraDetails?.reason || `تحديث حالة الجاهزية إلى [${newStatus}]`,
            'المستخدم الحالي',
            currentRole,
            extraDetails
          );
          onRefresh();
          setSuccessToast(`تم حفظ وتحديث حالة الفرد بنجاح إلى (${newStatus})`);
        }}
      />

      {/* Instant Profile Photo Update Modal */}
      {showPhotoModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-sm animate-in fade-in duration-200">
          <div className="bg-white rounded-3xl border border-slate-200 shadow-2xl w-full max-w-lg overflow-hidden flex flex-col max-h-[90vh]">
            <div className="p-5 bg-gradient-to-l from-slate-900 via-slate-800 to-slate-900 text-white flex items-center justify-between border-b border-slate-700">
              <div className="flex items-center space-x-3 space-x-reverse">
                <div className="p-2.5 bg-emerald-600/30 border border-emerald-500/50 rounded-2xl text-emerald-400">
                  <Camera className="w-6 h-6" />
                </div>
                <div>
                  <h3 className="text-base font-black font-['Tajawal'] text-emerald-400">
                    تحديث الصورة العسكرية الشخصية
                  </h3>
                  <p className="text-xs text-slate-300">
                    {personnel.rank} / {personnel.fullName} ({personnel.militaryId})
                  </p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setShowPhotoModal(false)}
                className="text-slate-400 hover:text-white bg-slate-800 hover:bg-slate-700 p-2 rounded-xl text-xs font-bold transition-all cursor-pointer"
              >
                ✕
              </button>
            </div>

            <div className="p-6 space-y-4 overflow-y-auto">
              <div className="text-xs text-slate-600 bg-slate-50 border border-slate-200 p-3 rounded-2xl leading-relaxed">
                💡 يمكنك التقاط صورة فورية عبر كاميرا الجهاز أو اختيار صورة شخصية من المعرض. يتم ضغط الصورة وحفظها فورياً ومزامنتها محلياً وسحابياً دون فقدان.
              </div>

              <ImageUploadPicker
                label="الصورة الشخصية العسكرية"
                value={tempPhotoUrl}
                onChange={(img) => setTempPhotoUrl(img)}
                maxDimension={400}
                quality={0.75}
              />
            </div>

            <div className="p-4 bg-slate-50 border-t border-slate-200 flex items-center justify-end space-x-3 space-x-reverse">
              <button
                type="button"
                onClick={() => setShowPhotoModal(false)}
                className="px-4 py-2.5 rounded-xl border border-slate-300 text-slate-700 font-bold text-xs hover:bg-slate-100 transition-all cursor-pointer"
              >
                إلغاء
              </button>
              <button
                type="button"
                onClick={async () => {
                  try {
                    let finalPhoto = '';
                    if (tempPhotoUrl && tempPhotoUrl.trim()) {
                      finalPhoto = await compressBase64Image(tempPhotoUrl, 400, 400, 0.75);
                    }
                    const updatedRecord = { ...personnel, photoUrl: finalPhoto };
                    StorageService.updatePersonnel(
                      updatedRecord,
                      'المستخدم الحالي',
                      currentRole,
                      finalPhoto ? 'تحديث الصورة الشخصية للفرد' : 'حذف الصورة الشخصية للفرد',
                      personnel.militaryId
                    );
                    onRefresh();
                    setShowPhotoModal(false);
                    setSuccessToast(finalPhoto ? 'تم حفظ وتحديث الصورة الشخصية للفرد بنجاح في قاعدة البيانات.' : 'تم حذف الصورة والاعتماد على الرمز العسكري.');
                  } catch (e) {
                    console.error('Error saving photo:', e);
                  }
                }}
                className="px-6 py-2.5 rounded-xl bg-emerald-700 hover:bg-emerald-800 text-white font-black text-xs shadow-md transition-all flex items-center space-x-1.5 space-x-reverse cursor-pointer"
              >
                <Check className="w-4 h-4" />
                <span>حفظ وتثبيت التعديل 💾</span>
              </button>
            </div>
          </div>
        </div>
      )}

    </div>
  );
};
