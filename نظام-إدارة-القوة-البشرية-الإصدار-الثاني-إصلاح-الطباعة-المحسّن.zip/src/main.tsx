import {StrictMode} from 'react';
import {createRoot} from 'react-dom/client';
import App from './App.tsx';
import './index.css';
import { registerServiceWorker } from './lib/pwa.ts';
import { ErrorBoundary } from './components/ErrorBoundary.tsx';
import { initSafeStorage } from './lib/safeLocalStorage.ts';

// Ensure any legacy desktop-forced-mode or zoom is reset to standard responsive mobile/web layout
try {
  localStorage.removeItem('military_app_display_mode');
  localStorage.removeItem('military_app_display_zoom');
  if (typeof document !== 'undefined') {
    document.documentElement.classList.remove('desktop-forced-mode');
    document.body?.classList.remove('desktop-forced-mode');
    (document.documentElement.style as any).zoom = '';
    if (document.body) (document.body.style as any).zoom = '';
    const root = document.getElementById('root');
    if (root) {
      root.style.minWidth = '';
      root.style.width = '';
    }
  }
} catch {}

let isMounted = false;

function mountApplication() {
  if (isMounted) return;
  isMounted = true;

  try {
    registerServiceWorker();
  } catch (err) {
    console.warn('[PWA] Service Worker initialization skipped:', err);
  }

  const container = document.getElementById('root');
  if (container) {
    createRoot(container).render(
      <StrictMode>
        <ErrorBoundary>
          <App />
        </ErrorBoundary>
      </StrictMode>,
    );
  }
}

// Ensure zero data loss by pre-hydrating IndexedDB into memory before React mounts,
// but never freeze the UI startup for more than 150ms
Promise.race([
  initSafeStorage().catch(() => false),
  new Promise((res) => setTimeout(res, 150))
]).finally(() => {
  mountApplication();
});

