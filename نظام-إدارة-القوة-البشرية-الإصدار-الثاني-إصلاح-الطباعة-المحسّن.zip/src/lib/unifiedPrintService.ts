/**
 * خدمة طباعة موحدة للأقسام والتقارير والسندات في المتصفح وAndroid/Capacitor.
 * تعتمد على نافذة الطباعة الأصلية عبر @capgo/capacitor-printer، وتحوّل التنسيقات
 * المحسوبة إلى أنماط مضمّنة لتجنّب صفحة المعاينة البيضاء بعد تحويل التطبيق.
 */
import { Printer } from '@capgo/capacitor-printer';

export interface UnifiedPrintOptions {
  element: HTMLElement | null;
  documentTitle?: string;
  orientation?: 'portrait' | 'landscape';
  onBeforePrint?: () => void;
  onAfterPrint?: () => void;
}
export interface UnifiedPrintResult {
  success: boolean;
  method: 'native_print' | 'share_document' | 'file_export' | 'fallback';
  message?: string;
  error?: any;
}

export async function preparePrintableDocument(target: HTMLElement | null): Promise<boolean> {
  if (!target) return false;
  try {
    if (document.fonts?.ready) await Promise.race([document.fonts.ready, new Promise((r) => setTimeout(r, 2500))]);
    const images = Array.from(target.querySelectorAll('img'));
    await Promise.all(images.map((img) => {
      if (img.complete && img.naturalWidth > 0) return Promise.resolve();
      return new Promise<void>((resolve) => {
        const done = () => resolve();
        img.addEventListener('load', done, { once: true });
        img.addEventListener('error', done, { once: true });
        setTimeout(done, 1800);
      });
    }));
    await new Promise((resolve) => requestAnimationFrame(() => setTimeout(resolve, 80)));
    return true;
  } catch (e) {
    console.warn('[PrintService] preparation warning', e);
    return true;
  }
}

function safeTitle(value: string): string {
  return value.replace(/[&<>"']/g, (ch) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[ch] || ch));
}

function copyComputedStyles(source: Element, clone: Element): void {
  if (source instanceof HTMLElement && clone instanceof HTMLElement) {
    try {
      const computed = window.getComputedStyle(source);
      const props = [
        'display','position','box-sizing','width','min-width','max-width','height','min-height','max-height',
        'margin','margin-top','margin-right','margin-bottom','margin-left','padding','padding-top','padding-right','padding-bottom','padding-left',
        'border','border-top','border-right','border-bottom','border-left','border-radius','border-collapse','border-spacing',
        'background','background-color','background-image','color','font-family','font-size','font-weight','font-style','line-height',
        'text-align','text-decoration','text-transform','white-space','word-break','overflow-wrap','vertical-align',
        'flex','flex-direction','flex-wrap','flex-grow','flex-shrink','align-items','align-self','justify-content','gap',
        'grid-template-columns','grid-column','grid-row','float','clear','direction','opacity','visibility','list-style','page-break-inside'
      ];
      for (const prop of props) {
        const value = computed.getPropertyValue(prop);
        if (value) clone.style.setProperty(prop, value);
      }
    } catch { /* بعض العناصر لا تدعم حساب الأنماط */ }
  }
  const sourceChildren = Array.from(source.children);
  const cloneChildren = Array.from(clone.children);
  for (let i = 0; i < Math.min(sourceChildren.length, cloneChildren.length); i++) {
    copyComputedStyles(sourceChildren[i], cloneChildren[i]);
  }
}

function buildPrintableHtml(element: HTMLElement, title: string, orientation: 'portrait' | 'landscape'): string {
  const clone = element.cloneNode(true) as HTMLElement;
  copyComputedStyles(element, clone);
  // تحويل اللوحات/الحقول التفاعلية إلى نص قابل للطباعة بدل إسقاط قيمها.
  const originalFields = Array.from(element.querySelectorAll('input, textarea, select'));
  const clonedFields = Array.from(clone.querySelectorAll('input, textarea, select'));
  clonedFields.forEach((field, index) => {
    const source = originalFields[index];
    let value = '';
    if (source instanceof HTMLInputElement) value = source.type === 'checkbox' ? (source.checked ? '✓' : '') : source.value;
    else if (source instanceof HTMLTextAreaElement) value = source.value;
    else if (source instanceof HTMLSelectElement) value = source.selectedOptions[0]?.textContent || '';
    const span = document.createElement('span');
    span.textContent = value || field.textContent || '';
    span.setAttribute('style', field.getAttribute('style') || '');
    field.replaceWith(span);
  });
  clone.querySelectorAll('button, .no-print, [data-no-print], .print\\:hidden').forEach((node) => node.remove());
  clone.querySelectorAll('canvas').forEach((canvas) => {
    try {
      const img = document.createElement('img');
      img.src = (canvas as HTMLCanvasElement).toDataURL('image/png');
      img.style.maxWidth = '100%';
      canvas.replaceWith(img);
    } catch { /* تجاهل canvas غير القابل للتحويل */ }
  });
  clone.querySelectorAll('img').forEach((img) => {
    try { img.src = new URL(img.getAttribute('src') || '', document.baseURI).href; } catch { /* keep source */ }
  });
  const titleText = safeTitle(title || 'تقرير رسمي');
  const pageSize = orientation === 'landscape' ? 'A4 landscape' : 'A4 portrait';
  return `<!doctype html><html lang="ar" dir="rtl"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1"><title>${titleText}</title>
  <style>
    *{box-sizing:border-box;-webkit-print-color-adjust:exact!important;print-color-adjust:exact!important}
    html,body{margin:0;padding:0;background:#fff;color:#111827;font-family:Arial,Tahoma,sans-serif;direction:rtl}
    body{padding:8mm;font-size:12px}
    @page{size:${pageSize};margin:8mm}
    table{width:100%;border-collapse:collapse;page-break-inside:auto}
    th,td{border:1px solid #9ca3af;padding:5px 7px;vertical-align:top}
    tr{page-break-inside:avoid;break-inside:avoid}
    img{max-width:100%;height:auto}
    .no-print,[data-no-print],button{display:none!important}
    @media print{body{padding:0} .no-print,[data-no-print],button{display:none!important}}
  </style></head><body><main>${clone.outerHTML}</main></body></html>`;
}

export async function executeUnifiedPrint(
  targetOrOptions: HTMLElement | null | UnifiedPrintOptions,
  secondaryOptions?: Omit<UnifiedPrintOptions, 'element'>
): Promise<UnifiedPrintResult> {
  let element: HTMLElement | null = null;
  let documentTitle = 'تقرير رسمي';
  let orientation: 'portrait' | 'landscape' = 'portrait';
  let onBeforePrint: (() => void) | undefined;
  let onAfterPrint: (() => void) | undefined;
  if (targetOrOptions && typeof targetOrOptions === 'object' && 'nodeType' in targetOrOptions) {
    element = targetOrOptions as HTMLElement;
    if (secondaryOptions) {
      documentTitle = secondaryOptions.documentTitle || documentTitle;
      orientation = secondaryOptions.orientation || orientation;
      onBeforePrint = secondaryOptions.onBeforePrint;
      onAfterPrint = secondaryOptions.onAfterPrint;
    }
  } else if (targetOrOptions && typeof targetOrOptions === 'object') {
    const opts = targetOrOptions as UnifiedPrintOptions;
    element = opts.element;
    documentTitle = opts.documentTitle || documentTitle;
    orientation = opts.orientation || orientation;
    onBeforePrint = opts.onBeforePrint;
    onAfterPrint = opts.onAfterPrint;
  }
  if (!element) return { success: false, method: 'fallback', message: 'لم يتم العثور على محتوى المستند المراد طباعته.' };

  await preparePrintableDocument(element);
  try { onBeforePrint?.(); } catch (e) { console.warn('[PrintService] onBeforePrint warning', e); }
  const html = buildPrintableHtml(element, documentTitle, orientation);
  try {
    // Android: يفتح نافذة الطباعة الأصلية. Web/Windows: يطبع HTML داخل إطار مستقل،
    // ما يمنع اعتماد المعاينة على عناصر التطبيق أو CSS الذي قد يخفي التقرير.
    await Printer.printHtml({ name: documentTitle, html });
    try { onAfterPrint?.(); } catch (e) { console.warn('[PrintService] onAfterPrint warning', e); }
    return { success: true, method: 'native_print', message: 'تم إرسال المستند إلى نافذة الطباعة.' };
  } catch (printError) {
    console.warn('[PrintService] Printer plugin failed; trying printable window', printError);
    try {
      const win = window.open('', '_blank');
      if (win) {
        win.document.open(); win.document.write(html); win.document.close();
        win.onload = () => setTimeout(() => { try { win.focus(); win.print(); } catch { /* viewer may not support print */ } }, 700);
        try { onAfterPrint?.(); } catch { /* no-op */ }
        return { success: true, method: 'fallback', message: 'تم فتح المستند في نافذة مستقلة للطباعة.' };
      }
    } catch (fallbackError) { console.warn('[PrintService] popup fallback failed', fallbackError); }
    try { onAfterPrint?.(); } catch { /* no-op */ }
    return { success: false, method: 'fallback', message: 'تعذرت الطباعة المباشرة. يرجى إعادة المحاولة أو فتح التطبيق في المتصفح.', error: printError };
  }
}

export async function executeUnifiedPrintFromButton(button: HTMLElement, documentTitle = 'تقرير رسمي', orientation: 'portrait' | 'landscape' = 'portrait'): Promise<UnifiedPrintResult> {
  const direct = button.closest('.printable-modal-card, [data-print-target], .printable-content, .printable-document');
  if (direct instanceof HTMLElement) return executeUnifiedPrint({ element: direct, documentTitle, orientation });
  const modal = button.closest('.fixed.inset-0');
  if (modal instanceof HTMLElement && modal.firstElementChild instanceof HTMLElement) {
    return executeUnifiedPrint({ element: modal.firstElementChild, documentTitle, orientation });
  }
  let section: HTMLElement | null = button.parentElement;
  while (section && section !== document.body) {
    if (section.classList.contains('space-y-4') || section.tagName === 'SECTION' || section.tagName === 'ARTICLE') break;
    section = section.parentElement;
  }
  return executeUnifiedPrint({ element: section || button.parentElement || document.body, documentTitle, orientation });
}

export async function shareOrSavePrintableDocument(
  element: HTMLElement | null,
  titleOrOptions: string | { title?: string; filename?: string; orientation?: 'portrait' | 'landscape' },
  orientationParam: 'portrait' | 'landscape' = 'portrait'
): Promise<boolean> {
  if (!element) return false;
  const title = typeof titleOrOptions === 'string' ? titleOrOptions : (titleOrOptions.title || 'وثيقة رسمية');
  const orientation = typeof titleOrOptions === 'string' ? orientationParam : (titleOrOptions.orientation || orientationParam);
  const html = buildPrintableHtml(element, title, orientation);
  try {
    const fileName = (typeof titleOrOptions === 'object' && titleOrOptions.filename) || `${title.replace(/[\\/?%*:|"<>]/g, '_')}.html`;
    const blob = new Blob([html], { type: 'text/html;charset=utf-8' });
    if (/Android|iPhone|iPad|iPod|Mobile/i.test(navigator.userAgent) && typeof navigator.share === 'function') {
      const file = new File([blob], fileName, { type: 'text/html' });
      if (!navigator.canShare || navigator.canShare({ files: [file] })) {
        await navigator.share({ files: [file], title, text: `وثيقة للطباعة: ${title}` });
        return true;
      }
    }
    const url = URL.createObjectURL(blob);
    const anchor = document.createElement('a'); anchor.href = url; anchor.download = fileName; anchor.click();
    setTimeout(() => URL.revokeObjectURL(url), 5000);
    return true;
  } catch (e) { console.error('[PrintService] export failed', e); return false; }
}
