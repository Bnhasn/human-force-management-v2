import { initializeApp, getApps } from 'firebase/app';
import {
  initializeFirestore,
  getFirestore,
  doc,
  setDoc,
  onSnapshot,
  getDoc,
  setLogLevel,
  persistentLocalCache,
  persistentMultipleTabManager,
} from 'firebase/firestore';
import firebaseConfig from '../../firebase-applet-config.json';
import { safeSetLocalItem } from './safeLocalStorage';

// Silence verbose/internal Firestore backend connection logs when working offline/flaky network
try {
  setLogLevel('silent');
} catch (e) {
  // ignore if not supported
}

// Suppress noisy Firestore backend reachability log warnings in the console
if (typeof window !== 'undefined') {
  const filterMsg = (msg: any) =>
    typeof msg === 'string' &&
    (msg.includes('Could not reach Cloud Firestore backend') ||
      msg.includes('Firestore (12.16.0)') ||
      msg.includes('@firebase/firestore'));

  const origWarn = console.warn;
  console.warn = function (...args: any[]) {
    if (args.some(filterMsg)) return;
    origWarn.apply(console, args);
  };

  const origError = console.error;
  console.error = function (...args: any[]) {
    if (args.some(filterMsg)) return;
    origError.apply(console, args);
  };
}

const app = getApps().length === 0 ? initializeApp(firebaseConfig) : getApps()[0];

const databaseId = firebaseConfig.firestoreDatabaseId || '(default)';

let firestoreInstance: any;
try {
  firestoreInstance = initializeFirestore(app, {
    localCache: persistentLocalCache({ tabManager: persistentMultipleTabManager() }),
    experimentalAutoDetectLongPolling: true,
  }, databaseId);
} catch (e) {
  try {
    firestoreInstance = initializeFirestore(app, {
      experimentalForceLongPolling: true,
    }, databaseId);
  } catch (err2) {
    firestoreInstance = getFirestore(app, databaseId);
  }
}

export const db = firestoreInstance;

const MAX_DOC_BYTES = 500000; // 500 KB limit for safe Firestore document headroom
const ITEMS_PER_CHUNK = 200;  // 200 items per chunk for multi-thousand scalability

// Direct write to cloud with Automatic Chunking for thousands of records
export async function syncDocToCloudDirect<T>(docId: string, data: T): Promise<boolean> {
  try {
    if (!db) return false;
    if (typeof navigator !== 'undefined' && !navigator.onLine) return false;

    const serialized = JSON.stringify(data);

    // If large array, chunk across multiple Firestore documents
    if (Array.isArray(data) && (serialized.length > MAX_DOC_BYTES || data.length > ITEMS_PER_CHUNK)) {
      const totalChunks = Math.ceil(data.length / ITEMS_PER_CHUNK);
      
      // Write each chunk
      const chunkPromises = [];
      for (let i = 0; i < totalChunks; i++) {
        const chunkData = data.slice(i * ITEMS_PER_CHUNK, (i + 1) * ITEMS_PER_CHUNK);
        const chunkDocRef = doc(db, 'app_data', `${docId}_chunk_${i}`);
        chunkPromises.push(
          setDoc(chunkDocRef, {
            payload: JSON.stringify(chunkData),
            chunkIndex: i,
            totalChunks,
            updatedAt: new Date().toISOString()
          }, { merge: true })
        );
      }
      await Promise.all(chunkPromises);

      // Write master manifest document
      const manifestDocRef = doc(db, 'app_data', docId);
      await setDoc(manifestDocRef, {
        isChunked: true,
        totalChunks,
        totalItems: data.length,
        updatedAt: new Date().toISOString()
      }, { merge: true });

      return true;
    }

    // Standard single document write
    const docRef = doc(db, 'app_data', docId);
    await setDoc(docRef, {
      isChunked: false,
      payload: serialized,
      updatedAt: new Date().toISOString()
    }, { merge: true });
    return true;
  } catch (err) {
    // Silent fail over to local storage
    return false;
  }
}

// Synchronize document data to Firestore cloud
export async function syncDocToCloud<T>(docId: string, data: T): Promise<void> {
  await syncDocToCloudDirect(docId, data);
}

// Helper to fetch chunked data
async function fetchAllChunks<T>(docId: string, totalChunks: number): Promise<T | null> {
  try {
    const chunkPromises = [];
    for (let i = 0; i < totalChunks; i++) {
      const chunkRef = doc(db, 'app_data', `${docId}_chunk_${i}`);
      chunkPromises.push(getDoc(chunkRef));
    }
    const chunkSnaps = await Promise.all(chunkPromises);
    const combined: any[] = [];

    for (const snap of chunkSnaps) {
      if (snap.exists()) {
        const d = snap.data();
        if (d && d.payload) {
          const parsed = JSON.parse(d.payload);
          if (Array.isArray(parsed)) {
            combined.push(...parsed);
          }
        }
      }
    }

    return combined as unknown as T;
  } catch (e) {
    return null;
  }
}

// Subscribe to real-time cloud updates from Firestore
export function subscribeCloudDoc<T>(
  docId: string,
  onDataReceived: (data: T) => void,
  initialFallbackData?: T,
  storageKey?: string
): () => void {
  if (!db) return () => {};

  try {
    const docRef = doc(db, 'app_data', docId);
    const unsubscribe = onSnapshot(docRef, async (docSnap) => {
      // Do not overwrite with local uncommitted pending writes
      if (docSnap.metadata.hasPendingWrites) {
        return;
      }

      if (docSnap.exists()) {
        const snapData = docSnap.data();
        if (snapData) {
          if (snapData.isChunked && snapData.totalChunks > 0) {
            // Reconstruct multi-chunk data
            const chunkedData = await fetchAllChunks<T>(docId, snapData.totalChunks);
            if (chunkedData) {
              onDataReceived(chunkedData);
            }
          } else if (snapData.payload) {
            try {
              const parsed = JSON.parse(snapData.payload) as T;
              onDataReceived(parsed);
            } catch (e) {}
          }
        }
      } else if (initialFallbackData !== undefined) {
        // Doc doesn't exist on cloud yet, upload local initial fallback data
        syncDocToCloudDirect(docId, initialFallbackData);
      }
    }, (error) => {
      // Quiet handler for offline or timeout snapshot errors
    });

    return unsubscribe;
  } catch (e) {
    return () => {};
  }
}

// Force fetch document from Cloud Firestore
export async function fetchCloudDoc<T>(docId: string): Promise<T | null> {
  try {
    if (!db) return null;
    if (typeof navigator !== 'undefined' && !navigator.onLine) return null;

    const docRef = doc(db, 'app_data', docId);
    const fetchPromise = getDoc(docRef);
    const timeoutPromise = new Promise<null>((resolve) => setTimeout(() => resolve(null), 3000));
    
    const result = await Promise.race([fetchPromise, timeoutPromise]);
    if (!result) return null;

    const docSnap = result as any;
    if (docSnap && docSnap.exists && docSnap.exists()) {
      const data = docSnap.data();
      if (data) {
        if (data.isChunked && data.totalChunks > 0) {
          return await fetchAllChunks<T>(docId, data.totalChunks);
        }
        if (data.payload) {
          return JSON.parse(data.payload) as T;
        }
      }
    }
    return null;
  } catch (err) {
    return null;
  }
}
