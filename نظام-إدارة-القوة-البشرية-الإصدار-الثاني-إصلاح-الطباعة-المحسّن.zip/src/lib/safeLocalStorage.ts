// Zero Data Loss Local Persistence Engine (High-Capacity IndexedDB + Persistent Browser Storage + LocalStorage + Auto-Snapshots)

const DB_NAME = 'MilitaryHQSafeStorage_v3';
const DB_VERSION = 3;
const STORE_NAME = 'records';
const LARGE_BLOBS_STORE = 'attachments_and_blobs';
const SNAPSHOTS_STORE = 'system_snapshots';

let idbInstancePromise: Promise<IDBDatabase> | null = null;
let isStorageReady = false;

// Request Persistent Storage from the browser to prevent eviction
export async function requestPersistentStorage(): Promise<{ persisted: boolean; quotaGB: number; usedMB: number }> {
  let persisted = false;
  let quotaGB = 50; // Default estimate
  let usedMB = 0;

  if (typeof navigator !== 'undefined' && navigator.storage) {
    try {
      if (navigator.storage.persist) {
        persisted = await navigator.storage.persist();
      } else if (navigator.storage.persisted) {
        persisted = await navigator.storage.persisted();
      }

      if (navigator.storage.estimate) {
        const estimate = await navigator.storage.estimate();
        if (estimate.quota) {
          quotaGB = parseFloat((estimate.quota / (1024 * 1024 * 1024)).toFixed(2));
        }
        if (estimate.usage) {
          usedMB = parseFloat((estimate.usage / (1024 * 1024)).toFixed(2));
        }
      }
    } catch (e) {
      console.warn('[StorageEngine] Persistent storage check error:', e);
    }
  }

  return { persisted, quotaGB, usedMB };
}

// Open IndexedDB with seamless upgrade and schema management
export function openIDB(): Promise<IDBDatabase> {
  if (idbInstancePromise) return idbInstancePromise;

  idbInstancePromise = new Promise((resolve, reject) => {
    if (typeof window === 'undefined' || !window.indexedDB) {
      reject(new Error('IndexedDB not supported'));
      return;
    }

    // Safety timeout in case browser hangs on indexedDB.open
    const timer = setTimeout(() => {
      idbInstancePromise = null;
      reject(new Error('IndexedDB open timeout'));
    }, 1500);

    try {
      const request = indexedDB.open(DB_NAME, DB_VERSION);

      request.onupgradeneeded = (e: any) => {
        try {
          const db = e.target.result;
          if (!db.objectStoreNames.contains(STORE_NAME)) {
            db.createObjectStore(STORE_NAME);
          }
          if (!db.objectStoreNames.contains(LARGE_BLOBS_STORE)) {
            db.createObjectStore(LARGE_BLOBS_STORE);
          }
          if (!db.objectStoreNames.contains(SNAPSHOTS_STORE)) {
            db.createObjectStore(SNAPSHOTS_STORE);
          }
        } catch (err) {
          console.warn('[SafeStorage IDB] upgrade schema error:', err);
        }
      };

      request.onsuccess = () => {
        clearTimeout(timer);
        resolve(request.result);
      };

      request.onerror = () => {
        clearTimeout(timer);
        idbInstancePromise = null;
        reject(request.error);
      };

      request.onblocked = () => {
        clearTimeout(timer);
        idbInstancePromise = null;
        console.warn('[SafeStorage IDB] IndexedDB version upgrade blocked by another tab');
        reject(new Error('IndexedDB blocked'));
      };
    } catch (err) {
      clearTimeout(timer);
      idbInstancePromise = null;
      reject(err);
    }
  });

  return idbInstancePromise;
}

export async function setIDBItem(key: string, value: any): Promise<void> {
  try {
    const db = await openIDB();
    return new Promise((resolve, reject) => {
      const tx = db.transaction(STORE_NAME, 'readwrite');
      const store = tx.objectStore(STORE_NAME);
      const req = store.put(value, key);
      req.onsuccess = () => resolve();
      req.onerror = () => reject(req.error);
    });
  } catch (err) {
    console.warn('[SafeStorage IDB] Write failed:', err);
  }
}

export async function getIDBItem<T>(key: string): Promise<T | null> {
  try {
    const db = await openIDB();
    return new Promise((resolve) => {
      const tx = db.transaction(STORE_NAME, 'readonly');
      const store = tx.objectStore(STORE_NAME);
      const req = store.get(key);
      req.onsuccess = () => resolve(req.result !== undefined ? req.result : null);
      req.onerror = () => resolve(null);
    });
  } catch (err) {
    return null;
  }
}

export async function deleteIDBItem(key: string): Promise<void> {
  try {
    const db = await openIDB();
    return new Promise((resolve) => {
      const tx = db.transaction(STORE_NAME, 'readwrite');
      const store = tx.objectStore(STORE_NAME);
      const req = store.delete(key);
      req.onsuccess = () => resolve();
      req.onerror = () => resolve();
    });
  } catch (err) {}
}

export async function getAllIDBEntries(): Promise<Record<string, any>> {
  try {
    const db = await openIDB();
    return new Promise((resolve) => {
      const tx = db.transaction(STORE_NAME, 'readonly');
      const store = tx.objectStore(STORE_NAME);
      const keysReq = store.getAllKeys();
      const valsReq = store.getAll();

      tx.oncomplete = () => {
        const keys = keysReq.result || [];
        const vals = valsReq.result || [];
        const res: Record<string, any> = {};
        for (let i = 0; i < keys.length; i++) {
          res[String(keys[i])] = vals[i];
        }
        resolve(res);
      };

      tx.onerror = () => resolve({});
    });
  } catch (err) {
    return {};
  }
}

// In-memory instant sync cache
const memoryFastCache = new Map<string, any>();
const localSaveTimestamps = new Map<string, number>();

export function getLocalSaveTimestamp(key: string): number {
  if (localSaveTimestamps.has(key)) {
    return localSaveTimestamps.get(key)!;
  }
  if (typeof window !== 'undefined') {
    try {
      const raw = localStorage.getItem(`${key}_saved_ts`);
      if (raw) {
        const ts = parseInt(raw, 10);
        if (!isNaN(ts)) {
          localSaveTimestamps.set(key, ts);
          return ts;
        }
      }
    } catch {}
  }
  return 0;
}

export function isStorageInitialized(): boolean {
  return isStorageReady;
}

// Check if user has previously saved data on this device for the whole app or a specific key
export function hasUserSavedDataOnDevice(key?: string): boolean {
  if (typeof window === 'undefined') return false;
  try {
    if (localStorage.getItem('military_has_user_saved_data') === 'true') {
      return true;
    }
    if (key && localStorage.getItem(`military_has_user_saved_data_${key}`) === 'true') {
      return true;
    }
    if (memoryFastCache.has('military_has_user_saved_data') && memoryFastCache.get('military_has_user_saved_data') === true) {
      return true;
    }
  } catch {}
  return false;
}

// Mark that user has actively saved data in the application on this device
export function markUserHasSavedData(key?: string): void {
  if (typeof window === 'undefined') return;
  try {
    localStorage.setItem('military_has_user_saved_data', 'true');
    localStorage.setItem('military_device_initialized', 'true');
    if (key) {
      localStorage.setItem(`military_has_user_saved_data_${key}`, 'true');
    }
    memoryFastCache.set('military_has_user_saved_data', true);
    setIDBItem('military_has_user_saved_data', true).catch(() => {});
    if (key) {
      setIDBItem(`military_has_user_saved_data_${key}`, true).catch(() => {});
    }
  } catch {}
}

// Sanitize objects for LocalStorage to avoid quota exhaustion by storing large images/blobs in IndexedDB
function sanitizeForLocalStorage(value: any): any {
  if (!value) return value;
  if (typeof value === 'string') {
    // If single string is huge data URL, replace with marker
    if (value.startsWith('data:image') && value.length > 20000) {
      return 'data:image/svg+xml;utf8,<svg xmlns="http://www.w3.org/2000/svg" width="100" height="100"><rect fill="%231e293b" width="100" height="100"/></svg>';
    }
    return value;
  }
  if (Array.isArray(value)) {
    return value.map((item) => {
      if (item && typeof item === 'object') {
        // If personnel record with heavy photoUrl, sanitize for localStorage copy
        if ('photoUrl' in item && typeof item.photoUrl === 'string' && item.photoUrl.startsWith('data:image') && item.photoUrl.length > 20000) {
          return { ...item, photoUrl: '' };
        }
      }
      return item;
    });
  }
  return value;
}

// Write data safely to localStorage + IndexedDB backup with multi-layer persistence
export function safeSetLocalItem(key: string, value: any): void {
  if (typeof window === 'undefined') return;

  const now = Date.now();
  localSaveTimestamps.set(key, now);

  // 1. Keep fast in-memory cache with full fidelity (untruncated)
  memoryFastCache.set(key, value);

  // 2. Mark durable flags that user has valid data on device
  markUserHasSavedData(key);

  // 3. Asynchronous un-capped IndexedDB write (Supports Gigabytes of records)
  setIDBItem(key, value).catch((e) => {
    console.warn(`[SafeStorage] IndexedDB write error for ${key}:`, e);
  });

  // 4. Mark timestamp in localStorage
  try {
    localStorage.setItem(`${key}_saved_ts`, now.toString());
  } catch {}

  // 5. Sync to localStorage safely (with sanitized photoUrl fallback to avoid QuotaExceededError)
  try {
    const json = typeof value === 'string' ? value : JSON.stringify(value);
    localStorage.setItem(key, json);

    // Clean up any old chunk keys if standard set succeeds
    let chunkIdx = 0;
    while (localStorage.getItem(`${key}_chunk_${chunkIdx}`)) {
      localStorage.removeItem(`${key}_chunk_${chunkIdx}`);
      chunkIdx++;
    }
    localStorage.removeItem(`${key}_meta`);
  } catch (err: any) {
    // LocalStorage full / Quota reached: try sanitized compact version first
    try {
      const compactValue = sanitizeForLocalStorage(value);
      const compactJson = JSON.stringify(compactValue);
      localStorage.setItem(key, compactJson);
    } catch (eCompact) {
      // If even compact version fails, clear any old stale version from localStorage
      // so safeGetLocalItem will never read obsolete pre-replacement data!
      try {
        localStorage.removeItem(key);
        localStorage.setItem(`${key}_idb_pointer`, JSON.stringify({ isStoredInIndexedDB: true, ts: now }));
      } catch {}
      console.warn(`[SafeStorage] LocalStorage quota reached for ${key}. Stale localStorage copy removed; full data is preserved in IndexedDB & Memory.`);
    }
  }

  // Trigger debounced snapshot creation only for essential domain entities (Personnel, Vehicles, Armory, Payroll, Backups)
  if (
    key.includes('personnel') ||
    key.includes('vehicles') ||
    key.includes('armory') ||
    key.includes('payroll') ||
    key.includes('backup')
  ) {
    scheduleAutoSnapshotDebounced();
  }
}

// Read data safely from Memory Cache, Chunked LocalStorage, standard LocalStorage or IndexedDB
export function safeGetLocalItem<T>(key: string): T | null {
  if (typeof window === 'undefined') return null;

  // 1. Fast memory cache (always contains latest uncompressed, full-fidelity data)
  if (memoryFastCache.has(key)) {
    const cached = memoryFastCache.get(key);
    if (cached !== undefined && cached !== null) {
      return cached as T;
    }
  }

  try {
    // 2. Check standard localStorage
    const raw = localStorage.getItem(key);
    if (raw) {
      try {
        const parsed = JSON.parse(raw);
        memoryFastCache.set(key, parsed);
        return parsed as T;
      } catch {
        memoryFastCache.set(key, raw);
        return raw as unknown as T;
      }
    }

    // 3. Check if chunked in localStorage
    const metaRaw = localStorage.getItem(`${key}_meta`);
    if (metaRaw) {
      const meta = JSON.parse(metaRaw);
      if (meta && meta.chunked && meta.totalChunks > 0) {
        const combined: any[] = [];
        let anyChunkFound = false;
        for (let i = 0; i < meta.totalChunks; i++) {
          const chunkRaw = localStorage.getItem(`${key}_chunk_${i}`);
          if (chunkRaw) {
            try {
              combined.push(...JSON.parse(chunkRaw));
              anyChunkFound = true;
            } catch {}
          }
        }
        if (combined.length > 0 && anyChunkFound) {
          memoryFastCache.set(key, combined);
          return combined as unknown as T;
        }
      }
    }
  } catch (err) {
    console.error(`[SafeStorage] Error reading ${key} from LocalStorage:`, err);
  }

  // 4. Background hydrate from IndexedDB if not found in memory/localStorage
  getIDBItem<T>(key).then((idbVal) => {
    if (idbVal !== null && idbVal !== undefined) {
      memoryFastCache.set(key, idbVal);
      window.dispatchEvent(new Event('military_data_changed'));
    }
  }).catch(() => {});

  return null;
}

// Initialize and pre-hydrate ALL keys from IndexedDB into memoryFastCache on startup
export async function initSafeStorage(): Promise<boolean> {
  if (typeof window === 'undefined') return true;

  // Background full loader that never gives up even after startup race
  const doFullHydration = async () => {
    try {
      const allEntries = await getAllIDBEntries();
      const entryKeys = Object.keys(allEntries);

      if (entryKeys.length > 0) {
        entryKeys.forEach((k) => {
          memoryFastCache.set(k, allEntries[k]);
        });
        markUserHasSavedData();
        isStorageReady = true;
        (window as any).__militaryStorageReady = true;
        window.dispatchEvent(new Event('military_data_changed'));
      } else {
        // If records store has no keys, check snapshots store for emergency auto-hydration
        const snapshots = await getDeviceSnapshots();
        if (snapshots.length > 0 && snapshots[0].data) {
          const latestSnapData = snapshots[0].data;
          for (const [k, val] of Object.entries(latestSnapData)) {
            memoryFastCache.set(k, val);
            setIDBItem(k, val).catch(() => {});
          }
          markUserHasSavedData();
          isStorageReady = true;
          (window as any).__militaryStorageReady = true;
          window.dispatchEvent(new Event('military_data_changed'));
        }
      }

      // Check legacy v2 database if needed
      if (entryKeys.length === 0 && window.indexedDB) {
        try {
          const legacyReq = indexedDB.open('MilitaryHQSafeStorage_v2', 2);
          legacyReq.onsuccess = async () => {
            try {
              const legDb = legacyReq.result;
              if (legDb.objectStoreNames.contains('records')) {
                const tx = legDb.transaction('records', 'readonly');
                const store = tx.objectStore('records');
                const keysReq = store.getAllKeys();
                const valsReq = store.getAll();
                tx.oncomplete = () => {
                  const keys = keysReq.result || [];
                  const vals = valsReq.result || [];
                  for (let i = 0; i < keys.length; i++) {
                    const k = String(keys[i]);
                    memoryFastCache.set(k, vals[i]);
                    setIDBItem(k, vals[i]).catch(() => {});
                  }
                  if (keys.length > 0) {
                    markUserHasSavedData();
                    window.dispatchEvent(new Event('military_data_changed'));
                  }
                };
              }
            } catch {}
          };
        } catch {}
      }
    } catch (err) {
      console.warn('[SafeStorage] Background hydration error:', err);
    }
  };

  try {
    // 1. Request browser storage persistence immediately
    requestPersistentStorage().catch(() => {});

    // 2. Start full hydration immediately
    const hydrationPromise = doFullHydration();

    // Fast resolution to avoid delaying app UI render (> 150ms)
    await Promise.race([
      hydrationPromise,
      new Promise((resolve) => setTimeout(resolve, 120))
    ]);

    isStorageReady = true;
    (window as any).__militaryStorageReady = true;
    return true;
  } catch (e) {
    console.warn('[SafeStorage] Initialization error:', e);
    isStorageReady = true;
    return false;
  }
}

// Auto-trigger on file load
if (typeof window !== 'undefined') {
  initSafeStorage().catch(() => {});
}

export async function hydrateFromIndexedDB(keys: string[]): Promise<void> {
  if (typeof window === 'undefined') return;
  let hasLoadedAny = false;
  for (const key of keys) {
    try {
      const val = await getIDBItem(key);
      if (val !== null && val !== undefined) {
        if (!memoryFastCache.has(key)) {
          memoryFastCache.set(key, val);
          hasLoadedAny = true;
        }
      }
    } catch (e) {}
  }
  if (hasLoadedAny) {
    window.dispatchEvent(new Event('military_data_changed'));
  }
}

// =========================================================================
// AUTOMATIC ROLLING ON-DEVICE SYSTEM SNAPSHOTS ENGINE (Zero Data Loss Guard)
// =========================================================================

export interface DeviceSnapshotEntry {
  id: string;
  timestamp: string;
  countSummary: string;
  data: Record<string, any>;
}

let autoSnapshotTimeout: any = null;
let lastSnapshotCreatedAt = 0;
let hasPendingUnsavedSnapshots = false;

function scheduleAutoSnapshotDebounced() {
  if (typeof window === 'undefined') return;
  hasPendingUnsavedSnapshots = true;
  if (autoSnapshotTimeout) clearTimeout(autoSnapshotTimeout);
  autoSnapshotTimeout = setTimeout(() => {
    createDeviceSnapshot().catch(() => {});
  }, 5000);
}

export async function createDeviceSnapshot(force = false): Promise<string | null> {
  if (typeof window === 'undefined') return null;

  const now = Date.now();
  // Throttle snapshots: don't create more frequently than once every 10 seconds unless forced
  if (!force && !hasPendingUnsavedSnapshots && now - lastSnapshotCreatedAt < 10000) {
    return null;
  }

  try {
    const allEntries = await getAllIDBEntries();
    const entryKeys = Object.keys(allEntries);
    if (entryKeys.length === 0) return null;

    const timestamp = new Date().toISOString();
    const id = `snap-${now}`;
    hasPendingUnsavedSnapshots = false;
    lastSnapshotCreatedAt = now;

    // Extract stats
    const pCount = Array.isArray(allEntries['military_hr_personnel_v2']) ? allEntries['military_hr_personnel_v2'].length : 0;
    const vCount = Array.isArray(allEntries['military_vehicles_readiness_v1']) ? allEntries['military_vehicles_readiness_v1'].length : 0;
    const wCount = Array.isArray(allEntries['military_armory_weapons_v1']) ? allEntries['military_armory_weapons_v1'].length : 0;
    const payCount = Array.isArray(allEntries['military_payroll_records_v1']) ? allEntries['military_payroll_records_v1'].length : 0;

    const countSummary = `${pCount} فرد | ${vCount} آلية | ${wCount} قطعة سلاح | ${payCount} مسير`;

    const snapshot: DeviceSnapshotEntry = {
      id,
      timestamp,
      countSummary,
      data: allEntries
    };

    const db = await openIDB();
    return new Promise((resolve) => {
      const tx = db.transaction(SNAPSHOTS_STORE, 'readwrite');
      const store = tx.objectStore(SNAPSHOTS_STORE);
      store.put(snapshot, id);

      // Keep only last 3 rolling snapshots to save space and eliminate freeze
      const keysReq = store.getAllKeys();
      keysReq.onsuccess = () => {
        const keys = keysReq.result || [];
        if (keys.length > 3) {
          const keysToDelete = keys.slice(0, keys.length - 3);
          keysToDelete.forEach((k) => store.delete(k));
        }
      };

      tx.oncomplete = () => {
        try {
          localStorage.setItem('military_last_device_snapshot_ts', timestamp);
        } catch {}
        resolve(id);
      };
      tx.onerror = () => resolve(null);
    });
  } catch (err) {
    return null;
  }
}

export async function getDeviceSnapshots(): Promise<DeviceSnapshotEntry[]> {
  try {
    const db = await openIDB();
    return new Promise((resolve) => {
      const tx = db.transaction(SNAPSHOTS_STORE, 'readonly');
      const store = tx.objectStore(SNAPSHOTS_STORE);
      const req = store.getAll();
      req.onsuccess = () => {
        const list = req.result || [];
        // Sort newest first
        list.sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime());
        resolve(list);
      };
      req.onerror = () => resolve([]);
    });
  } catch (err) {
    return [];
  }
}

export async function restoreDeviceSnapshot(snapshotId: string): Promise<boolean> {
  try {
    const db = await openIDB();
    const snapshot: DeviceSnapshotEntry | null = await new Promise((resolve) => {
      const tx = db.transaction(SNAPSHOTS_STORE, 'readonly');
      const store = tx.objectStore(SNAPSHOTS_STORE);
      const req = store.get(snapshotId);
      req.onsuccess = () => resolve(req.result || null);
      req.onerror = () => resolve(null);
    });

    if (!snapshot || !snapshot.data) return false;

    const dataObj = snapshot.data;
    for (const [key, val] of Object.entries(dataObj)) {
      safeSetLocalItem(key, val);
    }

    if (typeof window !== 'undefined') {
      window.dispatchEvent(new Event('military_data_changed'));
    }
    return true;
  } catch (err) {
    return false;
  }
}

// Dedicated Engine to Clean & Purge Replaced / Obsolete Data to Eliminate Lag and Accelerate Navigation
export async function purgeObsoleteReplacedData(keepLatestPersonnelKey = 'military_hr_personnel_v2'): Promise<{
  purgedSnapshotsCount: number;
  purgedLocalStorageKeysCount: number;
  purgedIdbKeysCount: number;
  reclaimedEstimateKB: number;
}> {
  let purgedSnapshots = 0;
  let purgedStorageKeys = 0;
  let purgedIdbKeys = 0;
  let reclaimedBytes = 0;

  // 1. Clean old snapshots in SNAPSHOTS_STORE, keeping only the 1 highest-fidelity latest snapshot
  try {
    const db = await openIDB();
    const snapshots = await getDeviceSnapshots();
    if (snapshots.length > 1) {
      // Find the snapshot that contains the largest, most complete personnel list
      const sorted = snapshots.slice().sort((a, b) => {
        const countA = Array.isArray(a.data?.[keepLatestPersonnelKey]) ? a.data[keepLatestPersonnelKey].length : 0;
        const countB = Array.isArray(b.data?.[keepLatestPersonnelKey]) ? b.data[keepLatestPersonnelKey].length : 0;
        return countB - countA;
      });
      const keepId = sorted[0]?.id;

      await new Promise<void>((resolve) => {
        const tx = db.transaction(SNAPSHOTS_STORE, 'readwrite');
        const store = tx.objectStore(SNAPSHOTS_STORE);
        for (const snap of snapshots) {
          if (snap.id !== keepId) {
            reclaimedBytes += JSON.stringify(snap).length * 2;
            store.delete(snap.id);
            purgedSnapshots++;
          }
        }
        tx.oncomplete = () => resolve();
        tx.onerror = () => resolve();
      });
    }
  } catch (e) {
    console.warn('[SafeStorage] Snapshot purge error:', e);
  }

  // 2. Clean dead / replaced / fragmented keys in LocalStorage
  if (typeof window !== 'undefined') {
    const keysToRemove: string[] = [];
    for (let i = 0; i < localStorage.length; i++) {
      const k = localStorage.key(i);
      if (k) {
        if (
          k.includes('_chunk_') ||
          k.includes('_meta') ||
          k.includes('legacy') ||
          k.includes('temp_') ||
          k.includes('obsolete') ||
          k.includes('test_') ||
          (k.startsWith('military_') && (k.includes('_backup_old') || k.includes('_temp') || k.includes('_replaced')))
        ) {
          keysToRemove.push(k);
        }
      }
    }
    keysToRemove.forEach((k) => {
      try {
        const raw = localStorage.getItem(k);
        if (raw) {
          reclaimedBytes += raw.length * 2;
        }
        localStorage.removeItem(k);
        purgedStorageKeys++;
      } catch {}
    });
  }

  // 3. Delete legacy databases from browser
  if (typeof window !== 'undefined' && window.indexedDB && window.indexedDB.deleteDatabase) {
    try {
      window.indexedDB.deleteDatabase('MilitaryHQSafeStorage_v1');
      window.indexedDB.deleteDatabase('MilitaryHQSafeStorage_v2');
    } catch {}
  }

  return {
    purgedSnapshotsCount: purgedSnapshots,
    purgedLocalStorageKeysCount: purgedStorageKeys,
    purgedIdbKeysCount: purgedIdbKeys,
    reclaimedEstimateKB: Math.round(reclaimedBytes / 1024)
  };
}

// Storage Health Diagnostic Reporter
export async function getStorageHealth(): Promise<{
  persisted: boolean;
  quotaGB: number;
  usedMB: number;
  totalRecordsInIDB: number;
  lastSavedAt: string;
  hasSnapshots: number;
}> {
  const p = await requestPersistentStorage();
  let totalEntries = 0;
  try {
    const entries = await getAllIDBEntries();
    totalEntries = Object.keys(entries).length;
  } catch {}

  const snaps = await getDeviceSnapshots();
  let lastSavedAt = 'غير محدد';
  if (typeof window !== 'undefined') {
    lastSavedAt = localStorage.getItem('military_last_device_snapshot_ts') || new Date().toISOString();
  }

  return {
    persisted: p.persisted,
    quotaGB: p.quotaGB,
    usedMB: p.usedMB,
    totalRecordsInIDB: totalEntries,
    lastSavedAt,
    hasSnapshots: snaps.length
  };
}

export function getMemoryCachedItem<T>(key: string): T | null {
  if (memoryFastCache.has(key)) {
    return memoryFastCache.get(key) as T;
  }
  return null;
}

export function getAllMemoryCachedEntries(): Record<string, any> {
  const obj: Record<string, any> = {};
  for (const [k, v] of memoryFastCache.entries()) {
    obj[k] = v;
  }
  return obj;
}

// Lifecycle listeners: Flush and persist on tab close, page refresh, or PWA app update
if (typeof window !== 'undefined') {
  window.addEventListener('beforeunload', () => {
    try {
      createDeviceSnapshot().catch(() => {});
    } catch {}
  });

  window.addEventListener('pagehide', () => {
    try {
      createDeviceSnapshot().catch(() => {});
    } catch {}
  });

  document.addEventListener('visibilitychange', () => {
    if (document.visibilityState === 'hidden') {
      try {
        createDeviceSnapshot().catch(() => {});
      } catch {}
    }
  });
}
